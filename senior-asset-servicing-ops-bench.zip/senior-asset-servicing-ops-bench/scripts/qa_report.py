#!/usr/bin/env python3
"""Stage 4/6: difficulty calibration and lifecycle update from live agent trials.

Reads results/<run>/<agent>/<task>/result.json, classifies each task and writes:
  * leaderboard/results/_qa_<run>.json  (per-task calibration + triage)
  * task.yaml -> qa: {lifecycle, last_trial_run, frontier_basic_solves, ...}

Lifecycle (adapted from Terminal-Bench 4 continuous QA):
  draft -> static_ok -> oracle_ok -> trialed -> {saturated | discriminating | unsolved}
        -> hardened -> expert_validated -> released
  saturated     : every frontier agent solved it (Basic Solve) -> goes back for a hardening round
  discriminating: some but not all frontier agents solved it -> keep
  unsolved      : no agent solved it -> solvability review (task defect vs genuine difficulty)
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "harness"))
from sabench.tasks import discover  # noqa: E402

TRIAGE_FILE = "triage.yaml"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("run", help="results/<run> directory name")
    ap.add_argument("--frontier", default="sonnet,opus,fable")
    ap.add_argument("--ablation", default="opus-noinputs")
    ap.add_argument("--write-tasks", action="store_true")
    a = ap.parse_args()
    base = ROOT / "results" / a.run
    frontier = a.frontier.split(",")
    res = defaultdict(dict)
    for p in base.glob("*/*/result.json"):
        r = json.loads(p.read_text())
        res[r["task_id"]][r["agent"]] = r
    triage = yaml.safe_load((base / TRIAGE_FILE).read_text()) if (base / TRIAGE_FILE).exists() else {}
    rows = []
    for t in discover("public"):
        rr = res.get(t.id, {})
        fs = [ag for ag in frontier if rr.get(ag, {}).get("basic_solve")]
        n = sum(1 for ag in frontier if ag in rr)
        state = "saturated" if len(fs) == n and n else "unsolved" if not any(
            x.get("basic_solve") for k, x in rr.items() if k != a.ablation) else "discriminating"
        abl = rr.get(a.ablation)
        leak = bool(abl and abl.get("basic_solve"))
        row = {
            "task_id": t.id, "domain": t.domain, "lifecycle": "leaking" if leak else state,
            "frontier_basic_solves": f"{len(fs)}/{n}",
            "agents": {ag: {"basic": x.get("basic_solve"), "g2": x["gates"].get("G2"),
                            "g1_score": x["verifier"]["gate1_correctness_score"],
                            "failed_critical": [c["id"] for c in x["verifier"]["checks"]
                                                if c["critical"] and not c["passed"]]}
                       for ag, x in sorted(rr.items())},
            "no_inputs_g1_score": abl["verifier"]["gate1_correctness_score"] if abl else None,
            "triage": triage.get(t.id, []),
        }
        rows.append(row)
        if a.write_tasks:
            ty = t.dir / "task.yaml"
            txt = ty.read_text()
            qa = {"qa": {"lifecycle": row["lifecycle"], "last_trial_run": a.run,
                         "frontier_basic_solves": row["frontier_basic_solves"],
                         "no_inputs_g1_score": row["no_inputs_g1_score"]}}
            txt = re.sub(r"\nqa:\n(?:  .*\n?)*", "\n", txt).rstrip() + "\n" + yaml.safe_dump(qa, sort_keys=False)
            ty.write_text(txt)
    out = ROOT / f"leaderboard/results/_qa_{a.run}.json"
    counts = defaultdict(int)
    for r in rows:
        counts[r["lifecycle"]] += 1
    out.write_text(json.dumps({"run": a.run, "frontier": frontier, "lifecycle_counts": dict(counts),
                               "tasks": rows}, indent=1))
    print(dict(counts), "->", out.relative_to(ROOT))
    return 0


if __name__ == "__main__":
    sys.exit(main())
