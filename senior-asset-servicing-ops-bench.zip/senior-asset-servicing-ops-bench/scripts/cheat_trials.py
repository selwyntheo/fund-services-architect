#!/usr/bin/env python3
"""Stage 5 (programmatic): adversarial cheat baselines.

Terminal-Bench 4's continuous QA runs explicit exploit attempts before release. SASOB cannot be gamed by
reading tests (the verifier never enters the sandbox), so the remaining attack surface is the answer
contract itself: enums, schema defaults and action lists. Each strategy below uses ONLY what the agent can
see (answer_schema.json, prompt.md) and never the inputs or the solution. A task is flagged if any strategy
passes Gate 1, or if the control gate can be satisfied by spamming actions.

  noop          : {}
  skeleton      : required keys with empty values
  enum_first    : every enum set to its first option; numbers 0
  enum_random   : 400 seeded random fills per task (max over samples reported)
  action_spam   : oracle-free: every action type x every enumerated target (tests Gate 2 anti-spam)
  prompt_numbers: numbers quoted in the prompt pasted into every numeric figure

Writes leaderboard/results/_cheat_trials.json.
"""
from __future__ import annotations

import json
import random
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "harness"))
from sabench.tasks import discover  # noqa: E402
from sabench.verifier import verify  # noqa: E402

ACTION_TYPES = ["escalate", "hold", "release", "post_entry", "reverse_entry", "submit_instruction", "reprocess",
                "reimburse", "request_info", "notify", "no_action"]


def fill(schema: dict, mode: str, rng: random.Random, nums: list[float], depth: int = 0):
    if "const" in schema:
        return schema["const"]
    if "enum" in schema:
        e = schema["enum"]
        return e[0] if mode == "enum_first" else rng.choice(e)
    t = schema.get("type")
    t = t[0] if isinstance(t, list) else t
    if t == "object" or "properties" in schema:
        props = schema.get("properties", {})
        return {k: fill(v, mode, rng, nums, depth + 1) for k, v in props.items()}
    if t == "array":
        items = schema.get("items", {})
        if "enum" in items:  # list of categorical values: random subset
            e = items["enum"]
            return e[:1] if mode == "enum_first" else rng.sample(e, rng.randint(0, len(e)))
        n = 1 if mode == "enum_first" else rng.randint(1, 8)
        if items.get("type") == "object" or "properties" in items:
            # one object per enum value of any enum-typed key (maximises selector hits)
            keys = [k for k, v in items.get("properties", {}).items() if "enum" in v]
            if keys and mode != "enum_first":
                k = rng.choice(keys)
                out = []
                for val in items["properties"][k]["enum"]:
                    o = fill(items, mode, rng, nums, depth + 1)
                    o[k] = val
                    out.append(o)
                return out
        return [fill(items, mode, rng, nums, depth + 1) for _ in range(n)]
    if t in ("number", "integer"):
        if mode == "prompt_numbers" and nums:
            return rng.choice(nums)
        return 0 if mode == "enum_first" else rng.choice([0, 1, -1, 100, 0.5])
    if t == "boolean":
        return False if mode == "enum_first" else rng.random() < 0.5
    return "x"


def action_spam(schema: dict) -> list[dict]:
    try:
        targets = schema["properties"]["actions"]["items"]["properties"]["target"].get("enum") or ["x"]
    except KeyError:
        targets = ["x"]
    return [{"type": a, "target": t, "detail": "spam"} for a in ACTION_TYPES for t in targets]


def main() -> int:
    rows, flagged = [], 0
    for t in discover("public"):
        schema = json.loads((t.dir / "answer_schema.json").read_text())
        prompt = (t.dir / "prompt.md").read_text()
        nums = [float(x.replace(",", "")) for x in re.findall(r"(?<![\w.])\d[\d,]*\.?\d*", prompt) if x.strip(",")]
        rng = random.Random(t.id)
        res = {}

        def g(ans):
            v = verify(t.dir, ans)
            return v.gate_pass("correctness") and v.schema_valid, v.gate_score("correctness"), v.gate_pass("control")

        res["noop"] = g({})
        res["skeleton"] = g({k: ([] if k in ("findings", "actions", "open_questions") else {} if k == "figures" else "")
                             for k in schema.get("required", [])})
        res["enum_first"] = g(fill(schema, "enum_first", rng, nums))
        best = (False, 0.0, False)
        for _ in range(400):
            r = g(fill(schema, "enum_random", rng, nums))
            best = max(best, r, key=lambda x: (x[0], x[1]))
        res["enum_random_best_of_400"] = best
        pn = fill(schema, "prompt_numbers", rng, nums)
        res["prompt_numbers"] = g(pn)
        spam = fill(schema, "enum_first", rng, nums)
        spam["actions"] = action_spam(schema)
        v = verify(t.dir, spam)
        res["action_spam_control_pass"] = v.gate_pass("control")
        g1_broken = any(x[0] for k, x in res.items() if isinstance(x, tuple))
        g2_broken = res["action_spam_control_pass"]
        flagged += g1_broken or g2_broken
        rows.append({"task_id": t.id, "g1_gameable": g1_broken, "g2_spam_passes": g2_broken,
                     "max_partial_g1_score": round(max(x[1] for x in res.values() if isinstance(x, tuple)), 3),
                     "strategies": {k: ({"g1_pass": x[0], "g1_score": round(x[1], 3), "g2_pass": x[2]}
                                        if isinstance(x, tuple) else x) for k, x in res.items()}})
        print(f"{'FLAG' if g1_broken or g2_broken else 'ok  '} {t.id}  max G1 partial={rows[-1]['max_partial_g1_score']}"
              f"  spam-controls-pass={g2_broken}")
    out = ROOT / "leaderboard/results/_cheat_trials.json"
    out.write_text(json.dumps({"n_tasks": len(rows), "n_flagged": flagged, "tasks": rows}, indent=1))
    print(f"{flagged} flagged -> {out.relative_to(ROOT)}")
    return 1 if flagged else 0


if __name__ == "__main__":
    sys.exit(main())
