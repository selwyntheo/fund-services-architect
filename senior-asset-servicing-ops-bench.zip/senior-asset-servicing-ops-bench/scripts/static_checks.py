#!/usr/bin/env python3
"""Stage 1: static leak and hygiene checks (complements validate_tasks.py).

ERROR (fails CI)
  E1 absolute paths or host-specific paths in prompt/hints/schema/inputs
  E2 an expected value of a CRITICAL numeric check appears verbatim in prompt.md, hints.md or answer_schema.json
  E3 prompt.md names an input file (method leakage: the agent must discover the evidence)
  E4 hints.md text copied into prompt.md
  E5 solution/, verifier/, rubric or task.yaml content referenced from inputs (e.g. 'checks.yaml', 'oracle')
WARN (reported, reviewed by a human)
  W1 an expected critical value appears verbatim in inputs (may be legitimate, e.g. a stated total)
  W2 a critical categorical expected value is the FIRST option of its enum (position bias)
  W3 prompt shorter than 80 words or longer than 250 words
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "harness"))
from sabench.tasks import discover  # noqa: E402

ABS = re.compile(r"(/home/|/Users/|/root/|/tmp/|[A-Z]:\\\\)")


def fmt_variants(x: float) -> set[str]:
    out = {f"{x:.2f}", f"{x:,.2f}"}
    if abs(x) >= 1000 and float(x).is_integer():
        out |= {f"{int(x):,}", str(int(x))}
    if abs(x) < 10 and not float(x).is_integer():
        out |= {f"{x:.4f}"}
    return {s.lstrip("-") for s in out if len(s.replace(",", "").replace(".", "").lstrip("-0")) >= 4}


def enum_for(schema: dict, path: str):
    """Best-effort: find the enum list for the leaf field of a checks path."""
    leaf = re.split(r"[.\]]", path.replace("[", "."))[-1] or path.split(".")[-1]
    found = []

    def walk(s):
        if isinstance(s, dict):
            for k, v in (s.get("properties") or {}).items():
                if k == leaf and isinstance(v, dict) and "enum" in v:
                    found.append(v["enum"])
            for v in s.values():
                walk(v)
        elif isinstance(s, list):
            for v in s:
                walk(v)
    walk(schema)
    return found[0] if len(found) == 1 else None


def check(task):
    errs, warns = [], []
    d = task.dir
    prompt = (d / "prompt.md").read_text()
    hints = (d / "hints.md").read_text()
    schema_txt = (d / "answer_schema.json").read_text()
    schema = json.loads(schema_txt)
    inputs = {p.relative_to(d / "workspace/inputs"): p for p in (d / "workspace/inputs").rglob("*") if p.is_file()}
    input_txt = {}
    for rel, p in inputs.items():
        try:
            input_txt[rel] = p.read_text()
        except UnicodeDecodeError:
            pass
    for name, txt in [("prompt.md", prompt), ("hints.md", hints), ("answer_schema.json", schema_txt), *[(str(k), v) for k, v in input_txt.items()]]:
        if ABS.search(txt):
            errs.append(f"E1 absolute path in {name}: {ABS.search(txt).group(0)}")
        if name not in ("prompt.md", "hints.md") and re.search(r"checks\.yaml|rubric\.yaml|solve\.py|\boracle\b", txt):
            errs.append(f"E5 grader artefact referenced in {name}")
    for rel in inputs:
        if rel.name in prompt:
            errs.append(f"E3 prompt names input file {rel.name}")
    for line in (l.strip("-* ").strip() for l in hints.splitlines()):
        if len(line) > 40 and line in prompt:
            errs.append("E4 hint copied into prompt")
    checks = yaml.safe_load((d / "verifier/checks.yaml").read_text())["checks"]
    for c in checks:
        if not c.get("critical"):
            continue
        if c["type"] == "number" and isinstance(c.get("expected"), (int, float)) and c["expected"] not in (0, 1):
            for v in fmt_variants(float(c["expected"])):
                for name, txt in [("prompt.md", prompt), ("hints.md", hints), ("answer_schema.json", schema_txt)]:
                    if re.search(rf"(?<![\d.,]){re.escape(v)}(?![\d])", txt):
                        errs.append(f"E2 expected value {v} of critical check {c['id']} appears in {name}")
                for rel, txt in input_txt.items():
                    if re.search(rf"(?<![\d.,]){re.escape(v)}(?![\d])", txt):
                        warns.append(f"W1 expected value {v} ({c['id']}) appears in input {rel}")
                        break
        if c["type"] == "equals" and isinstance(c.get("expected"), str):
            e = enum_for(schema, c["path"])
            if e and e[0] == c["expected"]:
                warns.append(f"W2 critical expected '{c['expected']}' ({c['id']}) is first enum option")
    words = len(re.sub(r"<!--.*?-->", "", prompt, flags=re.S).split())
    if words < 80 or words > 250:
        warns.append(f"W3 prompt length {words} words")
    return errs, sorted(set(warns))


def main() -> int:
    n_err = 0
    report = {}
    for t in discover("public"):
        e, w = check(t)
        report[t.id] = {"errors": e, "warnings": w}
        n_err += bool(e)
        print(f"{'FAIL' if e else 'ok  '} {t.id}  ({len(w)} warnings)")
        for x in e:
            print("     ", x)
    (ROOT / "leaderboard/results/_static_checks.json").write_text(json.dumps(report, indent=1))
    print(f"{n_err} tasks with errors")
    return 1 if n_err else 0


if __name__ == "__main__":
    sys.exit(main())
