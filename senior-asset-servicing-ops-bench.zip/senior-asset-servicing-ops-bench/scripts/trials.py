#!/usr/bin/env python3
"""Stage 4: live agent trials for agents that cannot be driven by `sabench run` (e.g. hosted agents,
IDE agents, subagents). Two steps:

  python scripts/trials.py prepare --out TRIALS --agents a,b --attempts 1 [--ablation no_inputs]
      -> TRIALS/<agent>/<task>/attempt_<i>/{prompt.txt, work/{inputs/, answer_schema.json, out/}}
         Nothing from solution/, verifier/, rubric.yaml or task.yaml is copied.
  (run each agent in its work/ directory with prompt.txt)
  python scripts/trials.py grade --out TRIALS [--stats stats.json]
      -> result.json per attempt (same format as sabench run) and TRIALS/summary.json

`--ablation no_inputs` empties inputs/ (Terminal-Bench-style leakage probe: a task whose Gate 1 can be
passed without the evidence is leaking through its prompt or schema).
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "harness"))
from sabench.report import load_results, summarize  # noqa: E402
from sabench.runner import grade  # noqa: E402
from sabench.tasks import discover, get, tree_sha256  # noqa: E402


def prepare(a):
    out = Path(a.out)
    tasks = [t for t in discover("public") if not a.tasks or t.id in a.tasks.split(",")]
    for ag in a.agents.split(","):
        for t in tasks:
            for i in range(a.attempts):
                d = out / ag / t.id / f"attempt_{i}"
                if d.exists():
                    shutil.rmtree(d)
                w = d / "work"
                (w / "out").mkdir(parents=True)
                if a.ablation == "no_inputs":
                    (w / "inputs").mkdir()
                else:
                    shutil.copytree(t.inputs_dir, w / "inputs")
                shutil.copy(t.dir / "answer_schema.json", w / "answer_schema.json")
                (d / "prompt.txt").write_text(t.prompt(guided=a.guided))
                (d / "meta.json").write_text(json.dumps({
                    "task_id": t.id, "domain": t.domain, "agent": ag, "attempt": i, "guided": a.guided,
                    "ablation": a.ablation, "inputs_sha256": tree_sha256(w / "inputs"),
                    "task_version": t.meta.get("version")}))
    print(f"prepared {len(tasks)} tasks x {len(a.agents.split(','))} agents x {a.attempts} in {out}")


def grade_all(a):
    out = Path(a.out)
    stats = json.loads(Path(a.stats).read_text()) if a.stats else {}
    for m in sorted(out.rglob("meta.json")):
        meta = json.loads(m.read_text())
        t = get(meta["task_id"])
        w = m.parent / "work"
        res = grade(t, w, meta["inputs_sha256"], None)
        key = f"{meta['agent']}/{meta['task_id']}/{meta['attempt']}"
        res.update({"task_id": t.id, "domain": t.domain, "attempt": meta["attempt"], "guided": meta["guided"],
                    "agent": meta["agent"], "ablation": meta["ablation"], "task_version": meta["task_version"],
                    "agent_stats": stats.get(key, {}),
                    "wall_clock_s": (stats.get(key, {}).get("duration_ms") or 0) / 1000})
        (m.parent / "result.json").write_text(json.dumps(res, indent=2, default=str))
    summ = {ag.name: summarize(load_results(ag), meta={"name": ag.name})
            for ag in sorted(p for p in out.iterdir() if p.is_dir())}
    (out / "summary.json").write_text(json.dumps(summ, indent=2))
    for k, v in summ.items():
        print(f"{k:22} basic@1={v['basic_pass@1']}  gates={v['gate_pass_rates']}")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--out", required=True); p.add_argument("--agents", required=True)
    p.add_argument("--attempts", type=int, default=1); p.add_argument("--tasks")
    p.add_argument("--guided", action="store_true"); p.add_argument("--ablation", default=None)
    p = sub.add_parser("grade"); p.add_argument("--out", required=True); p.add_argument("--stats")
    a = ap.parse_args()
    prepare(a) if a.cmd == "prepare" else grade_all(a)


if __name__ == "__main__":
    main()
