# TSIF accrued interest vs Northgate, NAV 17 Sep 2026

**To:** Delphine Okoro, Income & Accruals Team Lead
**Re:** USD 62.99 break, GL 1300 vs Northgate accrued income report

## Bottom line
Please don't sign the de minimis write-off yet. The folder I was given (`inputs/`) is **empty**. It has no GL 1300 detail, no Northgate report, and none of the terms, notices or reference data. So I can't explain the break position by position. The only figure I have is the **USD 62.99 net break** (Fund minus Northgate) in your email.

A net break that small tells us nothing about the size of the errors underneath. Two or three wrong accruals of several thousand dollars each can offset to about $63. You mentioned Reference Data had feed problems. That is exactly where the errors would come from: a stale FRN reset, a wrong inflation index ratio, a day-count or coupon field, or a position that should be on non-accrual.

## What I could and could not determine
| Item | Status |
|---|---|
| Net break (GL 1300 minus Northgate) | USD 62.99, as stated in your email and not re-performed |
| Position-level differences and who is wrong | Not determinable: no data |
| Correct GL 1300 total / entry to book | Not determinable |
| Corbin FRN current coupon, TIPS index ratio | Not determinable: no notices or reference data |
| NAV impact per share, 17 Sep and earlier NAVs | Not determinable: no shares outstanding, NAV or error policy |

In `answer.json`, every figure except the break is a placeholder of 0. None of them is a conclusion.

## Recommended treatment
- **No write-off** under de minimis, and **no true-up to Northgate**. We shouldn't assume the custodian is right. We should recompute each accrual from the terms and notices.
- **Hold** any decision on NAV restatement or reprocessing until we have quantified the per-security errors and their per-share impact, and measured them against the fund's NAV error policy. That includes how long each error has been running.

## Who to chase
1. **You / the team:** please re-send the folder. I need:
   - GL 1300 detail, accrued plus past-due, as of 17 Sep
   - Northgate's accrued income and income claims report
   - Security terms
   - FRN reset and calculation-agent notices
   - Index ratio and CPI data
   - Any default or non-accrual notices
   - Shares outstanding and reported NAVs
   - The NAV error policy
2. **Reference Data (security master):** which TSIF securities and dates were affected by the summer feed problems.
3. **Northgate:** the rates, index ratios, day counts and accrual start dates behind their position-level figures.

Once I have the files I can re-perform the rec, identify the correct amount for each security, and work out the entry and the NAV impact.

## Assumptions
- I took the USD 62.99 figure from the email as given.
- I assumed the fund's documented policy does not allow an unexplained break to be written off.
