**To:** Mara Lindqvist, Treasurer & PFO, Corvane Investment Trust
**Re:** Mid Cap Opportunities, OSMD stale price: view before the 2pm with Stellmark
**Date:** 18 Sep 2026

## Bottom line
Don't sign Stellmark's proposal today. The pack I received (`inputs/`) is **empty**. It has no NAV history, OSMD prices, TA activity, exception log, Rafael's note, policy excerpt or agreement excerpt. So I can't independently tell you which days to correct, what the error cost the Fund, which shareholders are owed and how much, or who pays. I have not made up any figures. Every number in `answer.json` is a zero placeholder, not a conclusion.

## What to say at 2pm
1. The Fund will approve the correction only after re-performing Stellmark's calculation from source data against our NAV error correction policy. Until then, the Corrections Desk should not reprocess, credit or pay anything.
2. Ask Stellmark for the following items, which the re-performance needs:
   - Daily NAV history for the stale period: published NAV, net assets and shares outstanding.
   - OSMD quantity held, the stale price carried each day, the correct price each day and the source of the correct price.
   - The pricing exception log: when the stale price was flagged, and who cleared or overrode it.
   - Rafael's proposal with its workings.
   - TA activity for each affected trade date, by account, with direct/omnibus flag.
3. Responsibility: I have named Stellmark (administrator) provisionally, because the stale price was carried in its NAV process. That depends on the agreement's standard of care and on what the exception log shows. The pricing vendor or the Valuation Designee could share responsibility.

## How I will do it once the data is in
- **Corrected NAV per day:** published NAV − (stale price − correct price) × OSMD quantity ÷ shares outstanding. Round to $0.01.
- **Error %:** (published − corrected) ÷ corrected × 100.
- **Material days:** apply the policy threshold to each day and cumulatively. Only material days are reprocessed, unless the policy says otherwise.
- **Direction of harm on material days:**
  - Overstated NAV: redeemers were overpaid, which is a Fund loss to be reimbursed. Subscribers got too few shares, so shares are credited to them.
  - Understated NAV: the reverse.
- **No netting:** gains on one day are not netted against losses on another unless the policy allows it.
- **De minimis:** apply the policy's de minimis to account adjustments.
- **Who pays:** the responsible party reimburses the Fund and the shareholders, so the Fund should bear $0 if Stellmark is liable.

## What you owe the CCO and the Board
- **CCO:** notify now, under the NAV error and pricing policies. The CCO should review the methodology and whether the failed pricing control needs remediation under Rule 38a-1 and reporting under the Rule 2a-5 fair-value program.
- **Board:** report through the Valuation Designee/Treasurer. Cover the affected dates, materiality, cost, reimbursement and control fixes, either promptly (if a material error) or at the next meeting, as the policy requires.

## Where I would differ from Rafael
I can't compare because his note wasn't in the pack. The usual points to test in an administrator's proposal:
- Selective day thresholds.
- Netting across days.
- Waivers for omnibus/intermediary accounts.
- Caps on liability.
- Treating the Fund's own gain as an offset to what the administrator owes.

## Open items (from whom)
- **Stellmark:** everything listed under point 2 above.
- **Adviser/Valuation Designee:** the correct OSMD valuation for each day, and whether OSMD should have been fair valued.
- **Trust legal/CCO:** the NAV error policy and the Stellmark agreement's liability clauses.
