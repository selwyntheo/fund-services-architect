# BMAI: December 2026 excise distribution estimate (status: blocked on missing inputs)

**To:** Owen Latimer, Assistant Treasurer, Brightwater Series Trust
**From:** Oakhurst Fund Administration, Fund Tax
**Re:** Your note of Fri 13 Nov 2026

## Bottom line
I can't give you a number yet. The folder I got (`inputs/`) is empty. None of the documents you listed were in it:
- tax-basis monthly results
- the desk's Nov–Dec forecast
- the distribution register
- the 2025 excise workpaper
- Harwick's share projection
- the annual report tax note
- Trust policy
- Marcus's views

I won't make up figures for a number the Board will declare. Every figure in `answer.json` is a **0 placeholder, not an estimate**. I recommend we don't pre-clear a rate with Elaine on Monday until I've built it from the source files.

## How I will build it once the files arrive
1. **Ordinary income for the 2026 calendar year.** Tax-basis net investment income for Jan–Oct actuals, plus the desk's Nov–Dec forecast, plus ordinary-income book-tax adjustments from the tax note. The requirement is 98% of this.
2. **Capital gain net income for the year from 1 Nov 2025 to 31 Oct 2026.** No reduction for capital loss carryforwards under §4982, apart from any items Trust policy and the regulations allow. The requirement is 98.2% of this.
3. **2025 shortfall.** From the 2025 excise workpaper, add any 2025 amount not distributed (or subtract any overdistribution that can be carried forward) under §4982(b)(2)–(4).
4. **Distributed amount before December.** From the register: Jan–Nov 2026 dividends, including November declared but unpaid, plus any spillback dividends that count toward 2026.
5. **Minimum December distribution** = required distribution less the distributed amount. Divide by Harwick's projected all-class shares at the 16 Dec record date, then round **up** to 4 decimal places, adding any cushion Trust policy requires.
6. **Regular-rate scenario.** If December pays only the regular $0.0280: shortfall = required distribution less (distributed amount + $0.0280 × record-date shares). Excise tax = 4% of the shortfall, which also carries into the 2027 requirement.

## On Marcus's views
I haven't seen his email, so I can't answer his points one by one. I'll push back on any position that lowers the requirement without documented support. For example:
- leaving out the 2025 shortfall
- using a basis for the Nov–Dec forecast that isn't supported
- netting carryforwards against CGNI
- rounding the rate down

## What I need, and from whom
- **Owen / Trust (requester):** all of the folder documents listed above, plus Marcus's email.
- **Harwick (transfer agent):** projected all-class shares at 16 Dec, with its flow assumptions.
- **Oakhurst Tax Director:** review of the finished calculation before 19 Nov.
