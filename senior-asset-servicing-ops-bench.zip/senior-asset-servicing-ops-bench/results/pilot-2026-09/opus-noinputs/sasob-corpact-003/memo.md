# Fenwick claims list: Bracken & Van Oosterlo

**To:** Keisha Osei, Income & Claims Supervisor
**Re:** Tomas Albright's (Fenwick) claims list: Bracken Foods and Van Oosterlo
**Date:** 19 Sep 2026

## 1. What I could and could not do
The working folder `inputs/` is **empty**. These documents are missing:
- Tomas Albright's note
- the Fenwick trade/settlement status extract
- the Bracken Foods and Van Oosterlo dividend notices
- the CSD market-claims report
- any claims or tax policy

Without them I can't confirm, for any trade:
- whether it settled before or after record date
- the account (own or lending)
- the rate
- the withholding
- whether the CSD has already generated a claim

The only data I have is the list of 13 trade references in the answer template:
- **6 Bracken-series trades:** EQ-S-260908-5490, EQ-B-260909-5501/5502/5504, EQ-S-260909-5503, EQ-B-260910-5511
- **6 Van Oosterlo-series trades:** EQ-S-260904-7088, EQ-B-260907-7101/7102/7103, EQ-B-260908-7110, EQ-S-260908-7111
- **1 older trade:** EQ-B-260511-6620 (traded May, likely outside any claim period)

The split between the two names is my assumption from the ref numbering. The source extract doesn't confirm it.

I have not made up amounts. So `answer.json` has no per-trade findings, and every ledger figure is 0.

## 2. Ledger (month-end pack)
- **Nothing booked today** to 4410-3104 (USD claims) or 4410-3107 (EUR claims). Booking now would mean posting unsupported figures.
- Please flag the month-end pack: the claims accrual is **outstanding**, pending the documents.

## 3. What to say to Tomas
1. **"Pay the Bracken money now": no.** A market claim is compensation we collect from the failing counterparty. We credit Fenwick once the claim is agreed and the money comes in, not because the client asks. Nothing in the file shows Fenwick has contractual (advance) crediting of claims. Even if it did, we would need the notice terms and the settlement status first. I've put the payment on **hold**.
2. **Only trades that give rise to a claim will be claimed.** A trade that settled on or before record date, or was traded on or after ex-date, gives no claim, whatever the list says.
3. **Some claims may run against Fenwick.** Sales that failed over record date create claims *payable* by Fenwick. These will be accrued and paid when the counterparty presents them.
4. **Van Oosterlo (NL):** the CSD detects and generates claims automatically during the detection period. Any it has already generated will be monitored, not raised a second time. Claims it misses must be raised manually before the detection period ends. I can't work out that end date without the record date.
5. **EQ-B-260511-6620 (May):** likely outside the claims time limit. If so, we escalate it rather than raise it, and we don't book a receivable.

## 4. What I need, and from whom
| From | Item |
|---|---|
| Keisha / Fenwick (Tomas Albright) | His note and the claims list itself |
| Settlement ops | Status extract for the 13 trades (settlement dates, fails, accounts) |
| Corporate actions / Vandermeer (sub-custodian) | Bracken and Van Oosterlo notices: ex, record and pay dates, rates; claim-detection end date |
| CSD claims report | Claims already auto-generated on Van Oosterlo |
| Tax services | Withholding treatment of claim compensation (US and NL) |
| Relationship manager | Whether Fenwick's agreement gives contractual or actual crediting of claims |

Once I have these, I'll produce the per-trade claim schedule (type, direction, quantity, amount, route) and the 4410-3104 and 4410-3107 postings.
