# GAOF II second closing (30 Sep 2026): equalization

**To:** Priya Sethi  **Re:** Tom Brandt's request for the equalization figures

## Bottom line
I can't produce the equalization numbers yet. The working folder (`inputs/`) that should hold the Fund II documents is empty. I didn't receive:
- the Fund II LPA or side letters
- the partner register or capital activity as of last night
- the second-close list or subscription status
- Tom's Fund I methodology

I haven't estimated any figure or carried anything over from Fund I, so every amount in `answer.json` is a placeholder of 0 and the partner tables are empty. Nothing should go out in the funds-flow memo or the closing notices until the calculation is re-performed from the source documents.

## What I need, and from whom
| From | Item |
|---|---|
| You / Halcyon records | The executed Fund II LPA. I need these sections: subsequent closings, equalization, Additional Amount (rate, base, period), Management Fee, and the definitions of Capital Contribution and Unfunded Commitment. Also any side letters. |
| You / Halcyon records | The partner register (commitments incl. GP-0200) and capital activity as of 17 Sep 2026, with contributions split between fees and other purposes. Also any distributions. |
| Tom Brandt (GP) | The second-close list and commitments for each LP, with GP acceptance and KYC/AML status. |
| Tom Brandt (GP) | The Fund I methodology he wants us to follow. |

## How I will calculate it once the documents arrive (subject to the Fund II LPA)
1. **Closing population.** Admit only LPs whose subscription the GP has accepted and whose KYC/AML is cleared. Defer any others and flag duplicates or partners already on the register.
2. **Funded percentage.** Aggregate non-fee contributions before the closing ÷ total commitments after the closing.
3. **Equalization contribution.** Each incoming LP pays its commitment × the funded percentage. Existing Partners get back the excess over their own commitment × the funded percentage, and whether that return is recallable follows the LPA.
4. **Management fee catch-up.** Calculated on the LPA fee basis from the fee start date and paid to the Manager, not to the Existing Partners.
5. **Additional Amount.** The base, rate, day-count and recipient come from the Fund II LPA. The recipient could be the Existing Partners or the Partnership. I'll also check the LPA for whether the Additional Amount counts as a Capital Contribution. I'll flag every place where this differs from Fund I.
6. **Commitment percentages and unfunded commitments.** Recalculated after the closing for every Partner, including the GP.

## Actions
- Hold the closing notices and wire instructions to incoming LPs, and the distribution notices to Existing Partners, until the figures are computed and reviewed.
- Tell Tom that the Tuesday deadline depends on getting the documents by Monday.
