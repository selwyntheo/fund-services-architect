**To:** Graham Voss, Head of Operations Oversight
**Re:** TMAI holdings rec vs Northgate (7730-131, as of 17 Sep 2026)

Graham,

**I can't analyse this yet because the folder you sent is empty.** The `inputs/` directory has no files in it. I don't have Pellmore's rec, Northgate's holdings statement, the lending reports, the corporate action notices, the NAV packs, the Trust's NAV error policy or the desk emails. I haven't guessed any quantities, causes or NAV impacts. Every figure in `answer.json` is a placeholder of 0, apart from the count of four securities, which comes from your email.

**Recommendation for today: don't sign off Pellmore's true-up.** Our book is on a trade-date basis, and Northgate reports settled holdings. The two can legitimately differ in these cases:
- securities on loan, or loan returns still in flight;
- trades that are pending or have failed to settle;
- corporate actions that one side has processed and the other hasn't yet.

If we force the books to Northgate's figures, we'd remove positions we actually own, or add positions we don't own. That could also hide a real error in a NAV we've already struck. Each break needs a documented cause before anything gets booked.

**Items that may need action today, pending the documents:**
1. **Brindlewood:** if shares are on loan ahead of a record date or vote, the recall deadline may be close. We need the lending agent's on-loan report now.
2. **Marlowe Diversified Holdings / Marlowe Water Technologies distribution:** if it wasn't booked or was booked wrongly, the 16 and 17 Sep NAVs could be misstated. The treasurer should know now. If the error is material under Trust policy, the CCO needs to be told, and shareholder activity reprocessed or reimbursed as the policy requires.

**What I need, and from whom:**
- **Pellmore:** the position rec for 17 Sep 2026, open trade and fail reports, the CA booking detail, and the NAV packs for 16 and 17 Sep (NAV per share, shares outstanding).
- **Northgate:** the MT535 for 7730-131 as of 17 Sep, with pending settlements and CA entitlements.
- **Lending agent:** open loans and returns, and Brindlewood loan quantity and recall timing.
- **CA vendor / notices:** MDH→MWT distribution terms (ratio, dates, cost allocation, cash-in-lieu rate).
- **Fund treasurer / CCO:** the Trust's NAV error correction policy and materiality threshold.

Once I have these, I'll produce the per-security breakdown for you: cause, which side is wrong, what gets booked, and the NAV error per share and percentage for each NAV date against the policy threshold.

Actions and open questions are recorded in `out/answer.json`.
