# AGEF — 18 Sep 2026 class NAVs: NOT COMPLETED (inputs missing)

**To:** Henrik Aalto  **Re:** AGEF 18/09 class NAVs incl. EUR hedged

## Bottom line
The `inputs/` folder I was given is **empty**. There is no TB or P&L, class register, dealing, FX forward blotter, Brackenridge hedge report, FX rates or hedging policy. Because of that, I could not do any of the following:
- the class allocation (I-USD-Acc, A-USD-Acc, I-EUR-H-Acc)
- the attribution of the I-EUR-H-Acc hedge P&L, including the forward rolled on 18 Sep
- the class NAVs or NAV per share
- the independent post-dealing hedge-ratio check that ManCo Risk asked for

**Please do not publish at 11:30.** The 18 Sep NAV release should stay on hold until this is done and reviewed.

All numbers in `answer.json` are **0 placeholders meaning "not computed"**. `hedge_ratio_breach=false` is also a placeholder that the schema requires. It does **not** mean the hedge is within limits.

## What I need, and from whom
- **From you / Fund Accounting:** signed-off sub-fund TB and P&L for 18 Sep; class capital and NAV for 17 Sep; 17 and 18 Sep subscriptions and redemptions by class; class fee and expense rates; FX fixing rates; the class hedging policy (target, tolerance band, rebalancing trigger).
- **From Brackenridge (hedging agent):** the 18 Sep hedge report, the forward positions and MTM, and confirmations for the rolled forward (closing leg plus new forward).
- **To confirm:** whether AGEF holds any portfolio-level FX forwards. If it does, that P&L goes to all classes pro rata and not to the hedged class.

## Planned method once the data arrives
1. Allocation ratios = each class's share of 17 Sep net assets after 17 Sep dealing.
2. Hedge P&L for I-EUR-H-Acc = realised result on the rolled forward plus the change in unrealised on the open forwards. This is charged only to I-EUR-H-Acc. Portfolio hedges are shared pro rata.
3. Class NAV = allocated common P&L + class-specific fees + class hedge P&L. Then convert to EUR at the policy FX rate and calculate NAV per share at 4dp and at the published precision.
4. Independent check: open EUR notional ÷ class NAV in EUR after 18 Sep dealing, compared against the policy band. Size any rebalancing trade needed to get back to 100%. Escalate to ManCo Risk if the ratio is outside the band.

## Actions recorded
Hold the NAV release and publication. Request the data from you and from Brackenridge. Tell ManCo Risk that the independent check is still outstanding. Tell the TA that the NAV is delayed.
