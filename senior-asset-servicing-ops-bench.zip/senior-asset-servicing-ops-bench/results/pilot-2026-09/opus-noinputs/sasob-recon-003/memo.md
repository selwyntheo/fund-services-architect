# TCBF Core Bond: admin draft vs Tidewell shadow NAV, 17 Sep 2026

**To:** Anneliese Kroft, NAV Oversight Manager
**Re:** Draft 10.3379 vs shadow 10.3558 (Tidewell's shadow is 0.0179/share, about 0.17%, higher)

## Bottom line
The folder you pointed me to (`inputs/`) was **empty**. I had no position files, vendor prices, emails, notices, pricing policy or shares-outstanding figure. That means I **could not** do the position-by-position reconciliation or put a dollar amount on any item. I have not guessed at any figures. Every net-asset figure in `answer.json` is set to 0, and that 0 means "unknown", not a real value.

## What I recommend for tonight
1. **Don't reprice to Tidewell's marks just because Hollis asked.** A shadow NAV is a check, not a pricing source. A mark changes only if the fund's pricing hierarchy says it should, or if the valuation designee makes a documented fair-value call.
2. **Escalate to the Fund Treasurer before 7:00 PM.** A 1.79c gap (about 17bp) on a bond fund is well above the usual shadow tolerance, and right now it's unexplained. The Treasurer should decide whether to:
   - release the unchanged draft of **10.3379 (10.34 at 2dp)**, or
   - delay the release until the files are reviewed.
3. **Tell the valuation designee** about any mark Tidewell is disputing.
4. **Get the missing information:**
   - From you or the team: the full pack plus shares outstanding.
   - From Hollis: position-level marks with sources, accruals and amortized cost, including Quenby Health Partners.

## What I need to finish the reconciliation
- Admin and shadow position files: par, price, market value, accrued interest, amortized cost, paydown factor.
- Vendor price file and any challenge or override notices.
- Valuation / pricing-source policy and the NAV error tolerance.
- Shares outstanding and both net-asset totals.

## Assumptions
- The only figures I used are the two NAVs per share in your email. No other data was available.
- Where information is missing, the fund's documented pricing policy decides the treatment, not the adviser's request.
