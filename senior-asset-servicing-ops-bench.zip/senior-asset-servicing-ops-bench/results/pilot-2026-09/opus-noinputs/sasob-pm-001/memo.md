# GACP IV Call #2 (Lanternfly): allocation not built, notices on hold

**To:** Nadia Kowalczyk, Client Service Director
**Re:** Marcus Feld's Call #2 request (Lanternfly equity, fund expenses, first management fee installment)

## Bottom line
I can't build the per-partner allocation or a call total this morning. The case file I was given (`inputs/`) is empty. It contains no LPA, side letters, partner register, Call #2 request, excuse requests, expense invoices, fee terms or fee income ledger. I haven't estimated or invented any figures. `answer.json` reports every amount as 0 and leaves the partner allocations empty; these are "not determined", not a zero call. **Please don't put the notices on the portal today.**

## What I relied on
- Your email of 5 Oct 2026: Call #2 is the first investment call; Marcus asks for notices today and money in by **Fri 16 Oct 2026**, ahead of the **20 Oct closing**; two LPs asked to be excused from the deal.
- No other source. `inputs/` holds no files.

## Why the notice can't go out today
1. **Excuse requests.** I can't tell which two LPs asked or whether their requests meet the LPA and side-letter conditions (grounds, timing, legal opinion). I also don't have the LPA rule for re-spreading their share across the other partners, including any cap.
2. **Amounts.** I have no figures for the Lanternfly equity, the fund expenses or the fee installment.
3. **Management fee.** I don't have the rate, the fee base, the start date, the installment period or day count, any side-letter discounts, or the fee income and offset percentage. So the gross fee, offset, net fee and `fee_period_days` can't be calculated.
4. **Notice period.** Notice on 5 Oct with a 16 Oct due date gives 11 calendar days, or 8 or 9 business days depending on whether Columbus Day (12 Oct) counts. I can't confirm that meets the LPA minimum without the LPA. I've marked the date as *not confirmed compliant*. The `earliest_compliant_due_date` field repeats the requested date only because the schema requires a value; it is not a finding.
5. **Unfunded commitments and investment limits.** These can't be tested without the register, the Call #1 history and the LPA limits.

## What to go back to Marcus with
- **From Marcus Feld (GP CFO):**
  - the Call #2 request with the Lanternfly equity amount
  - an expense schedule with invoices
  - the partner register with commitments and paid-in capital after Call #1
  - the management fee installment calculation
  - the manager fee income ledger for Lanternfly
  - the closing and funding timetable
- **From GP General Counsel:**
  - the executed LPA (capital calls, notice, excuse/exclusion, management fee and offset sections)
  - all side letters and MFN elections
  - the two LPs' written excuse requests
  - counsel's decision on whether each excuse is valid
- **Timing:** if the LPA notice period means the due date must move past 16 Oct, Marcus should confirm now whether a subscription facility will bridge the 20 Oct closing.

## Once the documents arrive
I'll build the allocation one component at a time:
- **Investment:** split pro rata to commitment across the partners who aren't excused, with each excused share re-spread under the LPA's rule and cap.
- **Expenses and management fee:** split across all partners, including excused LPs if the LPA says so, after applying side-letter fee terms and the fee income offset.

For each partner, I'll then check the total against their unfunded commitment and confirm the due date against the LPA notice period.
