**To:** Sam Adeyemi, Fund Controller
**Re:** GACP III Q4-2026 management fee invoice — OK to pay Monday 5 Oct?

Sam,

**Recommendation: do not pay the invoice on Monday's run. Take it off the run and hold it until the fee has been recomputed.**

**Why:** I wasn't able to recompute the fee. The workpaper folder I was given (`inputs/`) is empty. I have no:
- invoice (so no amount and no basis schedule);
- LPA (Investment Period end, Management Fee rate and step-down, Invested Capital definition, treatment of realizations, write-offs and write-downs, fee offsets);
- side letters or investor register for the fee-paying share;
- Q3-2026 fee calculation or payment record;
- portfolio cost, realization, write-off, recap or follow-on records;
- services agreement.

Without these I can't confirm or challenge any part of the invoice. Every number in `answer.json` is a 0 placeholder, not a calculated result. I haven't made up any figures. Since Marcus Feld signed the invoice and you want any pushback to be airtight, paying before we have checked it would be the wrong call.

**What I will check once the documents arrive:**
1. **Step-down date.** I'll get the Investment Period end date from the LPA. If it falls partway through Q3, the Q3 fee has to be split pro rata: commitments up to the step-down, Invested Capital after it. I'll then compare that with what was paid for Q3 and apply any overpayment as a credit against Q4.
2. **Invested Capital basis.** I'll build it company by company from cost, using the LPA definitions and not the valuation deck. That means:
   - removing the cost of full realizations and the realized portion of partial exits;
   - removing write-offs and permanent write-downs only as far as the LPA allows;
   - leaving ordinary unrealized markdowns in the basis unless the LPA says otherwise;
   - treating recap proceeds and follow-ons according to the definitions.
3. **Fee-paying share.** I'll exclude the GP commitment and any fee-waived LPs.
4. **Offsets and credits.** I'll apply any transaction or monitoring fee offsets and the Q3 credit, and carry forward any credit left over.
5. **Services agreement.** I'll follow its procedure for a disputed manager invoice (hold, and notify or escalate to the client and LPAC as it requires).

**What I need, and from whom:**
- **From you (Halcyon records):** the invoice, the LPA and any side letters, the Q3 fee workpaper and payment confirmation, the investment ledger (cost, exits, write-offs, follow-ons, recaps with dates), and the services agreement.
- **From the Granite Arch CFO, once we have our own numbers:** the supporting calculation behind the Q4 invoice.

**Assumption:** the fund's documented policy isn't available either, so I've taken the cautious approach: no payment out of the partnership account until the fee is verified.
