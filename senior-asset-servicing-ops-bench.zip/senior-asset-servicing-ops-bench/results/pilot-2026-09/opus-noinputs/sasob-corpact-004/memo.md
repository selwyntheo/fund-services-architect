# Halvard Dutch auction: final allocation, Fenwick and Ashgrove

**To:** Anya Brandt, Voluntary Events Lead
**Re:** Your email of 7 Oct 2026, 4:00 PM ET

## Bottom line
I can't give you final numbers tonight. The input set I was given (`inputs/`) has no files in it:

- no Stonemere final results announcement
- no offer document
- no tender or VOI records
- no positions
- no event-engine projection
- no policies
- no Fenwick or Ashgrove correspondence

I have not estimated or made up any figures. The per-account findings in `answer.json` are left empty. The totals are zero placeholders, required by the schema, and are **not** results.

## What to do before tomorrow morning
1. **Client cash forecast:** don't sign off the Halvard lines (proceeds and returned shares) for accounts 4410-2201, 4410-2204, 4410-3104 and 4410-5024. Sign them off once the allocation is recalculated on final terms.
2. **Event engine:** hold any automatic credit scheduled for Friday's DTC payable date. It may be based on a preliminary or projected allocation. Credit clients only from the depositary/DTC final allocation.
3. **Recalculate the allocation for each account.** For each one:
   - count only live tenders at or below the purchase price
   - give odd-lot priority only where it was certified
   - test conditional tenders against the final proration factor
   - leave out validly withdrawn shares
   - proceeds = accepted shares × purchase price, rounded to 2dp

## Fenwick: what to say to Grant
Grant should make no further commitments, and he should not offer a credit of "the difference".

The shares come back only if a withdrawal reached the depositary through DTC before the offer's withdrawal deadline. Our internal cut-off doesn't decide that.

- **If the withdrawal was validly transmitted:** Fenwick gets the shares back and there is nothing to compensate.
- **If Fenwick met our cut-off but we didn't transmit in time:** this is a potential Meridale processing error. It goes to the Head of Asset Servicing and Operational Risk to decide any make-whole.
- **If Fenwick missed our cut-off:** the tender stands, and Fenwick is paid on final terms like everyone else.

Grant's assurance to the client is part of what gets escalated.

## Ashgrove: 85-share account
Odd-lot priority in a Dutch auction tender offer is normally based on the beneficial owner's *total* holding: fewer than 100 shares across all accounts, certified in the tender instruction. It is not based on the size of a single account.

- If Ashgrove holds 100 or more shares in total, or didn't certify, the account is prorated like any other.
- Shares tendered above the purchase price are returned in any case.

I need the tender instruction and Ashgrove's total holding to confirm which applies.

## What I need from whom
- **Stonemere/depositary:**
  - final price, proration factor, and odd-lot and conditional treatment
  - per-VOI accepted and returned share counts
- **DTC ATOP / our instruction logs:** Fenwick's VOI and withdrawal messages, with timestamps
- **Grant / client records:**
  - Fenwick's withdrawal instruction and when it was received
  - Ashgrove's total holdings and odd-lot certification
- **Event engine owner:** the scheduled auto-credit amount, and whether it is based on the preliminary or final allocation
- **Policy owners:** the cut-off, RM-commitment and error-compensation policies

## Assumptions
- Market-standard Dutch auction tender offer mechanics, as described above, because I have no offer document.
- Nothing in this memo is based on data from `inputs/`, since the folder had no files.
