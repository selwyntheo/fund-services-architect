# BEIO September 2026 Section 19(a) notice: response to Nadia Okonkwo

**From:** Oakhurst Fund Administration, CEF Administration
**Date:** 24 Sep 2026

## Bottom line
1. **I could not produce final figures.** The working folder (`inputs/`) is empty. Kieran's draft, Talia's note, the tax team's estimate, last month's notice, the books and the Section 19 procedures were not there. I have not worked out or checked any per-share source, percentage or plan-disclosure rate. The zeros in `answer.json` only keep the file valid. They are placeholders, not figures, and must not be used.
2. **Talia's request: no.** The 19(a) notice must estimate sources from the fund's books and accounting records (book basis) at the time of payment, as Rule 19a-1 requires. A tax projection showing no return of capital uses a different basis and a different period (year-end tax character). It cannot replace the book-basis estimate. The notice can keep its standard wording: the amounts are estimates, and final tax character will be reported on Form 1099-DIV and may differ.
3. **Hold the insert file.** Please do not send anything to Harwick until the figures have been worked out from the books.

## Who else needs to hear about this, and why
- **CCO:** marketing has asked to change the basis of a regulatory notice. The CCO should know about that request. If the recalculation finds that last month's notice was wrong, or that the cumulative estimates it reported changed by a significant amount under the fund's procedures, the CCO (and the Board, if the procedures require it) needs to decide whether to issue a corrective or updated disclosure. I cannot assess last month's notice without it and the books.
- **Fund tax:** I need the tax estimate so I can reconcile it to the book-basis sources. It is for context only, not for the notice.

## What I need, from whom
| Item | From |
|---|---|
| Draft notice (Kieran), last month's notice | Treasurer / CEF admin team |
| September rate, record and pay dates; FYTD distributions; fiscal year start | Treasurer |
| Book-basis NII, net realized STCG/LTCG, undistributed balances, shares outstanding for each payment date | Accounting system / GL |
| Month-end NAV, fiscal-year-start NAV, 5-year average annual total return, FYTD cumulative total return | Fund accounting |
| Section 19 procedures, including the significant-change threshold | CCO |
| Tax team estimate | Fund tax |

## Method once the inputs arrive (for re-performance)
- **Current sources:** allocate the September distribution in this order: NII first, then net STCG, then net LTCG, with the remainder as return of capital. Use book-basis amounts available at the pay date, net of amounts already allocated to earlier FYTD distributions.
- **Cumulative sources:** work out FYTD sources from the books through September. Do not simply add up the earlier notices.
- **Percentages:** each source as a percent of the distribution, to 1dp.
- **Rates:**
  - Annualized distribution rate = current rate × 12 / month-end NAV.
  - Cumulative FYTD rate = FYTD distributions / fiscal-year-start NAV.
- **Last month's notice:** compare its cumulative figures to the recalculated ones and apply the procedures' threshold.
- **Deficit statement (Rule 19a-1(b)):** check whether one is required.

## Assumptions
- BEIO runs a managed distribution plan, so a 19(a) notice goes with every distribution (`notice_required = true`).
- `deficit_statement_required` and `prior_notice_significant_change` are set to false as placeholders only. Neither has been verified.
