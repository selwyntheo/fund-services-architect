# GACP II Distribution 8 (Delphine): waterfall status

**To:** Jonas Whitcombe | **Re:** Distribution 8, payable 30 Sep 2026

## Bottom line
I have not been able to run the Article 9 waterfall. The input pack I received (`inputs/`) is **empty**. There is no LPA, capital account ledger, prior distribution register, Delphine proceeds or IC approval, GP commitment data, or escrow terms. I have not made up any figures. Every number in `answer.json` is a **0 placeholder**, not a calculated amount.

## Recommendations
1. **Hold the carry wire to the GP.** Do not pay any carried interest on 30 Sep until we have computed and checked the waterfall. This is the first carry-bearing distribution. We also need to check the LPA escrow/holdback and clawback terms before we pay carry the same day as the LPs.
2. **Hold the distribution notices** until we have per-investor amounts from source data. The 24 Sep deadline is at risk.
3. **Don't repeat the GP finance team's carry number.** We have not verified it.

## What I need, and from whom
- **Fund legal / client:** the GACP II LPA. I need Article 9 (whole-of-fund or deal-by-deal, hurdle rate and compounding, catch-up %, carry %, whether the GP commitment is carry-free), plus the escrow and clawback provisions.
- **Fund accounting records:** the partner register (LP-0021 to LP-0027 plus GP) showing commitments and carry-bearing status. Also the inception-to-date contributions for all purposes with dates, and Distributions 1-7 by partner.
- **Client / IC:** the approved distributable amount from Delphine.
- **GP CFO / finance:** their carry calculation with workings, so we can reconcile it to ours.
- **Treasury:** escrow account details, if the LPA requires a holdback.

## Method once the data arrives
1. Take the GP commitment share out pro rata. It is carry-free if the LPA says so.
2. Split the LP portion by partner.
3. Run the tiers for each partner on a whole-of-fund basis, if Article 9 provides that: (A) return of all contributions; (B) preferred return to the hurdle; (C) GP catch-up at the stated %; (D) the carry split.
4. Carry per LP = catch-up to GP + the GP share of the split.
5. Apply escrow as the LPA requires.
