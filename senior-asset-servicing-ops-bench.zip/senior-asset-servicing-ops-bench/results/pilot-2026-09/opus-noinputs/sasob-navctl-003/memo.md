**To:** Mara Lindqvist, Treasurer & PFO, Corvane Investment Trust
**Re:** CGEF / Tarrant Hollis 9/17 trades

Mara,

**I can't give you the order-by-order answer yet because the files aren't there.** The inputs folder I was given is empty. None of the files you mention are in it:
- Tarrant Hollis order records
- omnibus transmission files
- Stellmark TA processing report
- 9/17 and 9/18 NAVs
- intermediary agreement

So I can't yet tell you which orders were entitled to Thursday's price, what leaving them costs the Fund, or whether 9/18 needs restating. I haven't estimated any figures. Every numeric field in answer.json is a placeholder of 0 and should not be relied on.

**The rule to apply.** Under Rule 22c-1 forward pricing, an order gets the 9/17 NAV only if the intermediary received it before the 4:00 PM ET close on 9/17. Any additional condition in the Tarrant Hollis agreement also has to be met, typically transmission to Stellmark by the agreed deadline. The following don't qualify and must be priced at the 9/18 NAV:
- orders received at or after the close
- any increase to an order made after the close
- orders transmitted after the deadline

An order can be split: the portion received before the close is timely and the increase is late. Only the late portions need reprocessing. Timely orders should stand.

**My recommendation for Ken: no, don't leave everything at 9/17.** With a takeover announced right around the close, orders priced at the stale 9/17 NAV transfer value away from existing shareholders. Leaving them would also be a forward-pricing violation. Instead:
1. Hold the flagged orders.
2. Get the time-stamped records.
3. Classify each order or portion of an order.
4. Reprocess the late portions at the 9/18 NAV. If that isn't possible, have the intermediary reimburse the dilution, measured as (9/17-priced shares issued minus 9/18-priced shares) × 9/18 NAV for purchases, and the equivalent for redemptions.
5. Measure the per-share effect on the 9/18 NAV of taking the late orders out of 9/17 capital stock, and compare it with the Fund's materiality threshold before deciding whether 9/18 must be restated.

**Who needs to hear about this:**
- the CCO, for possible late trading and intermediary compliance, and board or regulatory reporting if warranted
- Stellmark, as TA
- Tarrant Hollis, as the presumptive responsible party under its agreement
- the adviser and PM, because the flows change

**What I need, and from whom:**
- From Tarrant Hollis: order records with entry and amendment timestamps.
- From Stellmark:
  - transmission files with receipt times
  - the TA processing report
  - 9/17 and 9/18 NAVs and shares outstanding
- From you or Legal:
  - the executed intermediary agreement
  - the NAV error materiality policy

Once I have these I'll send the full order-level classification and dilution figures well before Monday 9am.
