**To:** Dev Raman, Mandatory & Reorg Events
**Re:** Pellam / Orvane proceeds: allocation not releasable yet

**Bottom line:** Don't release tonight. I can't give you per-account figures or a tie-out to DTC because I don't have any of the source data. The `inputs/` folder I was given is empty. The engine's allocation run is already showing out of balance, so it should stay in pending release until someone re-performs it.

**What I have**
- Your email. It says the Pellam merger paid at DTC this morning, the engine run is in pending release and out of balance, we have four accounts (4410-2201, 4410-2204, 4410-3104, 4410-5024), and Lumenfield says it elected cash on 125,000 shares.
- Nothing else. I have no merger terms, DTC payment advice, exchange agent proration notice, position or election records, engine run output or policies.

**What I did not do:** I haven't calculated any account's cash, Orvane shares or cash in lieu, the proration factor, the rounding difference, or the engine's over-allocation. Every figure in answer.json is 0 as a placeholder, not a calculated value. I have no inputs, so I haven't made any figures up.

**How I'll allocate once the data arrives (method)**
1. For each account, start from its Pellam shares at the Effective Time. Split them into valid cash elections, stock elections and non-elections, using the elections DTC/the exchange agent actually accepted. Withdrawn elections, void NGD protects (cover not delivered) and rejected late instructions go to whatever default treatment the terms set.
2. Apply the announced cash proration factor to the cash election shares. Cash election shares that are prorated out, stock elections and non-elections get stock (or whatever the agreement's waterfall says).
3. Calculate each account's cash consideration, whole Orvane shares and cash in lieu at the account level. Round the way the documented policy says.
4. Tie the totals to the DTC advice (cash, Orvane shares, cash in lieu). Book any rounding difference to the account policy requires, not to a client.
5. Compare the result with the engine run to find the out-of-balance cause before releasing.

**Lumenfield (Harriet Voss)**
- **What we can't do:** set Lumenfield's allocation to "cash on all 125,000" because the client says so. The allocation has to follow the elections DTC and the exchange agent accepted. Even a valid cash election may be prorated and partly paid in Orvane shares if cash was oversubscribed.
- **What we can do:**
  - Ask Lumenfield for a copy of its instruction, with timestamp and channel.
  - Check it against our election log and the DTC submission, including whether an NGD protect was used and whether cover was delivered.
  - If Meridale mishandled the instruction, take it through the exceptions/claims route and op-risk. It does not get fixed in the allocation.

**Raise internally**
- Head of Asset Servicing: the proceeds are paid but the allocation is held, statements on Monday are at risk, and there is a client dispute.
- Relationship manager: expectations for Lumenfield.
- Operational risk: log an event if the review finds an election-handling error or an engine over-allocation.

**What I need from whom**
- Event engine / CA team: the run detail, positions and elections.
- DTC: payment advice and allocation.
- Exchange agent: proration factor, exchange ratio, CIL price, and election acceptance results.
- Lumenfield, via the RM: its instruction evidence.
- Policy owner: the rounding and suspense policy.
