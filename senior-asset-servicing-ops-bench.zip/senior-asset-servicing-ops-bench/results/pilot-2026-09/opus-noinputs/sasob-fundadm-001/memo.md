# BFVF 8/31/2026 RIC diversification: review status

**To:** Elaine Marsh, Treasurer, Brightwater Series Trust
**From:** Oakhurst Fund Administration, Fund Tax
**Re:** BFVF 8/31 asset test sign-off for the Board certificate

## Bottom line
**Please don't sign the certificate yet.** I could not check Stella's "clean pass" because the review folder I received (`inputs/`) is empty. The following were all missing:
- the 8/31 books
- the issuer data
- the quarter's trades
- the repo confirms
- the 5/31 workpaper
- Stella's draft
- Dev's note
- the Trust's policy

As a result, I have not tested the 50% part of the asset test or the 25% part (IRC 851(b)(3)(A) and (B)). I am not reporting any figures. `answer.json` records both tests as `not_tested`, gives zero figures and has no issuer findings. I have not made up any data.

## Why timing matters
- Under IRC 851(d)(1), a failure at quarter end caused by an acquisition during the quarter can be cured by disposing of assets within **30 days after quarter end**. For 8/31/2026, the last trade date is **Wednesday 30 September 2026**.
- A failure that was not caused by an acquisition cannot be cured this way. It would need the 851(d)(2) de minimis rule or the reasonable-cause relief (a filing, a tax and a disposal within 6 months). Tax counsel would be needed in that case.
- If there is a problem, a Monday sign-off leaves about 7 business days to trade. The data is needed today.

## What I will do once I have the files
1. **Denominator:** gross total assets at 8/31 per the books, applied the same way to both tests and following the Trust policy.
2. **50% test:** add cash items (including receivables), US government securities, securities of other RICs, and other issuers that meet both limits: position no more than 5% of total assets and no more than 10% of the issuer's outstanding voting securities. For the 10% limit I will use the shares outstanding in the issuer master. I will treat repo as the policy and the confirms support.
3. **25% test:** check three things:
   - the largest single issuer (excluding government securities and RICs)
   - groups of issuers the Fund controls (20% or more voting) that are in the same or similar trades
   - total QPTP holdings

   For each I will check whether it was caused by a quarter acquisition (trade blotter compared with the 5/31 workpaper).
4. **If there is a failure:** calculate the minimum sale at 8/31 values needed to restore compliance, with proceeds held in cash, and the resulting percentages.

## Actions and calls
- **Hold:** the Board compliance certificate, until I have re-tested.
- **You / Stella / Dev:** re-send the full package today (the list is under "Open questions" in `answer.json`).
- **Adviser CCO and PM:** "Oakhurst is re-testing 8/31 diversification. Please be ready for a possible cure trade no later than 30 Sept. Until you hear from us, please don't add to any large or controlled-issuer position, or to any position that doesn't count toward the 50% test."
- **Oakhurst Tax Director:** told that the review is blocked and that the deadline is close.

## Assumptions
- The cure deadline is 30 calendar days after quarter end, per 851(d)(1).
- No figures are given because the source data is missing.
