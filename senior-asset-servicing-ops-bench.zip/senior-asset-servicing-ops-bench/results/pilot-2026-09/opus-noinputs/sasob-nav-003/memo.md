# AECB 18 Sep 2026 NAV - swing decision (NOT COMPLETED - inputs missing)

To: Sophie Lindahl, NAV Team Lead | cc: Elena (valuation sign-off)
Date: Mon 21 Sep 2026

## Bottom line
I cannot give you a swing decision or final dealing NAVs. The working folder (`inputs/`) I was given is **empty**:
there is no dealing register, no pre-swing NAV, no swing-pricing system parameters and no ManCo/prospectus documents.
I have not estimated or invented any figures. The numbers in `answer.json` are placeholders of 0 and must not be
used for pricing.

**Recommendation: hold the 18 Sep AECB NAV publication** until the documents arrive and the swing test can be
re-performed. Please flag the 11:00 deadline risk to Elena now.

## What I did
- Checked `inputs/` - no files present.
- The only item I could say anything about is order **AECB-0921-001**: its reference suggests it was received for the
  21 Sep dealing day, so it would fall outside 18 Sep net activity. This is an assumption from the naming
  convention only and needs confirming against the register timestamps.

## Method I will apply once documents arrive
1. From the register, classify each order: plain subscriptions/redemptions; intra-sub-fund conversions (net to zero at
   sub-fund level unless policy says otherwise); cancellations (excluded); orders after cut-off (next dealing day,
   unless a documented, approved exception exists).
2. Net capital activity = sum of subscriptions - redemptions dealt on 18 Sep (EUR); divide by unswung sub-fund NAV.
3. Compare with the swing threshold in the system parameters and ManCo policy (checking the two agree); if breached,
   swing all classes in the direction of net flow by the swing factor; round NAVs per share to 2dp.
4. Shares allotted for AECB-0918-001 = subscription amount / swung NAV of its class (rounded per prospectus).

## Carrow
Nothing to review - I do not have their order or correspondence. Until we do, the line to Aldermoor's relationship
team should be: *the order is being reviewed against the prospectus dealing cut-off and late-trading rules; we will
confirm the dealing date and price once checked.* No undertaking should be given that a late order will be dealt at the
18 Sep NAV; any exception needs CCO / conducting officer approval under the ManCo policy.

## What I need, from whom
- **Sophie / NAV team:** pre-swing NAV pack (sub-fund NAV, class NAVs, shares in issue) and swing system parameters.
- **TA / RTA:** final 18 Sep dealing register with receipt timestamps, conversions, cancellations, the Carrow order.
- **ManCo / compliance:** swing pricing policy and prospectus extracts (threshold, factor, cut-off, late-order rules).
