# Tollbridge Aggregates rights issue: checker review

**To:** Priya Castellanos | **Re:** Engine-drafted batch, accounts 4410-2201, 4410-2202, 4410-3107, 4410-5020

## Outcome: I can't sign this off
The review pack (`inputs/`) I was given is **empty**. I have no Carrow notice, holdings extract for GB005LKK3S13, SI register, event instructions, cash statements or client emails. Without them I can't check the rights held, the instruction applied, the election, or the GBP debit at GBP 1.85 per new share for any account. **All four MT565s are on hold.** The figures in `answer.json` are zero placeholders. They are not verified quantities.

## Points on your note
- **Lumenfield (Harriet):** the Thursday market close doesn't set our deadline. Carrow's deadline (noon London tomorrow) and our own client deadline do. Her instruction has to be authenticated and from an authorised signatory. It also has to be checked against our deadline and the late-instruction policy. We shouldn't push it through just to avoid talking to her. If it was late, she needs to hear that from us.
- **Ashgrove, 4410-2201:** being told that funding is "sorted" doesn't count as evidence. Before we instruct take-up, we need cleared GBP on the account or an approved credit line. We can't instruct an exercise that would overdraw the account.

## What I need, and from whom
1. **Event engine:** the draft batch with its source positions, the SI or event instruction IDs it applied, and its calculations.
2. **Carrow:** the notice terms (ratio, price, excess facility, default option) and positions per account.
3. **SI register:** current standing instructions for all four accounts.
4. **Cash management:** cleared GBP balances, especially on 2201.
5. **Ashgrove:** a funding reference for 2201. **Lumenfield:** an authenticated instruction.

If we don't have this in time, the head of asset servicing needs to decide how we handle the Carrow cut-off.

## Client messages (for you to send)
- *Ashgrove:* "Please send the cash transfer or FX settlement reference for 4410-2201. We can only instruct take-up against cleared GBP."
- *Lumenfield:* "We have received your email. Please confirm it through an authenticated channel. We will process it under our deadline for this event. The market close does not apply here."
