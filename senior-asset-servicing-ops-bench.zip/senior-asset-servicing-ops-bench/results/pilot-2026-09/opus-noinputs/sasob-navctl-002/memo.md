**To:** Priya Ramaswamy
**Re:** CMAF: expired 10 bp management fee waiver, recommendation for Mara

**Bottom line:** I can't give you numbers you can stand behind yet. The working folder (`inputs/`) is empty. None of the documents you mention reached me: Priyanka's note, the fee accrual detail, the NAV history, the expense summary and our policy. Every dollar and per-share figure in `answer.json` is therefore a **0 placeholder, not a result**. Below is the recommended treatment and the exact calculations to re-perform once the files arrive.

### 1. Recommendation for tonight (2026-09-18 NAV)
- **Hold NAV release** until the catch-up is quantified and the Treasurer approves it.
- **Fee module:** remove the expired waiver today so the full contractual fee accrues from now on.
- **Catch-up:** book the cumulative under-accrued management fee **in full in the 2026-09-18 NAV**, provided the materiality test (section 2) shows no material NAV date. Do not amortize: amortizing keeps future NAVs misstated and moves cost onto future shareholders. Book any increase in the Adviser's expense-limitation reimbursement at the same time. The net NAV hit = catch-up fee minus the extra reimbursement.
- **If any NAV date is material** under our policy, the treatment for that period becomes reprocessing shareholder activity at corrected NAVs, per the policy.

### 2. Is it a "NAV error" in the reprocess sense? The test to run
For each NAV date *d* from the first NAV after the waiver lapsed (February 2026, exact date to be confirmed) through 2026-09-17:
- Missed fee_d = 10 bp × net assets_d / day-count basis. Cumulative misstatement_d = Σ missed fee up to *d* (net of any expense-cap offset, if the cap was binding).
- Error per share_d = cumulative_d / shares_d. Error %_d = error per share_d / corrected NAV per share_d.
- Penny prong: round(published NAV) − round(corrected NAV) ≥ $0.01.
- Material if the policy's threshold is met (typically a penny *and* ≥ 0.5% of NAV; confirm in our policy).

A rough sense check, not a computed figure: 10 bp a year over about 7 months builds to at most about 0.06% of NAV. That suggests the penny prong may be hit but a percentage threshold probably is not. If so, it is a NAV error to log and report, but not one that requires shareholder reprocessing. This has to be confirmed with the data.

### 3. Does anyone owe the Fund money?
The fee was genuinely owed to the Adviser, so the catch-up is not a loss the Fund is compensated for. If no date is material, the Fund is owed **no** reimbursement from Stellmark (placeholder $0). The Adviser's expense-limitation reimbursement changes only if the cap binds (quantify from the expense summary). If any date is material, the resulting Fund loss (overpaid redemptions / underpriced subscriptions) is a candidate claim against Stellmark under its service agreement.

### 4. Q3 Board materials
Description and root cause (waiver not removed at expiry); period affected; per-share and % impact by date; materiality conclusion; treatment and approvals; effect on the Adviser's expense cap; Stellmark's control remediation for fee-schedule changes; entry in the NAV error log. Notify the CCO and the auditor.

### 5. What I need, and from whom
- **Stellmark (Priyanka):** her note and two options; daily accrual detail (net assets, rate, accrual) from expiry to 9/17; NAV history with shares outstanding; FYTD expense and expense-cap calculation; waiver agreement/expiry date.
- **Fund Treasurer / Legal:** NAV error policy (thresholds, approvals), expense limitation agreement, contractual fee rate and day-count basis.

### Assumptions
Tonight's NAV is 2026-09-18 (your email is dated 18 Sep and says "tonight"). The latest accrual date is 2026-09-17. Treasurer approval is assumed to be required until the policy says otherwise. No figures were invented. See `answer.json` → `open_questions`.
