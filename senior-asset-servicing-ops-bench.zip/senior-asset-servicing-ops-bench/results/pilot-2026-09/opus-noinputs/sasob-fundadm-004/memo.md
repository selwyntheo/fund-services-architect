**To:** Graham Sato, Manager, Regulatory Reporting
**Re:** BGOF August 2026 N-PORT: senior validation. Recommendation: hold, do not submit today

Graham,

I can't sign off on the August N-PORT. **Please don't submit it to EDGAR this afternoon.**

**Why:** The validation folder (`inputs/`) is empty. It doesn't contain the Part C extract, the holdings or valuation report, the liquidity vendor file, the security master, net assets, the LRM policy or prior filings. Because of that, I have not re-performed any line and I can't tell you which lines (L01–L25) need to change. I also can't give you fund-level liquidity numbers I'd stand behind. The auto-check results you quoted (illiquid under 10%, highly liquid above the 25% HLIM) haven't been independently verified. Auto-checks run on the draft's own classifications, so they won't catch misclassified positions (e.g. restricted or Level 3 names bucketed as Highly or Moderately Liquid). They also won't catch HLIM measurement adjustments, such as highly liquid assets posted as derivatives margin or collateral.

**Timing:** There is no pressure to file today. The fiscal quarter ended 2026-08-31, so the public quarter-end filing is due **2026-10-30** (60 days) under current Form N-PORT timing. If the Fund is already on the amended 30-day monthly timing, the due date is 2026-09-30. Please confirm which applies. Either way, there is time to validate properly. Once a filing is public, correcting it means an amendment.

**Figures in answer.json:** net assets, illiquid USD/% and HLIM measure are placeholders (0), because there's no data. HLIM = 25% is taken from your email. `illiquid_limit_exceeded`/`hlim_shortfall` = false only means no breach has been evidenced, not that compliance has been confirmed. Board report due date = null because I haven't identified a liquidity event.

**What I need, from whom:**
- **You:** the Part C extract and all supporting files, re-sent to the folder.
- **LRM Program Administrator:** confirmation of the HLIM and how it is measured, and whether any HLIM shortfall lasted more than 7 days or illiquid holdings went above 15% during or since August. Either would require Board reporting within the policy or rule timelines and a Form N-RN filing.
- **Liquidity vendor:** the 2026-08-31 position-level bucketing file, with overrides flagged.
- **Fund Treasurer:** informed that the filing is on hold pending validation. There is nothing for the adviser yet, but I will escalate immediately if re-performance shows a limit breach.

When the files arrive I'll turn the line-by-line review around the same day.
