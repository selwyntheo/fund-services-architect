**To:** Anya Brandt, Voluntary Events Lead
**From:** Asset Servicing — Voluntary Events
**Date:** Wed 7 Oct 2026
**Subject:** Halvard Dutch auction (HALV26DTCH01) — final allocation, Fenwick, Ashgrove, and an engine auto-credit that must be stopped tonight

## 1. Headline

On Stonemere's final terms — Purchase Price **USD 32.50**, final proration factor **0.748212**, shares purchased per VOI = shares subject to proration x 0.748212 **rounded down** (`inputs/notices/stonemere_final_results_notice_20261007.txt`) — our four tendering accounts get:

| Account | Client | VOI(s) | Live tender | At/below 32.50 | Odd lot | Accepted | Returned | Proceeds USD |
|---|---|---|---|---|---|---|---|---|
| 4410-2201 | Ashgrove (Global Equity) | 26093004 / 26093005 | 100,000 | 60,000 | No | 44,892 | 55,108 | 1,458,990.00 |
| 4410-2204 | Ashgrove (US Small Cap) | 26092810 | 85 | 85 | **No** | 63 | 22 | 2,047.50 |
| 4410-3104 | Fenwick | 26092407 | 120,000 | 120,000 | No | 89,785 | 30,215 | 2,918,012.50 |
| 4410-5024 | Lumenfield | 26092915 | 50,000 | 50,000 (conditional, min 40,000) | No | 0 | 50,000 | 0.00 |
| **Total** | | | **270,085** | | | **134,740** | **135,345** | **4,379,050.00** |

Cash and returned shares both come through DTC on **Friday 9 October** (Stonemere notice). Check: 134,740 x 32.50 = 4,379,050.00; 134,740 + 135,345 = 270,085 = the four contra-CUSIP (NDCFFY9Z5) balances in `inputs/positions/custody_positions_HALVARD_20261007.csv` (100,000 + 85 + 120,000 + 50,000).

**Stop before tomorrow morning:** engine run PJ-HALV-01 (`inputs/event_engine/projected_tender_proceeds_HALV26DTCH01.csv`) has **USD 2,608,937.50** in three `SCHEDULED_AUTO_CREDIT 2026-10-08 06:00` lines (1,421,550.00 + 2,762.50 + 1,184,625.00). It is built on the superseded preliminary 0.729 factor and would credit clients a day before DTC pays. Schedule 4 s.8.2/8.3 (`inputs/policies/meridale_voluntary_events_terms_extract.md`) says preliminary factors are never used for booking and any engine projection scheduled for auto-credit must be held and re-run on final terms. Every line in that run is wrong (see s.5).

## 2. Workings per account

Sources: `inputs/instructions/tender_instruction_log_HALV26DTCH01.csv` (TL-01..TL-08), Stonemere final notice, Offer to Purchase extract (`inputs/notices/halvard_offer_to_purchase_extract.md`).

**4410-2201 Ashgrove Global Equity.** TL-01 100,000 @ 31.00 (VOI 26092201) was withdrawn (TL-02) and re-tendered at 11:02 ET on 30 Sep (TL-03/TL-04) — before the 1 Oct 5:00 pm ET deadline, all accepted by the depositary — as 60,000 @ 31.00 (VOI 26093004) and 40,000 @ 33.00 (VOI 26093005).
- VOI 26093004: 60,000 x 0.748212 = 44,892.72 -> **44,892 accepted**, 15,108 returned.
- VOI 26093005: 33.00 > 32.50 Purchase Price -> not purchased, **40,000 returned**.
- Proceeds 44,892 x 32.50 = **USD 1,458,990.00**. Returned total 55,108.

**4410-2204 Ashgrove US Small Cap (the "odd lot").** TL-05: 85 shares AT_PURCHASE_PRICE (treated as tendered at 30.00, so at or below the price), `odd_lot_certified = N`, note "odd-lot box not completed at checker review". The checker was right:
- Offer Section 1 (Odd Lots): an Odd Lot Holder owns **beneficially or of record an aggregate of fewer than 100 shares**; the priority "is not available ... to beneficial holders of 100 or more shares, even if those holders have separate accounts or certificates each representing fewer than 100 shares". Nominees must certify per beneficial owner.
- Ashgrove Pension Trust (client ASH) holds 100,000 tendered + 80,000 free in 4410-2201 and 85 in 4410-2204 = **180,085 shares** (positions file). Schedule 4 s.8.1 aggregates separate accounts of the same beneficial owner and only permits certification when the aggregate is below the threshold.
- Result: prorated like any other VOI. 85 x 0.748212 = 63.60 -> **63 accepted, 22 returned, USD 2,047.50**.
- Marcus Leland's email of 5 Oct (`inputs/correspondence/email_ashgrove_20261005.txt`) should get a reply on that basis; it is Ashgrove's own aggregate holding that disqualifies the sleeve, not anything we did.

**4410-3104 Fenwick.** TL-06: 120,000 @ LIMIT 32.50 via client portal, 24 Sep, VOI 26092407. Equal to the Purchase Price, so at or below and purchasable.
- TL-07 WITHDRAW by email, `received_at = 2026-10-01T16:40:12-05:00`. That offset is Central time: **4:40 pm CT = 5:40 pm ET**. Our Client Response Deadline (s.7.1) is 5:00 pm ET on the business day before expiration, i.e. **Thu 1 Oct 5:00 pm ET** (offer expired Fri 2 Oct 5:00 pm ET). The withdrawal was **40 minutes late**. Grant's "4:40 pm ... before your 5 pm cut-off" (`inputs/correspondence/email_rm_fenwick_20261006.txt`) is comparing a Central-time clock to an ET deadline.
- Log status `LATE_NOT_TRANSMITTED`: referred to Head of Asset Servicing 08:50 ET 2 Oct; best-efforts transmission declined 09:40 ET; client emailed 09:55 ET — i.e. Fenwick knew before the offer expired that the withdrawal had not gone.
- The tender therefore stood: 120,000 x 0.748212 = 89,785.44 -> **89,785 accepted, 30,215 returned, USD 2,918,012.50**.
- s.7.2: late instructions do not bind Meridale; no liability for a late instruction not transmitted. s.9.1: after expiration we do not ask a depositary to reverse or amend a tender, and RMs and Asset Servicing staff may not promise or credit compensation.

**4410-5024 Lumenfield.** TL-08: 50,000 AT_PURCHASE_PRICE, conditional minimum 40,000 (VOI 26092915). 50,000 x 0.748212 = 37,410.6 -> 37,410 < 40,000, so the condition fails. Stonemere: "no conditional tenders were selected by random lot ... all shares covered by them are returned." **0 accepted, 50,000 returned, USD 0.** (Note the condition would also have failed on the preliminary factor: 36,450 < 40,000. The engine never applied it.)

## 3. Fenwick — what to say to Grant

1. Facts: withdrawal received 5:40 pm ET on 1 Oct (log TL-07, timestamp -05:00), after the 5:00 pm ET Client Response Deadline. Escalated to the Head of Asset Servicing the next morning; best-efforts transmission declined 09:40 ET; Fenwick informed 09:55 ET, before the offer closed.
2. We **cannot ask Stonemere to give the shares back**. The tender was properly tendered and not properly withdrawn under the offer; Stonemere's final results are out; s.9.1 prohibits asking a depositary to reverse a tender after expiration. Fenwick will receive USD 2,918,012.50 for 89,785 shares and 30,215 shares back on Friday.
3. He **may not promise or credit "the difference"** (s.9.1). His commitment to Tomas Albright must be corrected today, and no credit will be booked by Asset Servicing. Any redress can only be considered through the Operational Incident process with Head of Operations approval — and on the log, Meridale followed its published terms, so no Meridale error is identified. There is also no defined "difference": we hold no market price or loss basis for Halvard in our records.
4. I am opening an Operational Incident / complaint record (facts + time stamps) and briefing the Head of Asset Servicing. Please ask Grant to send us Tomas's original email with full headers and to say exactly what he promised, so the file is complete.

## 4. Ashgrove — what to say

4410-2204 is not an odd lot for this offer because the beneficial owner holds 180,085 shares across Meridale; separate sub-100 accounts are expressly excluded by the Offer, and Schedule 4 s.8.1 aggregates. 63 of 85 purchased, 22 returned, USD 2,047.50. Global Equity: 44,892 purchased, 55,108 returned (15,108 from proration plus the 40,000 tendered at 33.00, above the price), USD 1,458,990.00. Cash and shares Friday.

## 5. Engine and cash forecast

PJ-HALV-01 vs final terms:

| VOI | Engine | Final | Engine error |
|---|---|---|---|
| 26093004 | 43,740 / USD 1,421,550.00, auto-credit 8 Oct | 44,892 / USD 1,458,990.00 | preliminary 0.729 factor; auto-credit before DTC pays |
| 26093005 | 0 / 40,000 returned | same | — |
| 26092810 | 85 / USD 2,762.50 at factor 1.000, "Y (POSITION < 100)" | 63 / USD 2,047.50 | odd-lot test run on account position, not beneficial owner; ignores `odd_lot_certified = N` |
| 26092407 | 0 / 120,000 returned ("withdrawal request on file") | 89,785 / USD 2,918,012.50 | untransmitted withdrawal treated as effective |
| 26092915 | 36,450 / USD 1,184,625.00 | 0 / 50,000 returned | conditional minimum not applied |

Actions tonight: hold the USD 2,608,937.50 auto-credit; re-run on 0.748212 / 32.50 with the corrections above; set crediting to on-receipt of DTC funds on 9 Oct (s.8.3). Cash forecast: remove USD 2,608,937.50 on Thu 8 Oct; add USD 4,379,050.00 on Fri 9 Oct (2201 1,458,990.00; 2204 2,047.50; 3104 2,918,012.50; 5024 nil). On Friday reconcile DTC cash and the four contra-CUSIP reductions to these per-VOI figures before crediting — Stonemere quotes accepted shares as "approximately 4,780,000", so any per-VOI variance from DTC governs and should be queried with Stonemere.

## 6. Assumptions and open points

- Timestamps in the instruction log are taken as the control record. The Fenwick receipt is recorded with a -05:00 offset; US Eastern on 1 Oct 2026 is EDT (-04:00), so 16:40 -05:00 = 17:40 ET. The original email headers should be retained for the incident file. If a server header ever showed receipt before 5:00 pm ET, the case would need re-examination.
- I have assumed the Halvard event notification to clients stated the 1 Oct 5:00 pm ET deadline as s.7.1 requires; please attach a copy to the incident file.
- s.8.1 requires the client to confirm aggregate holdings; the custody positions alone already exceed 100 shares, so Ashgrove's confirmation would not change the conclusion.
- No compensation figure for Fenwick can be computed from the inputs and none should be; that is for Operational Risk / Head of Operations.
- Worth a systemic check: whether the engine has scheduled unheld auto-credits on preliminary factors for any other open prorated event.

Structured findings and actions are in `out/answer.json`.
