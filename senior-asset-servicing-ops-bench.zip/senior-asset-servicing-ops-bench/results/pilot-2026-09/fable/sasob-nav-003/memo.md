# AECB — Dealing Day 18 Sep 2026 — Swing decision and dealing NAVs

**To:** Sophie Lindahl, NAV Team Lead
**From:** NAV / Fund Accounting
**Date:** Mon 21 Sep 2026, before 11:00 publication
**Re:** Aldermoor Euro Corporate Bond Fund (AECB) — swing pricing decision, final dealing NAVs, and the Carrow late order (AECB-0918-012)

## 1. Decision in one paragraph

Net capital activity for 18 Sep is **+EUR 13,478,920.00**, which is **2.4831%** of the unswung Sub-Fund NAV of EUR 542,818,558.77. That is strictly above the 2.00% threshold, so the NAV **swings up**. The applicable inflow factor is **0.38%** — the SPC-approved figure effective DD 1 Sep 2026 — not the 0.30% still held in the NAV system, whose change request (CR-2291) has not cleared four-eyes. Per Policy s.7 we apply the SPC figure manually and report this to Elena Marchetti as Conducting Officer. **Dealing NAVs: A-EUR-Acc 124.79, I-EUR-Acc 118.69, R-EUR-Dis 96.32.** The Carrow redemption was received after cut-off and is dealt on 21 Sep; same-day dealing is refused.

## 2. Sources relied on

| File | Used for |
|---|---|
| `inputs/accounting/pre_swing_nav_AECB_20260918.csv` | Shares in issue, net assets and 2dp unswung NAV per class; Sub-Fund total EUR 542,818,558.77 (status PRE_SWING_REVIEWED) |
| `inputs/registrar/dealing_register_AECB_DD20260918.csv` | All 13 orders, receipt times, status |
| `inputs/nav_system/swing_parameters_extract_20260921.csv` | System parameters: mode PARTIAL, threshold 2.00%, factors 0.30/0.41 with CR-2291 AWAITING_4_EYES, max 2.00%, rounding 2dp |
| `inputs/governance/SPC_minutes_20260827_extract.md` | Approved factors from DD 1 Sep 2026: 0.38% in / 0.45% out; threshold unchanged at 2.00% |
| `inputs/governance/AAM_swing_pricing_policy_v4.md` | s.3 scope (Sub-Fund level, conversions in/out), s.4 valuation of share-denominated orders at unswung 2dp NAV, s.5 strict > threshold, s.6 unrounded NAV x (1+factor) then round, s.7 manual application, s.8 exceptions |
| `inputs/prospectus/AGS_prospectus_extract_general_and_AECB.md` | s.7.2 cut-off 12:00 Lux, distributor time irrelevant, no late trading; s.7.5 conversions; s.8.1 NAV 2dp half-up, shares 4dp rounded down; s.8.4 swing applies equally to all classes, cap 2.00% |
| `inputs/correspondence/email_carrow_late_order_20260918.txt` | Carrow's request for same-day dealing of AECB-0918-012 |

## 3. Order-by-order treatment (Policy s.3 and s.4)

Share-denominated orders are valued at the unswung 2dp NAV of their class (A 124.32, I 118.24, R 95.95).

| Order | Class | Type | Received (Lux) | Treatment | EUR in net activity |
|---|---|---|---|---|---|
| 006 | A | Redemption 11,250.0000 sh | 08:55:31 | Redemption; 11,250 x 124.32 | -1,398,600.00 |
| 001 | I | Subscription EUR 9,500,000 | 09:14:02 | Subscription | +9,500,000.00 |
| 011 | I | Subscription EUR 6,000,000 | 09:40:00 | **Cancelled 11:38:12** (before cut-off, callback verified) — excluded | 0.00 |
| 007 | R | Redemption EUR 420,000 | 10:05:12 | Redemption | -420,000.00 |
| 009 | A -> I | Switch 40,000.0000 sh | 10:22:18 | Conversion within Sub-Fund: -4,972,800.00 (A) and +4,972,800.00 (I) — **nets to zero** at Sub-Fund level | 0.00 |
| 002 | I | Subscription EUR 4,200,000 | 10:41:37 | Subscription | +4,200,000.00 |
| 003 | A | Subscription EUR 1,850,000 | 11:02:10 | Subscription | +1,850,000.00 |
| 004 | R | Subscription EUR 640,000 | 11:15:44 | Subscription | +640,000.00 |
| 010 | I -> AGE I | Switch 9,000.0000 sh | 11:20:05 | Conversion **out** of Sub-Fund = redemption; 9,000 x 118.24 | -1,064,160.00 |
| 008 | I | Redemption 18,000.0000 sh | 11:31:50 | Redemption; 18,000 x 118.24 | -2,128,320.00 |
| 005 | A | Subscription EUR 2,300,000 | 11:48:09 | Subscription | +2,300,000.00 |
| 012 | I | Redemption EUR 3,000,000 | **12:07:41** | After cut-off — **deferred to DD 21 Sep** (see s.6) | 0.00 |
| 0921-001 | A | Subscription EUR 750,000 | 15:12:26 | Requested dealing date 21 Sep — not this Dealing Day | 0.00 |

Subscriptions (incl. conversions in, net of the 009 in-leg which is offset): 9,500,000 + 4,200,000 + 1,850,000 + 640,000 + 2,300,000 = **18,490,000.00**
Redemptions (incl. conversion out): 1,398,600 + 420,000 + 2,128,320 + 1,064,160 = **5,011,080.00**
**Net capital activity = +13,478,920.00**

## 4. Threshold test (Policy s.5)

13,478,920.00 / 542,818,558.77 = **2.4831%** > 2.00% -> swing applies, direction **up** (net inflow).

Sensitivities the reviewer should be aware of:
- If the cancelled Ostmark order (011) had stood: net +19,478,920 = 3.59% (still swings).
- If the Carrow order (012) were wrongly dealt on 18 Sep: net +10,478,920 = **1.93%, below threshold — no swing**. So the cut-off decision is not cosmetic: dealing it same-day would remove the dilution protection for all remaining shareholders and reprice every other 18 Sep order.
- If 009 were wrongly treated as an I-class inflow only (ignoring the A-class out-leg): net +18,451,720 = 3.40%. Policy s.3 measures at Sub-Fund level, so the legs offset.

## 5. Swing factor and swung NAVs (Policy s.6 and s.7; Prospectus s.8.1, s.8.4)

**Which factor.** The NAV system shows SWING_FACTOR_IN_PCT = 0.30% effective 1 Jun 2026, with CR-2291 (the update to the 1 Sep factors) still AWAITING_4_EYES as at 21 Sep. The SPC on 27 Aug 2026 approved 0.38% in / 0.45% out effective DD 1 Sep 2026 and notified Quayside in writing on 28 Aug. Policy s.7: "Until the system is updated the Administrator applies the SPC-approved parameters manually and reports the manual application to the Conducting Officer for valuation." We therefore apply **0.38%** manually. Using 0.30% would be a deviation requiring the CO's prior approval under s.8, and there is no basis for one. The factor is within the 2.00% prospectus cap.

**Calculation.** Swung NAV = unrounded NAV per share x 1.0038, rounded half-up to 2dp. The unrounded NAV is net assets / shares in issue from the pre-swing file.

| Class | Net assets EUR | Shares in issue | Unrounded NAV | Unswung 2dp | x 1.0038 | **Swung 2dp** |
|---|---|---|---|---|---|---|
| A-EUR-Acc | 159,688,420.17 | 1,284,512.4410 | 124.31831337 | 124.32 | 124.79075 | **124.79** |
| I-EUR-Acc | 343,512,904.66 | 2,905,118.2200 | 118.24403644 | 118.24 | 118.69336 | **118.69** |
| R-EUR-Dis | 39,617,233.94 | 412,880.1000 | 95.95336259 | 95.95 | 96.31799 | **96.32** |

Note on R-EUR-Dis: applying the factor to the *rounded* 95.95 would give 96.31; the policy requires the unrounded base, which gives 96.32. Please make sure the manual override in the system is keyed on the unrounded base (or the published figure is overridden to 96.32).

For comparison only, the system's stale 0.30% would have produced 124.69 / 118.60 / 96.24 — a 0.08% understatement of the dilution charge on EUR 18.5m of subscriptions.

## 6. Dealing at the swung NAVs (Prospectus s.7.5, s.8.1)

- **AECB-0918-001 (Verwood, EUR 9,500,000, I):** 9,500,000 / 118.69 = 80,040.44140... -> **80,040.4414 shares** (4dp, rounded down). At the unswung 118.24 it would have been 80,345.0608; the 304.6194-share difference is the anti-dilution charge staying in the fund.
- **AECB-0918-009 (Pellworth, A -> I):** redeem 40,000 A at 124.79 = EUR 4,991,600.00; issue 4,991,600.00 / 118.69 = **42,055.7755 I shares**. Because the swing is applied equally to every class (Prospectus s.8.4) the conversion is economically neutral for the investor.
- **AECB-0918-010 (Hallam & Rye, I -> AGE I):** redeem 9,000 I at 118.69 = EUR 1,068,210.00, to be applied to the Global Equity Fund I-EUR-Acc subscription at that Sub-Fund's 18 Sep NAV (not in this folder; AGE's own swing test should count it as a conversion in).
- 006 and 008 redemption proceeds: 11,250 x 124.79 = EUR 1,403,887.50; 18,000 x 118.69 = EUR 2,136,420.00. 007 redemption of EUR 420,000 at 96.32 = 4,360.4651 R shares cancelled (4dp; RTA to confirm rounding convention for amount-based redemptions).
- 011 stays cancelled; nothing to process.

## 7. Carrow — AECB-0918-012 (EUR 3,000,000 I-EUR-Acc redemption)

**Facts.** RTA receipt time 12:07:41 Lux (SWIFT MT502), 7 min 41 s after the 12:00 Cut-Off. Carrow says their internal system timestamped the client order at 11:52 and their SWIFT gateway queued it; they ask for same-day dealing and say Aldermoor's relationship manager is "aware and supportive".

**Rule.** Prospectus s.7.2: requests received by the RTA after the Cut-Off are treated as received before the Cut-Off on the next Dealing Day; distributors and nominees must transmit so that requests reach the RTA before the Cut-Off; "the time of receipt by a distributor is not relevant"; the Company does not permit late trading. The 18 Sep NAV is struck at 17:00, after the order arrived, so dealing it on 18 Sep would be late trading regardless of who supports it. Neither Quayside nor the ManCo relationship team has discretion here; this is not a Policy s.8 swing exception but a prospectus dealing rule.

**Decision.** Refuse same-day dealing. Move 012 from PENDING_OPS_DECISION to ACCEPTED for **DD 21 Sep 2026**, dealt at the 21 Sep I-EUR-Acc NAV and included in the 21 Sep swing test at the 21 Sep unswung NAV. It is excluded from 18 Sep net activity. As noted in s.4, including it would have taken 18 Sep net activity below the threshold and switched off the swing for everyone else, which is exactly the kind of outcome the cut-off rule exists to prevent.

**What we say to Carrow (draft, for RM to co-sign or for TA to send):**
> Thank you for your email. The MT502 for AECB-0918-012 was received by the Registrar and Transfer Agent at 12:07:41 CET on 18 September, after the 12:00 Cut-Off Time for the Sub-Fund. Under section 7.2 of the Prospectus, requests received after the Cut-Off Time are dealt at the Net Asset Value of the next Dealing Day, and the time of receipt by a distributor is not relevant; the Company does not permit late trading. We are therefore unable to deal the order at the 18 September NAV. It has been accepted for the Dealing Day of 21 September 2026 and will be dealt at that day's NAV. Your order-log screenshots are not required, as they cannot change the time of receipt by the RTA. Any arrangement with your underlying client in respect of the gateway delay is a matter for Carrow.

Elena should also be made aware that a relationship manager was cited as supporting a post-cut-off dealing request; a reminder to Aldermoor's distribution/RM staff would be sensible.

## 8. Actions and who I need

| # | Action | Owner | By |
|---|---|---|---|
| 1 | Report manual application of 0.38% factor (Policy s.7) and obtain acknowledgement | Elena Marchetti (CO Valuation) | before 11:00 today |
| 2 | Publish swung NAVs 124.79 / 118.69 / 96.32 | NAV team, after (1) | 11:00 |
| 3 | Price 18 Sep orders at swung NAVs; 001 = 80,040.4414 sh; 009 = 42,055.7755 I sh; 010 out-leg EUR 1,068,210.00 | RTA | today |
| 4 | Re-status 012 to ACCEPTED for DD 21 Sep; reply to Carrow (s.7 wording); copy Aldermoor RM | RTA / Aldermoor RM | today |
| 5 | Clear four-eyes on CR-2291 (0.38 / 0.45) before the 21 Sep NAV is struck; document why it has been pending since the 28 Aug notification | Quayside change control | today |
| 6 | Check whether any AECB NAV for DD 1–17 Sep swung on the stale 0.30 / 0.41 factors; if so, run NAV error procedure | NAV team + CO | this week |

## 9. Open points

1. Possible NAV errors on DD 1–17 Sep if any swing was triggered with the system's superseded factors — need the swing log for those days.
2. Reason CR-2291 has been AWAITING_4_EYES for over three weeks.
3. AGE-side pricing of conversion 010 (AGE 18 Sep NAV not in this folder).
4. Who sends the Carrow reply — RTA or Aldermoor RM (substance unchanged either way).
5. Confirmation that the Ostmark cancellation fax and callback record are attached to order 011 in the RTA system.
6. Elena's sign-off to be recorded against the swung figures with the manual-application note attached.

Nothing in this memo moves money or publishes anything; all steps above await the sign-offs indicated.
