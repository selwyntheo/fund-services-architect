# AGEF — NAV 18 Sep 2026: class allocation, EUR hedged class and independent hedge check

**To:** Henrik Aalto, Fund Accounting Manager — Quayside Fund Administration (Luxembourg) S.A.
**Re:** Aldermoor Global Equity Fund (AGEF), Valuation Day Fri 18 Sep 2026 — class NAVs for 11:30 publication
**Prepared:** Mon 21 Sep 2026

## 1. Class NAVs for publication

| Class | Net assets USD | Net assets class ccy | Shares in issue | NAV/share 4dp | **Published (2dp)** | 17 Sep | Move |
|---|---|---|---|---|---|---|---|
| I-USD-Acc | 211,643,045.04 | USD 211,643,045.04 | 1,412,337.5520 | 149.8530 | **USD 149.85** | 150.59 | -0.49% |
| A-USD-Acc | 117,835,681.73 | USD 117,835,681.73 | 811,204.9913 | 145.2601 | **USD 145.26** | 145.98 | -0.49% |
| I-EUR-H-Acc | 79,809,838.62 | EUR 67,727,290.07 | 562,118.4400 | 120.4858 | **EUR 120.49** | 121.01 | -0.43% |
| Sub-fund | 409,288,565.39 | | | | | | |

Rounding to 2dp per Prospectus 8.3. EUR conversion at WM/Reuters 4pm London mid 18 Sep = 1.17840 (`inputs/fx/wmr_rates_20260917_20260918.csv`).

**Two things need your action today (section 4):** (i) an over-hedge breach on I-EUR-H-Acc — our independent ratio is **107.91%** post-dealing, not the 100.70% in Brackenridge's report; (ii) the portfolio JPY forward result (+USD 92,694.17) was not in the signed-off P&L file and I have added it — please confirm.

## 2. Build-up and sources

### 2.1 Allocation base (Prospectus 8.2)
Common items are allocated on class net assets at the preceding Valuation Day after that day's dealing: `inputs/accounting/nav_final_AGEF_20260917.csv` (status FINAL, dealing through DD 17 Sep).

| Class | 17 Sep net assets USD | Ratio |
|---|---|---|
| I-USD-Acc | 212,688,904.12 | 51.755097% |
| A-USD-Acc | 118,420,556.40 | 28.816112% |
| I-EUR-H-Acc | 79,843,118.27 | 19.428791% |
| Total | 410,952,578.79 | 100% |

### 2.2 Sub-fund common items
`inputs/accounting/pnl_and_expenses_AGEF_20260918.csv` (all lines SUB_FUND): dividends 184,220.40; WHT -21,488.11; interest 3,318.62; realised securities 1,240,118.55; unrealised securities -3,912,440.18; FX translation 402,337.90; depositary -225.18; admin/RTA -450.36; audit -180.82; directors/CSSF/other -132.88. **Sum -2,104,922.06.** (Depositary and admin re-performed: 0.02% and 0.04% of 410,952,578.79 / 365 — agree.)

Plus **portfolio hedge FWD-P-0818** (tag PORTFOLIO, `inputs/fx/fx_forwards_AGEF_20260917_20260918.csv`): buy USD 17,593,244.19 / sell JPY 2,500,000,000 @ 142.10; MTM 17 Sep -31,006.78 (fwd 141.85), 18 Sep +61,687.39 (fwd 142.60), re-performed as 17,593,244.19 - 2.5bn/fwd rate. **Day result +92,694.17**, attributed to all classes pro rata (Prospectus 5.5). This is not in the P&L file (its UNREALIZED_FX_TRANSL line covers securities and cash only), so it is added here — see open question 1.

**Common total -2,012,227.89**, allocated: I-USD -1,041,430.49; A-USD -579,845.85; I-EUR-H -390,951.55 (sums exactly).

### 2.3 Class-specific items
`inputs/accounting/class_expense_accruals_AGEF_20260918.csv`, all re-performed as prior-day class NA x rate / 365 and agreed:

| Class | Mgmt fee | Taxe d'ab. | Hedging fee | Class hedge P&L | Total class-specific |
|---|---|---|---|---|---|
| I-USD-Acc | -4,370.32 (0.75%) | -58.27 (0.01%) | – | – | -4,428.59 |
| A-USD-Acc | -4,866.60 (1.50%) | -162.22 (0.05%) | – | – | -5,028.82 |
| I-EUR-H-Acc | -1,640.61 (0.75%) | -21.87 (0.01%) | -65.62 (0.03%) | +359,400.00 | +357,671.90 |

### 2.4 Share class hedge result — I-EUR-H-Acc only (Prospectus 5.5, procedure s.5)
Sources: `fx_forwards_AGEF_20260917_20260918.csv`, `fx_settlement_report_20260918.csv`. Each MTM re-performed as notional x (valuation forward rate - contract rate); all agree to the file.

| Contract | Status 18 Sep | 17 Sep MTM | 18 Sep | Day result |
|---|---|---|---|---|
| FWD-H-0817 buy EUR 34.0m @1.17120 | matured 18 Sep; realised at WMR 1.17840 = 34m x 0.0072 = +244,800.00 | +61,200.00 (reversed) | – | **+183,600.00** |
| FWD-H-0901 buy EUR 34.5m @1.17650, 19 Oct | open | -41,400.00 (fwd 1.17530) | +124,200.00 (fwd 1.18010) | **+165,600.00** |
| FWD-H-0918 buy EUR 34.0m @1.17985, 20 Oct | new (roll of 0817) | – | +10,200.00 (fwd 1.18015) | **+10,200.00** |
| FX-S-0918-01 spot sell EUR 34m @1.17840 | settled | – | – | 0.00 |
| **Total** | | | | **+359,400.00** (realised 244,800.00; unrealised change +114,600.00) |

Attribution check: only contracts tagged I-EUR-H-Acc are attributed to the class; the PORTFOLIO-tagged contract is allocated to all classes. Nothing from the class hedge reaches the USD classes.

### 2.5 Class net assets 18 Sep (before DD 18 Sep dealing)
Prior NA + allocated common + class-specific:
- I-USD-Acc: 212,688,904.12 - 1,041,430.49 - 4,428.59 = **211,643,045.04**
- A-USD-Acc: 118,420,556.40 - 579,845.85 - 5,028.82 = **117,835,681.73**
- I-EUR-H-Acc: 79,843,118.27 - 390,951.55 + 357,671.90 = **79,809,838.62** → / 1.17840 = **EUR 67,727,290.07**

Reasonableness: EURUSD rose 0.39% (1.17380 → 1.17840); an unhedged EUR class would have printed c. EUR 119.94 (-0.88%). The hedge (100.7–101.1% of pre-dealing NAV) offsets this, leaving the EUR class at -0.43% versus -0.49% for the USD classes; the small outperformance is the over-hedge plus forward-point roll. No pricing or NAV-error indicators.

## 3. Independent hedge monitoring (procedure v2.1 s.2–3)

Ratio = open class-currency notional at the valuation point / class NAV in class currency **after** 18 Sep dealing. Matured FWD-H-0817 excluded.

- Open notional: FWD-H-0901 EUR 34,500,000 + FWD-H-0918 EUR 34,000,000 = **EUR 68,500,000**
- DD 18 Sep dealing (`inputs/registrar/dealing_summary_AGEF_DD20260918.csv`): +EUR 250,000.00 subscriptions, -EUR 4,500,000.00 redemptions, all before 12:00 cut-off
- Post-dealing NAV: 67,727,290.07 + 250,000 - 4,500,000 = **EUR 63,477,290.07**
- **Hedge ratio = 68,500,000 / 63,477,290.07 = 107.91%** → **BREACH** of the 105.00% upper tolerance (procedure s.3; Prospectus 5.4)
- Adjustment to return to 100%: **reduce notional by EUR 5,022,709.93** (approx. USD 5.92m)

Why Brackenridge's report (`inputs/fx/hedging_agent_daily_report_20260918.txt`) shows 100.70% and "no action": it was run at 13:05 CEST on 18 Sep against the 17 Sep NAV (EUR 68,021,058.33) with "none received" dealing adjustments. The registrar's file shows the hedged-class dealing was only sent to the agent on **21 Sep 08:05 CEST** (RTA interface incident INC-7730). The agent therefore rolled FWD-H-0817 at the full EUR 34m notional without knowing of the EUR 4.25m net outflow. On its own basis the report is arithmetically right (68.5m / 68,021,058.33 = 100.70%); on the procedure's basis it is not the ratio we are required to monitor. Even on the 18 Sep pre-dealing NAV the ratio is 101.14%, so the breach is entirely dealing-driven.

Per procedure s.4 the NAV is calculated with the contracts as they stand and the breach does not delay release. We do not amend or book any hedge trade; only Brackenridge-confirmed trades will be recorded, and any de-hedge executed today affects the 21 Sep NAV, not 18 Sep.

## 4. Actions (recorded in answer.json)

1. **Notify Brackenridge (hedging agent) today** — procedure s.4(a): post-dealing NAV EUR 63,477,290.07; ratio 107.91%; reduce notional by EUR 5,022,709.93 to 100%; ask for confirmation of the adjusting trade.
2. **Escalate to ManCo Risk** — procedure s.4(b): breach details, cause (INC-7730 / agent run before dealing data), adjustment notified; ask for breach-log treatment and whether the over-hedge is to be corrected before month-end (Prospectus 5.4: not carried forward month to month).
3. **Release the 18 Sep NAV** for 11:30 as above — no hold.
4. **Accounting entries**: to I-EUR-H-Acc only — realised +244,800.00, reversal of prior unrealised 61,200.00, unrealised change +165,600.00 and +10,200.00 (net +359,400.00), hedging fee -65.62; to sub-fund, allocated pro rata — FWD-P-0818 +92,694.17.
5. **Transfer agent**: root cause and remediation for INC-7730, confirmation the file is now acknowledged by the agent, and whether other days/sub-funds were affected.
6. **Conducting Officer**: for information.

## 5. Assumptions and open questions

1. **Portfolio forward in the signed-off P&L?** I have treated FWD-P-0818's +92,694.17 as *not* included in the P&L file (the FX translation line is described as securities and cash). If it is already in there, aggregate net assets are overstated by 92,694.17 (I-USD 47,973.96 / A-USD 26,710.86 / I-EUR-H 18,009.36) and the NAVs would be 149.82 / 145.23 / EUR 120.46. Please confirm before release.
2. **Brackenridge's response**: has a reduction been executed today, at what notional and rate? Recorded on 21 Sep once confirmed.
3. **Post-dealing NAV** uses the registrar's cash amounts; share allotment at 120.49 may create a few euro of rounding. Please confirm the DD 18 Sep dealing summary is final (no late or cancelled orders).
4. **ManCo Risk**: whether this is logged as an administrator-identified breach (agent reported within tolerance on a stale basis) and whether the agent's 13:05 run timing should be reviewed given that dealing data is required for the ratio.

Files relied on: `inputs/accounting/nav_final_AGEF_20260917.csv`, `inputs/accounting/pnl_and_expenses_AGEF_20260918.csv`, `inputs/accounting/class_expense_accruals_AGEF_20260918.csv`, `inputs/registrar/dealing_summary_AGEF_DD20260918.csv`, `inputs/fx/fx_forwards_AGEF_20260917_20260918.csv`, `inputs/fx/fx_settlement_report_20260918.csv`, `inputs/fx/wmr_rates_20260917_20260918.csv`, `inputs/fx/hedging_agent_daily_report_20260918.txt`, `inputs/governance/AAM_share_class_hedging_procedure_v2.md`, `inputs/prospectus/AGS_prospectus_extract_hedged_classes.md`.
