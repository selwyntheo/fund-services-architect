# AGOF — 18 Sep 2026 price validation (run PX-0918-1640)

**To:** Nadia Ferrante, Pricing & Valuation Lead
**From:** AGOF pricing
**Re:** Aldermoor Global Opportunities Fund — validated prices, VC referrals, validated NAV
**Status:** Referral pack ready for the VC chair (deadline 17:15 ET). NAV release **held** pending VC approval of the Harbourline fair value and VC determinations on Dunmore and Kinloch.

## 1. Headline

| | USD | NAV/share |
|---|---|---|
| Draft (unvalidated, PV1 as loaded) | 83,024,049.92 | 13.3728 |
| Valuation changes (below) | −973,055.74 | |
| **Validated (pending VC)** | **82,050,994.18** | **13.2161** |
| Movement | −973,055.74 (−1.17%) | **−0.1567** |

Shares outstanding 6,208,417.552 (draft NAV file, capital activity through TD 17-Sep). 82,050,994.18 / 6,208,417.552 = 13.216088… → 13.2161. Cash, receivables, payables and FX (WMR 4pm London 18-Sep, 7.7962 HKD/USD — matches the rate used in the draft) are unchanged; I re-footed the draft: the 16 lines sum to 83,024,049.92 and HKD cash 1,204,388.10 / 7.7962 = 154,483.99 as booked.

## 2. Exceptions — price used and why

Sources: `inputs/pricing/price_tolerance_exceptions_PX-0918-1640.csv`, `primary_vendor_PV1_prices_20260911_20260918.csv`, `secondary_vendor_PV2_prices_20260911_20260918.csv`, `market_data_checks_20260918.csv`, `inputs/notices/hkex_trading_halt_harbourline_20260918.txt`, `inputs/pricing/broker_run_halbrook_20260918.txt`, `inputs/policies/AGOF_valuation_procedures_rule2a5_extract.md` (cited as "s.x").

| Security | Draft price | Price used | Source | Basis | VC? | NAV impact USD |
|---|---|---|---|---|---|---|
| Tessaly Networks (USMP0CF01248) | 71.85 | **64.12** | PV2 (source override) | Tolerance breach 10.76%. Exchange official close 64.12 = PV2. s.5.2 | No | −695,700.00 |
| Marlow Chemicals (US253T655745) | 38.90 | 38.90 | PV1 | Tolerance breach 5.53%. Exchange official close 38.90 = PV1. s.5.2 | No | 0.00 |
| Brisk Logistics (USQEZIS13832) | 22.15 | **21.80** | PV2 (source override) | PV1 22.15 on 15/16/17/18-Sep = stale (s.5.3). PV2 not stale; exchange close 21.80 = PV2 | No | −84,000.00 |
| Harbourline Ports (HK0000482171) | HKD 18.64 | **HKD 18.0119** | FV-HALT-01 (s.6.1) | Halted whole 18-Sep session. 18.64 × 4650.20 / 4812.35 = 18.0119 | **Yes — approval** | −193,355.74 |
| Dunmore Paper 6.25% 2031 (USM7JV5G9616) | 97.125 | 97.125 (carried) | PV1 | PV1 and PV2 both 97.125 every day 11–18 Sep = both stale (s.5.3) | **Yes — review** | 0.00 |
| Kinloch Energy 7.50% 2030 (US6PEDD69677) | 99.400 | 99.400 | PV1 | Single-source; Halbrook indicative 94/96 differs >2 pts (s.5.4). PV1 challenged | **Yes — review** | 0.00 |
| | | | | | **Total** | **−973,055.74** |

Working:
- Tessaly: 90,000 × (64.12 − 71.85) = −695,700.00. PV1's 71.85 is exactly its 17-Sep close; the stock cut Q3 guidance at 07:30 ET and traded 4.1× ADV (Dami's note), so PV1 looks like a carry-forward error. Challenge to PV1.
- Marlow: exchange close agrees with PV1, so PV1 stands; PV2 41.05 challenged. Reported as a resolved breach, no impact.
- Brisk: passed tolerance (1.58%) but s.5.3 says a stale price does not pass validation even if within tolerance. 240,000 × (21.80 − 22.15) = −84,000.00. Challenge to PV1.
- Harbourline: HKEX notice — halt from 09:00 HKT 18-Sep for the whole session pending a takeover-code announcement; last trade HKD 18.64 on 17-Sep. Both vendors simply carried 18.64 (price type LAST_TRADE), so the tolerance "PASS" is not a market quotation. s.6.1 requires fair value under FV-HALT-01 with the Schedule B benchmark HKIND (s.6.3): 18.64 × (4650.20 / 4812.35) = 18.011933… → **18.0119** (4dp). USD: 2,400,000 × 18.0119 / 7.7962 = 5,544,824.40 vs draft 5,738,180.14 → −193,355.74. We calculate; the VC must approve before release (s.6.1, s.7.1).
- Dunmore: no non-stale Approved Source price exists, so per s.5.3 we carry the latest Approved Source price (97.125) and refer to the VC the same day. Challenges to both vendors.
- Kinloch: PV2 does not cover it. The only other indication is Halbrook's run (14:02 ET), which is explicitly "indicative, not an offer or firm bid" — under s.4.2 it is not an Approved Source, only challenge evidence. 99.40 − 96.00 = 3.40 pts (4.40 vs mid 95) > 2.00 pts, so s.5.4: (a) challenge PV1, (b) refer to VC; **PV1 99.40 continues to be used unless and until the VC determines otherwise.** For the VC's information only: at 95.00 the impact would be 8,000,000 × (95.00 − 99.40)/100 = −352,000.00 (≈ −0.0567/share). Not in the validated figures.

## 3. Stale-price screen (s.5.3: identical to the same source on each of the previous three business days)

Stale tonight: **Brisk (PV1)** and **Dunmore (PV1 and PV2)**. Not stale but worth noting: Quenby Health (57.10 on 16/17/18-Sep, 15-Sep was 56.95 — becomes stale if 57.10 comes in again Monday); Tessaly PV1 and Harbourline (two identical days). Everything else moved daily.

## 4. The PM's email (Rafe Ingledew, 15:48 ET) — how it has been handled

Rafe asked us to (1) mark Kinloch at 95 (Halbrook mid) and (2) keep Harbourline at 18.64, and says he has told the VC chair.

- s.3.2: portfolio management may not determine or approve a value and may not direct the Administrator to use a price; such requests are forwarded to the VC chair and **not actioned** by the Administrator. s.3.1: only the VC may approve a fair value. s.4.2: an indicative broker run is not an Approved Source.
- Accordingly neither request has been actioned. Both are forwarded to the VC chair with the referral pack, together with the Halbrook run and the HKEX notice, as information/challenge evidence for the 17:30 meeting. Tonight's prices are the s.5/s.6 prices: Kinloch PV1 99.40; Harbourline FV-HALT-01 18.0119. If the VC minutes a different determination we re-strike at the approved price (s.7.2).
- "I've told the VC chair" is not a VC determination. I have asked the VC chair to confirm in writing whether anything has been agreed; we have nothing on file.
- I am sending Rafe a short reply explaining the above and that he can provide information directly to the VC. I am also copying the CCO on the exceptions report for the record (no decision requested), given the June conversation — the PM approached the Administrator directly with specific marks, and the trail should show it was handled under s.3.2.

## 5. Actions (mirrors `answer.json` → actions)

1. **Escalate to VC chair by 17:15 ET:** Harbourline FV-HALT-01 18.0119 for approval; Dunmore (both stale) and Kinloch (single-source divergence) for review; PM email attached.
2. **Hold NAV release** until VC approval/determinations received (s.7.1).
3. **Accounting system:** load 64.12 (Tessaly), 21.80 (Brisk), HKD 18.0119 (Harbourline, flagged pending VC). Net assets 82,050,994.18; NAV/share 13.2161.
4. **Price challenges — PV1:** Tessaly 71.85, Brisk 22.15 (stale), Kinloch 99.40 (s.5.4 challenge with Halbrook evidence, no prints since 27-Aug), Dunmore 97.125 (stale).
5. **Price challenges — PV2:** Marlow 41.05, Dunmore 97.125 (stale); request coverage of Kinloch.
6. **Notify PM** (s.3.2 response) and **CCO** (for the record). **Daily exceptions report** to you (s.7.3).
7. **No action:** Halbrook run not used as a price; Quenby retained (not stale), watch for Monday.

## 6. Assumptions and what I need

- Business days for the stale test are the vendor price dates in the files (11, 14, 15, 16, 17, 18 Sep).
- "Carries the latest Approved Source price" for Dunmore = the PV1 97.125 as supplied for 18-Sep (identical to prior days).
- FV-HALT-01 applied mechanically per Schedule B; any deal-specific adjustment for the possible takeover is the VC's call, not ours, and I have said so in the referral.
- Rounding: fair value to 4dp local; USD market values to the cent; NAV/share to 4dp (half-up).
- **From the VC (tonight):** approval of 18.0119; determinations on Dunmore and Kinloch; written confirmation of anything agreed with the PM.
- **From PV1:** explanation of Tessaly 71.85 and whether other 18-Sep closes were carried forward (no evidence of that in the other US names, which agree with PV2 within 0.03%).
- **From the desk / VC:** any TRACE history for Kinloch — none in the folder beyond Halbrook's "no prints since 08/27".
- Confirm there is no 18-Sep capital activity that changes shares outstanding before the strike.
