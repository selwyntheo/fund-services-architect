# BEIO — September 2026 Section 19(a) notice: final figures and review of draft v1

**To:** Nadia Okonkwo, Treasurer, Brightwater Equity Income Opportunities Fund
**From:** Oakhurst Fund Administration, CEF Administration
**Date:** Thu 24 Sep 2026
**Re:** Distribution FY26-11, $0.1150/share, record 14-Sep-2026, payable 30-Sep-2026

## 1. Bottom line

1. **A 19(a) notice is required.** Part of the September distribution is from realized gains and part is return of capital.
2. **Kieran's draft v1 should not go to Harwick.** The cumulative and current source figures are wrong (three methodology errors), one performance line is off by 1 bp, and the draft is missing the standard legends and the required changed-estimate statement.
3. **Final figures (book basis, procedures v1.6):**

| Source | Current $/sh | Current % | Cumulative FYTD $/sh (11/1/25–9/30/26) | Cumulative % |
|---|---|---|---|---|
| Net investment income | 0.0586 | 51.0% | 0.6578 | 52.8% |
| Net realized short-term gains | 0.0092 | 8.0% | 0.3295 | 26.5% |
| Net realized long-term gains | 0.0000 | 0.0% | 0.0000 | 0.0% |
| Return of capital | 0.0472 | 41.0% | 0.2577 | 20.7% |
| **Total** | **0.1150** | **100.0%** | **1.2450** | **100.0%** |

| Performance line (as of 31-Aug-2026, NAV $15.4180) | Value |
|---|---|
| Average annual total return, 5 years (NAV) | 7.84% |
| Annualized current distribution rate (0.1150 × 12 ÷ 15.4180) | 8.95% |
| Cumulative total return, FYTD (NAV) | 9.12% |
| Cumulative FYTD distribution rate (1.2450 ÷ 15.4180) | **8.07%** (draft 8.08%) |

4. **Last month's notice was wrong in a significant amount and this must go to the CCO before release** (procedure 5.1; Rule 19a-1(e)). Details in section 4.
5. **Talia's request cannot be accommodated.** Sources must be book basis (procedure 4.1; Rule 19a-1); the tax estimate is a different measurement for a different purpose. Details in section 5.
6. **No Rule 19a-1(b) deficit statement is needed** — the aggregate of accumulated realized gains and unrealized appreciation after the payment is a surplus of about $51.4m.

## 2. Inputs relied on

| File | Used for |
|---|---|
| `inputs/policies/BEIO_managed_distribution_plan_19a_procedures.md` (v1.6) | Method: 4.1 book basis; 4.2 NII available; 4.3 realized gains not forecast; 4.4 aggregate net profits; 4.5 ordering; 4.6 cumulative/previous/current; 4.7 rounding; 5.1 $0.0100 threshold; 6.2 timetable |
| `inputs/accounting/BEIO_book_income_and_realized_gains_FY2026.csv` | Monthly book NII, ST and LT realized (Nov-25 to Aug-26 FINAL; Sep-26 MTD to 23-Sep, daily NAV, unaudited) |
| `inputs/accounting/BEIO_nii_accrual_forecast_20260924_20260930.csv` | NII forecast 24–30 Sep: $265,910 (realized gains: not forecast) |
| `inputs/accounting/BEIO_capital_accounts_20251031_and_20260923.csv` | Opening undistributed NII $412,540; opening accumulated realized $0; unrealized appreciation $51,377,815 at 23-Sep; 18,420,000 shares, no FY2026 share activity |
| `inputs/distributions/BEIO_distribution_history_FY2026.csv` | 11 distributions FY26-01 to FY26-11; $0.1100 × 4 + $0.1150 × 7 = $1.2450; $22,932,900 |
| `inputs/performance/BEIO_performance_summary_20260831.csv` | NAV $15.4180 (31-Aug), 5-yr AATR 7.84%, FYTD TR 9.12%; NAV $15.2915 (31-Jul) |
| `inputs/notices/BEIO_19a_notice_2026-08_AS_SENT.txt` | Prior cumulative estimates for the 5.1 test |
| `inputs/notices/BEIO_19a_notice_2026-09_DRAFT_v1.txt` | Draft under review |
| `inputs/tax/BEIO_tax_character_estimate_FY2026_20260915.csv`, `inputs/correspondence/email_Ruiz_marketing_20260923.txt` | Marketing request (section 5) |

Shares used throughout: 18,420,000 (record date 14-Sep-2026; unchanged all year).

## 3. Re-performance

### 3.1 Sources available through 30 September (procedure 4.6(a))

| Item | $ |
|---|---|
| Opening undistributed NII at 31-Oct-2025 | 412,540 |
| Book NII Nov-25 to Aug-26 (10 FINAL months) | 10,625,010 |
| Book NII Sep MTD (1–23 Sep) | 812,640 |
| NII accrual forecast 24–30 Sep | 265,910 |
| **NII available** | **12,116,100** |
| ST realized gains FYTD (through 23-Sep) | 9,400,950 |
| LT realized FYTD (through 23-Sep) | (3,332,350) |
| **Net realized gains available (4.4: LT loss reduces ST; LT shown as zero)** | **ST 6,068,600; LT 0** |

Monthly NII: 1,041,220 + 1,098,730 + 1,012,455 + 987,610 + 1,076,340 + 1,054,905 + 1,088,270 + 1,102,615 + 1,069,480 + 1,093,385 = 10,625,010.
Monthly ST: 905,410 + 1,120,330 + 640,275 − 212,840 + 1,301,560 + 988,120 + 1,175,400 + 854,930 + 1,012,655 + 1,146,890 + 468,220 = 9,400,950.
Monthly LT: 410,250 − 620,480 − 1,244,300 − 705,110 + 318,940 − 402,660 − 915,770 + 210,330 − 380,540 + 295,420 − 298,430 = (3,332,350).

Attribution of cumulative distributions $22,932,900 in 4.5 order: NII 12,116,100 → ST 6,068,600 → LT 0 → ROC 4,748,200.
Per share (÷ 18,420,000, 4 dp): NII 0.6578; ST 0.3295; LT 0.0000; ROC balancing to 1.2450 = 0.2577.

### 3.2 Previous cumulative through 31 August, final books (procedure 4.6(b))

NII available = 412,540 + 10,625,010 = 11,037,550. ST FYTD 8,932,730; LT FYTD (3,033,920) → ST available 5,898,810; LT 0.
Cumulative distributions through August: $20,814,600 ($1.1300/share).
Attribution: NII 11,037,550 → ST 5,898,810 → LT 0 → ROC 3,878,240.
Per share: NII 0.5992; ST 0.3202; LT 0.0000; ROC 0.2106 (balancing to 1.1300).

### 3.3 Current September distribution (procedure 4.6(c) = 3.1 − 3.2)

| Source | $ | ÷ shares | Per share | % of 0.1150 |
|---|---|---|---|---|
| NII | 1,078,550 | 0.058553 | 0.0586 | 51.0% |
| ST gains (Sep net realized: +468,220 ST − 298,430 LT) | 169,790 | 0.009218 | 0.0092 | 8.0% |
| LT gains | 0 | — | 0.0000 | 0.0% |
| ROC (balancing) | 869,960 | 0.047229 | 0.0472 | 41.0% |
| Total | 2,118,300 | | 0.1150 | 100.0% |

Convention note: I computed the current column from dollar differences and then converted to per share. If instead the rounded per-share cumulative columns are differenced (0.3295 − 0.3202), ST is 0.0093 and ROC 0.0471 (8.1% / 41.0%). The procedures do not specify; please confirm which convention you want documented in the workpaper. The dollar-based figures are shown above and in `answer.json`.

### 3.4 Performance lines

* Annualized current rate: 0.1150 × 12 ÷ 15.4180 = 8.951% → **8.95%** (draft agrees).
* Cumulative FYTD rate: 1.2450 ÷ 15.4180 = 8.0750% → **8.07%** (draft 8.08% — incorrect).
* 5-yr AATR 7.84% and FYTD cumulative total return 9.12% taken from the performance summary as at 31-Aug-2026; I have no return series to recompute them.

### 3.5 Rule 19a-1(b) deficit test

Payment is partly from realized gains, so the test applies. After giving effect to the payment: accumulated undistributed realized gains = opening 0 + FYTD net 6,068,600 − 6,068,600 attributed = 0; net unrealized appreciation at 23-Sep = 51,377,815. Aggregate is a surplus; **no deficit statement required**.

## 4. Errors in draft v1 and in the August notice as sent

| # | Item | Draft / Aug notice | Corrected | Cause |
|---|---|---|---|---|
| 1 | Cumulative ST gains | 0.5104 | 0.3295 | Gross FYTD ST used; LT net loss (−$3.33m) not netted (4.4). Draft note "LT is a net loss for the year so shown as zero" applied only half of 4.4. |
| 2 | Cumulative NII | 0.6354 | 0.6578 | Opening undistributed NII $412,540 ($0.0224/share) omitted (4.2). August notice did include it (0.5992), so the draft also breaks continuity with the prior notice. |
| 3 | Cumulative ROC | 0.0992 (8.0%) | 0.2577 (20.7%) | Consequence of 1 and 2. |
| 4 | Current column | NII 0.0586 / ST 0.0254 / ROC 0.0310 | 0.0586 / 0.0092 / 0.0472 | Draft used September-only NII and September gross ST; 4.6(c) requires cumulative minus previous cumulative. NII coincides because September NII is the entire NII increment. |
| 5 | Cumulative FYTD distribution rate | 8.08% | 8.07% | Rounding/arithmetic. |
| 6 | Legends / statements | Omitted | Plan paragraph; "You should not draw any conclusions…"; estimates-not-for-tax / Form 1099-DIV; **statement that previously reported estimates have changed (5.1(ii))** | 3.3, 5.1. |
| 7 | **August notice as sent, cumulative** | NII 0.5992 / ST 0.4849 / LT 0 / ROC 0.0459 | NII 0.5992 / ST 0.3202 / LT 0 / ROC 0.2106 | Same LT-netting error: 0.4849 = gross ST $8,932,730 ÷ 18.42m exactly. ST overstated / ROC understated by **$0.1647/share**, vs the $0.0100 threshold in 5.1. |

**Consequence of item 7 (this is the item that needs to go beyond you):** under procedure 5.1 the August estimates are inaccurate in a significant amount (Rule 19a-1(e)). The procedures require (i) notification of the **Chief Compliance Officer** and the Treasurer before the September notice is released, (ii) a statement in the September notice that previously reported cumulative estimates have changed, and (iii) a flag for the next report to shareholders. I have not released anything; I recommend you and I notify the CCO today so the September notice is not delayed. The CCO should also decide whether the Board needs to be informed under the Plan's exemptive conditions and whether any corrective posting for August is warranted. The August current column (ST 0.0556 appears to be 0.1150 − 0.0594 as a plug) also does not reconcile to the procedures, and I cannot see the pre-August notices — if the same method was used all year, the correction statement may need to cover them (see open questions).

## 5. Marketing's request (T. Ruiz, 23-Sep)

We cannot line the notice up with the tax team's estimate, for four reasons:

1. **Procedure 4.1** (and Rule 19a-1(c) "good accounting practice") requires sources from the US GAAP books to the close of the month of payment, and says expressly that tax-basis character estimates for Form 1099-DIV are not used for 19(a).
2. The tax estimate is a **full-fiscal-year projection of 12 distributions including October** ($1.2450 total), not a source analysis of distributions paid to date.
3. It reflects **tax-only items** — IRC §1092 straddle-loss deferrals, wash-sale deferrals and REIT/MLP recharacterisations — which is why it shows $0.3038 of LT gain where the books show a FYTD LT net loss of $3.33m, and zero ROC where the books show $4.75m.
4. Publishing zero ROC when the books show 41% of the current distribution is ROC would misstate the sources to shareholders in a regulatory notice. The notice legend already tells shareholders the estimates are not for tax purposes and that 1099-DIV character may differ; that is the answer to wirehouse questions.

I have recorded the request as declined and suggest you copy the CCO on the reply given that it asked for a regulatory notice to be changed for optics.

## 6. Timetable

Today (Thu 24-Sep) is the business day before Harwick's deadline; TA insert file due 12:00 ET Fri 25-Sep (third business day before 30-Sep payment); press release no later than Mon 28-Sep (6.2). On your approval of v2 and CCO notification, we can meet the insert deadline.

## 7. Assumptions

* September NII = actual to 23-Sep ($812,640) + forecast 24–30 Sep ($265,910) per 4.2; realized gains actual to 23-Sep, not forecast per 4.3. Figures are estimates and will be re-tested against final September books next month.
* Shares of record 14-Sep-2026 = 18,420,000 (capital accounts file: no issuance or repurchase in FY2026).
* Current column derived from dollar differences (see 3.3 note).
* Deficit test uses unrealized appreciation at the 23-Sep daily NAV.

## 8. What I need

* **From you:** approval of the corrected figures; confirmation of the current-column rounding convention; go-ahead to notify the CCO jointly today.
* **From you / the CCO:** decision on scope of the prior-notice correction (August only, or earlier FY2026 notices if they used the same method — please send the Nov-25 to Jul-26 notices as sent), and whether the Board is to be informed.
* **From marketing:** nothing further; reply drafted as above.
* **From tax:** nothing; their estimate is not an input to this notice.
