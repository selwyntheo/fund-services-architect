# GACP II — Distribution 8 (Delphine): Article 9 waterfall, per-investor amounts and GP payment

**To:** Jonas Whitcombe, Director, PE Fund Accounting
**From:** GACP II fund accounting
**Date:** 18 September 2026
**Re:** Distribution No. 8, USD 112,000,000.00, payment date Wednesday 30 September 2026

## 1. Bottom line

| | USD |
|---|---|
| Distributable Proceeds (IC consent 16 Sep 2026) | 112,000,000.00 |
| GP Commitment distribution (LPA 9.3, not carry) | 2,240,000.00 |
| Apportioned to Limited Partners (LPA 9.1) | 109,760,000.00 |
| — paid to Limited Partners | 87,808,000.00 |
| — Carried Interest (LPA 9.2(c) + 9.2(d)(ii)) | 21,952,000.00 |
| — of which to Carry Escrow Account 4471-2290 (LPA 9.6, 25%) | 5,488,000.00 |
| — of which carry to GP operating account | 16,464,000.00 |
| **Total wire to GP operating account (SSI-II-014)** | **18,704,000.00** |
| **Total wire to Carry Escrow (SSI-II-015)** | **5,488,000.00** |
| **Total wires to LPs** | **87,808,000.00** |
| Check: 87,808,000.00 + 21,952,000.00 + 2,240,000.00 | 112,000,000.00 |

Three points for Marcus:

1. **The carry is USD 21,952,000.00, not ~USD 16.4mm.** Their number is 20% x (112mm − 30mm Delphine cost) = 16,400,000 exactly, i.e. a deal-by-deal calculation on Delphine alone. GACP II's LPA (Section 9.2) is a whole-of-fund waterfall run separately for each LP "taking into account all prior distributions". On that basis every LP had already had 100% of its Capital Contributions (including fees and expenses) returned before this distribution, and the remaining 8% Preferred Return hurdle across the LPs is USD 73.8mm against an LP share of USD 109.76mm. The catch-up therefore completes in this distribution and the GP ends up with exactly 20% of the LP apportionment. Their approach ignores (i) the GP's own 2% Commitment share, (ii) the USD 49.5mm of fees and expenses that count as Capital Contributions, (iii) the USD 324.4mm already distributed to LPs, and (iv) the fund-level pref position. It understates gross carry by USD 5,552,000.00.
2. **Only USD 16,464,000.00 of carry can be wired to the GP on 30 September.** LPA 9.6 requires 25% of every Carried Interest distribution (USD 5,488,000.00) to be paid into the Carry Escrow Account (Halcyon Trust Services 4471-2290, SSI-II-015), released only on liquidation or under the 9.7 clawback. Marcus's 17 Sep request to wire "the carry amount" to the GP operating account cannot be followed as written. That the post-escrow cash (16.464mm) is close to their 16.4mm is coincidence; partners' cash planning should be USD 16,464,000.00 now plus USD 5,488,000.00 in escrow.
3. **The GP also receives USD 2,240,000.00 for its own Commitment** (2% of 112mm) under 9.3. It is not carry, is not escrowed and must be shown separately on the GP notice and in the wire reference, consistent with how Distributions 1–7 booked GP_COMMITMENT_RETURN.

## 2. Sources relied on (all in `inputs/`)

| File | Used for |
|---|---|
| `lpa/GACP_II_LPA_excerpt_distributions.md` | Art. 1 definitions (Capital Contributions incl. fees/expenses; Preferred Return = 8% compounded, 1.08^(d/365)); 9.1 apportionment by Commitment; 9.2 tiers (a)–(d); 9.3 GP Commitment; 9.4 rounding to cent per Partner per tier; 9.6 25% carry escrow to 4471-2290; 9.8 notice content |
| `investor_records/partner_register_GACP_II.csv` | Commitments: GP-0020 6,000,000; LP-0021 60,000,000; LP-0022 50,000,000; LP-0023 45,000,000; LP-0024 35,000,000; LP-0025 40,000,000; LP-0026 24,000,000; LP-0027 40,000,000; total 300,000,000. All LPs CARRY_BEARING; GP CARRY_FREE |
| `capital_activity/contributions_GACP_II_inception_to_20260917.csv` | 475 contribution lines, 54 due dates 1 Jul 2015 – 1 Jul 2026. LP total 270,009,600.00 (investments 220,500,000.00; management fees 44,511,600.00; organizational/partnership expenses 4,998,000.00). GP total 4,602,000.00 |
| `capital_activity/distributions_GACP_II_inception_to_20260917.csv` | Distributions 1–7 (30 Nov 2018 – 30 Jun 2025), total 331,000,000.00: LPs 324,380,000.00 (all booked LP_TIERS_1_2, carry 0.00); GP 6,620,000.00 (GP_COMMITMENT_RETURN) |
| `correspondence/2026-09-16_GP_distribution_approval_Delphine.txt` | Distributable Proceeds 115,420,000.00 (Delphine) + 3,300,000.00 (Varro escrow release) − 6,720,000.00 retention = 112,000,000.00; distribution date 30 Sep 2026 |
| `correspondence/2026-09-17_feld_email_carry.txt` | GP finance team's ~16.4mm deal-by-deal estimate and instruction to wire carry to GP operating account |
| `treasury/standing_settlement_instructions_GACP_II.csv` | SSI-II-001 Partnership 4471-2201; SSI-II-014 GP operating, First Calder Bank 00-771934-2; SSI-II-015 Carry Escrow 4471-2290 — all ACTIVE and callback-verified |
| `investor_records/portfolio_realizations_GACP_II.csv` | Corroborates Delphine proceeds/cost and that Ashgrove remains unrealized (FV 41,500,000 at 30 Jun 2026) |

## 3. Method (re-performable from the inputs above)

1. **Apportion (9.1):** 112,000,000.00 x Commitment / 300,000,000.00, rounded to the cent. GP 2,240,000.00; LPs 109,760,000.00.
2. **Tier (a) return of capital:** for each LP, unreturned capital = max(0, cumulative Capital Contributions − cumulative prior distributions). Every LP is already over-returned (e.g. LP-0021: 55,104,000.00 contributed vs 66,200,000.00 received), so tier (a) = 0.00 for all.
3. **Tier (b) Preferred Return** as at 30 Sep 2026 per Art. 1: Σ contribution_i x 1.08^(days_i/365) − Σ prior distribution_j x 1.08^(days_j/365) − unreturned capital (nil). Days are actual calendar days from each contribution due date / distribution date to 30 Sep 2026. Because prior distributions already returned capital and part of the pref, the pref still owed is the shortfall to an exact 8% compounded IRR; I cross-checked that after tier (b) each LP's cash flows (contributions negative, distributions positive, tier (b) on 30 Sep) have a zero NPV at 8%.
4. **Tier (c) catch-up:** 80% GP / 20% LP until GP catch-up = 20% x (tier (b) + tier (c)). Solving, total tier (c) = tier (b) / 3 and GP share = 0.8 x that. Each LP's apportionment is large enough to complete it.
5. **Tier (d):** residual 80% LP / 20% GP.
6. **Rounding:** each tier per LP rounded half-up to the cent (9.4); GP catch-up and 80/20 shares rounded; LP receives the residual so each LP's tiers sum exactly to its apportionment.
7. **Escrow (9.6):** 25% of total Carried Interest to 4471-2290.

## 4. Fund-level tiers, this distribution

| Tier | To LPs | To GP |
|---|---|---|
| (a) Return of capital | 0.00 | — |
| (b) Preferred Return | 73,827,790.16 | — |
| (c) Catch-up | 4,921,852.68 | 19,687,410.71 |
| (d) 80/20 split | 9,058,357.16 | 2,264,589.29 |
| **Total** | **87,808,000.00** | **21,952,000.00** (Carried Interest) |

Catch-up complete for all seven LPs: yes.

## 5. Per-investor amounts for the notices (USD)

| Partner | Commitment | Apportioned | Cum. contributions | Prior distributions | (a) | (b) Pref | (c) LP 20% | (d) LP 80% | **Cash to LP** | Carry attributable | of which escrow (25%) |
|---|---|---|---|---|---|---|---|---|---|---|---|
| LP-0021 Aldermoor SERS | 60,000,000 | 22,400,000.00 | 55,104,000.00 | 66,200,000.00 | 0.00 | 15,066,895.95 | 1,004,459.73 | 1,848,644.32 | **17,920,000.00** | 4,480,000.00 | 1,120,000.00 |
| LP-0022 Brightwater Teachers | 50,000,000 | 18,666,666.67 | 45,920,000.00 | 55,166,666.67 | 0.00 | 12,555,746.63 | 837,049.78 | 1,540,536.93 | **14,933,333.34** | 3,733,333.33 | 933,333.33 |
| LP-0023 Meridian Crossing FoF II | 45,000,000 | 16,800,000.00 | 41,328,000.00 | 49,650,000.00 | 0.00 | 11,300,171.96 | 753,344.80 | 1,386,483.24 | **13,440,000.00** | 3,360,000.00 | 840,000.00 |
| LP-0024 Northfield Univ. Endowment | 35,000,000 | 13,066,666.67 | 32,144,000.00 | 38,616,666.67 | 0.00 | 8,789,022.64 | 585,934.84 | 1,078,375.86 | **10,453,333.34** | 2,613,333.33 | 653,333.33 |
| LP-0025 Tamsin Bay Insurance | 40,000,000 | 14,933,333.33 | 36,736,000.00 | 44,133,333.33 | 0.00 | 10,044,597.30 | 669,639.82 | 1,232,429.54 | **11,946,666.66** | 2,986,666.67 | 746,666.67 |
| LP-0026 Harrowgate Holdings | 24,000,000 | 8,960,000.00 | 22,041,600.00 | 26,480,000.00 | 0.00 | 6,026,758.38 | 401,783.89 | 739,457.73 | **7,168,000.00** | 1,792,000.00 | 448,000.00 |
| LP-0027 Corran Valley Foundation | 40,000,000 | 14,933,333.33 | 36,736,000.00 | 44,133,333.33 | 0.00 | 10,044,597.30 | 669,639.82 | 1,232,429.54 | **11,946,666.66** | 2,986,666.67 | 746,666.67 |
| **LPs total** | 294,000,000 | 109,760,000.00 | 270,009,600.00 | 324,380,000.00 | 0.00 | 73,827,790.16 | 4,921,852.68 | 9,058,357.16 | **87,808,000.00** | 21,952,000.00 | 5,488,000.00 |
| GP-0020 Granite Arch GP II (Commitment, 9.3) | 6,000,000 | 2,240,000.00 | 4,602,000.00 | 6,620,000.00 | n/a | n/a | n/a | n/a | **2,240,000.00** | — | — |

Per-LP escrow split shown for notice purposes (9.8 requires the escrowed amount to be disclosed); the escrow wire is a single USD 5,488,000.00.

Worked example, LP-0021: FV of contributions at 8% to 30 Sep 2026 = 110,615,948.45; FV of prior distributions = 95,549,052.50; unreturned capital 0 → Preferred Return 15,066,895.95. Tier (c) = 15,066,895.95 / 3 = 5,022,298.65 (GP 4,017,838.92 = 20% x (15,066,895.95 + 5,022,298.65); LP 1,004,459.73). Residual 22,400,000.00 − 15,066,895.95 − 5,022,298.65 = 2,310,805.40 → LP 1,848,644.32 / GP 462,161.08. LP cash 17,920,000.00; carry 4,480,000.00 (= 20% x 22,400,000.00).

## 6. Prior distributions check

For each of Distributions 1–7 I confirmed that cumulative LP distributions to that date remained below cumulative contributions compounded at 8% (e.g. LP-0021 at Distribution 7, 30 Jun 2025: shortfall to 8% IRR still USD 13.3mm). Booking all prior LP distributions as tiers 1–2 with nil carry was therefore correct, and no catch-up had begun before Distribution 8. This is consistent with Jonas's note that everything to date has gone to partners pro rata.

## 7. Payment instructions for 30 September 2026 (from Partnership operating account SSI-II-001)

| Beneficiary | SSI | Amount USD | Reference |
|---|---|---|---|
| Seven LPs (per table above) | LP SSIs on file (not in extract — to be confirmed) | 87,808,000.00 | GACP II Distribution 8 — Delphine |
| Carry Escrow Account, Halcyon Trust Services 4471-2290 | SSI-II-015 | 5,488,000.00 | LPA 9.6 — 25% of Carried Interest, Distribution 8 |
| Granite Arch GP II, LLC, First Calder Bank 00-771934-2 | SSI-II-014 | 18,704,000.00 | Carried Interest 16,464,000.00 + GP Commitment distribution 2,240,000.00 |
| **Total** | | **112,000,000.00** | |

The GP wire is on hold pending Marcus's acknowledgement of the escrow split and GP sign-off of the notices.

## 8. Assumptions

- Extracts are complete and final to 17 Sep 2026 and there is no capital activity dated 18–30 Sep 2026 (the next management-fee call would ordinarily fall on 1 Oct 2026, after the distribution date).
- Measurement date for the Preferred Return is the distribution date, 30 Sep 2026 (the LPA measures "as of any date" and the distribution occurs on that date); actual/365 day count with 1.08^(d/365) as the LPA defines.
- Prior distributions are used at their booked cash amounts and dates; no prior tier reclassification is needed (section 6).
- The operational LPA extract reflects the executed agreement; no side letters, excused-investor, defaulted-partner, fee-offset or withholding provisions alter the pro rata result.
- The IC's USD 6,720,000.00 retention is at the GP's discretion; when released it will be a further carry-bearing distribution (LP share entirely tier (d) 80/20, 25% of carry to escrow).

## 9. What I need and from whom

- **Marcus Feld (GP CFO):** acceptance of the whole-of-fund result (gross carry 21,952,000.00; 16,464,000.00 cash / 5,488,000.00 escrow); withdrawal of the instruction to wire full carry to the GP account; confirmation of no capital activity before 30 Sep; confirmation of the 6,720,000.00 retention and that Delphine transaction costs were not separately called from partners; any side-letter/withholding items.
- **Treasury:** callback-verified LP SSIs (not in the extract provided) before release of the 30 Sep wires.
- **Fund auditor:** heads-up that this is the first carry-generating distribution; per-LP workpapers (this memo, sections 3–5) available for re-performance.
- **Jonas:** approval to issue draft notices to the GP by 24 Sep with the tier disclosures required by LPA 9.8, and to hold the GP wire at 18,704,000.00.
