# ADGF — 18 Sep 2026 class NAV review and strike

**To:** Priya Castellane, NAV Oversight Manager
**From:** NAV review (covering for Marco)
**Re:** Aldermoor Dividend Growth Fund — final NAVs for 18 Sep 2026, expense cap worksheet, Aldermoor Class A recoupment request

## 1. Final NAVs for transmission

| Class | Shares outstanding (through TD 17 Sep) | Class net assets (before 18 Sep capital activity) | NAV 4dp | Published | System draft 4dp | Draft would have published |
|---|---|---|---|---|---|---|
| A | 6,412,337.218 | 117,687,765.21 | 18.3533 | **18.35** | 18.3581 | 18.36 |
| C | 1,905,441.502 | 33,986,943.63 | 17.8368 | **17.84** | 17.8413 | 17.84 |
| I | 11,873,205.664 | 218,961,503.55 | 18.4417 | **18.44** | 18.4383 | 18.44 |
| Total | 20,190,984.384 | 370,636,212.39 | | | | |

Unrounded: A 18.35333377, C 17.83678145, I 18.44165003. 4dp round half up; published rounded half up from the unrounded value (Procedure B.5).

Two corrections versus system run NAVRUN-0918-1602 (`inputs/accounting/class_allocation_draft_ADGF_20260918.csv`): (1) the allocation base, and (2) the expense limitation waiver, which the system never books (B.3). Class A's published price changes by one cent as a result. Release is conditional on the override and manual entries being posted and the re-run agreeing to the figures above.

## 2. Correction 1 — allocation base (ALLOCATION_BASE, corrected)

The draft shows `alloc_basis = TD_SHARES_INCL_CURRENT` with bases A 117,882,852.41 / C 34,060,821.98 / I 247,070,854.68. These equal the 17 Sep final class net assets plus today's PENDING NAV flows from `inputs/transfer_agent/ta_capital_activity_ADGF_20260917_20260918.csv`:

- A: 118,126,152.53 + 412,000.00 − 655,300.12 = 117,882,852.41
- C: 34,114,262.48 + 38,000.00 − 91,440.50 = 34,060,821.98
- I: 219,775,411.48 + 28,500,000.00 − 1,204,556.80 = 247,070,854.68

Multiple Class Plan §3 requires beginning-of-day net assets adjusted only for trades dated on or before the preceding business day; same-day trades are priced at today's NAV and do not share in today's income, gains or expenses. Procedure B.4 requires the base to agree to the prior-day final; it did not. Correct base = `inputs/accounting/nav_report_ADGF_20260917_final.csv` (FINAL, capital activity through TD 2026-09-17), total 372,015,826.49:

| Class | Base | Ratio used | Draft ratio |
|---|---|---|---|
| A | 118,126,152.53 | 31.752991% | 29.543499% |
| C | 34,114,262.48 | 9.170111% | 8.536236% |
| I | 219,775,411.48 | 59.076898% | 61.920265% |

Fund-level items (`income_and_gains_ADGF_20260918.csv`: dividends 164,385.60, withholding −5,760.00, sweep interest 2,904.18, realised +412,870.40 / −96,212.75, unrealised −1,845,315.92 and FX −1,204.33 = −1,368,332.82; fund expenses 9,075.10) net to −1,377,407.92, agreeing to the draft total. Re-allocated line by line, cent-rounded, residuals to Class I (B.2):

| Class | Fund-level net allocation (corrected) | Draft | Shift |
|---|---|---|---|
| A | −437,368.24 | −406,934.49 | −30,433.75 |
| C | −126,309.83 | −117,578.79 | −8,731.04 |
| I | −813,729.85 | −852,894.64 | +39,164.79 |

Class expenses (12b-1 A 809.08, C 934.64; sub-TA I 602.12; TA per-account A 210 / C 140 / I 60) are unchanged. All asset-based accruals in `expense_accruals_ADGF_20260918.csv` recompute on the correct prior-day bases (management 0.50% × 372,015,826.49 / 365 = 5,096.11; 12b-1 A 0.25% × 118,126,152.53 / 365 = 809.08, etc.), so only the allocation engine used the wrong base. Root cause referred to NAV system support; the 17 Sep final reconciles on the correct basis, so I see no prior-day restatement on the evidence in the folder, but the run history should be checked.

## 3. Correction 2 — expense limitation worksheet (WAIVER_CALCULATION, corrected)

Source: `inputs/agreements/ADGF_expense_limitation_agreement.md` — limits A 1.00% / C 1.75% / I 0.70% (from 2025-03-01); class-by-class (§3); daily test on beginning-of-day class net assets / 365 with the excess, rounded to the cent, accrued first as a management-fee waiver (§4).

**Excluded Expenses (§2):** GL 5160 LOC interest on the 4,000,000 drawn balance 598.14 (§2(i)) and GL 5125 Brightwater litigation 1,643.84 (§2(vi) extraordinary) — total **2,241.98/day**. GL 5170 LOC commitment fee 117.81 on the undrawn facility is an Operating Expense. The 15% withholding tax on the Sorrel dividend sits in income, not in the accrual set (taxes would be excluded anyway). Fund-level Operating Expenses = 9,075.10 − 2,241.98 = 6,833.12.

| Class | Allocated fund OpEx | Class expenses | Operating Expenses | Annualised / BOD NA | Daily limit | Excess → waiver | Allocated mgmt fee |
|---|---|---|---|---|---|---|---|
| A | 2,169.73 | 1,019.08 | 3,188.81 | 0.985316% | 1.00% × 118,126,152.53 / 365 = 3,236.33 | 0.00 (headroom 47.52) | 1,618.17 |
| C | 626.60 | 1,074.64 | 1,701.24 | 1.820214% | 1.75% × 34,114,262.48 / 365 = 1,635.62 | **65.62** | 467.32 |
| I | 4,036.79 | 662.12 | 4,698.91 | 0.780389% | 0.70% × 219,775,411.48 / 365 = 4,214.87 | **484.04** | 3,010.62 |

Total waiver **549.66**, all management-fee waiver (GL 5900 / 1390); no reimbursement component since each class's allocated management fee exceeds its excess. Class A's headroom is not offset against C or I (§3). Register (`ela_waiver_recoupment_register_ADGF.csv`): add 65.62 to C 2026-09 MTD (→ 937.16) and 484.04 to I 2026-09 MTD (→ 6,917.24); recoupment expiry for September 2026 waivers is **2029-09-30** (last day of the 36th month following September 2026).

Class net assets = BOD net assets + fund-level allocation − class expenses + waiver, e.g. Class I: 219,775,411.48 − 813,729.85 − 662.12 + 484.04 = 218,961,503.55.

## 4. Aldermoor request — Class A recoupment (RECOUPMENT_REQUEST, declined tonight; referred to Fund Treasurer)

`inputs/correspondence/email_aldermoor_finance_recoupment_20260918.txt` — Maren Holt asks us to start accruing Class A recoupment from tonight "using whatever headroom there is under the limit", with Board ratification on 10 December. Not booked, for two independent reasons:

1. **Approvals.** ELA §5(b) requires Board approval, and the Administrator may not accrue recoupment until written notice from the Fund Treasurer specifying class and maximum amount. Procedure B.6 prohibits NAV-affecting entries on the Adviser's instruction alone. The register shows no `board_approval_ref` for any row; the Adviser's GC's comfort is not a substitute.
2. **Expense condition.** §5(a) limits recoupment to the lesser of the limit in effect when waived and the current limit. The 2024 Class A waivers (2024-01 to 2024-04, total 16,312.85, register `limit_in_effect_pct` 0.90, expiring 2027-01-31 to 2027-04-30) were accrued under the 0.90% cap. Class A's Operating Expenses today are 3,188.81 versus a 0.90% daily limit of 2,912.70 (0.90% × 118,126,152.53 / 365), i.e. 0.985% annualised — above 0.90%. **Permissible Class A recoupment today, even with all approvals in place: 0.00.** The 47.52 of headroom Maren has in mind exists only against the 1.00% limit, which does not govern the 2024 tranches.

Recoupment accrued tonight: 0.00. Referred to the Fund Treasurer (with a note that at the current run-rate the 2024 Class A tranches will expire unrecouped unless Class A operating expenses fall below 0.90%), Adviser to be informed, CCO copied for awareness. The Adviser's separate point about the Class I platform onboarding is noted in §5.

## 5. Other items reviewed

- **Capital activity.** 17 Sep CONFIRMED trades reprice exactly at 17 Sep 4dp NAVs and are in the 17 Sep final shares. 18 Sep trades (incl. 28,500,000.00 Class I subscription, of which 27,000,000.00 Linwood Retirement Platform omnibus) are PENDING NAV, correctly excluded from tonight's net assets and shares, and must be priced by the TA at the corrected finals (A 18.35, not 18.36). They enter the 21 Sep allocation base, when Class I's share rises to roughly 62%.
- **Accrual rates.** All asset-based and budget-based accruals agree to the Plan / agreement rates on prior-day final bases (see §2). Class A 12b-1 at the post-2025-03-01 0.25% rate.
- **Income.** Totals agree to the system; withholding = 15% × 38,400.00. Holdings and vendor price files are not in the folder, so security-level pricing and the unrealised change were not re-performed.
- **Rounding.** Line-by-line cent rounding with residual to Class I; 4dp and 2dp per B.5.

## 6. Actions and what I need

| Action | Owner |
|---|---|
| Post allocation override (ratios in §2) and re-run; post waiver entries GL 5900/1390 C 65.62, I 484.04; update ELA register | Fund accounting |
| Release A 18.35 / C 17.84 / I 18.44 to NASDAQ once the re-run agrees; send finals to TA for pricing 18 Sep activity | NAV oversight / TA |
| Investigate and correct `TD_SHARES_INCL_CURRENT` allocation basis before the 21 Sep run; provide run history | NAV system support |
| Decide on Aldermoor's Class A recoupment request; confirm Brightwater litigation is an Excluded (extraordinary) expense for the ELA test | Fund Treasurer |
| Inform Maren Holt / Colm Radley that the request is not actioned and why | NAV team (after Treasurer) |

Open questions: (i) whether any final NAV before 17 Sep was struck on the wrong allocation base; (ii) whether any Board approval for Class A recoupment has been minuted; (iii) litigation classification — if GL 5125 were an Operating Expense, Class A would breach its cap and extra waivers of about A 474.42 / C 150.74 / I 971.16 per day would be needed; (iv) Marco to confirm the worksheet rounding convention matches the MTD register; (v) pricing not independently re-performed.
