# TCBF 17 Sep 2026 — Shadow NAV break: findings, corrections and release recommendation

**To:** Anneliese Kroft, NAV Oversight Manager, Pellmore Fund Services
**Re:** Tidewell Core Bond Fund (TCBF) — Tidewell shadow 10.3558 vs Pellmore draft 10.3379
**Prepared:** Thu 17 Sep 2026, before the 19:00 ET release cut-off

## 1. Bottom line

* The whole USD 719,893.44 gap (1.79c/share) is explained by five positions; unexplained residual is **0.00**.
* Four items are on Tidewell's side (their shadow is overstated by USD 745,618.44 in total). One item is ours: **Calloway Freight Lines** was carried forward at yesterday's Vendor A price although Vendor B priced it today. That overstates our draft by **USD 25,725.00**.
* Corrected net assets **USD 415,714,484.87**, NAV **10.3372** (4dp) — still **10.34** at 2dp. Policy 6.3 requires the correction to be booked even though the published figure does not move.
* **Release 10.34 by 19:00 ET.** Do not hold and do not reprice to Tidewell's marks (policy 6.4). No Treasurer delay approval is needed.
* Tonight: report the reconciliation to Tidewell Fund Oversight (Hollis Mbeki) and the pricing matters to the Valuation Designee.

## 2. Files relied on

| File | Used for |
|---|---|
| `inputs/administrator/draft_nav_positions_TCBF_20260917.csv` | Our draft positions, prices, accruals, amortized cost |
| `inputs/administrator/draft_nav_summary_TCBF_20260917.csv` | Draft net assets 415,740,209.87; shares 40,215,337.482; NAV 10.3379 |
| `inputs/adviser/shadow_nav_positions_TCBF_20260917.csv` | Tidewell shadow positions |
| `inputs/adviser/shadow_nav_summary_TCBF_20260917.csv` | Shadow net assets 416,460,103.31; NAV 10.3558 |
| `inputs/pricing/vendor_prices_TCBF_20260917.csv` | Vendor A / Vendor B prices, statuses, prior-day prices, quote convention |
| `inputs/administrator/tax_lots_premium_discount_TCBF.csv` | Quenby lot (par 4,000,000 at 108.500, settle 2025-09-15, 30/360, to maturity 2036-03-15) |
| `inputs/notices/kestrel_auto_2025-2_servicer_report_20260915.txt` | Kestrel A-3 15 Sep paydown: factor 0.68240 -> 0.64118 |
| `inputs/notices/brackett_trustee_notice_and_press_release.txt` | Brackett missed 15 Sep coupon; Chapter 11 filed 16 Sep |
| `inputs/correspondence/email_pm_harrowpoint_price_challenge.txt` | PM price challenge; Vendor A acknowledgement (price stands pending next-day review) |
| `inputs/correspondence/email_tidewell_oversight_shadow_break.txt` | Tidewell's hold/reprice request |
| `inputs/policies/TFT_valuation_income_and_shadow_nav_procedures.md` | Sections 4 (pricing hierarchy), 5 (income, amortization, paydowns, non-accrual), 6 (shadow, release) |

## 3. Tie-out of the gap

Summary lines (shadow minus draft): Investments at value +559,578.00; Interest receivable +160,315.44; all other lines identical. Total **+719,893.44** = 416,460,103.31 - 415,740,209.87. Both position files foot to their summaries (draft MV 406,473,502.00, accrued 4,450,838.63; shadow MV 407,033,080.00, accrued 4,453,654.07 + past-due 157,500.00 = 4,611,154.07).

| # | Position (ISIN) | Shadow - draft (USD) | Cause | Who is right | Our correction |
|---|---|---:|---|---|---:|
| F1 | Harrow Point Energy 5.25% 06/15/34 (US4NCZQ04871) | +84,480.00 | Adviser used PM-supplied broker mid 99.25 vs Vendor A 97.842 | Pellmore | 0.00 |
| F2 | Calloway Freight Lines 6.10% 03/01/30 (USPH76AX8211) | -25,725.00 | We carried forward 101.115; Vendor B 100.380 was available | Tidewell | **-25,725.00** |
| F3 | Quenby Health Partners 6.75% 03/15/36 (USHOWLOR8717) | 0.00 (amortized cost -7,952.96) | Adviser straight-line vs required effective interest | Pellmore | 0.00 |
| F4 | Kestrel Auto 2025-2 A-3 4.62% (USTSSMTX1062) | +501,013.44 | Adviser did not apply 15 Sep paydown factor | Pellmore | 0.00 |
| F5 | Brackett Specialty Retail 7.875% 03/15/29 (USCOHZR54060) | +160,125.00 | Adviser still accruing / carrying missed coupon after Ch.11 | Pellmore | 0.00 |
| | **Total** | **+719,893.44** | | | **-25,725.00** |

Residual: 719,893.44 - (84,480.00 - 25,725.00 + 0 + 501,013.44 + 160,125.00) = **0.00**.

The other nine positions agree in every figure. Their shadow rows are labelled STRAIGHT_LINE against our EFFECTIVE_INTEREST, but all are held at par, so there is nothing to amortize and no numeric difference.

## 4. Position detail

### F1 — Harrow Point Energy (Pellmore correct)
Par 6,000,000. Vendor A evaluated bid **97.842, status OK** (prior day 97.860; Vendor B 97.905). We used it (MV 5,870,520.00). The PM, Tobias Renner, challenged Vendor A at 15:10 ET citing a Coverdale 98.75/99.75 run and told the shadow team to carry the **99.25 mid** (MV 5,955,000.00). Vendor A's auto-acknowledgement (ref VA-CH-2609-4471) says challenges after 14:00 are reviewed next business day and the current price stands.
Policy 4.1 makes Vendor A primary; 4.2-4.4 are only reached if Vendor A is NP or rejected by the VD, which is not the case. Policy 4.6: a challenge does not change the NAV price until the vendor revises or the VD approves a written override; PMs may not supply prices. Difference (99.250 - 97.842) x 60,000 = **84,480.00**. No change to the draft. There is no VD override in the folder (open question).

### F2 — Calloway Freight Lines (Tidewell correct; our correction)
Par 3,500,000. Vendor A: **no price, "NP - insufficient observable inputs"**, prior day 101.115. Vendor B: **100.380, OK**. Our draft carried forward 101.115 (source PRIOR_DAY_CARRY_FORWARD, MV 3,539,025.00); the shadow used Vendor B (MV 3,513,300.00).
Policy 4.2 requires Vendor B when Vendor A is NP; 4.5 allows carry-forward only when no 4.1-4.3 source exists, and requires same-day VD reporting even then. Vendor B was available, so the carry-forward was not permitted. Correction: (100.380 - 101.115) x 35,000 = **-25,725.00** to investments at value / unrealized. Accrued 10,081.94 and amortized cost agree on both sides.

### F3 — Quenby Health Partners (Pellmore correct; no NAV effect)
Both sides: Vendor A 106.214, MV 4,248,560.00, accrued 2,250.00. Amortized cost differs: shadow 4,307,349.21 vs draft 4,315,302.17, i.e. adviser minus administrator **-7,952.96**; daily net income 660.05 vs 679.08.
Re-performance from the tax lot (cost 4,340,000, 21 semi-annual coupons of 135,000, redemption 4,000,000 at 2036-03-15):
* Effective interest (policy 5.2): semi-annual yield 2.83245% (5.66490% p.a.). Amortization 12,071.58 to 15 Mar 2026, 12,413.50 to 15 Sep 2026 (book 4,315,514.92), period-3 amortization 12,765.11 / 180 = 70.92 per day x 3 days (15-17 Sep inclusive, consistent with the 3-day coupon accrual) = 4,315,302.17. **Ties exactly to the draft**; daily NI 750.00 - 70.92 = 679.08.
* Straight line: 340,000 / 3,780 days (30/360, 15 Sep 2025 - 15 Mar 2036) = 89.95 per day x 363 days = 32,650.79 -> 4,307,349.21. **Ties exactly to the shadow.**
Policy 5.2 mandates the constant-yield method and states amortization does not change valuation. Net assets are unaffected (only the NII / unrealized split: unrealized -66,742.17 draft vs -58,789.21 shadow). No change to the draft; Tidewell should align its IBOR method.

### F4 — Kestrel Auto Receivables 2025-2 A-3 (Pellmore correct)
Servicer report: distribution date **15 Sep 2026**, Class A-3 principal 41.22 per 1,000 original, factor **0.68240 -> 0.64118**. Original face 12,000,000 (both files' face / factor). Our draft: face 7,694,160.00 x 101.250 = 7,790,337.00, accrued 2,962.25 (4.62% 30/360 on new face, 987.42/day x 3). Shadow: face 8,188,800.00 (old factor) x 101.250 = 8,291,160.00, accrued 3,152.69, amortized cost 8,188,800.00.
Policy 5.3: paydowns recorded on the distribution date at the published factor; interest accrues on current face from that date. The shadow still holds 494,640.00 of principal that was repaid on 15 Sep and is already in the custodian cash both sides use (6,017,407.33) - a double count. Overstatement: 494,640 x 1.0125 = 500,823.00 MV + 190.44 accrued = **501,013.44**; shadow amortized cost is also 494,640.00 too high. No change to the draft.

### F5 — Brackett Specialty Retail (Pellmore correct)
Trustee notice 15 Sep: the 39.375 per 1,000 coupon due 15 Sep will not be paid. Press release 16 Sep 07:05 ET: Chapter 11 filed; notes to be exchanged for equity. Vendor A 38.500 **FLAT**, OK (prior day 41.000); Vendor B 37.750. Both sides use 38.50 (MV 1,540,000.00).
Our draft: NON_ACCRUAL effective 16 Sep, accrued 0, past-due 0. Shadow: ACCRUING, accrued 2,625.00 (875/day x 3) and past-due receivable 157,500.00 (4,000,000 x 3.9375%).
Policy 5.4: non-accrual effective at the earliest of (a) bankruptcy filing (16 Sep - earlier than the 30-day grace expiry on 15 Oct), with all accrued and past-due interest reversed; defaulted securities are valued at the flat price, which includes any value for the unpaid-interest claim. The shadow therefore counts the missed coupon twice (in the flat price and as a receivable) and keeps accruing on a bankrupt issuer. Overstatement **160,125.00**. No change to the draft.

## 5. Corrected NAV and release

| | USD |
|---|---:|
| Draft net assets | 415,740,209.87 |
| F2 Calloway reprice to Vendor B 100.380 | -25,725.00 |
| **Corrected net assets** | **415,714,484.87** |
| Shares outstanding | 40,215,337.482 |
| NAV per share (4dp) | 10.3372 (draft 10.3379) |
| **NAV to release (2dp)** | **10.34** (unchanged) |
| Shadow minus corrected draft | 745,618.44 (all shadow-side: F1 + F4 + F5) |

Policy 6.2: the break exceeds 0.005/share, so it was investigated position by position - done above. Policy 6.3: our error is corrected before release regardless of the 2dp effect. Policy 6.4: we do not adopt Tidewell's marks and shadow-side differences do not delay release. Policy 6.5: release by 19:00 ET; no delay, so no Treasurer approval required. No shareholder activity reprocessing is needed - the NAV has not been released and the 2dp NAV is unchanged.

## 6. Actions tonight

1. **Book** the Calloway reprice (-25,725.00; source VENDOR_B_EVAL_BID) in the accounting system and re-run the NAV: 10.3372 / 10.34.
2. **Release** 10.34 by 19:00 ET.
3. **Reply to Hollis Mbeki (Tidewell Fund Oversight)**: decline the hold and reprice request under 6.4; send the table in section 3 with the F1/F4/F5 errors and the F3 method difference; ask them to correct the IBOR (Kestrel factor, Brackett non-accrual, Harrow Point price, Quenby method) so tomorrow's shadow reconciles.
4. **Report to the Valuation Designee** (Tidewell Valuation Committee), per 6.4 and 4.5: (a) Vendor A NP on Calloway and our (now corrected) carry-forward; (b) the pending Harrow Point challenge - Vendor A price used, no override on file, shadow used a PM-supplied price contrary to 4.6; (c) Brackett non-accrual from 16 Sep and valuation at the Vendor A flat price 38.50.
5. **Portfolio manager** (via Fund Oversight): the Vendor A price stands until revised or overridden by the VD; PMs may not supply prices.
6. **Vendor A**: request the outcome of challenge VA-CH-2609-4471 on 18 Sep and the reason/duration of the Calloway NP.
7. **Security master / pricing waterfall**: fix the configuration that carried forward instead of falling to Vendor B; ensure any carry-forward triggers same-day VD reporting; confirm the Kestrel factor and Brackett non-accrual flag roll into 18 Sep.
8. **Fund Treasurer**: no delay request needed.

## 7. Assumptions and open questions

* Day-count convention: both sides accrue 30/360 through and including day T (policy 5.1), e.g. Sorrel Bay 63 days from 15 Jul, Quenby/Kestrel/Brackett 3 days from 15 Sep. I have not changed any accrual that agrees on both sides.
* Kestrel original face of 12,000,000 is inferred from both position files; please confirm against custody, and that the 15 Sep principal (494,640.00) and interest were received into the Northgate DDA.
* No VD price override for Harrow Point, and no VD determination on Brackett, is in the folder; I have assumed none exists.
* There is no evidence the Calloway carry-forward was reported to the VD today (4.5); the VD report above covers it.
* The position file does not show the income-statement side of the Brackett non-accrual; confirm the reversal of previously accrued coupon interest (157,500.00) against interest income was booked on 16 Sep.
* The nine par positions labelled STRAIGHT_LINE in the shadow have no numeric effect today; Tidewell should confirm its IBOR amortization setting matches policy 5.2 for future premium/discount lots.
