# Checker note — Tollbridge Aggregates rights issue (CA-26-0915-TOLL), draft batch B-TOLL-01

**To:** Priya Castellanos, Asset Servicing Team Lead
**From:** Checker, Corporate Actions
**Date:** Mon 28 Sep 2026 (evening ET)
**Carrow deadline:** Tue 29 Sep 2026 12:00 London (MT564 `RDDT`) — three MT565s to go first thing

## 1. Bottom line

I am **not** signing off draft batch B-TOLL-01 as drafted. All four lines applied the wrong instruction. The engine
took the *latest recorded* SI for each client (`source = SI_AUTO (latest recorded SI)`), whereas Service Terms 4.1–4.2
require the current row whose **validity period contains the Client Response Deadline** (28 Sep 2026 12:00 ET). It also
ignored `callback_status` (4.4) and the Available Cash test (5.1–5.4). The corrected elections I will approve are:

| Account | Client | Rights held | Governing SI | Election | Take up (rights) | Excess (new shares) | Sell nil paid | Lapse | GBP debit |
|---|---|---:|---|---|---:|---:|---:|---:|---:|
| 4410-2201 | Ashgrove Global Equity | 357,142 | SI-0412 | Partial take-up, balance sold | 331,027 | 0 | 26,115 | 0 | 612,399.95 |
| 4410-2202 | Ashgrove UK Value | 139,000 | SI-0877 | Full take-up + excess | 139,000 | 23,162 | 0 | 0 | 299,999.70 |
| 4410-3107 | Fenwick Intl Equity | 258,096 | SI-0931 | Partial take-up, balance lapses | 249,613 | 0 | 0 | 8,483 | 461,784.05 |
| 4410-5020 | Lumenfield Global Equity | 114,285 | SI-0605 | Lapse all (late instruction not actioned) | 0 | 0 | 0 | 114,285 | 0.00 |
| **Total** | | **868,523** | | | **719,640** | **23,162** | **26,115** | **122,768** | **1,374,183.70** |

Total rights of 868,523 tie to the MT564 `:93B::ELIG//UNIT/868523,` for omnibus MRDL-OMNI-GB01. Each entitlement also
ties to the record-date ordinary position × 2/7 rounded down (positions file).

Things we **cannot** do, and why, are in section 4. Client wording for you to send is in section 5.

## 2. Inputs relied on

| File | Used for |
|---|---|
| `inputs/notices/MT564_CARWGB2L_TOLL_EXRI_20260915.txt` | Terms: 2 for 7 at GBP 1.85, options 001 EXER / 002 OVER / 003 SLLE / 004 LAPS (default); OVER only if all rights exercised, quantity in new shares, must be fully funded; Carrow deadline 29 Sep 12:00 London; unfunded instructions rejected; cash PAYD 01 Oct |
| `inputs/notices/meridale_client_notice_CA-26-0915-TOLL.txt` | Client Response Deadline 28 Sep 2026 12:00 ET; funding must be cleared GBP by that time; no credit; no MT565 for lapsing rights |
| `inputs/notices/tollbridge_prospectus_terms_extract.md` | Fractions rounded down; excess scaled back pro rata and refunded; lapsed-rights premium < GBP 5.00 retained by company |
| `inputs/policies/meridale_corporate_actions_service_terms_extract.md` | 4.1–4.4 SI register/precedence/verification; 5.1–5.5 Available Cash, no credit/FX, partial funding, excess; 7.2–7.4 late instructions, same-day client notice, maker-checker |
| `inputs/client_instructions/standing_instruction_register_extract_20260928.csv` | Governing SI per account (see section 3) |
| `inputs/client_instructions/email_ashgrove_20260928_0852.txt` | Ashgrove 08:52 ET: FX ticket AGP-FX-0928-01, "take up per our standing instruction", 2202 "SI as usual" |
| `inputs/client_instructions/email_lumenfield_20260928.txt` | Lumenfield 17:05:31 +0100 (= 12:05:31 ET): take up in full |
| `inputs/positions/custody_positions_TOLL_20260928.csv` | Nil paid rights (GB005LKK3S13) settled per account; record-date ordinary positions |
| `inputs/cash/cash_availability_GBP_20260928_1200ET.csv` | Cleared GBP and pending items at the 12:00 ET deadline snapshot |
| `inputs/event_engine/draft_mt565_batch_CA-26-0915-TOLL.csv` | The draft under review |

Subscription price GBP 1.85 per new share throughout; one right = one new share.

## 3. Account-by-account re-performance

### 4410-2201 — Ashgrove Pension Trust, Global Equity (ASH)

* **Rights:** 357,142 (1,250,000 × 2/7 = 357,142.86 → 357,142). Ties to position file.
* **Instruction:** No account-level SI for 2201. Client-level SI-0412 (ALL, `TAKE_UP_FULL`, excess 0%, `balance_if_unfunded = SELL_NIL_PAID`, `auto_fx = N`, valid 2024-01-01 → 9999-12-31, `recorded_to` 9999-12-31, VERIFIED) contains 28 Sep 2026 and governs under 4.3(c). **SI-0951 (LAPSE), which the engine applied, is `valid_from` 2026-10-15 — it does not govern this event.** Marcus Leland's 08:52 ET email arrived before the deadline but only asks us to apply the SI; it is not call-back verified (4.4) so could not vary it anyway.
* **Available Cash (5.1):** cleared GBP 612,400.00. The GBP 60,000 FX (AGP-FX-0928-01) is a `PROJECTED_INFLOW`, `UNCONFIRMED`, value 30 Sep — projected inflows and FX purchases are explicitly excluded unless cleared by the deadline. USD 4,882,110.55 cannot be used: no credit, no FX (5.2, `auto_fx = N`).
* **Arithmetic:** full take-up 357,142 × 1.85 = GBP 660,712.70; shortfall GBP 48,312.70. Per 5.3: floor(612,400.00 / 1.85) = 331,027 shares → debit 331,027 × 1.85 = **GBP 612,399.95**. Balance 357,142 − 331,027 = **26,115 rights → SLLE** (SI balance = SELL_NIL_PAID). No OVER (excess 0%, and not all rights exercised).
* **Draft was:** LAPS 357,142 under SI-0951 — wrong.

### 4410-2202 — Ashgrove Pension Trust, UK Value (ASH)

* **Rights:** 139,000 (486,500 × 2/7 = 139,000 exactly).
* **Instruction:** account-level SI-0877 (4410-2202, `TAKE_UP_FULL`, excess 25% of entitlement, `balance_if_unfunded = LAPSE`, `auto_fx = N`, valid from 2026-09-01, current, VERIFIED) governs under 4.3(b), ahead of SI-0412. Email: "Nothing different for 2202 — SI as usual." SI-0951 again not yet valid.
* **Available Cash:** cleared GBP 300,000.00. The GBP 40,112.35 Harcourt sale (`PENDING_SETTLEMENT_IN`, value 29 Sep, MATCHED) is a pending sale and is excluded by 5.1.
* **Arithmetic:** take-up 139,000 × 1.85 = GBP 257,150.00 — fully funded. Residual 300,000.00 − 257,150.00 = GBP 42,850.00. Excess per 5.4 = lower of (i) 25% × 139,000 = 34,750 and (ii) floor(42,850.00 / 1.85) = 23,162 → **23,162 new shares**, GBP 42,849.70. **Total debit GBP 299,999.70.** MT564 conditions met: all rights exercised, quantity in new shares, full excess amount funded. Scale-back refund to be reconciled when received.
* **Draft was:** LAPS 139,000 under SI-0951 — wrong.

### 4410-3107 — Fenwick County Retirement System, Intl Equity (FEN)

* **Rights:** 258,096 (903,337 × 2/7 = 258,096.29 → 258,096).
* **Instruction:** SI-0520 v1 has `recorded_to` 2026-09-16 — a replaced row that must not be used (4.1). SI-0520 v2 (current) has `valid_to` 2026-09-14, so it does not contain 28 Sep. **SI-0931** (ALL, `TAKE_UP_FULL`, excess 0, `balance_if_unfunded = LAPSE`, `auto_fx = N`, valid from 2026-09-15, current, VERIFIED with call-back 16 Sep to T. Albright) governs.
* **Available Cash:** cleared GBP 520,000.00 **less** matched purchase EQ-B-260925-2207 GBP 58,214.40 (value 29 Sep, on or before the 1 Oct market payment date → reserved) = **GBP 461,785.60**. Purchase EQ-B-260928-2291 GBP 30,006.00 values 5 Oct, after the payment date, so it is not reserved (see open question 1).
* **Arithmetic:** full take-up 258,096 × 1.85 = GBP 477,477.60; shortfall GBP 15,692.00. Per 5.3: floor(461,785.60 / 1.85) = 249,613 shares → **GBP 461,784.05**. Balance **8,483 rights lapse** (SI balance = LAPSE); no MT565 line needed for the lapsing portion.
* **Draft was:** SLLE 258,096 under SI-0520 — wrong (superseded SI; would have sold rights the client now wants taken up).

### 4410-5020 — Lumenfield Endowment, Global Equity (LUM)

* **Rights:** 114,285 (400,000 × 2/7 = 114,285.71 → 114,285).
* **Instruction:** SI-0944 (`TAKE_UP_FULL`, from 24 Sep, sourced from Harriet's 24 Sep email) is **`PENDING_CALLBACK`** — call-backs on 25 Sep and 28 Sep to the registered number went unanswered. Under 4.4 it is not effective. The governing SI is **SI-0605** (4410-5020, `LAPSE`, valid 2025-07-01 → 9999-12-31, VERIFIED).
* **Today's email:** sent Mon 28 Sep 2026 17:05:31 +0100, i.e. **12:05:31 ET — five minutes after** the 12:00 ET Client Response Deadline. It is a late instruction under 7.2 (and, being email, also unverified under 4.4).
* **7.2 test:** best-efforts transmission needs **all** of (i) Head of Asset Servicing written approval, (ii) Carrow written confirmation it can still accept, (iii) cleared GBP covering the election **in full**. (iii) fails: cleared GBP 150,000.00 against 114,285 × 1.85 = GBP 211,427.25 (shortfall GBP 61,427.25). USD 2,310,000.00 cannot be converted (`auto_fx = N`, 5.2). "Cash will be in the account" is a projection, not cleared cash at the deadline. Because one condition fails, 7.2 requires us to process the account as if the late instruction had not been received → SI-0605 → **all 114,285 rights lapse; no MT565; GBP debit nil.** Any underwriter premium ≥ GBP 5.00 on the lapsed rights is credited when received (prospectus 3.5).
* **On "the market doesn't close until Thursday":** the relevant deadline for us is Carrow's 29 Sep 12:00 London response deadline, and the policy hinge is *cleared* cash at *our* 12:00 ET deadline, not the 1 Oct market deadline. Even if we wanted to put it in, Carrow's MT564 says instructions not fully funded in cleared GBP will be rejected — the draft EXER 114,285 / GBP 211,427.25 would bounce.
* **Draft was:** EXER 114,285 / GBP 211,427.25 under SI-0944 — wrong (unverified SI, unfunded).

## 4. What we cannot do, and why

1. **Take up Lumenfield 5020 in full.** Late (12:05 ET vs 12:00 ET), unverified (no call-back), unfunded (GBP 150,000 vs 211,427.25). Terms 7.2 gives no discretion when condition (iii) fails. I have therefore not sought Head of AS approval or a Carrow confirmation for it — neither would cure the funding gap.
2. **Count Ashgrove's GBP 60,000 FX on 2201.** Unconfirmed, values 30 Sep, projected inflow — excluded by 5.1. Result: 26,115 rights are sold nil paid per Ashgrove's own SI-0412 rather than taken up.
3. **Execute FX or extend credit** for 2201, 3107 or 5020 shortfalls — 5.2, and `auto_fx = N` on every governing SI.
4. **Use SI-0951 (Ashgrove LAPSE)** — not valid until 15 Oct 2026.
5. **Use SI-0520 (Fenwick SELL_NIL_PAID)** — superseded; validity closed 14 Sep.
6. **Release B-TOLL-01 as drafted** — every line fails the 7.4 checker test (SI applied, quantity, funding).

## 5. Client communications (for you to send)

**Lumenfield (Harriet Voss) — mandatory same-day written notice under 7.3:**
> Your instruction to take up the Tollbridge entitlement in 4410-5020 was received at 17:05 BST / 12:05 ET on 28 September, after Meridale's Client Response Deadline of 12:00 ET. Your 24 September request to change the standing instruction to "take up in full" has not taken effect because our call-backs to the registered contact number on 25 and 28 September were unanswered; email instructions require call-back verification under Schedule 4 s.4.4. We are unable to transmit the late instruction on a best-efforts basis because s.7.2 requires the account to hold cleared GBP covering the election in full: 4410-5020 held GBP 150,000.00 against GBP 211,427.25 required (114,285 rights at GBP 1.85), and Meridale does not extend credit or execute FX on your behalf. The account has therefore been processed under your verified standing instruction SI-0605 (lapse). All 114,285 nil paid rights will lapse; any premium of GBP 5.00 or more paid by the underwriters on lapsed rights will be credited to the account when received. Please complete the call-back so your revised standing instruction is effective for future events, and let us know whether you wish to enable automatic FX funding for GBP subscription events.

**Ashgrove (Marcus Leland):**
> 4410-2201: FX ticket AGP-FX-0928-01 (GBP 60,000, value 30 Sep) had not been confirmed and is a projected inflow, which Schedule 4 s.5.1 excludes from Available Cash. Cleared GBP 612,400.00 funds 331,027 of 357,142 rights (GBP 612,399.95). Per SI-0412 the balance of 26,115 rights will be sold nil paid through Carrow's broker on a best-efforts basis and net proceeds credited. 4410-2202: full take-up of 139,000 rights (GBP 257,150.00) plus an excess application for 23,162 new shares (GBP 42,849.70) under SI-0877 — the 25% cap of 34,750 was limited by available cash because the 29 Sep Harcourt sale proceeds (GBP 40,112.35) could not be counted. Excess is subject to issuer scale-back with refund. Total debit 2202 GBP 299,999.70. Your new SI-0951 (lapse) takes effect from 15 October 2026 and was not applied to this event.

**Fenwick (T. Albright):**
> Under SI-0931, 4410-3107 takes up 249,613 of 258,096 rights (GBP 461,784.05). Cleared GBP 520,000.00 less the matched Harcourt purchase EQ-B-260925-2207 (GBP 58,214.40, settling 29 Sep) left Available Cash of GBP 461,785.60, short of the GBP 477,477.60 required for full take-up. The remaining 8,483 rights will lapse per the standing instruction; any lapsed-rights premium of GBP 5.00 or more will be credited on receipt.

## 6. Actions (mirrors `answer.json → actions`)

* **Hold** draft batch B-TOLL-01; return to maker. **Escalate** the engine SI-selection defect to Head of Asset Servicing and ask for a sweep of other open subscription events drafted with "latest recorded SI".
* **Submit** MT565s to Carrow (CARWGB2L) before 29 Sep 12:00 London: 2201 EXER 331,027 + SLLE 26,115 (GBP 612,399.95); 2202 EXER 139,000 + OVER 23,162 (GBP 299,999.70); 3107 EXER 249,613 (GBP 461,784.05).
* **No MT565** for 5020; rights lapse by default.
* **Notify** Lumenfield (same day, 7.3), Ashgrove, Fenwick as above; **request** Lumenfield complete the call-back for SI-0944.
* **Cash management** to ring-fence GBP 1,374,183.70 across the three accounts; **no FX, no credit**.
* **SI register**: note SI-0944 still pending and not applied; SI-0951 not applicable before 15 Oct. No SI rows changed.

## 7. Assumptions and open questions

1. *Market payment date for the 5.1 reserve test* taken as 1 Oct 2026 (MT564 cash `PAYD` on option 001). Fenwick's GBP 30,006.00 purchase settling 5 Oct was therefore not reserved. If Carrow debits on instruction (29 Sep) the answer is unchanged.
2. *Ashgrove's 08:52 email* treated as a reaffirmation of SI-0412, not an event-specific instruction (it introduces nothing the SI does not already say, and it is not call-back verified). If Ashgrove would rather the 26,115 unfunded rights lapse than be sold, that would now be a late instruction.
3. *Lumenfield call-back status* taken from the 12:00 ET register extract. Confirm no verified call-back has since been logged — although with GBP 150,000 cleared the funding test would still fail.
4. *Cash* is the 12:00 ET snapshot, which is the Client Response Deadline. Anything credited later is not Available Cash under 5.1.
5. *Scope of the engine defect* beyond this event is outside the files provided and needs checking by Head of Asset Servicing.

Checker sign-off is given for the corrected elections in section 1 only.
