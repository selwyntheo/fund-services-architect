# CGEF — Tarrant Hollis trade date 9/17 orders: late-trade determination and impact

**To:** Mara Lindqvist, Treasurer & PFO, Corvane Investment Trust
**Re:** Ken Osterhaut (Stellmark) email of Fri 18 Sep 2026 16:55 ET — proposal to leave the flagged trades at the 9/17 NAV
**Prepared:** Sat 19 Sep 2026, for reply to Stellmark before Mon 21 Sep 9:00 am ET

## 1. Bottom line

1. **Six of the twelve Tarrant Hollis orders (or portions) were not entitled to Thursday's NAV.** Five orders are late in full (5504, 5505, 5507, 5509, 5512) and one is split (5508: $400,000 timely, $1,000,000 late). Six orders are timely in full (5501, 5502, 5503, 5506, 5510, 5511).
2. **Ken's proposal cannot be accepted.** Order Acceptance Procedures §2: a late order "must be processed at the next NAV. The Transfer Agent may not process a late order at the prior day's NAV, and no officer may authorise it to do so." The TA must cancel and re-bill the late pieces at the 9/18 NAV of 32.19 (§3).
3. **Cost if left at 31.42:** $123,758.81 dilution on $5,050,000 of late purchases (3,844.635 excess shares), offset by $5,005.00 the Fund under-paid on 6,500 late redemption shares — **net $118,753.81 loss to the Fund** (Procedures §4 method). Reprocessing eliminates the loss; any residual cost is Tarrant's under Agreement §9.2.
4. **Friday's NAV (9/18, 32.19) is not affected.** Removing the late activity from the 9/17 capital stock moves the unrounded 9/18 NAV by +$0.0045 (32.1874 → 32.1919); it still rounds to 32.19, so no Material Day, no restatement, log entry only.
5. **Who needs to hear:** CCO (same-day report under Procedures §5, with the order-entry evidence and a Rule 22c-2 question on two customers), Stellmark (hold the batch, cancel/re-bill, control failures), Tarrant Hollis (formal notice, information request, indemnity reservation), Administrator (as-of entries, NAV error log), PM/Fund Ops (cash re-dating), Board via CCO.

## 2. Files relied on

| File | Used for |
|---|---|
| `inputs/intermediary/tarrant_hollis_order_entry_audit_CGEF_20260917.csv` | Order entry timestamps (branch-local), time zones, modification record, Fund/SERV file id |
| `inputs/transfer_agent/fundserv_transmissions_THS_CGEF_tradedate_20260917.txt` | FS1 received by TA 2026-09-18 06:52:14 ET (11 records); FS2 supplemental received 09:41:37 ET (5509 only) |
| `inputs/transfer_agent/ta_processing_report_CGEF_tradedate_20260917.csv` | Shares issued/redeemed at 31.42, confirm numbers, SURV-LATE-REVIEW flags (5504, 5505, 5508, 5509 only) |
| `inputs/nav/published_nav_CGEF_20260915_20260918.csv` | 9/17 NAV 31.42; 9/18 NAV 32.19, TNA $856,047,840.83, shares 26,595,743.702 |
| `inputs/agreements/tarrant_hollis_intermediary_agreement_excerpt.md` | §4.1–4.5 (Close, at/after Close, 9:00 am transmission deadline, post-Close increases, time-stamping), §9.2 indemnity |
| `inputs/policies/CIT_order_acceptance_and_late_trading_procedures.md` | §2 no late order at prior NAV; §3 cancel and re-bill; §4 impact formula; §5 same-day CCO report; §6 NAV impact via error policy |
| `inputs/policies/CIT_NAV_error_correction_policy.md` | §1.2 (second-order effects not re-struck), §1.4 Material Day thresholds, §8.3 error log |
| `inputs/correspondence/email_stellmark_ta_supervisor_20260918.txt` | Ken's position and Tarrant's arguments |
| `inputs/market/newswire_20260917.txt` | Harrowgate takeover headline 16:09 ET 9/17; 9/18 market close |

## 3. Assumptions

- The NYSE closed at 4:00:00 pm ET on Thu 17 Sep 2026 (a regular trading day; no early close).
- Daylight saving time was in effect: America/Chicago = ET − 1h, America/Los_Angeles = ET − 3h. Tarrant's own file labels the branch timestamps as local time in those zones (Agreement §4.5), so the conversion applies. Tarrant's "local, so obviously before the close" argument is the reverse of the truth: a Chicago timestamp of 15:18 CDT is 16:18 EDT.
- "At or after the Close" (§4.2) is read literally: a 16:00:00 ET timestamp is at the Close and is late.
- Under §4.3 an order received by the TA after 9:00 am ET is priced at the NAV next computed after receipt "notwithstanding any earlier trade date shown on the transmission". The cause of the delay is irrelevant to pricing.
- Under §4.4 an increase at or after the Close is a new order for the increase, received at the time of the increase; the original amount keeps its original receipt time.
- Impact is measured with the Procedures §4 formula: purchases (shares at 31.42 − shares at 32.19) × 32.19, shares to 3dp (round half up); redemptions shares × (31.42 − 32.19). Dollar orders hold dollars constant; share orders hold shares constant.
- Capital stock convention: 9/17 trade-date activity enters shares outstanding for the 9/18 NAV. Check: 26,595,743.702 − 26,418,773.905 = 176,969.797 = net shares on the 9/17 TA processing report (205,919.797 purchased − 28,950.000 redeemed). The late purchases' cash ($5,050,000, settled 9/18) is therefore assumed to be in 9/18 net assets and the redemption proceeds ($204,230.00) to have been paid out of them.

## 4. Order-by-order determination

Close = 2026-09-17 16:00:00 ET. TA deadline = 2026-09-18 09:00:00 ET.

| Firm order | Sub-acct | Side / basis | Entry (local) | Entry (ET) | TA receipt (ET) | Determination | Priced 9/17 | Priced 9/18 |
|---|---|---|---|---|---|---|---|---|
| 5501 | A-10442 | BUY $ | 10:14:22 NY | 10:14:22 | 06:52:14 (FS1) | Timely | $250,000 | — |
| 5502 | A-20918 | SELL sh | 13:47:05 NY | 13:47:05 | 06:52:14 | Timely | 3,000.000 | — |
| 5503 | A-31177 | BUY $ | 14:32:10 Chicago | 15:32:10 | 06:52:14 | Timely | $80,000 | — |
| **5504** | A-40021 | BUY $ | 15:18:44 Chicago | **16:18:44** | 06:52:14 | **Late — after Close (§4.2)** | — | $1,500,000 |
| **5505** | A-40021 | BUY $ | 15:26:09 Chicago | **16:26:09** | 06:52:14 | **Late — after Close (§4.2)** | — | $2,250,000 |
| 5506 | A-52210 | BUY $ | 15:59:58 NY | 15:59:58 | 06:52:14 | Timely (2 seconds before Close) | $120,000 | — |
| **5507** | A-52877 | SELL sh | 16:00:00 NY | **16:00:00** | 06:52:14 | **Late — at the Close (§4.2)** | — | 4,500.000 |
| **5508** | A-61034 | BUY $ | 15:52:31 NY; increased 16:12:40 to $1,400,000 | 15:52:31 / **16:12:40** | 06:52:14 | **Split — increase after Close is a new order (§4.4)** | $400,000 | $1,000,000 |
| **5509** | A-70315 | BUY $ | 15:47:03 NY | 15:47:03 | **09:41:37 (FS2)** | **Late — received by TA after 9:00 am (§4.3)** | — | $300,000 |
| 5510 | A-10442 | SELL sh | 11:05:40 NY | 11:05:40 | 06:52:14 | Timely | 1,200.000 | — |
| 5511 | A-83390 | BUY $ | 12:40:00 San Francisco | 15:40:00 | 06:52:14 | Timely | $60,000 | — |
| **5512** | A-83391 | SELL sh | 13:05:30 San Francisco | **16:05:30** | 06:52:14 | **Late — after Close (§4.2)** | — | 2,000.000 |

Responses to Tarrant's arguments (per Ken's email):
- "Chicago timestamps are local, so obviously before the close" — converting CDT to EDT adds an hour; 5504 and 5505 were entered 18 and 26 minutes after the Close. 5503 (14:32 CDT = 15:32 EDT) is fine.
- "5509 was taken at 3:47 pm; the supplemental file was a systems delay" — accepted that the order was received before the Close, but §4.3 makes the 9:00 am TA receipt the binding condition for 9/17 pricing; FS2 arrived at 09:41:37. Priced at the NAV next computed after receipt = 9/18.
- "5508 was placed before 4 and only topped up" — §4.4 is explicit: an increase at or after the Close is a new order for the increase. $400,000 keeps 9/17; $1,000,000 is a 9/18 order.
- Stellmark's surveillance flagged only the four large purchases ($5.45mm). It missed the two late redemptions (5507, 5512), and one flagged order (5508) is $400,000 timely.

## 5. Impact if left at the 9/17 NAV (Procedures §4)

NAV applied 31.42; correct NAV 32.19 (published 9/18 FINAL).

| Order | Late amount | Shares at 31.42 | Shares at 32.19 | Excess shares | Impact (× 32.19) |
|---|---|---|---|---|---|
| 5504 | $1,500,000.00 | 47,740.293 | 46,598.322 | 1,141.971 | $36,760.05 |
| 5505 | $2,250,000.00 | 71,610.439 | 69,897.484 | 1,712.955 | $55,140.02 |
| 5508 (increase) | $1,000,000.00 | 31,826.862 | 31,065.548 | 761.314 | $24,506.70 |
| 5509 | $300,000.00 | 9,548.059 | 9,319.664 | 228.395 | $7,352.04 |
| **Late purchases** | **$5,050,000.00** | **160,725.653** | **156,881.018** | **3,844.635** | **$123,758.81** |
| 5507 | 4,500.000 sh | proceeds $141,390.00 | proceeds $144,855.00 | — | −$3,465.00 |
| 5512 | 2,000.000 sh | proceeds $62,840.00 | proceeds $64,380.00 | — | −$1,540.00 |
| **Late redemptions** | **6,500.000 sh** | | | | **−$5,005.00** |
| **Net impact to the Fund if left** | | | | | **$118,753.81 (loss)** |

The redemption figures are negative (Fund paid less than owed), but they are not a reason to leave those orders: Rule 22c-1 and Procedures §2 require the next NAV, and the two redeeming customers are owed $5,005.00 more. Note the Fund's 9/18 gain of 2.45% (31.42 → 32.19) versus MSCI ACWI +1.6%, with the Harrowgate takeover announced at 16:09 ET on 9/17; the late purchases would capture that move at Thursday's price.

5508 mechanics: cancel confirm SSS260951208 (44,557.607 sh at 31.42 on $1,400,000) and re-bill $400,000 at 31.42 = 12,730.745 sh (TD 9/17) plus $1,000,000 at 32.19 = 31,065.548 sh (TD 9/18); shares cancelled 761.314, matching the per-amount excess in the table.

## 6. Effect on the 9/18 NAV (Procedures §6; NAV Error Policy)

Published 9/18: TNA $856,047,840.83 / 26,595,743.702 sh = 32.1874 unrounded → 32.19.
Removing the late activity from the 9/17 capital stock (re-dating it to TD 9/18, so it enters the 9/21 capital stock): TNA − $5,050,000 + $204,230.00 = $851,202,070.83; shares − 160,725.653 + 6,500.000 = 26,441,518.049; NAV = 32.1919 unrounded → 32.19.
Per-share effect **+$0.0045**, below the $0.01 and 0.50% Material Day tests (Policy §1.4), and the published 32.19 is unchanged. Policy §1.2 also directs that second-order effects of mispriced shareholder activity on later days are handled through reprocessing, not by re-striking. **No restatement of the 9/18 NAV; NAV error log entry only (§8.3), reported to the Board quarterly.** The reprocessing (net −3,844.635 shares, $5,005.00 additional redemption proceeds, re-dated subscriptions) is booked as-of into the next NAV (Mon 9/21).

## 7. Responsibility

Responsible Party: **Tarrant Hollis Securities** — failure to convert branch-local time stamps (§4.5), transmission of post-Close orders as 9/17 trade date (§4.2), treatment of a post-Close increase as part of the original order (§4.4), and late transmission of 5509 (§4.3). §9.2 indemnifies the Trust and the Fund for any loss "including any loss arising from the correction or reprocessing of transactions". Stellmark Shareholder Services also had control failures (pricing FS2 at 31.42 after its own 9:00 am cut-off without an as-of flag; surveillance that missed the two redemptions), which should be raised with Stellmark management for the CCO/Board root-cause report, but the primary indemnity route is the intermediary agreement.

## 8. Recommended reply to Ken and actions (mirrors `answer.json` → actions)

1. **Reply to Stellmark before Monday 9:00 am:** the trades may not stand at the 9/17 NAV; do not close the surveillance items; hold the batch as processed pending the Treasurer-approved correction.
2. **Reprocess (cancel and re-bill) on omnibus 900011 at 32.19, as-of TD 9/18:** 5504, 5505, 5509 (full), the $1,000,000 increase of 5508 (re-bill $400,000 at 31.42), 5507 and 5512 (redemptions, pay the additional $5,005.00). Timely orders unchanged.
3. **CCO report (Procedures §5)** with the order-entry evidence — the same-day requirement has already lapsed, so it should go first thing Monday at the latest. Flag for Rule 22c-2 review: A-40021 (two orders, $3.75mm, 16:18 and 16:26 ET) and A-61034 ($1.0mm increase at 16:12:40 ET), all after the 16:09 ET Harrowgate headline. CCO decides on Board/regulator reporting and purchase restrictions.
4. **Tarrant Hollis:** formal notice of the determinations; §4.5 request (within one Business Day) for clock-sync/time-zone evidence, the 5509 delay root cause, the 5508 modification record, and 22c-2 customer information for A-40021/A-61034; reservation of §9.2 indemnity for any cost of correction.
5. **Stellmark management:** written root cause/remediation for the FS2 pricing and surveillance gaps.
6. **Administrator:** book the as-of adjustments into the 9/21 NAV; NAV error log entry (+$0.0045 second-order effect, no Material Day).
7. **PM / Fund Ops:** cash and capital-stock re-dating ($5.05mm subscriptions and 6,500 redeemed shares to TD 9/18; 3,844.635 shares cancelled). No portfolio action.
8. **Treasurer:** approve this calculation in writing (Procedures §3; Policy §8.1) before Stellmark reprocesses.

## 9. What I need and from whom (open questions)

- Adviser/PM: does CGEF hold Harrowgate Industries, and at what weight (for the CCO's 22c-2 assessment)?
- Tarrant Hollis: full audit trail (any other post-Close modifications/cancels), clock-synchronisation and time-zone configuration evidence for Chicago and San Francisco, cause of the 5509 systems delay, 5508 modification record, customer identity/history for A-40021 and A-61034.
- Stellmark: confirmation of how the $5,050,000 late-purchase cash and the 6,500 redeemed shares are carried between 9/18 and the re-booked 9/18 trade date; rounding convention for the 5508 split (761.314 shares cancelled).
- CCO: whether to restrict further purchases by A-40021/A-61034 pending Tarrant's information.
- Borderline timestamps: 5506 (15:59:58 ET, timely) and 5507 (16:00:00 ET, late) turn on seconds; clock evidence from Tarrant would close both.
