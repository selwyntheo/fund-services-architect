# BMAI — December 2026 distribution estimate (IRC §4982 excise)

**To:** Owen Latimer, Assistant Treasurer, Brightwater Series Trust
**From:** Oakhurst Fund Administration — Fund Tax
**Date:** 13 November 2026
**Re:** Brightwater Multi-Asset Income Fund (BMAI) — minimum December distribution to avoid 2026 excise tax

## 1. Answer

| | USD |
|---|---:|
| Required 2026 distribution (§4982(b)) | **45,742,482.48** |
| Distributed amount counted toward 2026 before December (incl. November dividend at estimate) | 38,151,162.70 |
| **Minimum December distribution (policy 4.2)** | **7,591,319.78** |
| Projected 16-Dec record-date shares, all classes (Harwick 12-Nov) | 121,972,650.225 |
| Minimum per-share rate (policy 4.3: divide, round **up** to $0.0001) | **$0.0623** |
| Amount paid at $0.0623 on projected shares | 7,598,896.11 |
| Suggested cushion rate (policy 4.4, reported separately) | $0.0630 (≈ 7,684,277) |
| Excise tax if December paid only the regular $0.0280 | **≈ 167,043.42** |

The regular $0.0280 is $3.4mm; the minimum is $7.6mm. The gap is driven by (i) $9.6mm of net realized gains in Jul–Oct 2026 that fall inside the 2026 excise gain window, and (ii) a $658,050 grossed-up shortfall carried from 2025. None of the three points in Marcus Whitcombe's 12-Nov email reduces the number (section 4).

## 2. Build of the required distribution

Method: Trust Distribution and Excise Tax Policy v2.4 (`inputs/policies/BST_distribution_and_excise_policy.md`), sections 2–4.

### 2a. Ordinary income, calendar 2026 (policy 2.1(a), 2.2, 2.3) — 100% amount **40,992,425.00**

Source: `inputs/tax/BMAI_monthly_tax_basis_income_and_gains_202507_202610.csv` (Jan–Oct 2026 actual; October is **PRELIM**, close 2026-11-06) and `inputs/tax/BMAI_income_forecast_20261101_20261231.csv` (Nov–Dec desk forecast dated 2026-11-10).

| Component | USD |
|---|---:|
| Net investment income, tax basis, Jan–Oct 2026 (3,295,300 + 3,118,640 + 3,356,020 + 3,402,775 + 3,387,910 + 3,445,260 + 3,468,130 + 3,501,445 + 3,476,820 + 3,522,395) | 33,974,695.00 |
| NII forecast Nov 2026 (3,530,600) + Dec 2026 (3,612,450) | 7,143,050.00 |
| §988 FX gain/loss Jan–Oct 2026 (31,200 − 14,750 + 22,480 + 18,900 − 27,340 + 11,060 + 9,870 − 21,410 + 16,330 + 12,640) | 58,980.00 |
| Post-October 2025 §988 loss deferred into 2026 under §4982(e)(5) (2025 workpaper memo line; ties to Nov-25 −121,400 + Dec-25 −62,900) | (184,300.00) |
| Nov–Dec 2026 §988 (forecast +44,200 / −18,600 = +25,600) — **excluded**, treated as arising 1 Jan 2027 | — |
| **Ordinary income** | **40,992,425.00** |
| × 98% | **40,172,576.50** |

Note: I did not use the extract's `distributable_ordinary_income_incl_stcg` column. Short-term capital gains are capital gains for §4982(e)(1) and belong in 2b, not in ordinary income.

### 2b. Capital gain net income, 1 Nov 2025 – 31 Oct 2026 (policy 2.1(b), 2.4) — 100% amount **5,001,890.00**

Source: same monthly file, months 2025-11 through 2026-10, ST + LT combined.

| Period | ST | LT | Net |
|---|---:|---:|---:|
| Nov 2025 – Jun 2026 | (1,441,540) | (3,144,220) | (4,585,760) |
| Jul – Oct 2026 | 2,338,400 | 7,249,250 | 9,587,650 |
| **Total window** | **896,860** | **4,105,030** | **5,001,890** |

Excise-basis capital loss carryover from 2025: **0.00** (`inputs/tax/BMAI_2025_excise_workpaper_FINAL.csv`, section B). Post-31-October 2026 realized gains (Nov MTD actual −96,400 ST / +318,900 LT; Nov–Dec forecast +1,250,000) fall in the 2027 excise period and are excluded.

× 98.2% = **4,911,855.98**

### 2c. Prior-year shortfall (policy 2.1(c), §4982(b)(2)) — **658,050.00**

From `inputs/tax/BMAI_2025_excise_workpaper_FINAL.csv`:
grossed-up 2025 required distribution = ordinary income 39,872,173.71 + capital gain net income 6,905,400.00 = 46,777,573.71;
2025 distributed amount = 46,119,523.71; excess = **658,050.00**.
(2025 had no excise *tax* because distributions exceeded the 98%/98.2% requirement of 45,855,833.04 by 263,690.67 — but the carryover to 2026 is measured against the 100% amount, so a shortfall still carries.) No 2025 overdistribution under §4982(c)(2) because distributions were below the grossed-up amount.

### 2d. Required distribution

40,172,576.50 + 4,911,855.98 + 658,050.00 = **45,742,482.48**

## 3. Distributed amount counted toward 2026 before December (policy 3) — **38,151,162.70**

Source: `inputs/distributions/BMAI_distribution_register_202507_202611.csv`.

| Dist ref | Paid | USD |
|---|---|---:|
| 2026-01 … 2026-03 at $0.0275 | Jan 29 / Feb 26 / Mar 30 | 3,316,830.11 + 3,319,204.37 + 3,322,140.61 |
| 2026-04 … 2026-10 at $0.0280 | Apr 29 … Oct 29 | 3,385,532.49 + 3,388,205.13 + 3,391,878.07 + 3,394,741.61 + 3,396,825.85 + 3,399,280.75 + 3,401,664.43 |
| 2026-08S §855 ordinary income dividend, $0.0085 | Aug 28 | 1,031,179.28 |
| 2026-11 at $0.0280, **declared, estimated on 11/12 shares** (payable Nov 25) | included per policy 3.3 | 3,403,680.00 |
| **Total** | | **38,151,162.70** |

Excluded: BMAI-D-2025-12 (paid 5 Jan 2026) — counted in 2025 under §852(b)(7), already in the 2025 workpaper.

## 4. Where I disagree with the adviser (email of 12 Nov, `inputs/correspondence/email_Whitcombe_20261112.txt`)

1. **"No excise tax last year, so nothing hangs over from 2025."** Not correct. The §4982(b)(2) carryover is the excess of the *grossed-up* (100%) requirement over what was paid, not the excess of the 98%/98.2% requirement. 2025 paid 46,119,523.71 against a grossed-up requirement of 46,777,573.71, so **$658,050 carries into 2026**. Zero tax and zero carryover are different tests.

2. **"The ~$2.9mm capital loss carryforwards shelter this year's gains."** Not for excise. Those are the Fund's fiscal-year (§1212) carryforwards from FY2026 (ST 1,016,340 + LT 1,865,620 per `inputs/financial_statements/BMAI_annual_report_FY2026_tax_note_extract.md`; they tie exactly to the Jul 2025–Jun 2026 rows of the monthly file). The loss months — Nov 2025 through Jun 2026 — sit inside the 1 Nov 2025–31 Oct 2026 excise window, so those losses (net 4,585,760) are **already netted** in the 5,001,890 capital gain net income above. Using the carryforward again would double count. Policy 2.4 is explicit: only the excise-basis carryover from the prior workpaper may be used, and it is zero. Applying Marcus's approach would understate the requirement by about $2.83mm and expose the Fund to roughly $113k of excise tax.

3. **"The August special was FY2026 income, so it belongs to last year."** For income tax the §855 election relates that $1,031,179.28 back to FY2026. For excise, policy 3.2 (and §4982(c)) counts a dividend in the calendar year **paid** — 28 Aug 2026 — and it was not in the 2025 workpaper. So it counts toward **2026**. This point actually cuts in the adviser's favour: it reduces the December minimum by $1.03mm. Moving it to 2025 would make the December number larger, not smaller.

## 5. If December pays only the regular $0.0280

0.0280 × 121,972,650.225 = 3,415,234.21 paid. Underdistribution = 45,742,482.48 − 38,151,162.70 − 3,415,234.21 = **4,176,085.57**. Excise tax at 4% = **167,043.42**, a non-deductible fund expense (≈ $0.0014 per share). In addition, the grossed-up 2026 shortfall (≈ $5.0mm after removing the 2%/1.8% haircuts) would carry into the 2027 requirement, so the money would still have to be paid out next year, with the tax on top. Selling to fund the distribution is not required by the excise rules in any case; the payment can be made from cash on hand or, if the Board chooses, partly in additional shares via reinvestment.

## 6. Sensitivity and recommendation

- Every $100,000 of NII forecast miss moves the minimum by $98,000; every $100,000 of October gain true-up by $98,200.
- Every 100,000 shares above/below the projection moves the amount paid at $0.0623 by $6,230 and the November dividend (still estimated) by $2,800.
- At $0.0623 the cushion over the minimum is only $7,576; the rate becomes insufficient if record-date shares fall below ≈ 121,851,040.
- I recommend the Board consider **$0.0630** (≈ $7.68mm, ≈ $93k cushion). The minimum, as policy 4.4 requires, is reported separately above: **$7,591,319.78 / $0.0623**.

## 7. Assumptions

- The "tax basis" NII column already reflects book-to-tax adjustments other than §988 (wash sales, PFIC, REIT/RIC reclassifications). Nothing in the folder indicates otherwise.
- October 2026 preliminary figures are used as final.
- Nov–Dec NII forecast of 10 Nov is used unadjusted; Nov–Dec §988 and realized gains are deferred to 2027 per policy 2.3/2.1(b).
- The November dividend is included at its declared estimate of $3,403,680.00.
- Harwick's projected net share activity of +412,650.225 to 16 Dec is used unadjusted.

## 8. What I need, and from whom

| From | Need | By |
|---|---|---|
| Fund Accounting / accounting system | Final (non-PRELIM) October 2026 tax-basis NII, §988, realized ST/LT | Before Monday pre-clearance if possible; otherwise before 19 Nov |
| PM desk (via adviser) | Confirmation that the 10-Nov Nov–Dec NII/§988 forecast is current; any expense true-ups or year-end income not yet in it | 18 Nov |
| Harwick (via Treasurer — Fund Tax does not instruct the TA) | Refreshed 16-Dec share projection; actual 24-Nov record-date shares for the November dividend | 25 Nov / before payment |
| Oakhurst Tax Director | Second-level review of this estimate before pre-clearance, given the disagreement with the adviser | 16 Nov |
| Treasurer | Decision on the cushion rate ($0.0623 minimum vs $0.0630 suggested) for the Board paper | 16 Nov |

Character of the December distribution (ordinary vs long-term gain) is a separate exercise for the 1099-DIV/§19(a) notice and is not addressed here.

*Prepared by Oakhurst Fund Administration — Fund Tax. Workpaper: this memo plus `out/answer.json`.*
