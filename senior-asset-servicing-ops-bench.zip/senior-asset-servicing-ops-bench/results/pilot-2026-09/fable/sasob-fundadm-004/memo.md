# BGOF August 2026 Form N-PORT — senior validation

**To:** Graham Sato, Manager, Regulatory Reporting — Oakhurst Fund Administration
**From:** Senior validation
**Date:** Fri 18 Sep 2026
**Re:** Brightwater Global Opportunities Fund (BGOF) — N-PORT report for August 2026 (fiscal Q3, third month — public)

## 1. Bottom line

Do not submit this afternoon. The draft has nine field errors, three of which are liquidity classifications that
only the Program Administrator can confirm, and once they are corrected the fund-level numbers flip:

| Measure at 2026-08-31 | Draft (auto-check) | Corrected | Limit | Status |
|---|---|---|---|---|
| Illiquid investments that are assets | USD 36,601,000 = 9.95% | **USD 57,505,000 = 15.63%** | 15% max | **Exceeded** |
| HLIM compliance measure | 28.12% | **24.59%** | 25% min | **Shortfall** |
| Net assets | 367,956,922.39 | 367,956,922.39 | | |

The auto-checks passed for two reasons: Norcastle (L16, halted since 27 Aug) and Tessaly Series C (L14, private
placement) were carried as Highly Liquid / Less Liquid instead of Illiquid, and the HLIM check did not deduct the
USD 4.6m futures margin at Kestrow as Program section 5.2 requires.

This is an after-the-fact identification under Program section 4.3. The Program Administrator (Brightwater LRM
Committee, chair J. Amsel) must report to the Board and cause Form N-RN Part B to be filed **no later than Monday
21 September 2026**. Separately, the adviser is about to fund a USD 6,000,000 illiquid purchase (Tessaly Series D)
on 25 September that the 15% rule prohibits while the Fund is above the limit; the funding instruction must be held.

The N-PORT deadline is not at risk: the fiscal Q3 reports (June, July, August) are due 60 days after 31 August,
i.e. **30 October 2026** (Procedures 1.1–1.2). Filing requires Treasurer sign-off and no open exceptions
(Procedures 3.4; Program 6.1).

## 2. Line-by-line corrections (Part C)

All 25 lines were checked against the section 2 sources of truth in `inputs/policies/BST_Form_NPORT_preparation_procedures.md`:
value and level to `inputs/accounting/BGOF_holdings_valuation_20260831.csv`, percentage to net assets on
`inputs/accounting/BGOF_statement_of_net_assets_20260831.csv`, asset/issuer type and restricted flag to
`inputs/reference/BGOF_security_master_extract.csv`, liquidity to the Program rules applied over
`inputs/liquidity/BGOF_vendor_liquidity_classification_20260831.csv` and `inputs/liquidity/BGOF_liquidity_override_log_2026.csv`.

| # | Line | Field | Draft | Corrected | Basis |
|---|---|---|---|---|---|
| 1 | L03 Vaudrey SA | value_usd | 11,186,000.00 | **12,399,681.00** | Draft carries the EUR local value. Accounting: EUR 11,186,000 × 1.1085 = USD 12,399,681.00. With this fix, Part C sums to 348,613,282.39 = "Investments at value" on the statement of net assets (draft sums to 347,399,601.39, short by exactly 1,213,681.00). |
| 2 | L03 Vaudrey SA | pct_net_assets | 3.0400 | **3.3699** | 12,399,681.00 / 367,956,922.39 × 100, 4 dp. |
| 3 | L07 Carrow Networks 5.875% 2030 (144A) | is_restricted_security | N | **Y** | Security master: rule_144a_eligible Y, restricted_security Y. Item C.10 includes 144A securities (Procedures s.2). L05 and L25, the other 144A lines, are correctly Y. Liquidity unaffected (Program 3.6). |
| 4 | L09 US Treasury Note 4.250% 2034 | issuer_cat | CORP | **UST** | Security master issuer_type "U.S. Treasury". |
| 5 | L11 Brightwater Government MMF | asset_cat | EC | **STIV** | Money market fund shares = short-term investment vehicle (Procedures s.2). Issuer type RF is correct. |
| 6 | L14 Tessaly Series C Conv. Preferred (private placement) | liquidity_classification | Less Liquid | **Illiquid** | Program rule 3.5: restricted, not 144A-eligible, no secondary market (security master: private_placement Y, "no public market; transfer subject to ROFR; issuer consent required"). Vendor bucket is an explicit "default bucket for unlisted preferred — no market data"; Program rules apply before the vendor model. No LRM Committee approval of any other bucket in the override log. |
| 7 | L16 Norcastle Mining common | liquidity_classification | Highly Liquid | **Illiquid** | Program rule 3.4: primary market halted 27 Aug 2026 (exchange notice, `inputs/notices/…`), no alternative venue, still halted 17 Sep, issuer does not expect to file before 15 Oct. Vendor inputs dated 2026-08-26 (pre-halt, stale — Program 2.2). Valuation Designee memo item 1: "not saleable while the halt continues", Program Administrator informed 2 Sep. Level 3 in the draft is correct. |
| 8 | L19 Dellbrook Foods TLB | liquidity_classification | Illiquid | **Less Liquid** | Override OVR-2026-019 (PM request to Illiquid) was **rejected** 2026-08-20; "revert to vendor bucket". Vendor: Less Liquid. Program 2.2 (rejected request has no effect) and 3.7 (saleable in 7 days, settles T+7 to T+15). |
| 9 | L22 Pembury Retail plc | fair_value_level | 1 | **2** | Accounting level 2, priced "EXCHANGE_CLOSE × FAIR VALUE FACTOR (systematic, 2026-08-31 trigger)"; Valuation Designee memo item 5 puts all non-U.S. equities (L03, L04, L22) at Level 2. L03/L04 already show 2. |

Items 1–5 and 9 are data-mapping errors Oakhurst corrects and logs (Procedures 3.1). Items 6–8 are classification
exceptions: Oakhurst does not change them on its own authority; they go to the Program Administrator for written
confirmation (Procedures 3.2) and the draft stays open until then.

Lines verified correct with no change: L01, L02, L04, L05, L06, L08, L10, L12 (override OVR-2026-021 to Highly
Liquid is PENDING and has no effect — stays Moderately Liquid), L13, L15, L17, L18, L20, L21, L23, L24, L25.
Every other value, percentage (4 dp), level, restricted flag, asset and issuer code agrees to source.

## 3. Fund-level liquidity figures I would stand behind (as of 2026-08-31, corrected classifications)

**Net assets:** USD 367,956,922.39 (statement of net assets).

**Illiquid investments that are assets**

| Line | Security | USD |
|---|---|---|
| L14 | Tessaly Biosciences Series C preferred | 21,804,000.00 |
| L15 | Kilnworth Holdings private term loan (OVR-2026-011, standing) | 17,901,000.00 |
| L16 | Norcastle Mining common (halted) | 9,600,000.00 |
| L17 | Amberlane Therapeutics PIPE (OVR-2026-014, lock-up to 2027-03-15) | 8,200,000.00 |
| | **Total** | **57,505,000.00 = 15.63% of net assets** |

Excluding L16 the figure would be 47,905,000 = 13.02%, so the excess arose on 27 August 2026, the first business
day of the Norcastle halt (Program 3.4), and has persisted since. The draft's 9.95% (and the adviser's daily report
at 9.9%) is the result of the L14/L16/L19 misclassifications.

**HLIM compliance measure (Program 5.2)**

| Component | USD |
|---|---|
| Highly liquid investments: L01 12,099,920.00; L02 10,400,000.00; L03 12,399,681.00 (corrected); L04 6,200,146.16; L09 14,499,852.50; L11 9,000,000.00; L22 8,799,617.73; L24 181,350.00 | 73,580,567.39 |
| Cash — Fallowmere DDA | 16,900,000.00 |
| Cash at Kestrow Futures (initial margin) | 4,600,000.00 |
| Less: highly liquid assets posted as margin for derivatives classified Moderately Liquid (L23 index futures, Program 3.8) — full amount held by the FCM including the USD 388,000 excess (Kestrow statement 2026-08-31) | (4,600,000.00) |
| **Measure** | **90,480,567.39 = 24.59% of net assets** vs HLIM 25% → **shortfall of about USD 1.51m** |

Assumptions: receivables (investments sold 1,215,880.40; income 2,187,420.15) are not "investments" and are excluded;
the FX forward L24 is included at the vendor's Highly Liquid bucket. Sensitivity: counting receivables would give
25.51%; not deducting the margin would give 25.84% — which is roughly what the auto-check did. On the Program's
stated measure the Fund is below its HLIM. The Program Administrator should confirm the treatment.

## 4. Consequences and who needs to hear before Monday

1. **Program Administrator (Brightwater LRM Committee, J. Amsel) — today.** Confirm the three classifications.
   Under Program 4.3, report the illiquid excess to the Board and cause **Form N-RN Part B** to be filed by
   **Monday 21 Sep 2026** (one business day after identification), explaining why it was identified late —
   the Valuation Committee told the Program Administrator on 2 Sep that Norcastle was not saleable, and no
   reclassification followed. From now the Fund is treated as above 15% until the Program Administrator
   confirms otherwise. Under 5.3 the Program Administrator must determine from daily data whether the HLIM
   shortfall has run more than seven consecutive calendar days (the halt has run 22 days); if so, Board report
   within one business day and **N-RN Part D**; otherwise report at the 14 Oct 2026 meeting. The daily
   liquidity report must be corrected — it feeds pre-trade compliance.
2. **Tessaly Series D funding (CMT-2026-044, USD 6,000,000, closing 25 Sep) — hold.** Private placement
   preferred, restricted, not 144A → Illiquid under rule 3.5. Program 4.1 / Rule 22e-4(b)(1)(iv): the Fund may
   not acquire an illiquid investment while illiquid investments exceed 15% (post-funding roughly USD 63.5m ≈
   17.3%). Pre-trade compliance cleared it on 15 Sep against the wrong daily figure (M. Lindqvist email,
   `inputs/correspondence/…`). Oakhurst must not prepare or pass the 24 Sep custody/funding instruction to
   Fallowmere until the Program Administrator and CCO confirm in writing that the acquisition is permitted. The
   commitment is signed subject to closing conditions; the adviser (R. Castell) needs to take this up with the
   issuer now. The Harwood TLB add-on (CMT-2026-045, Less Liquid) is not an illiquid acquisition and is unaffected.
3. **CCO — today.** Illiquid limit breach since 27 Aug not identified until 18 Sep; misclassified daily
   liquidity report; a further illiquid purchase cleared on it; N-RN Part B due Monday, Part D possible.
4. **Treasurer — today.** No sign-off possible; nine open exceptions; N-PORT deadline 30 Oct 2026 unaffected.
   NAV and accounting are clean: the L03 and L22 errors are draft transcription errors only.
5. **Portfolio manager (R. Castell) — notify.** Series D cannot be funded while above 15%; Dellbrook reverts to
   Less Liquid; Ellery override still pending; Norcastle Illiquid until trading resumes.
6. **Liquidity vendor — request.** Re-run L16 with halt status and post-26 Aug inputs; confirm the L14 default
   bucket is suppressed where Program rule 3.5 applies.

## 5. Open items I need answered

- Program Administrator's written confirmation of L14, L16, L19.
- Daily illiquid and HLIM data from 27 Aug to date, to fix the breach start date and the HLIM shortfall duration
  (N-RN Part D trigger).
- Any written LRM Committee approval of a non-Illiquid bucket for Tessaly Series C not in the override log
  (none found; rule 3.5 applied).
- Whether the June and July fiscal Q3 drafts (filed together with August) carry the same L03 local-currency error,
  the L14 classification (held since the 19 May Series C close) and the L19 override.
- Whether 2 Sep (Program Administrator informed of the halt) rather than 18 Sep is the "identification" date for
  Program 4.3 — the N-RN narrative must address it.
- Whether the adviser can defer or withdraw the Series D commitment before 25 Sep.
- Program Administrator's confirmation of the HLIM measure treatment of receivables and margin (section 3).
- Item C.4.b issuer type for the exchange-traded futures (L23, shown CORP, issuer N/A): no derivative mapping in
  the Procedures; left unchanged, flagged.

## 6. Files relied on

`inputs/nport/BGOF_NPORT_draft_2026-08_PartC_holdings.csv`; `inputs/accounting/BGOF_holdings_valuation_20260831.csv`;
`inputs/accounting/BGOF_statement_of_net_assets_20260831.csv`; `inputs/reference/BGOF_security_master_extract.csv`;
`inputs/liquidity/BGOF_vendor_liquidity_classification_20260831.csv`; `inputs/liquidity/BGOF_liquidity_override_log_2026.csv`;
`inputs/policies/BGOF_liquidity_risk_management_program_extract.md`; `inputs/policies/BST_Form_NPORT_preparation_procedures.md`;
`inputs/valuation/BGOF_valuation_designee_memo_20260831.txt`; `inputs/derivatives/Kestrow_Futures_statement_BGOF_20260831.txt`;
`inputs/notices/exchange_notice_Norcastle_trading_halt_20260827.txt`; `inputs/trades/BGOF_pending_commitments_20260918.csv`;
`inputs/correspondence/email_Castell_team_Tessaly_SeriesD_20260917.txt`.

Re-performance: percentage = value_usd ÷ 367,956,922.39 × 100 rounded to 4 dp; illiquid % = 57,505,000 ÷
367,956,922.39 = 15.63%; HLIM measure = (73,580,567.39 + 16,900,000 + 4,600,000 − 4,600,000) ÷ 367,956,922.39 =
24.59%; N-PORT due = 2026-08-31 + 60 days = 2026-10-30; Board report / N-RN Part B due = one business day after
Fri 2026-09-18 = Mon 2026-09-21.
