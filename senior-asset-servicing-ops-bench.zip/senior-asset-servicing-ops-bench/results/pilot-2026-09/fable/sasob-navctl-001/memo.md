# CMOF — Ostrander Micro Devices (OSMD) stale price 9/10–9/16: what to correct, what it cost, who pays

**To:** Mara Lindqvist, Treasurer & PFO, Corvane Investment Trust
**Re:** Stellmark proposal of 17 Sep 2026 (R. Castellan) — recommendation before your 2pm
**Date:** 18 Sep 2026

## Bottom line

Do not sign Rafael's proposal as drafted. It gets the framework right (re-price on the Nasdaq official closes) but is wrong on four points that matter to the Board:

| Point | Stellmark proposal | Policy requires | Effect |
|---|---|---|---|
| Days to reprocess | All five (9/10–9/16) | Only Material Days: **9/11, 9/14, 9/16**. 9/10 and 9/15 fail the 0.50% test (policy 1.4, 2.1, 3.1) | Fewer, defensible adjustments |
| Fund impact | "Net loss roughly $12k" | **Gross Fund Losses, not netted** against gains (6.2): **$43,724.90** | Reimbursement is 3.6x Rafael's figure |
| De minimis | Skip any transaction under $10 | **Per account, aggregated across Material Days** (5.3) | Two accounts Rafael would skip (101945, 100587) must be adjusted |
| Who pays | Vendor error; Fund carries loss "for now" | **Stellmark** — it did not perform Schedule C, so the 7.2 safe harbour is gone and 7.3 applies. The Fund never bears a NAV error (policy 7.2) | Fund cost: **$0** |

## 1. What happened (inputs relied on)

- `inputs/pricing/primary_vendor_notice_QPS-558120.txt`: OSMD moved from NYSE to Nasdaq effective 9/10. The vendor's feed kept delivering the last NYSE close, **$48.20**, for 9/10–9/16; corrected in the 9/17 file.
- `inputs/pricing/price_exception_log_CMOF_20260910_20260917.csv`: Stellmark's own control flagged OSMD **every day**, and Stellmark accepted the stale primary price every day until 9/17:

| Date | Exception | Primary | Nasdaq close (secondary) | Diff | Cleared as |
|---|---|---|---|---|---|
| 9/10 | UNCHANGED_PRICE | 48.20 | 47.10 | 2.34% | "Within tolerance" |
| 9/11 | UNCHANGED + TOLERANCE_BREACH | 48.20 | 45.60 | 5.70% | "vendor says price will update" |
| 9/14 | UNCHANGED + TOLERANCE_BREACH | 48.20 | 44.90 | 7.35% | "vendor ticket open" |
| 9/15 | UNCHANGED_PRICE | 48.20 | 47.35 | 1.80% | "Within tolerance" |
| 9/16 | UNCHANGED + TOLERANCE_BREACH | 48.20 | 51.10 | -5.68% | "ticket still open" |
| 9/17 | UNCHANGED + TOLERANCE_BREACH | 48.20 | 50.62 | -4.78% | Escalated by NAV Oversight; Nasdaq close used |

- `inputs/correspondence/email_corvane_pm_desk_20260911.txt`: Oren Blakeslee told Ops at 16:47 on 9/11 that OSMD "printed 45.60 on Nasdaq today"; Ops forwarded to Stellmark Pricing at 16:58. Stellmark cleared the exception at 17:55 accepting 48.20 anyway.
- `inputs/portfolio/holdings_top_positions_CMOF_20260909.csv`: 1,200,000 sh OSMD (14.46% of net assets).
- `inputs/portfolio/trade_blotter_CMOF_20260910_20260916.csv`: EQ-260915-0063, **SELL 200,000 OSMD trade date 9/15** at 47.30. Position is therefore **1,000,000 sh for the 9/15 and 9/16 NAVs**. No other OSMD trades in the period.
- `inputs/nav/published_nav_history_CMOF_20260910_20260917.csv`: published TNA, shares outstanding and NAV (Institutional class only). 9/17 NAV 24.52 is struck on 50.62 and is clean.
- `inputs/transfer_agent/ta_transaction_detail_CMOF_20260910_20260917.csv`: 27 shareholder transactions 9/10–9/17.
- `inputs/policies/CIT_NAV_error_correction_policy.md` (v3.1) and `inputs/agreements/stellmark_fund_administration_agreement_excerpt.md` (s.7, Schedule C).

## 2. Which days we correct — day-by-day test (policy 1.2, 1.4, 2.1)

Corrected NAV = (published TNA − (48.20 − Nasdaq close) × OSMD quantity) ÷ published shares outstanding, rounded to $0.01. Material Day = error ≥ $0.01 **and** ≥ 0.50% of Corrected NAV.

| NAV date | Qty | Valuation error | Published TNA | Shares out | Corrected NAV (raw) | Corrected | Published | Error/sh | % | Material? |
|---|---|---|---|---|---|---|---|---|---|---|
| 9/10 | 1,200,000 | +1,320,000.00 | 401,183,412.58 | 16,482,915.337 | 24.2593 | **24.26** | 24.34 | +0.08 | 0.3298% | **No** |
| 9/11 | 1,200,000 | +3,120,000.00 | 399,621,900.89 | 16,487,734.565 | 24.0483 | **24.05** | 24.24 | +0.19 | 0.7900% | **Yes** |
| 9/14 | 1,200,000 | +3,960,000.00 | 402,230,366.97 | 16,508,347.601 | 24.1254 | **24.13** | 24.37 | +0.24 | 0.9946% | **Yes** |
| 9/15 | 1,000,000 | +850,000.00 | 402,416,236.68 | 16,514,483.581 | 24.3160 | **24.32** | 24.37 | +0.05 | 0.2056% | **No** |
| 9/16 | 1,000,000 | −2,900,000.00 | 402,138,352.04 | 16,478,997.328 | 24.5791 | **24.58** | 24.40 | −0.18 | −0.7323% | **Yes** |

So the Error Period is five days, but only **9/11, 9/14 and 9/16** are Material Days. 9/10 and 9/15 are logged (8.3) and nothing is reprocessed for them (3.1). Rafael's "cleaner than picking days" is not what the policy permits — 2.1 requires each day to be tested separately, and reprocessing non-material days would adjust accounts (e.g. Harlow Family Trust, Pinecrest, Wexcombe on 9/10) that have no entitlement.

Note: the 9/15 sale of 200k shares at 47.30 was executed at market and is already correctly reflected in the published 9/15 NAV; only the remaining 1,000,000 sh were mispriced. Reprocessing on 1,200,000 sh for 9/15–9/16 would overstate the 9/16 error (it would still be material, but the Corrected NAV would be wrong).

No further correcting entry to the OSMD valuation is needed: the 9/17 NAV already carries the correct price (1.2 — later NAVs are not re-struck for second-order effects).

## 3. Reprocessing the three Material Days (policy 4, 5, 6)

Dollar orders: hold dollars, recalc shares to 3dp (half up). Share orders: hold shares, recalc cash to the cent.

### 9/11 — published 24.24, corrected 24.05 (overstated by $0.19)

| Confirm | Account | Txn | As processed | Corrected | Result |
|---|---|---|---|---|---|
| SSS26091140123 | 900011 Tarrant Hollis omnibus | PUR $2,400,000 | 99,009.901 sh | 99,792.100 sh | **Owed 782.199 sh = $18,811.89** |
| SSS26091140124 | 100587 Okonkwo | PUR $900 | 37.129 | 37.422 | Owed 0.293 sh = $7.05 |
| SSS26091140125 | 103771 Sato IRA | PUR $600 | 24.752 | 24.948 | Owed 0.196 sh = $4.71 |
| SSS26091140126 | 102310 Ellery Twp | RED 60,000 sh | $1,454,400.00 | $1,443,000.00 | **Fund Loss $11,400.00** (5.2 — not recovered) |
| SSS26091140127 | 900027 Wexcombe omnibus | RED 18,500 sh | $448,440.00 | $444,925.00 | **Fund Loss $3,515.00** |
| SSS26091140128 | 101945 Vasquez IRA | PUR $1,000 | 41.254 | 41.580 | Owed 0.326 sh = $7.84 |

Day: Fund Loss **$14,915.00**; owed to shareholders **$18,831.49**.

### 9/14 — published 24.37, corrected 24.13 (overstated by $0.24)

| Confirm | Account | Txn | As processed | Corrected | Result |
|---|---|---|---|---|---|
| SSS26091440129 | 100587 Okonkwo | PUR $800 | 32.827 | 33.154 | Owed 0.327 sh = $7.89 |
| SSS26091440130 | 103771 Sato IRA | PUR $400 | 16.414 | 16.577 | Owed 0.163 sh = $3.93 |
| SSS26091440131 | 900027 Wexcombe omnibus | PUR $750,000 | 30,775.544 | 31,081.641 | **Owed 306.097 sh = $7,386.12** |
| SSS26091440132 | 101122 Pinecrest | RED $500,000 (dollar basis) | 20,517.029 sh redeemed | 20,721.094 sh | **Fund Loss: 204.065 sh left in account × 24.13 = $4,924.09** |
| SSS26091440133 | 103002 Farrow | RED 4,200.500 sh | $102,366.19 | $101,358.07 | **Fund Loss $1,008.12** |
| SSS26091440134 | 101945 Vasquez IRA | PUR $700 | 28.724 | 29.010 | Owed 0.286 sh = $6.90 |

Day: Fund Loss **$5,932.21**; owed **$7,404.84**.

### 9/16 — published 24.40, corrected 24.58 (understated by $0.18)

| Confirm | Account | Txn | As processed | Corrected | Result |
|---|---|---|---|---|---|
| SSS26091640138 | 900011 Tarrant Hollis omnibus | PUR $3,100,000 | 127,049.180 sh | 126,118.796 sh | **Fund Loss: 930.384 excess sh × 24.58 = $22,868.84** |
| SSS26091640139 | 102310 Ellery Twp | RED 25,000 sh | $610,000.00 | $614,500.00 | **Owed cash $4,500.00** (5.1(b)) |
| SSS26091640140 | 101945 Vasquez IRA | RED 40 sh | $976.00 | $983.20 | Owed cash $7.20 |
| SSS26091640141 | 100587 Okonkwo | PUR $1,200 | 49.180 | 48.820 | Fund Loss: 0.360 sh × 24.58 = $8.85 |
| SSS26091640142 | 900027 Wexcombe omnibus | RED 12,000 sh | $292,800.00 | $294,960.00 | **Owed cash $2,160.00** |

Day: Fund Loss **$22,877.69**; owed **$6,667.20**.

### What it cost the Fund

**Fund Losses, gross, all Material Days: $14,915.00 + $5,932.21 + $22,877.69 = $43,724.90.** Under 6.2 these are not reduced by the Fund's gains (fewer shares issued on 9/11 and 9/14; underpaid redemptions on 9/16) — those gains are passed to shareholders under 5.1 or, where de minimis applies, retained by the Fund. Rafael's "net roughly $12k" nets the two and is not the policy measure; I could not reconcile his figure to the data on any basis.

### Which shareholders we owe (per-account aggregate, 5.3)

| Account | Registration | Shares to credit | Cash to pay | Aggregate value | Treatment |
|---|---|---|---|---|---|
| 900011 | Tarrant Hollis omnibus | 782.199 (9/11) | — | $18,811.89 | Adjust |
| 900027 | Wexcombe omnibus | 306.097 (9/14) | $2,160.00 (9/16) | $9,546.12 | Adjust |
| 102310 | Ellery Twp Police & Fire | — | $4,500.00 (9/16) | $4,500.00 | Adjust |
| 101945 | R Vasquez Trad IRA | 0.326 + 0.286 = 0.612 | $7.20 | $21.94 | **Adjust** (each item < $10, aggregate ≥ $10) |
| 100587 | J & M Okonkwo JTWROS | 0.293 + 0.327 = 0.620 | — | $14.94 | **Adjust** (aggregate ≥ $10) |
| 103771 | L Sato Roth IRA | (0.359) | — | $8.64 | **Below de minimis** — no adjustment; Fund retains |

**Totals after de minimis: 1,089.528 shares credited; $6,667.20 cash paid; 5 accounts adjusted; 1 account below de minimis.** Amounts owed before de minimis: $32,903.53.

Benefiting accounts (102310, 900027 on 9/11; 101122, 103002 on 9/14; 900011, 100587 on 9/16) are not charged (5.2) and their benefit is not offset against what they are owed (5.3) — e.g. Ellery is paid $4,500 for 9/16 even though it was overpaid $11,400 on 9/11. Omnibus accounts are adjusted at Fund level; allocation is Tarrant Hollis' and Wexcombe's responsibility (5.4).

The cash compensation and share credits are funded by the Fund (they are the Fund's own gains being passed through under 6.2); the $43,724.90 reimbursement is owed to the Fund by the Responsible Party.

## 4. Who pays

**Stellmark.** Rafael relies on agreement 7.2, but 7.2 only excludes Stellmark's liability for a Pricing Source error *"provided that Stellmark performed the validation procedures in Schedule C"*. It did not, on any of the five days:

- **C.3** — an unchanged-price exception "may not be cleared on the basis that the primary and secondary prices are within tolerance", and Stellmark must confirm the security traded and use the primary-exchange close. 9/10 and 9/15 were cleared exactly that way; 9/11, 9/14, 9/16 were also unchanged-price exceptions.
- **C.2** — a >5.00% primary/secondary difference requires the official close of the primary listing exchange unless the Adviser's pricing committee directs otherwise in writing. 9/11 (5.70%), 9/14 (7.35%) and 9/16 (−5.68%) breached; no adviser direction exists; the secondary price *was* the Nasdaq official close and was sitting in the log.
- **C.4** — "a vendor's statement that a price 'will update' is not evidence of the correct price and may not be used to clear an exception." That is verbatim what the 9/11, 9/14 and 9/16 clearances rely on.
- **C.5** — NAV supervisor review before release failed five times.
- The PM's 9/11 warning (45.60 on Nasdaq) was forwarded to Stellmark Pricing an hour before the exception was cleared.

This is a failure to perform Schedule C, so **7.3** applies: Stellmark reimburses the Fund per the policy and bears its own reprocessing costs, and **7.4** says that liability is not reduced by any claim against the vendor. The vendor's fee-based liability cap is Stellmark's problem, not the Fund's. Policy **7.2**: "The Fund does not bear the cost of a NAV error… recovery from third parties… does not delay reimbursement to the Fund." The Fund carrying the loss "for now" is not available to you.

Fallback: if Stellmark disputes 7.3, policy 7.1 puts the reimbursement on the Adviser (Corvane Partners) pending Board review — again, never the Fund. **Fund-borne cost: $0.**

## 5. What you owe the CCO and the Board

- **8.1** — your written approval of the correction calculation before any reprocessing. Approve a revised calculation on the basis above, not Rafael's.
- **8.2** — three Material Days must be reported **promptly to the CCO** (today) and to the **Board at its next regular meeting**, with root cause (vendor listing-line mapping failure not caught because Stellmark cleared its own Schedule C exceptions improperly for five consecutive days, including after a PM warning) and remediation (Stellmark to fix its exception-clearance practice; C.3/C.4 hard stops; supervisor review evidence).
- **8.3** — 9/10 and 9/15 go in the NAV error log for the quarterly Board report.
- **3.3** — the accounting entries (receivable from Stellmark $43,724.90; liability for $6,667.20 cash and 1,089.528 shares) move NAV by roughly $0.002/sh, below the $0.01 pre-approval trigger; log it anyway.
- **6.3** — reimbursement is due within five Business Days of your approval.

## 6. Where I differ from Rafael — summary

1. Three Material Days, not five. Days are tested individually (2.1); 9/10 and 9/15 fail the 0.50% test.
2. Fund Loss is the gross sum on Material Days, $43,724.90, not a netted ~$12k (6.2).
3. De minimis is $10 per account aggregated across the Error Period, not per transaction (5.3). Vasquez (101945) and Okonkwo (100587) are adjusted; only Sato (103771, $8.64) is not.
4. Position for 9/15–9/16 is 1,000,000 sh after the 9/15 sale, not 1,200,000.
5. Stellmark is the Responsible Party under 7.3; the Fund bears nothing and does not wait on the vendor (policy 7.2; agreement 7.4).

## 7. Assumptions and what I need

- Corrected prices are the secondary-vendor Nasdaq official closes in the exception log; Stellmark should confirm them against the exchange before you approve.
- Only the Institutional class appears in the NAV and TA extracts; if other classes exist they need the same test.
- Second-order items (management fee/expense accrual on overstated net assets) are not re-struck (1.2); ask Stellmark how the true-up is booked prospectively.
- **From Stellmark:** revised calculation on this basis with per-transaction workings; C.5 supervisor review evidence; written acceptance of 7.3 responsibility; confirmation no other Trust series holds OSMD; confirmation the 9/17 CONFIRMED trades settled at 24.52.
- **From Stellmark Shareholder Services:** confirmation the TA extract is complete and that the Corrections Desk will apply a per-account aggregate de minimis.
- **From the PM desk:** confirmation of the 1,200,000 / 1,000,000 position and no other OSMD trades 9/09–9/16.
- **From Legal:** the full administration agreement (only s.7 and Schedule C were in the pack).

Full workings and account-level adjustments are in `out/answer.json`.
