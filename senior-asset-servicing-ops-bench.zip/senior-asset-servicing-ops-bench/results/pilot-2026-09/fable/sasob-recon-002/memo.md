**To:** Graham Voss, Head of Operations Oversight
**From:** Operations Oversight analyst
**Date:** Fri 18 Sep 2026
**Subject:** TMAI / Northgate 7730-131 holdings rec as of 17 Sep — what the four differences are, and why we should not force them

## Bottom line

Do not sign off a true-up to Northgate. Every difference is traced. Three of the four are not accounting errors at all, and forcing them would put 90,000 shares of a delisted company (USD 3.7m, already received in cash) back on the books, double the Alder position a day early, and write off 170,000 Brindlewood shares the fund owns. The one genuine accounting break — the Marlowe Water Technologies spin-off not booked — is fixed by booking the corporate action, not by copying the custodian. It caused a small, non-material understatement of the 16 and 17 Sep NAVs.

Three things need doing **today**: (1) recall the 150,000 Brindlewood shares on loan for the material Castellan vote (Harrowgate cut-off 11:00 ET); (2) book the MWT spin-off before tonight's NAV and notify the Fund Treasurer of the non-material NAV error; (3) raise the Pinecrest stale position with Northgate (policy 2.4 requires same day).

## Sources relied on

| File | Used for |
|---|---|
| `inputs/accounting/positions_TMAI_7730-131_20260917.csv` | Trade-date accounting quantities, costs, prices |
| `inputs/custodian/MT535_NTCUS33_7730-131_20260917.txt` | Northgate settled holdings at close 17 Sep |
| `inputs/custodian/MT566_confirmations_7730-131_20260915-17.txt` | Northgate CA confirmations: MDH spin-off (msg 1), Pinecrest merger (msg 2), Alder split (msg 3) |
| `inputs/lending/harrowgate_onloan_report_TMAI_20260917.csv` | Open / returned / pending loans |
| `inputs/lending/securities_lending_authorization_agreement_extract.txt` | Ownership, voting, recall mechanics (ss.4, 6, 7) |
| `inputs/accounting/unsettled_trades_TMAI_20260917.csv` | Brindlewood 20k buy settling 18 Sep |
| `inputs/accounting/corporate_action_events_TMAI.csv` | Status of the four CA events in the accounting system |
| `inputs/accounting/nav_history_TMAI.csv` | Reported TNA, shares outstanding, NAV/share 14–17 Sep |
| `inputs/pricing/closing_prices_20260915_17.csv` | MWT / MDH / Alder closes |
| `inputs/notices/*` | Alder split terms, Brindlewood meeting record date, Marlowe Form 8937 and cash-in-lieu rate |
| `inputs/correspondence/email_pm_brindlewood_vote.txt` | PM intention to vote; material-vote designation |
| `inputs/policies/TFT_position_reconciliation_and_corporate_actions_procedures.md` | ss.2.2–2.5, 3.1–3.4, 4.2, 5.1–5.4 |

## Full-account rec (accounting trade-date vs MT535 settled)

| Security | ISIN | Accounting | Northgate | Diff (acct − cust) | Status |
|---|---|---|---|---|---|
| Brindlewood Industrial | USLPV8NW1399 | 420,000 | 250,000 | **+170,000** | Reconciling: 150,000 on loan + 20,000 unsettled buy |
| Alder Semiconductor | US0C86UQ8545 | 64,000 | 128,000 | **−64,000** | Reconciling: split paid 17 Sep, ex-date 18 Sep |
| Marlowe Diversified (MDH) | USEY5J8C8865 | 185,002 | 185,002 | 0 | Quantity agrees; cost needs allocation |
| Marlowe Water Tech (MWT) | US3EP60F8227 | 0 | 46,250 | **−46,250** | Accounting break: spin-off not booked |
| Pinecrest Health | USE3E5QV1890 | 0 | 90,000 | **−90,000** | Custodian error: cashed out 16 Sep |
| Ostrander Chemicals | US9SK49R0286 | 200,000 | 200,000 | 0 | Loan of 60,000 returned 17 Sep — cleared |
| Keel Harbor Bancorp | US83F34E5057 | 310,000 | 310,000 | 0 | 40,000 sale settled 17 Sep |
| Corvant Pharmaceuticals | USRC99X23381 | 145,000 | 145,000 | 0 | 30,000 loan PENDING_DELIVERY for 18 Sep; still in custody (SLAA 4.3) |
| Tessaly, Halbrook, Ashgrove, Lumen Ridge, 3 corporate bonds | — | agree | agree | 0 | Ribbonwood 500k buy settled 16 Sep |

Four securities differ. Findings below are one per cause (Brindlewood has two).

## Finding 1 — Brindlewood +170,000: on loan (150,000) + unsettled buy (20,000). No break.

- Harrowgate on-loan report 17 Sep: loan **HSF-L-2608-11932**, 150,000 sh, Borrower 0417, status OPEN since 20 Aug, collateral USD 7,983,540 (= 150,000 × 52.18 × 102%, ties to the 17 Sep close).
- Northgate's MT535 ADDINFO states securities delivered out under lending programmes are not reported; SLAA 4.1–4.2 says the fund keeps them on its books. Policy 2.3(b): accounting = custodian + open loans → 250,000 + 150,000 = 400,000.
- Ticket **EQ-260917-0412**: buy 20,000 @ 52.04, trade 17 Sep, settles 18 Sep (T+1), OPEN. Policy 2.3(a). 400,000 + 20,000 = 420,000 = accounting. Ties exactly.
- **Booked:** nothing. Carry both as evidenced reconciling items; the 20k clears on the 18 Sep rec.

**Act today — the vote.** The Castellan special-meeting record date is **24 Sep** (notice filed 8 Sep). Selin's email of 17 Sep says the Proxy Voting Committee minuted this as a material vote (27 Aug, item 4) and wants the full position of record. Voting rights on loaned shares sit with the borrower (SLAA 6.2; policy 4.2), so 150,000 of our 420,000 cannot be voted unless recalled. Under SLAA 7.1 a recall notice received by **11:00 a.m. ET** is communicated the same day and the borrower must redeliver T+1: notice today → shares back **Mon 21 Sep**. SLAA 7.2 recommends at least three business days before the record date for a material vote, which is Mon 21 Sep at the latest — so waiting until next week uses up the entire buffer for a borrower fail. Recommendation: recall the full **150,000** today and instruct Harrowgate to make no further Brindlewood loans until after 24 Sep. Once the recall settles, expect Harrowgate's report to show the loan closed and Northgate to show 420,000 (250,000 + 20,000 settlement + 150,000 return).

## Finding 2 — Alder −64,000: split paid before ex-date. Timing only, no break.

- MT566 msg 3 (SPLF): 2-for-1 effected as a 100% stock distribution; record 10 Sep; **payable 17 Sep**; NYSE **ex-date 18 Sep** (due bills). Northgate credited the extra 64,000 on 17 Sep, so its statement shows 128,000 at the split-adjusted indicative price 94.20.
- Policy 3.1 records corporate actions on the **ex-date**, expressly including cases where the ex-date falls after the payable date; 2.3(c) names exactly this as an expected reconciling item. CA-26-04702 is correctly SCHEDULED for 18 Sep.
- Valuation check: accounting 64,000 × 188.40 (pre-split close) = USD 12,057,600 = Northgate 128,000 × 94.20. No NAV effect.
- **Booked:** nothing on 17 Sep. The event processes today; please confirm it did run before tonight's NAV, otherwise 64,000 shares would meet a post-split price and the 18 Sep NAV would be understated by roughly USD 6m.

## Finding 3 — Marlowe Water Technologies −46,250: spin-off not booked. Accounting break (Pellmore).

Facts:
- MT566 msg 1 (SOFF): 1 MWT per 4 MDH; record 4 Sep; **ex-date 16 Sep**; entitlement on 185,002 MDH = 46,250.5; **46,250 whole shares** credited 15 Sep; 0.5 fractional paid in cash on/about 22 Sep.
- Garrison distribution-agent notice 16 Sep: cash in lieu USD 24.3176 per whole MWT share → 0.5 sh = **USD 12.16**.
- **Form 8937 posted 14 Sep** (before ex-date): MDH **86.40%** / MWT **13.60%**. Policy 3.3 requires these percentages (the information-statement "approximately 15%" is illustrative and expressly not to be used).
- Accounting: CA-26-04655 still **PENDING_TERMS** at 17 Sep, "awaiting cost allocation from vendor feed; US3EP60F8227 not yet set up in security master". Policy 3.2 allows PENDING_TERMS only to the day before ex-date (15 Sep); after that Fund Accounting must book from the issuer's published information and escalate the vendor gap. Neither happened. Meanwhile MDH was priced ex-distribution (38.40 on 16 Sep, 38.95 on 17 Sep) with no MWT position — the books simply dropped ~USD 1.15m of value.

Cost allocation (policy 3.3/3.4, half-up to the cent):
- MDH pre-distribution cost (positions extract): **USD 7,215,078.00**
- To MWT (incl. fractional interest): 7,215,078.00 × 13.60% = 981,250.608 → **USD 981,250.61**
- MDH retains remainder: 7,215,078.00 − 981,250.61 = **USD 6,233,827.39** (185,002 sh unchanged)
- Fractional 0.5 sh cost relieved: 981,250.61 × 0.5 / 46,250.5 = 10.608 → **USD 10.61**
- MWT position: **46,250 sh at cost USD 981,240.00** (981,250.61 − 10.61)
- Cash-in-lieu receivable **USD 12.16** (due ~22 Sep); realized gain 12.16 − 10.61 = **USD 1.55**

**Booked:** the entries above, effective 16 Sep, in today's cycle; MWT priced at exchange close (24.91 on 17 Sep). Security master set-up for US3EP60F8227 is a prerequisite. Escalate the vendor feed gap per 3.2.

### NAV impact (policy 5.1–5.4)

Only the 16 and 17 Sep NAVs are affected (on 15 Sep MDH was correctly held cum-distribution at 44.62). Omitted assets = 46,250 MWT at close + USD 12.16 receivable. Cost allocation does not affect NAV.

| NAV date | Omitted value | Shares outstanding | Error/share | Reported NAV | Error % | Corrected NAV |
|---|---|---|---|---|---|---|
| 16 Sep | 46,250 × 24.55 + 12.16 = 1,135,449.66 | 41,380,112.405 | **+0.0274** | 11.7572 | **0.23%** | 11.7846 |
| 17 Sep | 46,250 × 24.91 + 12.16 = 1,152,099.66 | 41,362,540.118 | **+0.0279** | 11.7958 | **0.24%** | 11.8237 |

Policy 5.2 makes an error material only if it is **both** ≥ USD 0.01/sh **and** ≥ 0.50%. Both dates pass the cents test but fail the percentage test → **not material**. Per 5.4: correct in the 18 Sep NAV, no restatement of 16/17 Sep, no reprocessing of shareholder activity, notify the Fund Treasurer **today**, and log it for the quarterly Board report (I would note the 3.2 control breach in the log entry).

## Finding 4 — Pinecrest −90,000: custodian error. Accounting is right.

- MT566 msg 2 (MRGR): mandatory cash merger, USD 41.25/sh, effective 15 Sep, **90,000 sh debited 16 Sep**, **USD 3,712,500 credited to 7730-131-USD on 16 Sep**; shares delisted 15 Sep (pricing file confirms).
- Accounting CA-26-04418 PROCESSED 15 Sep: shares removed, proceeds received 16 Sep. Correct under 3.1 (effective date).
- Yet the 17 Sep MT535 still lists 90,000 Pinecrest at 41.25 = USD 3,712,500. Northgate is contradicting its own confirmation — a stale/unreversed position record.
- **Booked:** nothing. Policy 2.4: raise with Northgate Client Service today with the MT566 reference NTC-CA-26-744190 and request a corrected statement. If Pellmore had "trued up", the fund would carry USD 3.7m of a non-existent security on top of the cash.

## What to book / not book — summary

| Item | Accounting adj. as of 17 Sep | Action |
|---|---|---|
| Brindlewood 150,000 on loan | 0 | Reconciling item; **recall today** for 24 Sep record date |
| Brindlewood 20,000 unsettled buy | 0 | Clears 18 Sep |
| Alder 64,000 split entitlement | 0 | Processes on ex-date 18 Sep; confirm it ran |
| MWT 46,250 spin-off | **+46,250 sh, cost 981,240.00**; MDH cost → 6,233,827.39; receivable 12.16; gain 1.55 | Book today; Treasurer notice; vendor escalation |
| Pinecrest 90,000 | 0 | Raise with Northgate today |

## Assumptions

1. The Harrowgate report and the MT535 are both as of close 17 Sep and complete; PENDING_DELIVERY loans (Corvant 30,000) have not left custody (SLAA 4.3).
2. Harrowgate's 11:00 ET cut-off and T+1 redelivery apply as written in SLAA 7.1; 18 Sep is a business day.
3. The only omissions from the 16–17 Sep NAVs relating to this event were the MWT shares and the cash-in-lieu receivable; MDH was priced ex-distribution on both dates (extract shows 38.40 / 38.95). NAV working papers were not in the folder, so the error is computed from reported TNA and shares outstanding on unrounded figures per 5.1.
4. Half-up rounding to the cent at each step of the allocation, parent retaining the remainder, as 3.3/3.4 prescribe.
5. "Proceeds received 16 Sep" for Pinecrest is taken from Pellmore's CA note and the MT566; the cash account statement itself is not in the folder.

## What I need, from whom

- **Harrowgate:** confirmation the 150,000 Brindlewood recall was received before 11:00 ET today, borrower redelivery date, and confirmation no other Brindlewood loans are open or pending; lending restriction on Brindlewood through 24 Sep.
- **Northgate:** corrected MT535 removing Pinecrest, and the 7730-133 cash statement / MT950 for 16 Sep evidencing the USD 3,712,500 credit.
- **Pellmore Fund Accounting:** book the MWT spin-off today as above; set up US3EP60F8227; confirm Alder CA-26-04702 processed on 18 Sep; explain why CA-26-04655 was held in PENDING_TERMS past 15 Sep and whether any control flagged it; Treasurer notification and NAV error log entry.
- **Corporate-actions vendor:** root cause of the missing Form 8937 allocation and confirmation the feed now shows 86.40/13.60.
- **Proxy Voting Committee:** copy of the 27 Aug minutes (item 4) designating the vote material, for the file.
- **Selin Aukland:** informed that the loan is being recalled and that 420,000 shares should be of record on 24 Sep subject to borrower redelivery.
