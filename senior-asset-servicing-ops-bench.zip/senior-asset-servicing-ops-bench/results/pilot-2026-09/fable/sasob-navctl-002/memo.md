**To:** Priya Ramaswamy, Director, Fund Administration Oversight
**Re:** CMAF — 10 bp management fee waiver applied after expiry: recommendation for tonight's (9/18) NAV
**Date:** Fri 18 Sep 2026

## Bottom line

1. **It is not a "NAV error" in the reprocessing sense.** Tested day by day under the Trust's Policy on the Correction of NAV Errors (v3.1), there are **zero Material Days**. The error peaked at **$0.0143 per share = 0.0549% of the corrected NAV** on 9/17; the Policy's materiality test needs **both** ≥ $0.01 **and** ≥ 0.50% (s.1.4). The penny prong was met on 92 of the 140 affected NAV dates; the 0.50% prong (about $0.13/share at a $26 NAV) was never close. No shareholder activity is reprocessed, no accounts are adjusted, nothing is reimbursed to the Fund (s.3.1).
2. **Neither of Priyanka's options is permitted.** (a) Spreading the catch-up to 10/31 is expressly prohibited — s.3.2: "may not be deferred, amortized or spread over future NAVs". (b) Reprocessing back to the first penny day applies only half of the two-prong test.
3. **What we book tonight (9/18 NAV), in full:**
   - Dr 5100 Management fee expense **$176,355.81** / Cr Management fee payable – Corvane Partners LLC.
   - Dr 1380 Expense-limitation reimbursement receivable – Adviser **$42,491.49** / Cr Expense reimbursement (the missed fee pushes FYTD covered expenses over the 85 bp cap).
   - **Net reduction in net assets $133,864.32 = $0.0109 per share** on 12,332,341.362 shares, i.e. about one cent on the $26.04 NAV of 9/17 (before market movement and the normal 9/18 accruals). Because that is ≥ $0.01, **the Treasurer's written approval is required before the 9/18 NAV is released, and the item goes in the NAV error log** (s.3.3). The approval does not permit spreading.
4. **Does anyone owe the Fund money? No.** The Fund owes the Adviser the under-accrued fee ($176,355.81 through 9/17); the Adviser owes the Fund the expense-cap reimbursement ($42,491.49 through 9/17). No service-provider reimbursement is due because there is no Fund Loss without a Material Day (s.6).
5. **Board (Q3 materials):** report as a non-material NAV error under s.8.3 — see section 7 below.
6. **Fee module:** WVR-CMAF-01 end date must be set to 2026-02-28 before tonight's accrual; go-forward management fee is the full 60 bps; the Fund is now above the 85 bp cap so a daily reimbursement accrual will run for the rest of FY2026.

## 1. Sources relied on (all in `inputs/`)

| File | Used for |
|---|---|
| `correspondence/adviser_letter_fee_waiver_20260120.txt` | Waiver ran through 2026-02-28; full 0.60% from 2026-03-01; ELA extended at 0.85% to 2027-02-28 |
| `correspondence/email_stellmark_fund_accounting_20260918.txt` | Stellmark's finding, ~$176k / ~1.4¢ estimate, options (a)/(b) |
| `fund_documents/CMAF_prospectus_fee_table_excerpt_20260227.md` | Prospectus correctly discloses the waiver as expired 2/28/2026 |
| `accounting/fee_module_setup_CMAF.csv` | WVR-CMAF-01 `effective_to` = 2026-12-31 (should be 2026-02-28); EXPLIM-CMAF-01 was updated 2026-02-02 from the same letter |
| `accounting/mgmt_fee_daily_accrual_CMAF_FY2026_20260917.csv` | 321 calendar accrual days 2025-11-01..2026-09-17; `waiver_usd` per day; `booked_in_nav_date` |
| `accounting/expense_summary_CMAF_FYTD_20260917.csv` | FYTD covered expenses $2,201,519.44; ADNA $312,411,608.50; 321 days; cap $2,335,383.76; GL 1380 = $0.00 |
| `nav/nav_history_CMAF_20251030_20260917.csv` | Daily TNA, shares outstanding, published NAV (all FINAL, Institutional class only) |
| `policies/CIT_NAV_error_correction_policy.md` | Definitions (s.1), testing (s.2), non-material treatment (s.3), reimbursement (s.6), reporting (s.8) |
| `policies/stellmark_fee_and_expense_procedures_excerpt.md` | Accrual conventions (E1), FYTD cap method (E2), corrections (E3) |

Data integrity checks I ran before relying on the extracts: every accrual row recomputes (net assets × bps/10,000/365, gross − waiver = net) to the cent; the net-assets basis is the prior Business Day's NAV in every row; the 321 days are complete with no gaps; the sum of `net_fee_usd` ($1,373,274.90) ties to line 01 of the expense summary; every published NAV ties to TNA ÷ shares; FYTD ADNA recomputed from the NAV history = $312,411,608.50; cap recomputed 0.0085 × 312,411,608.50 × 321/365 = $2,335,383.76. No rate, basis or other accrual errors found — the only defect is the waiver end date.

## 2. The missed fee

- Waiver wrongly applied to accrual dates **2026-03-01 through 2026-09-17: 201 calendar days**.
- **Missed fee = Σ `waiver_usd` for those days = $176,355.81.** (Monthly: Mar 26,343.25; Apr 25,889.37; May 27,232.78; Jun 26,603.59; Jul 27,626.46; Aug 27,631.30; Sep 1–17 15,029.06.)
- **First NAV affected is Friday 2026-02-27, not 3/2.** Under Stellmark E1.2 a Friday NAV carries Saturday/Sunday accruals, and the accrual file shows the 3/1 (Sunday) row with `booked_in_nav_date` = 2026-02-27, waiver $858.45. Priyanka's "since March" figure (≈ $175,497 from the 3/2 NAV) omits that day. Please make sure Stellmark's entry uses $176,355.81.
- **140 NAV dates** are affected (2026-02-27..2026-09-17).

## 3. Materiality test (Policy s.1.2, 1.4, 2.1, 2.2)

Method: for each affected NAV date, cumulative misstatement = running sum of the wrongly applied waiver booked in NAVs up to and including that date, measured **gross** (before the expense-cap effect, s.2.2). Corrected NAV = (published TNA − cumulative misstatement) ÷ published shares, rounded to $0.01 (s.1.2). Difference = published NAV − Corrected NAV. Material Day = difference ≥ $0.01 **and** ≥ 0.50% of Corrected NAV.

| NAV date | Cumulative missed fee | Published NAV | Corrected NAV | Rounded diff | Error/share (unrounded) | % of corrected NAV |
|---|---|---|---|---|---|---|
| 2026-02-27 | 858.45 | 25.66 | 25.66 | 0.00 | 0.0001 | 0.0003% |
| 2026-03-31 | 26,343.25 | 25.60 | 25.60 | 0.00 | 0.0022 | 0.0085% |
| 2026-04-30 | 52,232.62 | 26.42 | 26.42 | 0.00 | 0.0043 | 0.0161% |
| 2026-05-29 | 79,465.40 | 26.22 | 26.22 | 0.00 | 0.0065 | 0.0248% |
| 2026-06-30 | 106,068.99 | 26.62 | 26.61 | 0.01 | 0.0087 | 0.0327% |
| 2026-07-31 | 135,491.49 | 26.87 | 26.86 | 0.01 | 0.0110 | 0.0411% |
| 2026-08-31 | 161,326.75 | 25.90 | 25.88 | 0.02 | 0.0131 | 0.0504% |
| 2026-09-17 | 176,355.81 | 26.04 | 26.03 | 0.01 | 0.0143 | 0.0549% |

Results across all 140 dates:
- Rounded difference ≥ $0.01 on **92 dates** (first on 3/17 by rounding; every day from 7/17, when the unrounded error first exceeded $0.01). Largest rounded difference $0.02.
- **Peak error $0.0143/share on 9/17** ($176,355.81 ÷ 12,332,341.362 shares) = **0.0549%** of the $26.03 corrected NAV.
- **0.50% prong never met → 0 Material Days.** Even at the 9/17 peak the error is about one-ninth of the threshold.

Consequence (s.3): no reprocessing, no shareholder adjustments, no Fund reimbursement; books corrected prospectively with the full cumulative correction in the next NAV.

## 4. Tonight's entries and NAV impact (Policy s.3.2–3.3; Stellmark E2.1, E3.1)

Measured as of the 9/17 accrual date, booked in the 9/18 NAV:

| # | Entry | Dr | Cr |
|---|---|---|---|
| 1 | Management fee expense (5100) / Management fee payable – Adviser | 176,355.81 | 176,355.81 |
| 2 | Expense-limitation reimbursement receivable (1380) / Expense reimbursement (contra-expense) | 42,491.49 | 42,491.49 |

Entry 2 derivation: FYTD covered expenses $2,201,519.44 + $176,355.81 = **$2,377,875.25**; FYTD cap $2,335,383.76; receivable = max(0, 2,377,875.25 − 2,335,383.76) = **$42,491.49**; current receivable $0.00, so the change is the full amount. (FYTD ADNA is not restated because there is no Material Day — E2.3.)

- **Net reduction in net assets: $133,864.32.**
- **Per share: $133,864.32 ÷ 12,332,341.362 = $0.0109** (gross $0.0143 before the cap offset). On the 9/17 figures the NAV would have been $26.03 instead of $26.04.
- Since the movement is ≥ $0.01, **s.3.3 applies: Treasurer written approval before release + NAV error log entry with the explanation of the day's movement.** Recommend Stellmark holds the 9/18 NAV release until the approval is on file.
- The ordinary 9/18 accrual (60 bp gross, no waiver) and the daily cap true-up for 9/18 are booked on top. Going forward the Fund's covered expenses run at roughly 0.865% of ADNA versus the 0.85% cap, so the Adviser will be reimbursing about 1.5 bp annualised for the remainder of FY2026; the shareholders' net expense ratio is therefore protected at 0.85% (the error's economic effect on shareholders is largely a timing one).

Why not the alternatives:
- **Option (a) — amortize to 10/31 (44 accrual days):** prohibited by s.3.2 for an Error Period with no Material Day ("may not be deferred, amortized or spread over future NAVs, and may not be recorded against capital or prior periods"). Smoothing a one-cent move is not a permitted reason.
- **Option (b) — reprocess from the first penny day:** s.1.4 requires both prongs; reprocessing without a Material Day is contrary to s.3.1 and would trigger s.4–6 machinery (recalculated trades, de minimis tests, Responsible Party reimbursement) that the Policy does not permit here.
- **Restating prior NAVs:** not permitted (s.3.1/3.2, E2.3).

## 5. Who owes whom

- **Fund → Adviser:** $176,355.81 of management fee under-accrued (and, subject to confirmation of the March–August payment runs, underpaid). This is the Adviser's contractual entitlement under the IAA at 0.60%, not compensation.
- **Adviser → Fund:** $42,491.49 expense-limitation reimbursement through 9/17, growing daily from here.
- **Stellmark → Fund:** nothing under the Policy. s.6 reimbursement is for Fund Losses on Material Days only, and there are none. Whether the service agreement carries any fee-credit provision for the control failure is a separate commercial question for the Board (open question below); it does not affect tonight's NAV.
- **Shareholders:** none reprocessed. Purchasers since 2/27 paid up to 2¢/share too much and redeemers received up to 2¢/share too much; the Policy treats this as immaterial.

## 6. Root cause and control failure

The 2026-01-20 letter covered two items. Stellmark actioned the ELA extension (EXPLIM-CMAF-01 updated 2026-02-02 by p.oduya to 2027-02-28) but left WVR-CMAF-01 at `effective_to` 2026-12-31 (set 2025-03-03 from the prior letter, which ran to 2/28/2026 — so the 12/31/2026 date was wrong from the outset, not merely un-updated). Stellmark's own procedure E1.3 requires rule dates to be set from the source document and reviewed by a second preparer; that review did not catch either the original mis-keying or the January letter. The 2/27/2026 prospectus correctly disclosed the waiver as expired, so the error is in the accounting, not the disclosure. Detection took 6.5 months and came from a quarterly rule review rather than a fee reasonableness check against the prospectus fee table — worth raising as a control point.

## 7. Q3 Board materials (Policy s.8.3)

Include as a non-material NAV error, reported quarterly:
1. Description and root cause (above), and who found it and when (Stellmark quarterly fee rule review, 9/17; reported 9/18).
2. Amounts: missed fee $176,355.81 (201 accrual days, 3/1–9/17); consequential expense-limitation reimbursement $42,491.49; net $133,864.32.
3. NAV impact: 140 NAV dates affected (2/27–9/17); peak $0.0143/share (0.0549% of NAV); rounded difference of $0.01–$0.02 on 92 dates; **0 Material Days** under s.1.4; no reprocessing, no shareholder adjustment, no Fund reimbursement.
4. Correction: booked in full in the 9/18 NAV; NAV movement ≈ −$0.0109/share; Treasurer approval obtained (attach); NAV error log reference.
5. Remediation: rule end date corrected to 2/28/2026; Stellmark review of all fee/waiver rule end dates across the Trust; evidence of second-preparer review; recommended addition of a periodic fee-rate reconciliation to the prospectus fee table.
6. Note that the Fund is now above the 85 bp cap and the Adviser is reimbursing expenses for the rest of FY2026; and that the 4/30/2026 semi-annual report understated management fee expense by $52,232.62 (immaterial; CCO to note).
7. If the Board wishes, the question whether Stellmark's service agreement provides any fee credit for the control failure.

## 8. What I need, from whom

- **Treasurer (Mara):** written approval today of the correction calculation and the 9/18 NAV movement (s.3.3); confirmation that the Corrected NAV method in s.1.2 (restate the fee accrual only, published shares) is the one to use — the zero-Material-Day conclusion is robust to any reasonable alternative.
- **Stellmark (Priyanka):** (1) book entries 1 and 2 in the 9/18 NAV in full, using $176,355.81 (through the 9/17 accrual, including the 3/1 day in the 2/27 NAV); (2) hold the 9/18 release for Treasurer approval and confirm the actual pre-release per-share impact; (3) fee module change evidence for WVR-CMAF-01 (end date 2026-02-28) with second-preparer sign-off; (4) confirmation that the daily cap true-up now accrues; (5) March–August fee payment runs so we can confirm the underpaid amount to the Adviser; (6) a review of every rule end date across the Trust and a root-cause write-up for the Board; (7) the NAV error log entry.
- **Adviser (Corvane Partners finance):** confirm the catch-up fee payable and the ELA reimbursement, and whether the ELA permits netting against the fee payable or requires separate remittance.
- **CCO:** notification of the non-material error and the E1.3 control failure; view on the semi-annual report understatement.
- **Tax preparer:** the catch-up reduces FY2026 net investment income by $133,864.32 net — pick up in December distribution estimates.

## 9. Assumptions

- The NAV history and accrual extracts are complete and final (all rows FINAL; only the Institutional class exists in the data).
- The 9/17 NAV is the last NAV struck; the 9/18 NAV is the next to be calculated (per Priyanka's email).
- FYTD covered-expense and cap figures in the 9/17 expense summary are correct apart from the management fee line (they recompute, and the summary's covered-expense total equals total expenses less the interest and Board-designated extraordinary items).
- The Adviser's expense-cap reimbursement is treated as a receivable from the Adviser (GL 1380) per E2.1; settlement mechanics are an open question and do not change the entries.
- No shareholder transaction data was provided or needed: with zero Material Days, none is required.
