**To:** Nadia Kowalczyk, Client Service Director
**From:** Fund Accounting, GACP IV
**Date:** Mon 5 Oct 2026
**Re:** GACP IV Call #2 (Project Lanternfly) — allocation, call total, and two items to take back to Marcus before we post

---

## 1. Bottom line

| Component | USD |
|---|---:|
| Portfolio Investment (Lanternfly) | 44,000,000.00 |
| Partnership Expenses | 180,000.00 |
| Management Fee — first installment, gross (73 days) | 1,983,000.00 |
| less Fee Income offset (80% x 495,750.00 Osprey break-up fee) | (396,600.00) |
| Management Fee — net | 1,586,400.00 |
| **Total call** | **45,766,400.00** |

Ostrander (LP-0106) is excused from the investment; Kestrel Ridge (LP-0107) is **not**, on the documents we hold.

**We should not post the notices this morning as Marcus asked.** Two things stop us:

1. **Due Date.** 16 Oct is not a compliant Due Date for a notice posted today. Columbus Day (Mon 12 Oct) is an FRBNY closure and therefore not a Business Day, so the 10th Business Day after 5 Oct is **Tue 20 Oct 2026** — the closing date itself (LPA 3.3(a), Art. 1 "Business Day", holiday calendar). 16 Oct is only the 8th Business Day.
2. **Kestrel.** Kestrel's request does not qualify under 3.7(a). The GP can still excuse it at its discretion under 3.7(b), but only in writing and before the notice issues (3.7(e)). Whichever way the GP decides changes every partner's investment figure, so we need the decision before we post.

Everything else is final. If Marcus confirms both points before 5:00 pm ET today, we can post today and keep 20 Oct.

## 2. What to go back to Marcus with

- **Due Date:** the notice must show 20 Oct 2026 (or later). His options: (a) accept 20 Oct and, if he wants, we add a non-binding cover-note request that LPs fund early where they can; (b) bridge the equity on the subscription line for a few days (he has ruled this out — Q4 draw is earmarked for Kite — but it is the standard fix); (c) move closing. Posting today before 5 pm ET is required to hold 20 Oct; a slip to tomorrow moves the earliest Due Date to 21 Oct.
- **Lanternfly closing fee cannot be netted in this call.** 8.2(a) only counts Fee Income *received on or before the Drawdown Notice date*. The 1,100,000.00 transaction fee is EXPECTED at closing (20 Oct), after the 5 Oct notice. Only the Osprey break-up fee (received 14 Aug) applies. The closing fee will reduce the 1 Jan 2027 installment by 880,000.00.
- **Kestrel:** he needs Rachel to either issue a written 3.7(b) consent excusing Kestrel or confirm Kestrel is called in full, and to give us the formal 3.7(e) list of Excused Partners.
- Confirm the equity is exactly 44,000,000.00 at signing (Investment Notice said "approximately"), and confirm the 180,000.00 expense figure against the invoices on his shared drive.

## 3. Per-partner allocation (rounded to the cent, each component separately — 3.3(d))

| Partner | Commitment | Investment | Expenses | Fee gross | Fee offset | Fee net | **Total** |
|---|---:|---:|---:|---:|---:|---:|---:|
| GP-0100 Granite Arch GP IV | 12,000,000 | 960,000.00 | 3,600.00 | 0.00 | 0.00 | 0.00 | **963,600.00** |
| LP-0101 Aldermoor SERS | 100,000,000 | 8,000,000.00 | 30,000.00 | 350,000.00 | 70,000.00 | 280,000.00 | **8,310,000.00** |
| LP-0102 Brightwater TPP | 90,000,000 | 7,200,000.00 | 27,000.00 | 315,000.00 | 63,000.00 | 252,000.00 | **7,479,000.00** |
| LP-0103 Meridian Crossing FoF III | 150,000,000 | 12,000,000.00 | 45,000.00 | 450,000.00 | 90,000.00 | 360,000.00 | **12,405,000.00** |
| LP-0104 Sable Point PMAF | 75,000,000 | 6,000,000.00 | 22,500.00 | 262,500.00 | 52,500.00 | 210,000.00 | **6,232,500.00** |
| LP-0105 Northfield University | 60,000,000 | 4,800,000.00 | 18,000.00 | 210,000.00 | 42,000.00 | 168,000.00 | **4,986,000.00** |
| LP-0106 Ostrander County FRF (excused) | 50,000,000 | 0.00 | 15,000.00 | 175,000.00 | 35,000.00 | 140,000.00 | **155,000.00** |
| LP-0107 Kestrel Ridge College | 25,000,000 | 2,000,000.00 | 7,500.00 | 87,500.00 | 17,500.00 | 70,000.00 | **2,077,500.00** |
| LP-0108 Harrowgate Holdings | 38,000,000 | 3,040,000.00 | 11,400.00 | 133,000.00 | 26,600.00 | 106,400.00 | **3,157,800.00** |
| **Total** | **600,000,000** | **44,000,000.00** | **180,000.00** | **1,983,000.00** | **396,600.00** | **1,586,400.00** | **45,766,400.00** |

All totals are well inside each partner's unfunded commitment (3.3(c)); smallest headroom is Kestrel, 2,077,500.00 against 24,875,000.00.

## 4. How each number was built (re-performance notes)

**Sources:** `inputs/investor_records/partner_register_GACP_IV_20260930.csv` (commitments, fee status, unfunded, side letter refs); `inputs/investor_records/side_letter_terms_summary_GACP_IV.csv`; `inputs/lpa/GACP_IV_LPA_excerpt_capital_calls_fees.md`; `inputs/manager/fee_income_register_GAM_FundIV_2026.csv`; `inputs/operations/holiday_calendar_2026H2.csv`; `inputs/operations/call_history_GACP_IV.csv`; correspondence of 15 Sep (Investment Notice), 24 Sep (Ostrander), 2 Oct (Kestrel; Marcus).

**Aggregate Commitments:** 600,000,000.00 (nine partners incl. GP, register dated 30 Sep 2026 after the final closing).

**a. Excuse requests (3.7)**
- Investment Notice delivered Tue 15 Sep 2026 11:02 ET (a Business Day, before 5 pm, so delivered that day — 11.2). 10th Business Day after: 16, 17, 18, 21, 22, 23, 24, 25, 28, **29 Sep**. No holidays in the window (Labor Day was 7 Sep).
- **Ostrander (LP-0106) — excused.** Letter dated 24 Sep (timely), opinion of Pruett & Laine LLP enclosed, legal basis is Ostrander County Retirement Code 7-114(c) (>10% civilian firearms revenue; Halberd 28%). GP Legal stamp: opinion reviewed and accepted by R. Oyelaran 28 Sep. Marcus's email confirms. SL-IV-007 cl. 5.2 confirms 3.7(a) applies to the Code. Under 3.7(d) Ostrander still pays its fee and its share of expenses (expenses are not deal-specific per Marcus, so no carve-out).
- **Kestrel Ridge (LP-0107) — not excused.** Email Fri 2 Oct 16:41 ET is after the 29 Sep deadline; no opinion of counsel; the ground is the College's responsible investment policy, not a "law or regulation applicable to that Limited Partner". Kestrel has no side letter, so no contractual excuse right (contrast Northfield's tobacco right, SL-IV-003, not relevant here). Only a written 3.7(b) discretionary consent from the GP can excuse it. Marcus's "reflect whatever the LPA requires" is an instruction to apply the LPA, not a consent.
- 3.7(e): we hold the stamped acceptance and the CFO email but not a formal GP notice of Excused Partners. Requested from Rachel.

**b. Investment — 44,000,000.00 (3.3(b), 3.7(c))**
Ostrander's would-be share 44,000,000 x 50/600 = 3,666,666.67 is re-spread to the eight non-excused partners pro rata to Commitments (participating Commitments 550,000,000). Each non-excused partner pays 44,000,000 x Commitment / 550,000,000 = 8.00% of Commitment. Uplift vs no-excuse case = 600/550 = 109.09%, under the 115% cap in 3.7(c), so no partner is capped.
*Sensitivity:* if the GP excuses Kestrel under 3.7(b), participating Commitments fall to 525,000,000 (8.38095% of Commitment; uplift 114.29%, still under 115%) and Kestrel's total drops to 77,500.00. I would re-run the table before posting.

**c. Partnership Expenses — 180,000.00 (3.3(b), 8.4)**
Q3 admin fee, audit accrual, fund counsel per Marcus; not deal-related, so all nine partners incl. GP and Ostrander pay pro rata to Commitments (0.03% of Commitment). Invoices are on the GP shared drive, not in our file; figure taken from the CFO's request.

**d. Management Fee — 1,983,000.00 gross (8.1)**
- Fee-Paying Partners: all LPs; GP-0100 is FEE_EXEMPT and excluded by definition.
- Rates: 1.75% (8.1(a)) for all except **Meridian LP-0103 at 1.50%** (SL-IV-001 cl. 2.1, size-based, excluded from MFN). MFN rights of Aldermoor (SL-IV-004 6.1) and Brightwater (SL-IV-002 6.2) only reach terms granted to equal-or-smaller investors, and the Meridian term is expressly excluded, so no MFN effect.
- Fee Commencement Date = first Portfolio Investment acquisition = Lanternfly closing, **Tue 20 Oct 2026**. First installment covers 20 Oct–31 Dec 2026 inclusive = 12 + 30 + 31 = **73 days** (8.1(b)); installment = annual fee x 73/365 (8.1(c)) = exactly 20% of the annual fee.
- Annual fee: 1.75% x 438,000,000 (7,665,000.00) + 1.50% x 150,000,000 (2,250,000.00) = 9,915,000.00; x 73/365 = 1,983,000.00. Per partner: Commitment x rate x 73/365 (see table).
- *Assumption / caveat:* the installment is payable **on** the Fee Commencement Date. It is included in this call so the money is in the account on 20 Oct, but the day count assumes closing on 20 Oct. If closing slips, the installment must be recomputed (fewer days; a slip past 31 Dec moves it to the Q1 2027 period) and any excess refunded or credited. The fee should be held in the fund account and released to the Manager only on the actual Fee Commencement Date.

**e. Fee Income offset — 396,600.00 (8.2)**
From the Manager's register (`fee_income_register_GAM_FundIV_2026.csv`):
- FI-IV-0001 Osprey break-up fee 495,750.00 — RECEIVED 14 Aug 2026, not previously applied → Fee Income; **80% = 396,600.00** applied.
- FI-IV-0002 Osprey expense reimbursement 118,400.00 — excluded from Fee Income by definition (out-of-pocket reimbursement) → nil.
- FI-IV-0003 Lanternfly transaction fee 1,100,000.00 — EXPECTED at closing 20 Oct, i.e. after the notice date → **not applied**; carries to the 1 Jan 2027 installment (880,000.00).
- FI-IV-0004 Lanternfly monitoring fee 300,000.00 — first payment 15 Jan 2027 → later installment.
- FI-IV-0005 directors' fees — waived, nil.
Offset allocated pro rata to each Fee-Paying Partner's gross installment (8.2(b)) = 396,600 / 1,983,000 = exactly 20.0% of each partner's gross fee. Offset is below the installment, so nothing carries forward under 8.2(c). The Manager's register should be updated to show FI-IV-0001 applied to this installment so it is not double-counted.

**f. Notice period (3.3(a), 11.2, holiday calendar)**
Notice posted Mon 5 Oct before 5 pm ET → delivered 5 Oct. Business Days after: 6, 7, 8, 9 Oct (4); 12 Oct excluded (Columbus Day, `frbny_open = N`; NYSE being open is irrelevant — the LPA definition follows FRBNY); 13, 14, 15, 16 Oct (8); 19 Oct (9); **20 Oct (10)**. Earliest Due Date 20 Oct 2026; requested 16 Oct is non-compliant.

**g. Delivery mechanics from side letters**
- LP-0102 Brightwater: copy the notice by email to the Plan's custodian (SL-IV-002 cl. 3.1).
- LP-0108 Harrowgate: also deliver by email and courier (SL-IV-005 cl. 3.2).

## 5. Actions recorded

- **Hold** the Call #2 notices pending Marcus's confirmation of the 20 Oct Due Date and the GP's written Kestrel decision.
- **Escalate to Marcus** (Due Date; closing fee cannot be netted; confirm 44.0m and 180k).
- **Request from Rachel Oyelaran** the 3.7(e) written Excused Partner notice and the 3.7(b) decision on Kestrel.
- **Notify** Kestrel (via GP IR) of the outcome once decided; confirm to Ostrander it is excused from the investment and called for 155,000.00.
- **Post to portal** before 5 pm ET once cleared, with the custodian copy and courier delivery above.
- **Update Manager fee income ledger** (FI-IV-0001 applied to this installment) and **book call receivables / reduce unfunded commitments** in the fund GL on issue.
- **No action** on the subscription facility per Marcus.

## 6. Open questions

1. GP decision on Kestrel under 3.7(b) (rebuild required if excused).
2. Marcus's acceptance of 20 Oct as Due Date and closing-day cash plan.
3. Formal 3.7(e) Excused Partner notice from the GP.
4. Final equity figure at signing (44,000,000.00 assumed).
5. Expense invoices supporting 180,000.00 and confirmation none is Lanternfly-specific.
6. Confirmation that the fee income register is complete for receipts up to 5 Oct 2026.
