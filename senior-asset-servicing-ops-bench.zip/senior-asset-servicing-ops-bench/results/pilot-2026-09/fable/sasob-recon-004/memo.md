# TSIF accrued interest reconciliation vs Northgate — NAV 17 Sep 2026

**To:** Delphine Okoro, Income & Accruals Team Lead, Pellmore Fund Services
**Re:** GL 1300 vs Northgate Accrued Income Report, account 7730-150, as of 2026-09-17 — net break USD 62.99
**Recommendation:** Do **not** sign the de minimis write-off. The USD 62.99 is the net of five offsetting position-level differences (USD 22,290.09 gross), every one of which is explained. Four are Fund-side errors requiring a net credit of **USD 276,337.99** to GL 1300 in the 18 Sep NAV; one is a Northgate set-up error. Nothing is unexplained.

---

## 1. Starting point

| Source | File | Accrued | Past-due / claims | Total |
|---|---|---:|---:|---:|
| Fund GL 1300 | `inputs/accounting/accrued_interest_TSIF_20260917.csv` (TOTAL row) | 1,357,765.25 | 247,500.00 | **1,605,265.25** |
| Northgate | `inputs/custodian/northgate_accrued_income_report_7730-150_20260917.csv` (TOTAL row) | 1,357,702.26 | 247,500.00 | **1,605,202.26** |
| Break (Fund − Northgate) | | | | **62.99** |

GL 1300 of 1,605,265.25 agrees to `interest_receivable_gl1300` for 17 Sep in `inputs/accounting/nav_summary_TSIF_20260917.csv`, so the detail ties to the struck NAV.

Accrual convention applied throughout (policy 5.1, `inputs/policies/TFT_income_accrual_and_reconciliation_procedures.md`): NAV date T includes interest through day T, so accrual periods run to 18 Sep 2026 exclusive. Both sides use that convention (day counts on the two reports agree for every position except Gantry, where the difference is the day-count basis).

## 2. Position-by-position

Five of the ten positions agree exactly on both reports (Harlan Brook 131,250.00; Osgood 86,819.44; Vantry 349,562.50; Pembrook 240,304.17; Ryland Cove 53,441.67) and I re-performed each on 30/360 to the stated day counts — all correct. The five differences:

| # | Security (ISIN) | Fund carries | Northgate | Correct | Fund − NG | Who is wrong | Fund entry |
|---|---|---:|---:|---:|---:|---|---:|
| F1 | UST 3.875% 15Aug2031 (US29DKMU3994) | 91,493.06 | 89,504.08 | 89,504.08 | +1,988.98 | Fund (day count) | −1,988.98 |
| F2 | Gantry Industrial 5.40% 15Dec2032 (US72IBAI2618) | 251,100.00 | 256,500.00 | 251,100.00 | −5,400.00 | Northgate (day count) | 0.00 |
| F3 | Corbin Bancorp FRN 15Aug2028 (USRLI7T61226) | 90,456.89 | 81,269.33 | 81,269.33 | +9,187.56 | Fund (missed reset) | −9,187.56 |
| F4 | UST TIPS 1.625% 15Jul2034 (USFTZ79R4065) | 45,462.52 | 45,676.07 | 45,676.07 | −213.55 | Fund (stale index ratio) | +213.55 |
| F5 | Pellar Commercial Finance 8.25% 01Mar2030 (US6FJH2Q7244) | 265,375.00 | 270,875.00 | 0.00 | −5,500.00 | Fund (non-accrual not reversed); NG differs by design | −265,375.00 |
| | **Total** | **1,605,265.25** | **1,605,202.26** | **1,328,927.26** | **+62.99** | | **−276,337.99** |

Check: +1,988.98 − 5,400.00 + 9,187.56 − 213.55 − 5,500.00 = +62.99. Unexplained residual: **0.00**.

### F1 — UST 3.875% 15Aug2031, par 25,000,000 — Fund wrong (day count)
- Offering terms (`inputs/reference/offering_terms_extracts_TSIF.txt`, item 1): actual/actual (ICMA), 15 Feb / 15 Aug.
- Security master (`inputs/reference/security_master_income_setup_TSIF.csv`): `sm_day_count = ACT/360`, last updated **2026-03-02 by RD_BULKLOAD**. This is the Reference Data feed problem showing up.
- Recalc: coupon period 15 Aug 2026 → 15 Feb 2027 = 184 days; accrued 15 Aug → 18 Sep (excl) = 34 days. 25,000,000 × 3.875% / 2 × 34/184 = **89,504.08**. Northgate agrees. Fund's ACT/360 figure 25,000,000 × 3.875% × 34/360 = 91,493.06 is over by **1,988.98**.
- Note the same set-up over-accrued the Feb–Aug period: at 14 Aug the Fund would have carried 487,065.97 on ACT/360 against a coupon of 484,375.00 (difference 2,690.97). How that was cleared at coupon date is an open question (section 6).

### F2 — Gantry Industrial 5.40% 15Dec2032, par 18,000,000 — Northgate wrong (day count)
- Offering terms item 2: 30/360 (US bond basis), 15 Jun / 15 Dec.
- Fund: 30/360, 93 days: 18,000,000 × 5.40% × 93/360 = **251,100.00** — correct.
- Northgate: ACT/360, 95 actual days → 256,500.00, over by 5,400.00. Custodian set-up error; report to Northgate Client Service (policy 3.4). No Fund entry (policy 3.2).

### F3 — Corbin Bancorp FRN 15Aug2028 (3M Term SOFR + 0.95%), par 20,000,000 — Fund wrong (rate reset not applied)
- Calculation Agent notice (`inputs/notices/corbin_frn_rate_reset_notices.txt`, sent 2026-08-13): interest period 2026-08-17 to 2026-11-16, 3M Term SOFR 3.6214% + 0.95% = **4.5714%**, Actual/360. (15 Aug 2026 is a Saturday; Modified Following moves the payment date and period start to Mon 17 Aug, consistent with both reports' `accrual_from = 2026-08-17`.)
- Security master: `sm_current_rate_pct = 5.0882` effective 2026-05-15, `sm_next_reset = 2026-08-17`, **last updated 2026-05-13 by RESET_FEED** — the August reset never loaded. The Fund has accrued the whole new period at the old rate.
- Recalc: 20,000,000 × 4.5714% × 32/360 = **81,269.33**. Northgate agrees. Fund over by **9,187.56**. Policy 5.2: resets take effect from the first day of the interest period at the Calculation Agent's rate.
- Daily accrual going forward should be 2,539.67, not 2,826.78.

### F4 — UST Inflation-Indexed 1.625% 15Jul2034, par 15,000,000 — Fund wrong (stale index ratio)
- Both sides use the same real accrual: 15,000,000 × 1.625% / 2 × 65/184 = 43,053.67 (period 15 Jul 2026 → 15 Jan 2027 = 184 days; 65 days accrued). The difference is entirely the index ratio (Fund 1.05595, Northgate 1.06091).
- Policy 5.3: use the Index Ratio for the accrual end date, i.e. **2026-09-18**.
- Offering terms item 4 and `inputs/reference/cpi_u_nsa_index_2026.csv` (Jun-2026 = 331.862, Jul-2026 = 332.305, both FINAL):
  Ref CPI(18 Sep) = 331.862 + (18 − 1)/30 × (332.305 − 331.862) = 332.113033 (truncated 6dp) → 332.11303 (5dp).
  Index Ratio = 332.11303 / 313.04548 = **1.06091**.
  Accrued = 43,053.67 × 1.06091 = **45,676.07**. Northgate agrees.
- The Fund's 1.05595 is exactly the Index Ratio for **2026-07-15** (Ref CPI = 330.214 + 14/31 × (330.978 − 330.214) = 330.55903; / 313.04548 = 1.05595), matching `sm_index_ratio_source = CPI_FEED (last load 2026-07-15)`. The CPI feed has been frozen for two months. Fund under by **213.55**.

### F5 — Pellar Commercial Finance 8.25% 01Mar2030, par 6,000,000 — Fund wrong (non-accrual not implemented); Northgate differs by design
- `inputs/notices/tam_valuation_committee_minute_20260914.txt`: coupon due 1 Sep 2026 unpaid; Valuation Committee determined collection not reasonably assured and **placed the notes on non-accrual effective 2026-09-14** under s.5.4(c); Pellmore income team on distribution.
- Policy 5.4: on placement, **all accrued interest and any past-due interest receivable are reversed against interest income**, and no further interest is accrued.
- Fund GL 1300 carries 17,875.00 accrued (1–13 Sep, 13 days × 1,375.00) plus 247,500.00 past-due (6,000,000 × 8.25% / 2). The security master shows the status was set by INCOME_TEAM on 2026-09-14 and the accrual stopped, but the balances were never reversed. Correct balance: **0.00**. Entry: reverse **265,375.00**. This should have been in the 14 Sep NAV; NAVs of 14–17 Sep carry the overstatement.
- Northgate shows 23,375.00 contractual accrual (17 days) plus a 247,500.00 open income claim = 270,875.00. Per policy 3.2 the custodian does not apply the Fund's non-accrual determinations, so this is not a custodian error; it becomes a **standing, documented reconciling item** (270,875.00 today, growing 1,375.00/day) until the position is resolved. Keep Northgate's income claim open — if the issuer pays within the grace period (expires 2026-10-01) the recovery is recognised on receipt.

## 3. What we book (18 Sep 2026 NAV)

| Entry | Dr | Cr | USD |
|---|---|---|---:|
| Pellar — reverse accrued (17,875.00) and past-due (247,500.00) on non-accrual, eff. 14 Sep | Interest income | GL 1300 | 265,375.00 |
| UST 3.875% — restate ACT/360 → ACT/ACT | Interest income | GL 1300 | 1,988.98 |
| Corbin FRN — restate 5.0882% → 4.5714% from 17 Aug | Interest income | GL 1300 | 9,187.56 |
| TIPS — apply index ratio 1.06091 | GL 1300 | Interest income | 213.55 |
| **Net** | | **Cr GL 1300** | **276,337.99** |

Corrected GL 1300 = 1,605,265.25 − 276,337.99 = **1,328,927.26** (agrees to the sum of the "Correct" column).

Remaining difference vs Northgate after the entries: 1,328,927.26 − 1,605,202.26 = **−276,275.00**, made up of Gantry −5,400.00 (clears when Northgate corrects its set-up) and Pellar −270,875.00 (expected non-accrual item). Both must be carried as explained items on the daily rec.

**De minimis write-off:** not available. Policy 3.3 permits it only for a net *unexplained* residual after every position-level difference is explained, and expressly forbids netting offsetting position-level differences. The residual is nil; there is nothing to write off, and the USD 62.99 "small break" was masking a USD 276k error.

## 4. Does it matter for NAVs already struck?

- 17 Sep NAV (`nav_summary_TSIF_20260917.csv`: net assets 648,332,410.55; shares 63,118,402.227; NAV 10.2717). Corrected − reported net assets = −276,337.99 (the Pellar price is a flat evaluated price per the Committee minute, so no pricing offset). Per share: −276,337.99 / 63,118,402.227 = **−0.0044** (−0.00438). That is 0.043% of NAV.
- Materiality (policy 6.2): material only if ≥ USD 0.01/share **and** ≥ 0.50% of NAV. Neither limb is met → **not material**.
- 14, 15 and 16 Sep NAVs were also overstated (Pellar 265,375.00 from 14 Sep; Corbin from 17 Aug growing 287.11/day; UST from 15 Aug growing 58.50/day; TIPS slightly understated). Each is smaller than the 17 Sep figure and therefore also immaterial. Position-level detail for 15/16 Sep is not in the folder, so I have not recomputed exact per-share figures for those dates.
- Policy 6.3: correct in the next NAV (18 Sep); **no restatement, no reprocessing of shareholder activity**; notify the Fund Treasurer today; log for the quarterly Board report.

## 5. Who to chase

| Party | What | Basis |
|---|---|---|
| **Reference Data (security master)** | Correct at source: (a) US29DKMU3994 day count ACT/360 → ACT/ACT; (b) USRLI7T61226 rate 4.5714% eff. 2026-08-17, next reset 2026-11-16; (c) CPI_FEED reload so index ratio = 1.06091 for 18 Sep and updates daily. Then report **every other security in the Trust** touched by the 2026-03-02 bulk load, the stalled RESET_FEED and the stalled CPI_FEED — three separate feed failures, all likely to affect other funds. | Policy 3.4 |
| **Northgate Client Service** | Gantry US72IBAI2618 set up on ACT/360; terms are 30/360 — correct and confirm. Pellar: Fund is on non-accrual; keep the 247,500.00 income claim open and advise of any receipt. | Policy 3.4 |
| **Fund Treasurer** | Same-day notice of the NAV error (−0.0044/share on 17 Sep; immaterial; corrected 18 Sep) and log for the Board report, citing Reference Data feed failures as root cause. | Policy 6.3 |
| **Valuation Committee (Valuation Designee)** | Confirm the 14 Sep resolution is now fully implemented (reversal booked); confirm Vendor A price remains flat. | Minute 2026-09-14 |
| **Portfolio manager** | Income impact of 276,337.99 in the 18 Sep NAV; Corbin now accruing at 4.5714%; Pellar accruing nil. | Courtesy |

## 6. Open questions / information needed

1. Reference Data: scope of the three feed failures (RD_BULKLOAD 2026-03-02, RESET_FEED since 2026-05-13, CPI_FEED since 2026-07-15) across all Tidewell series.
2. How was the 15/17 Aug UST coupon (484,375.00) cleared against the ACT/360 accrual of 487,065.97? If the 2,690.97 was written off as de minimis it needs revisiting.
3. Was the Corbin coupon of 265,717.20 (13.28586 per 1,000 × 20,000,000; 94 days at 5.0882%) received 17 Aug and agreed to the accrual? No cash rec is in the folder.
4. Why did the income team's 14 Sep non-accrual flag not carry the section 5.4 reversal? Control gap — recommend the non-accrual status change force the reversal entry.
5. Confirm the Pellar Vendor A price is clean/flat (no pricing file in the folder).
6. Northgate to confirm the Gantry correction date and that the Pellar claim stays open through 1 Oct.
7. The NAV summary shows GL 1300 moving ~46.5k/day (15→16→17 Sep) versus ~19.0k/day implied by the 17 Sep detail; please provide the 15/16 Sep detail so the prior-day errors can be quantified exactly (all are immaterial in any event).

## 7. Assumptions
- Offering terms extracts govern over system set-up (stated in the extracts file).
- Calendar: 17 Sep 2026 is a Thursday (per the request date), so 15 Aug 2026 is a Saturday and the Corbin period start of 17 Aug on both reports is consistent with Modified Following.
- The five positions with no offering-terms extract (Harlan Brook, Osgood, Vantry, Pembrook, Ryland Cove) are correct as both sides agree and the 30/360 arithmetic re-performs; I have not independently verified their day-count basis against offering documents.
- Rounding: index ratio and Ref CPI per the offering-terms method (truncate 6dp, round 5dp); accruals rounded to cents; per-share NAV error on unrounded net assets per policy 6.1.
