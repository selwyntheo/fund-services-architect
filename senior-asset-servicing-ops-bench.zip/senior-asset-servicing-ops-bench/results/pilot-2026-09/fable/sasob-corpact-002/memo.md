**To:** Dev Raman, Manager, Mandatory & Reorg Events
**From:** Corporate Actions (checker)
**Date:** Fri 18 Sep 2026
**Subject:** Pellam / Orvane (PELL26MRGR01) — allocation re-performed; PA-PELL-01 must not be released as is

## 1. Bottom line

- **Do not release PA-PELL-01.** It is out of balance because the engine (i) used a cash proration factor of 1.000000 ("CASH PRORATION FACTOR NOT LOADED"), (ii) defaulted 4410-2204 to CASH under the superseded preliminary MT564 (SEME MRDL2608240117) although the REPL notice (MRDL2608280233) made NOAC the default, (iii) treated Lumenfield's void 40,000-share guaranteed-delivery election as valid cash election shares, and (iv) omitted the Orvane shares due on prorated cash shares and non-election shares. It over-allocates cash by **USD 12,243,593.92** (34,245,600.00 vs DTC 22,002,006.08) and under-allocates Orvane by 310,554 shares (78,285 vs 388,839). Procedure 3.5: reject and reprocess.
- **The correct allocation ties to DTC.** Cash consideration USD 22,001,904.00 and 388,839 Orvane shares agree exactly to the DTC advice. Cash in lieu is USD 102.07 by account vs USD 102.08 per instruction at DTC; the USD 0.01 goes to CA Rounding GL 9990 under 3.4. Nothing to CA Suspense.
- **We can release tonight** once the engine is reprocessed with the correct factor, notice and void NGD flag and the checker agrees the re-run to the DTC receipt.
- **Lumenfield:** only 85,000 shares were valid Cash Election Shares. The 40,000 shares are Non-Election Shares because Meridale did not deliver the guaranteed-delivery cover by 15 Sep 17:00 ET. We cannot allocate them as cash-elected, cannot re-elect with Stonemere, and cannot credit or promise compensation. This is a Meridale processing failure: Operational Incident to Operational Risk today and escalation to the Head of Asset Servicing (procedure 6.1).

## 2. Sources relied on (all in `inputs/`)

| File | Used for |
|---|---|
| `notices/exchange_agent_election_results_20260917.txt` | Cash proration factor 0.783546; Orvane Average Closing Price 40.8715; s.2.4(a) applies (cash oversubscribed); proration applied per VOI, non-election at participant position level |
| `notices/merger_agreement_extract_article_II.md` | USD 48.00 cash / 1.2175 stock; s.2.2 NGD not delivered = Non-Election; s.2.4(a)(ii) floor per holder; s.2.5 aggregate before fractional CIL |
| `notices/MT564_..._NEWM_20260824.txt` / `..._REPL_20260828.txt` | REPL replaces NEWM: default corrected from CASH to NOAC (option 003); NGD void if not delivered within 2 NYSE trading days; Meridale client deadline 10 Sep 12:00 ET |
| `instructions/election_instruction_log_PELL26MRGR01.csv` | EL-01..EL-08: elections, Fenwick partial withdrawal, Ashgrove 2204 late rejection, Lumenfield NGD and expiry |
| `positions/custody_positions_PELLAM_20260916_pre_effective.csv` | Pre-effective positions by account (contra CUSIPs O3XZQC316 / TYPZGB281 and free US984TPQ9122) |
| `dtc/dtc_reorg_payment_advice_PELL26MRGR01_20260918.txt` | Receipt: cash 22,002,006.08 (consideration 22,001,904.00 + CIL 102.08), Orvane 388,839; per-VOI lines |
| `event_engine/provisional_allocation_PELL26MRGR01.csv` | PA-PELL-01 figures and engine messages |
| `policies/meridale_ca_allocation_and_exceptions_procedures.md` | 3.1–3.5 allocation/rounding/tie-out; 6.1–6.3 processing exceptions |
| `correspondence/email_lumenfield_20260917.txt` | Harriet Voss's request |

## 3. Method (procedures 3.1–3.3)

Per safekeeping account, treating the account as the holder: Cash shares = floor(valid Cash Election Shares x 0.783546); cash = cash shares x 48.00. Stock shares = remaining cash election shares + stock election shares + non-election shares; Orvane = stock shares x 1.2175, aggregated per account and rounded down; fraction x 40.8715 rounded half up to the cent. Elections used as the agent actually applied them: net of withdrawals, void NGD as non-election, rejected late instruction as non-election.

## 4. Allocation by account

| Account | Client | Pellam | Cash elect. | Stock elect. | Non-elect. | Cash shs | Stock shs | Cash USD | Orvane (raw) | Orvane | CIL USD | Total cash USD |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 4410-2201 | Ashgrove Global Eq | 214,300 | 150,000 | 64,300 | 0 | 117,531 | 96,769 | 5,641,488.00 | 117,816.2575 | 117,816 | 10.52 | 5,641,498.52 |
| 4410-2204 | Ashgrove US Small Cap | 88,450 | 0 | 0 | 88,450 | 0 | 88,450 | 0.00 | 107,687.8750 | 107,687 | 35.76 | 35.76 |
| 4410-3104 | Fenwick | 350,000 | 350,000 | 0 | 0 | 274,241 | 75,759 | 13,163,568.00 | 92,236.5825 | 92,236 | 23.81 | 13,163,591.81 |
| 4410-5024 | Lumenfield | 125,000 | 85,000 | 0 | 40,000 | 66,601 | 58,399 | 3,196,848.00 | 71,100.7825 | 71,100 | 31.98 | 3,196,879.98 |
| **Total** | | **777,750** | 585,000 | 64,300 | 128,450 | 458,373 | 319,377 | **22,001,904.00** | | **388,839** | **102.07** | **22,002,006.07** |

Workings: 150,000 x 0.783546 = 117,531.9 -> 117,531; 350,000 x 0.783546 = 274,241.1 -> 274,241; 85,000 x 0.783546 = 66,601.41 -> 66,601. CIL: 0.2575 x 40.8715 = 10.5244; 0.875 x 40.8715 = 35.7626; 0.5825 x 40.8715 = 23.8076; 0.7825 x 40.8715 = 31.9819.

Account notes:
- **4410-2201** — EL-01 (VOI 26090201, cash 150,000) and EL-02 (VOI 26090202, stock 64,300) accepted. DTC lines 0001/0002 give 117,531 cash shares, 39,531 + 78,285 = 117,816 Orvane, CIL 0.31 + 10.22 = 10.53. Account-level aggregation (3.2) gives CIL 10.52; the USD 0.01 is the rounding item.
- **4410-2204** — EL-07 cash election received 11 Sep 13:20 ET, after the 10 Sep 12:00 ET client deadline; rejected, no VOI; client told 11 Sep 13:45 it would be non-election. Under REPL default NOAC and s.2.4(a)(i), non-election shares receive stock. The engine's "DEFAULT OPTION 001 CASH" from the NEWM notice is wrong and allocated USD 4,245,600.00 that DTC never paid. Part of DTC line 0006.
- **4410-3104** — EL-03 402,000 less EL-04 withdrawal 52,000 (sold; settled 10 Sep) = 350,000 on VOI 26090311. Ties exactly to DTC line 0003.
- **4410-5024** — EL-05 85,000 accepted (VOI 26091007, DTC line 0004). EL-06 NGD 40,000 (VOI 26091008) protect accepted; purchase EQ-B-260909-5120 settled 14 Sep; cover exception EXQ-5521 opened 14 Sep 16:12, **unassigned**, cover not delivered by 15 Sep 17:00 ET (EL-08); agent voided (DTC line 0005). The 40,000 were free Pellam at 16 Sep and are in DTC line 0006 (128,450 = 88,450 + 40,000). Orvane 71,100 = 22,400 (line 0004) + 48,700 (40,000 x 1.2175 share of line 0006).

## 5. Tie-out to DTC (procedure 3.4)

| | Allocated to accounts | DTC advice | Difference |
|---|---|---|---|
| Cash consideration | 22,001,904.00 | 22,001,904.00 | 0.00 |
| Cash in lieu | 102.07 | 102.08 | +0.01 |
| Total cash | 22,002,006.07 | 22,002,006.08 | **+0.01 -> GL 9990** |
| Orvane shares | 388,839 | 388,839 | 0 |

The USD 0.01 arises solely from per-account vs per-VOI CIL rounding on 4410-2201, is within the USD 1.00 limit and is posted to CA Rounding GL 9990. It is not allocated to any client. Nothing goes to CA Suspense.

## 6. What has to happen before release

1. Reject PA-PELL-01 (3.5).
2. Reprocess in the engine with: proration factor 0.783546; event default linked to REPL MT564 MRDL2608280233 (option 003 NOAC); VOI 26091008 flagged VOID / non-election; ratio 1.2175; CIL price 40.8715. The re-run should reproduce section 4 exactly.
3. Checker agrees the re-run to the DTC advice (cash 22,002,006.08 = 22,002,006.07 clients + 0.01 GL 9990; 388,839 shares).
4. Post USD 0.01 to GL 9990; release to the four accounts. Cash and Orvane will then appear on Monday's statements.

## 7. Lumenfield — what we can and cannot do

- Facts: the election on the 85,000 settled shares was made 10 Sep 10:31 ET, verified by call-back 10:52 and accepted. The 40,000 bought on 9 Sep were elected by notice of guaranteed delivery, which required delivery within 2 NYSE trading days after the 11 Sep deadline (by 15 Sep 17:00 ET). The shares settled to us on 14 Sep, so cover was possible; exception EXQ-5521 was opened on 14 Sep 16:12 and never assigned; the cover was not delivered; Stonemere voided the election (DTC line 0005). Under s.2.2 those are Non-Election Shares and under s.2.4(a)(i) they receive 1.2175 Orvane each.
- We **cannot** show all 125,000 as cash election (3.3: the allocation reflects the agent's actual treatment, not what the client intended). The statement will show 85,000 cash-elected (66,601 cash / 18,399 stock after proration) and 40,000 non-election.
- We **cannot** "allocate the cash they would have had" (6.2: no crediting, allocating or promising compensation; no re-allocation of other clients' entitlements or of GL 9990/9980). We **cannot** resubmit or amend the election with Stonemere (6.3; results final, paid 18 Sep). Only the Head of Asset Servicing may ask the agent for anything exceptional.
- Internal (6.1): allocate per actual outcome (done above); raise an Operational Incident with Operational Risk today; escalate to Head of Asset Servicing. Impact estimate for the incident: had the cover been delivered, 125,000 x 0.783546 = 97,943 cash shares (USD 4,701,264.00) and 27,057 stock shares = 32,941 Orvane + CIL 36.68. Actual: 66,601 cash shares (USD 3,196,848.00), 71,100 Orvane + CIL 31.98. So Lumenfield has USD 1,504,416.00 less cash and 38,159 more Orvane shares. Whether that is a loss depends on the Orvane price (at 40.8715 the stock consideration is worth about 49.76 per Pellam share vs 48.00 cash); the price is not in the file and the compensation question belongs to the incident process with Head of Operations approval.
- Suggested reply to Harriet Voss (via you/RM): factual, no promise — 85,000 accepted; 40,000 NGD voided by the agent because the shares were not delivered within the guaranteed-delivery period; those shares are Non-Election Shares receiving stock; the allocation reflects that; the matter has been referred to Operational Risk and the Head of Asset Servicing.

## 8. Other points to raise internally

- Engine control failure: proration factor not loaded and default option taken from the superseded preliminary notice. Both would have released USD 12.2m of cash we did not receive had the run not been flagged out of balance. Record as a near-miss with Operational Risk.
- Ashgrove 4410-2204: outcome (stock) is as the client was told on 11 Sep; RM should be aware the engine's provisional "cash" treatment will not appear.

## 9. Assumptions and open questions

- Assumed no tax withholding: DTC cash equals the gross computation. Please confirm.
- Orvane market price not in the file; needed for the incident's impact estimate.
- Who owned EXQ-5521 and why it stayed unassigned to expiry (for the incident record). Note the one-business-day incident deadline in 6.1(b) may already have passed; raise today and record the timing.
- Confirm with the engine team the root cause of the missing factor and stale notice before the reprocess.
- Confirm who will act as checker for the re-run tonight.
