# BFVF — IRC §851(b)(3) asset diversification test at 31 August 2026: review of first cut

**To:** Elaine Marsh, Treasurer, Brightwater Series Trust
**Cc:** V. Osei, Director of Fund Tax (Oakhurst); S. Albright (preparer)
**From:** Oakhurst Fund Administration — Fund Tax
**Date:** Fri 18 Sep 2026
**Re:** Your note of 9:15 AM — 8/31 RIC diversification sign-off for the Board certificate

## 1. Bottom line

BFVF **does not pass** either part of the §851(b)(3) asset test at 8/31/2026. The first cut's "clean pass" is wrong for one structural reason (wrong denominator) and several classification reasons.

| | Result | Figure | Limit |
|---|---|---|---|
| 50% test — §851(b)(3)(A) | **FAIL** | qualifying assets USD 314,408,640.39 = **49.58%** of Total Assets | ≥ 50% |
| 25% test — §851(b)(3)(B)(ii) controlled group, same trade | **FAIL** | Stonefield + Harrowgate USD 167,957,320.00 = **26.49%** | ≤ 25% |
| 25% test — single issuer | pass | Stonefield 13.87% | ≤ 25% |
| 25% test — QPTP aggregate | pass | Tallis + Corbeck 3.12% | ≤ 25% |

- **Are we in trouble?** Not if we act. The Fund passed at 5/31 (54.22%, reviewed workpaper), and both 8/31 discrepancies follow acquisitions made during the quarter, so §851(d)(1) applies: RIC status is preserved if the discrepancy is eliminated within 30 days of quarter-end.
- **By when:** trade date on or before **Wednesday 30 September 2026** (policy 6.3).
- **How much has to move:** at least **USD 9,435,416.57** (at 8/31 values) of Stonefield and/or Harrowgate must be sold and the proceeds held in cash or Government securities. That single disposal cures both tests (25% group falls to exactly 25.00%; 50% test rises to 51.07%). We recommend a buffer — sell approximately **USD 12m** — because prices will move between 8/31 and the trade date and the post-cure 50% margin is thin.
- **Board certificate:** under policy 7.3 the BFVF certificate **cannot be signed Monday**. It is held until the cure is completed and Fund Tax has re-tested. Other series are unaffected.
- **Escalation:** this note is the same-day escalation required by policy 7.1 (result differs from first cut; tests failed) to you and to the Director of Fund Tax.

## 2. Files relied on (all in `inputs/`)

| File | Used for |
|---|---|
| `accounting/BFVF_statement_of_assets_and_liabilities_20260831.csv` | Total Assets 634,087,613.72; cash and receivables; prepaid; borrowings 45,000,000 |
| `accounting/BFVF_portfolio_valuation_20260831.csv` | 26 positions, market values (sum 622,490,883.50 — ties to the SoAL investments line) |
| `reference/issuer_master_extract_20260831.csv` | issuer type, RIC election flag, sub_industry, voting shares outstanding |
| `trades/repo_confirmations_20260831.txt` | collateral on the Fallowmere (Treasury, 102%) and Pemberton (corporate bonds, 105%) repos |
| `trades/BFVF_trade_blotter_20260601_20260831.csv` | quarter acquisitions — attribution under policy 6.2 |
| `tax/BFVF_diversification_test_20260531_final.csv` | prior-quarter pass (54.22%); Harrowgate 17.90% not controlled at 5/31 |
| `tax/BFVF_diversification_firstcut_20260831.csv` | Stella's draft — reviewed line by line |
| `correspondence/email_PM_Kapoor_20260917.txt` | PM's two arguments (addressed in §6) |
| `policies/BST_RIC_qualification_compliance_policy.md` v3.1 | definitions, tests, cure, escalation |

## 3. Denominator

Policy 3.1 defines Total Assets as **gross** total assets per the statement of assets and liabilities, before liabilities including borrowings: **USD 634,087,613.72**. The first cut used net assets (581,160,485.34), which overstated every percentage by ~9% relative and, in particular, pushed Kinsale (4.89% gross) over 5% while understating the true position of the controlled group. Reconciliation of Total Assets: investments 622,490,883.50 + cash 3,406,118.27 + receivable for investments sold 5,812,440.00 + dividends/interest receivable 1,947,062.18 + receivable for fund shares sold 318,205.44 + prepaid 112,904.33 = 634,087,613.72. Threshold values: 5% = 31,704,380.69; 25% = 158,521,903.43; 50% = 317,043,806.86.

## 4. Issuer-by-issuer classification (8/31 values, % of Total Assets)

| Issuer | Positions | Value USD | % TA | Voting % | 50% basket | Notes |
|---|---|---|---|---|---|---|
| Cash & receivables | SoAL | 11,483,825.89 | 1.81 | — | cash item | policy 3.2 |
| Prepaid/other | SoAL | 112,904.33 | 0.02 | — | not qualifying | policy 3.2 |
| ISS-0001 U.S. Treasury | P001, P002 | 42,942,812.50 | 6.77 | — | Government | |
| ISS-0002 FHLB | P003 | 15,092,850.00 | 2.38 | — | Government | GSE, policy 3.3 |
| ISS-0210 Fallowmere (tri-party repo) | P004 | 20,000,000.00 | 3.15 | — | Government | collateralized fully by USTs, MV 20,400,000 (102%) — policy 3.4 |
| ISS-0233 Pemberton (repo + CP) | P005, P006 | 34,030,425.00 | **5.37** | — | **non-qualifying** | corporate-collateral repo = security of counterparty; aggregated with CP (same LEI) — policy 3.4/3.6 |
| ISS-0107 Republic of Castellan | P007 | 38,501,600.00 | **6.07** | — | **non-qualifying** | non-US sovereign is not a Government security — policy 3.3 |
| ISS-0301 Brightwater Govt MMF | P008 | 31,500,000.00 | 4.97 | — | other RIC | election on file |
| ISS-0302 Arden Street ETF | P009 | 12,400,000.00 | 1.96 | — | other RIC | election on file |
| ISS-0410 Stonefield Aggregates | P010 | 87,976,080.00 | 13.87 | **23.60** | non-qualifying | controlled (≥20%); >5%; >10% voting |
| ISS-0411 Harrowgate Materials | P011 | 79,981,240.00 | 12.61 | **24.80** | non-qualifying | controlled since July adds; >5%; >10% voting |
| ISS-0412 Quillon Systems | P012 | 35,997,840.00 | **5.68** | 0.33 | **non-qualifying** | >5% of TA |
| ISS-0413 Ormsby Logistics (stock + notes) | P013, P014 | 34,479,300.00 | **5.44** | 1.72 | **non-qualifying** | aggregated across instruments — policy 3.6 |
| ISS-0414 Tallis Midstream (QPTP) | P015 | 8,599,584.00 | 1.36 | **11.20** | **non-qualifying** | >10% of units (units = voting, §851(c)(5), policy 4.3) |
| ISS-0415 Corbeck Pipeline (QPTP) | P016 | 11,199,760.00 | 1.77 | 1.10 | qualifying | |
| ISS-0416 Norbeck 6.10% pfd | P017 | 6,001,800.00 | 0.95 | n/a (non-voting) | qualifying | |
| ISS-0417 Pellham Instruments | P018 | 9,801,792.00 | 1.55 | 9.60 | qualifying | close to 10% — monitor |
| ISS-0418 Kinsale Robotics | P019 | 30,985,800.00 | 4.89 | 0.53 | qualifying | first cut excluded (5.33% of *net* assets) |
| ISS-0419 Aldermoor Software | P020 | 24,500,000.00 | 3.86 | 0.24 | qualifying | |
| ISS-0420 Brixton Health | P021 | 22,800,000.00 | 3.60 | 0.23 | qualifying | |
| ISS-0421 Cadell Foods | P022 | 19,600,000.00 | 3.09 | 0.63 | qualifying | |
| ISS-0422 Dunmore Insurance | P023 | 17,300,000.00 | 2.73 | 0.54 | qualifying | |
| ISS-0423 Everly Consumer Brands | P024 | 15,900,000.00 | 2.51 | 0.26 | qualifying | 318,000 sh post 8/31 sale |
| ISS-0424 Fenwick Semiconductor | P025 | 14,200,000.00 | 2.24 | 0.18 | qualifying | |
| ISS-0425 Galloway Water | P026 | 8,700,000.00 | 1.37 | 0.63 | qualifying | |

Voting % = shares/units held ÷ `voting_shares_or_units_outstanding` in the issuer master (e.g. Harrowgate 6,572,000 ÷ 26,500,000 = 24.80%; Stonefield 8,968,000 ÷ 38,000,000 = 23.60%; Tallis 1,500,800 ÷ 13,400,000 = 11.20%).

**50% test build-up:** cash items 11,483,825.89 + Government 78,035,662.50 (42,942,812.50 + 15,092,850.00 + 20,000,000.00) + other RICs 43,900,000.00 + qualifying other 180,989,152.00 (Corbeck, Norbeck, Pellham, Kinsale, Aldermoor, Brixton, Cadell, Dunmore, Everly, Fenwick, Galloway) = **314,408,640.39 = 49.58%**. Shortfall to 50%: 2,635,166.47.

**25% test:** Stonefield and Harrowgate are each controlled (≥20% voting, §851(c)(2), policy 5.2) and share `sub_industry` "Construction Materials - Aggregates"; under policy 5.3 they are treated as the same trade or business absent a prior written Tax Counsel conclusion (none in the folder). Group = 87,976,080.00 + 79,981,240.00 = **167,957,320.00 = 26.49%**; excess over 25% = **9,435,416.57**.

## 5. Where the first cut went wrong

1. Denominator: net assets instead of gross Total Assets (policy 3.1).
2. Line 2 "Government securities" included the Castellan sovereign (non-US government — not a Government security under 1940 Act §2(a)(16)) and the Pemberton repo (collateral is corporate bonds, not cash/Governments, so it is a security of Pemberton).
3. Line 4 tested "per position" rather than per issuer (policy 3.6): Ormsby stock + notes and Pemberton repo + CP each exceed 5% when aggregated; Quillon exceeds 5% of gross Total Assets.
4. The 10% voting-securities limit was not applied: Tallis Midstream units are 11.20% of units outstanding.
5. Kinsale was wrongly excluded (4.89% of gross Total Assets).
6. The 25% test looked only at the largest single issuer and did not test controlled-group aggregation, so the Harrowgate control crossing (17.90% → 24.80%) was missed.

## 6. Attribution and cure

**Acquisition rule (policy 6.1–6.2).** The Fund met the tests at 5/31. During the quarter it bought 1,828,500 Harrowgate shares on 14–16 Jul (T-260714-003, T-260715-006, T-260716-001; USD 20,380,725), taking Harrowgate from 17.90% to 24.80% voting and creating the controlled group; it bought USD 38,000,000 par Castellan on 12 Aug (T-260812-002) funded from the MMF (a RIC security, i.e. qualifying → non-qualifying swap), USD 12.1m Pemberton CP on 28 Aug (T-260828-003), Quillon on 20 Aug and Kinsale on 9 Jun. Both discrepancies therefore exist immediately after, and result from, acquisitions: **attributable to acquisition — cure required.**

**Cure sizing (policy 6.4)** — proceeds assumed held in cash/Government securities, Total Assets unchanged:
- 25% test: sell ≥ 9,435,416.57 of Stonefield and/or Harrowgate → group = 158,521,903.43 = 25.00%.
- 50% test: the same sale converts 9,435,416.57 of non-qualifying stock into cash items → qualifying 323,844,056.96 = **51.07%** (needed only 2,635,166.47).
- **Minimum disposal = USD 9,435,416.57.** Recommended with buffer: ~USD 12m (≈1.9% of TA), which would leave the group at ≈24.6% and qualifying assets at ≈51.5%.
- Alternatives the adviser may prefer: selling Stonefield instead of Harrowgate is equally effective (both are in the group); reducing Harrowgate below 20% voting (below 5,300,000 shares — a sale of >1,272,000 shares ≈ USD 15.5m) would break the group entirely but costs more. Sales of other names (e.g. Castellan, Quillon) help the 50% test but do nothing for the 25% test, so Stonefield/Harrowgate must be part of any cure.
- Not permitted: curing by borrowing more or by subscriptions (policy 6.4). Note also that repaying the USD 45m line of credit would *worsen* both ratios (it shrinks Total Assets and removes cash).
- Deadline: trade date **on or before 30 Sep 2026**. Re-test by Fund Tax on 8/31 values adjusted for the cure trades; certificate released only after that.

**Response to Dev Kapoor's 17 Sep points.** (a) That Stonefield and Harrowgate are separate companies is not the test: §851(b)(3)(B)(ii) aggregates issuers the Fund *controls* (≥20% voting) that are in the same or similar trades; both are aggregates producers and the July adds crossed the control threshold. The adviser's post-trade check ("issuer <25% OK") tested the wrong limit. (b) Castellan being sovereign, investment grade, USD and SEC-registered does not make it a "Government security" — that term covers U.S. Government and its instrumentalities only; it is a single non-qualifying issuer at 6.07%. §851(d)(2) de minimis/reasonable-cause relief is not an alternative to a timely cure (policy 6.5).

## 7. Calls to make

1. **Today — V. Osei (Director of Fund Tax):** review and sign this workpaper (policy 7.1).
2. **Today — Brightwater Advisors CCO (written, policy 7.2):** both tests failed at 8/31; minimum cure USD 9,435,416.57 of Stonefield/Harrowgate (recommend ~USD 12m), trade date ≤ 30 Sep 2026, proceeds to cash/Governments; ask that the post-trade screen be updated for controlled-group aggregation and the 20% control threshold.
3. **Today — Dev Kapoor (PM):** same notice; adviser selects the securities; Oakhurst does not instruct trades; consider Schedule 13D amendment on any Harrowgate sale; no new purchases in Stonefield, Harrowgate, Castellan, Pemberton, Quillon, Ormsby or Tallis before the re-test.
4. **Trading desk:** send Fund Tax executed confirmations for cure trades as done.
5. **Board (Tuesday):** BFVF certificate held pending an acquisition-related cure under §851(d)(1) due 30 Sep; re-test and certificate to follow (written consent or next meeting — your call).
6. **Tax Counsel:** confirm our reading on Castellan and on "same or similar trade" for the two aggregates producers (cannot change the 8/31 result — policy 5.3 required a prior written conclusion), and be on standby if the cure slips.
7. **Issuer master / Fund Accounting:** confirm source and as-of date for voting shares outstanding (Harrowgate, Stonefield, Tallis, Pellham); tag repo collateral type in the security master so policy 3.4 look-through is systematic.
8. **Auditor:** after cure, include the discrepancy, cure trades and corrected workpaper in the FY2026 RIC qualification support.

## 8. Assumptions and open items

- Voting shares outstanding are taken from the 8/31 issuer master extract; source/as-of date not shown. Harrowgate control (24.80% vs 20%) is robust; Tallis (11.20% vs 10%) and Pellham (9.60% vs 10%) are sensitive to the count — please confirm.
- The 30,000-share Everly sale on 8/31 (pending settle) is reflected in the receivable for investments sold; we assume the 318,000-share position is post-trade (no double count). Fund Accounting to confirm.
- No written Tax Counsel conclusion on Stonefield/Harrowgate existed before 8/31, so policy 5.3's default applies.
- The Fallowmere repo is treated as fully collateralized by Governments on the strength of the tri-party confirmation (Treasuries only, 102%); the Fallowmere DDA cash is a cash item and is not aggregated with the repo.
- No journal entries are required; NAV and the 8/31 statement are not affected.
