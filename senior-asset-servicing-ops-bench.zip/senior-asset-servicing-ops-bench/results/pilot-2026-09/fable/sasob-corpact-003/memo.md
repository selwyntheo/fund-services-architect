# Fenwick claims review — Bracken Foods (4410-3104) and Van Oosterlo (4410-3107)

**To:** Keisha Osei, Income & Claims Supervisor
**From:** Income & Claims analyst
**Date:** Fri 18 Sep 2026
**Re:** Tomas Albright's claims list (email 17 Sep 2026) — what really gives rise to a claim, direction, amount, route, and what to book today

## 1. Sources relied on

| File | Used for |
|---|---|
| `inputs/correspondence/email_fenwick_20260917.txt` | Tomas's list: Bracken 5502/5503/5504/5511; Van Oosterlo 7088/7101/7102/7103/7111; 6620; request to pay Bracken now |
| `inputs/trades/fenwick_trade_settlement_status_20260918.csv` | Trade dates, contractual/actual settlement, quantities, opt-out flag, counterparties, settlement location |
| `inputs/notices/MT564_MRDL_BRACKEN_DVCA_20260821.txt` | BRKN26DVCA03: XDTE 2026-09-10 = RDTE 2026-09-10, USD 0.54 gross, PAYD 2026-09-25 |
| `inputs/notices/MT564_MRDL_VANOOSTERLO_DVCA_20260826.txt` | VOH26DVCA02: XDTE 2026-09-08, RDTE 2026-09-09, EUR 0.88 gross, TAXR 15%, PAYD 2026-09-16 |
| `inputs/income/fenwick_income_ledger_VOH_BRKN.csv` | VOH26DVCA01 (May final: ex 05-12, record 05-13, EUR 1.24, paid 05-20), VOH26DVCA02 paid 09-16 (180,000 sh, 0% WHT), BRKN26DVCA03 projected 09-25 (240,000 sh). No claim entries booked yet |
| `inputs/csd/t2s_market_claims_report_VANDNL2A_20260918.csv` | CSD-generated claims MC-2609-118834 (7101), MC-2609-118902 (7088), RC-2609-020417 (7110) |
| `inputs/tax/tax_documentation_fenwick.csv` | US: W-9, 0% ; NL: exempt pension trust, relief at source 0% on dividends |
| `inputs/policies/meridale_market_claims_procedures.md` v5.0 | Entitlement rules (s.2), US (s.3), NL (s.4), time-barred (s.5), booking (s.6) |

## 2. Rules applied

* Entitled party = buyer if trade date **before** ex-date, seller if trade date **on/after** ex-date (2.1). Holder of record = settled position at close of record date (2.2). Claim only where the two differ (2.3, 2.5). Partial settlement: claim the unsettled quantity only (2.3c). Opt-out / special-ex: no claim (2.4).
* US: ex = record (T+1). Claims raised by us against the counterparty broker, gross; W-9 client suffers no withholding (3.2). Our payables are accrued and paid on presentation on/after pay date (3.3). Proceeds are credited to the client only when received and never before pay date; **no advances** (3.4).
* NL: T2S auto-detects claims on T2S-settled trades for 20 T2S business days after record date; never duplicate a CSD claim manually (4.2). Trades settled outside T2S matching (e.g. ICSD link) need a manual claim via Vandermeer by the end of that period (4.3). **All NL claims are compensated net of 15% Dutch dividend tax regardless of the parties' tax status** (4.4).
* Time-barred: cannot be raised; notify client and RM in writing; pursue counterparty only on client's written instruction; no receivable until counterparty agrees (5.1).
* Booking: receivables when detected, payables when presented/CSD-generated, CSD items at CSD amount (6.1).

Detection-period end dates (20 T2S business days after record date; T2S closing days assumed = TARGET closing days only, no other holidays in the windows):
* VOH26DVCA02, record 2026-09-09 → **2026-10-07**.
* VOH26DVCA01, record 2026-05-13 → **2026-06-10** (already passed).

## 3. Trade-by-trade

### Bracken Foods — BRKN26DVCA03, ex = record 2026-09-10, USD 0.54, pay 2026-09-25, no withholding

| Trade | Side / qty | TD | Settled | Result | Amount | Route |
|---|---|---|---|---|---|---|
| 5490 | SELL 5,000 | 09-08 | 09-09 | No claim — buyer entitled and holder of record | — | — |
| 5501 | BUY 12,000 | 09-09 | 09-10 (record date) | No claim — Fenwick entitled and holder of record | — | — |
| **5502** | BUY 30,000 | 09-09 | 09-14 (Aldwych fail) | **Market claim receivable** | 30,000 × 0.54 = **USD 16,200.00** | Raise vs Aldwych Securities Inc on claims platform |
| **5503** | SELL 8,000 | 09-09 | 09-11 (our fail, lending recall) | **Market claim PAYABLE** — buyer Tamsin entitled, Fenwick held at record | 8,000 × 0.54 = **USD 4,320.00** | Accrue; pay Tamsin on presentation on/after 09-25 |
| **5504** | BUY 25,000 | 09-09 | 18,000 on 09-10; 7,000 on 09-15 | **Market claim receivable on 7,000 only** | 7,000 × 0.54 = **USD 3,780.00** | Raise vs Aldwych |
| 5511 | BUY 20,000 | 09-10 (= ex-date) | 09-11 | No claim — traded ex, seller entitled and holder of record; price 40.41 is ex-div | — | — |

USD to book on 4410-3104 today: **receivable 19,980.00; payable 4,320.00.**

### Van Oosterlo — VOH26DVCA02, ex 2026-09-08, record 2026-09-09, EUR 0.88, pay 2026-09-16; claims net of 15% → EUR 0.748/sh

| Trade | Side / qty | TD | Settled | Result | Gross / net | Route |
|---|---|---|---|---|---|---|
| **7088** | SELL 9,000 | 09-04 | 09-10 T2S (our fail, lending) | **Market claim PAYABLE** — CSD MC-2609-118902, settled 09-16 | 7,920.00 / **6,732.00** | CSD auto; book at CSD amount, reconcile to cash |
| **7101** | BUY 15,000 | 09-07 | 09-11 T2S (cpty fail) | **Market claim receivable** — CSD MC-2609-118834, settled 09-16 | 13,200.00 / **11,220.00** | CSD auto; book, reconcile to cash |
| **7102** | BUY 10,000 | 09-07 | 09-14 via Euroclear Bank ICSD link | **Market claim receivable — not CSD-detectable** | 8,800.00 / **7,480.00** | Manual claim via Vandermeer vs Harlow, by 2026-10-07 |
| 7103 | BUY 4,000 | 09-07 | 09-10 | No claim — opt-out Y, traded special ex at ex price | — | — |
| **7110** | BUY 6,000 | 09-08 (= ex) | 09-09 (record, bilateral T+1) | **Reverse claim PAYABLE** — CSD RC-2609-020417, settles 09-21 | 5,280.00 / **4,488.00** | CSD auto; book, monitor settlement. Not on Tomas's list |
| 7111 | SELL 3,000 | 09-08 (= ex) | 09-10 | No claim — Fenwick as seller entitled and holder of record | — | — |

### Van Oosterlo — VOH26DVCA01 (May final, ex 05-12, record 05-13, EUR 1.24, paid 05-20)

| Trade | Side / qty | TD | Settled | Result | Gross / net | Route |
|---|---|---|---|---|---|---|
| **6620** | BUY 7,500 | 05-11 | 05-20 via ICSD link (Harlow fail) | Market claim did arise but needed a manual claim by 2026-06-10; never reviewed for income → **time-barred** | 9,300.00 / **7,905.00** | Not booked. Notify client and RM in writing; pursue Harlow only on written instruction; escalate the missed review |

EUR to book on 4410-3107 today: **receivable 18,700.00 (11,220.00 CSD + 7,480.00 manual); payable 11,220.00 (6,732.00 + 4,488.00).** Time-barred EUR 7,905.00 is **not** booked (policy 5.1). The two settled CSD claims net to EUR 4,488.00 received on 09-16 and should be cleared against Vandermeer cash.

## 4. What to say to Tomas

1. **Paying Bracken now — no.** Under our procedures claim proceeds are passed to the client when we receive them from the counterparty and never before the pay date (25 Sep); we do not advance claims. Only 5502 (USD 16,200.00) and the 7,000-share balance of 5504 (USD 3,780.00) are receivable, both dependent on Aldwych settling the claims. Fenwick itself owes USD 4,320.00 on 5503, which we will pay Tamsin on presentation after 25 Sep.
2. **5511** was traded on 10 Sep, the ex-date: the seller keeps the dividend and the ex price reflects that. No claim.
3. **5503** and **7088** are the other way round — Fenwick was the failing seller, so Fenwick pays. 7088 has already settled via the CSD (EUR 6,732.00 on 16 Sep).
4. **7110** is not on his list but Fenwick owes a reverse claim of EUR 4,488.00 (bought on ex-date, settled on record date), settling 21 Sep.
5. **7101** was already received via the CSD on 16 Sep (EUR 11,220.00). **7102** we are raising manually via Vandermeer (EUR 7,480.00) because it settled across the ICSD link. **7103** was traded special-ex at an ex price and **7111** was a sale on the ex-date: no claim on either.
6. **Dutch tax:** NL market claims are compensated net of 15% by market rule, whatever the parties' status. Claim compensation is not a dividend from the issuer, so Fenwick's exemption at source does not apply. The dividend on Fenwick's record-date position (180,000 sh) was paid gross, as it should be.
7. **6620:** a claim was due (EUR 7,905.00 net) but the window to raise it through Euroclear NL/Vandermeer closed on 10 Jun 2026. We are notifying Fenwick and the RM formally. We can approach Harlow directly only on Fenwick's written instruction, and nothing is booked until Harlow agrees.

## 5. Actions (mirrored in `answer.json`)

* Raise US claims vs Aldwych: 5502 USD 16,200.00; 5504 USD 3,780.00.
* Lodge manual NL claim via Vandermeer for 7102: EUR 8,800.00 gross / 7,480.00 net vs Harlow, deadline 2026-10-07.
* Post entries: 4410-3104 receivable USD 19,980.00, payable USD 4,320.00; 4410-3107 receivable EUR 18,700.00, payable EUR 11,220.00.
* Do not duplicate CSD claims 7088/7101/7110; monitor RC-2609-020417 to 09-21; reconcile 09-16 cash.
* Hold any early credit to Fenwick on Bracken (policy 3.4).
* Written time-barred notice on 6620 to Fenwick and RM; request written instruction on pursuing Harlow; escalate the missed ICSD-link income review to Head of Asset Servicing.
* Ask the securities lending desk to confirm manufactured dividends on the 8,000 Bracken and 9,000 Van Oosterlo shares that were on loan over the record dates.

## 6. Assumptions and open points

* T2S business-day count assumes only TARGET closing days are closed (none fall in either window); confirm with Vandermeer.
* Assumed Harlow made no voluntary payment on 6620 in May/June — May cash statements are not in the folder.
* Aldwych acceptance of the two US claims is not confirmed; receipt expected on/after 09-25.
* Ledger extract shows no claim entries booked; the 09-16 CSD settlements (EUR 11,220.00 in / 6,732.00 out) need confirming against the omnibus cash account.
* Lending: confirm in-lieu payments on lent shares so Fenwick is not out of pocket on the two payables that arose from lending-related fails.
