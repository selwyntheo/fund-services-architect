# GACP III — Q4 2026 Management Fee invoice GAM-III-2026-04: recomputation and recommendation

**To:** Sam Adeyemi, Fund Controller — Halcyon Private Fund Services
**From:** Fund Accounting (GACP III)
**Date:** 2 October 2026
**Re:** Granite Arch Management LP invoice GAM-III-2026-04, USD 817,500.00, on Monday 5 Oct payment run

## 1. Recommendation

**Do not pay the invoice as presented.** Pull it from Monday's run and hold it under Schedule 4.2 of our services agreement.

| | USD |
|---|---:|
| Invoice amount (GAM-III-2026-04) | 817,500.00 |
| Correct Q4-2026 installment (gross) | 633,847.50 |
| Less: Q3-2026 credit under LPA s.8.1(d) | (576,926.27) |
| **Correct amount payable for Q4-2026** | **56,921.23** |
| **Overbilling** | **760,578.77** |
| Credit carried forward after Q4 | 0.00 |

The difference is ~93% of the invoice and far exceeds the Schedule 4.2 tolerance (lower of USD 5,000 or 1%). We are not permitted to pay a different amount than the invoice (Sched. 4.5) or act on a verbal instruction (Sched. 4.4); we need a revised invoice signed by Marcus Feld for USD 56,921.23.

## 2. Why the invoice is wrong — three independent errors

### 2.1 The step-down date is 15 August 2026, not 1 October 2026

* LPA definition of "Investment Period" (`inputs/lpa/GACP_III_LPA_excerpt_management_fee.md`): Initial Closing 14 Aug 2020 + 5 years = 14 Aug 2025, extendable once by up to one year with Advisory Committee consent.
* LPAC minutes 12 June 2025, Item 3 (`inputs/governance/LPAC_records_GACP_III.txt`): "RESOLVED: the Committee consents to the extension of the Investment Period to and including 14 August 2026," and noted the fee "steps down from the day after the extended Investment Period ends."
* The invoice says the fee "steps down from this quarter" and uses "Invested Capital at 30 September 2026". The 1.50% basis actually applied from **15 August 2026**, i.e. part-way through Q3. LPA s.8.1(d) therefore requires Q3-2026 to be recomputed and the overpayment credited against Q4. The invoice ignores this entirely.

### 2.2 Invested Capital is USD 171.6mm, not USD 218.0mm

The invoice takes aggregate cost of USD 308.0mm less Brindle and Tessaract (USD 90.0mm). The LPA definition of "Invested Capital" also requires deduction of (i) cost of any *portion* of an investment Realized and (ii) each Permanent Write-Down. Company-by-company, from `inputs/portfolio/investment_cost_ledger_GACP_III_20260930.csv`:

| Company | Cost | LPA treatment | IC at 15 Aug 2026 | IC at 1 Oct 2026 | Invoice |
|---|---:|---|---:|---:|---:|
| Tessaract Logistics | 60.0 | Full sale 15 Sep 2026 (IC-015) → Realized after 14 Aug | 60.0 | 0.0 | 0.0 |
| Orla Specialty Foods | 36.0 | 40% of shares sold 20 Jun 2023 (IC-008) → 40% of cost (14.4) Realized. Ledger note: "cost relief not yet posted". Valuation system remaining cost 21.6 agrees. | 21.6 | 21.6 | **36.0** |
| Brindle Veterinary | 30.0 | Full sale 18 Mar 2025 (IC-011) | 0.0 | 0.0 | 0.0 |
| Kittering Software | 40.0 | FV 24.0 at 30 Jun 2026, "Not designated permanent" — unrealized markdown, no effect | 40.0 | 40.0 | 40.0 |
| Pellucid Diagnostics | 28.0 | Permanent Write-Down USD 16.0mm designated by GP notice to LPAC 22 Jul 2026, effective 30 Jun 2026 | 12.0 | 12.0 | **28.0** |
| Wexford Marine | 16.0 | Chapter 7 liquidation order 20 Nov 2025; written off as worthless 31 Dec 2025 (IC-013) → Realized | 0.0 | 0.0 | **16.0** |
| Halyard Packaging | 38.0 + 4.0 | Dividend recap 18 Dec 2024 (IC-010), no shares sold → no cost Realized. Follow-on USD 4.0mm 10 Sep 2026 (IC-014) included from that date. | 38.0 | 42.0 | 42.0 |
| Corvid Energy | 32.0 | Held | 32.0 | 32.0 | 32.0 |
| Tamarind Home Health | 24.0 | Held | 24.0 | 24.0 | 24.0 |
| **Total (USD mm)** | 308.0 | | **227.6** | **171.6** | **218.0** |

Reconciliation: 218.0 − 14.4 (Orla portion) − 16.0 (Wexford write-off) − 16.0 (Pellucid PWD) = 171.6.

Per your note on the rough year: the basis above follows the LPA definitions only. Kittering's 0.60x mark is *not* deducted (unrealized fair-value decreases are not Permanent Write-Downs unless designated; the 22 Jul 2026 GP notice confirms Pellucid is the only designation). Conversely, Pellucid is reduced by the designated USD 16.0mm, not to its USD 12.0mm fair value (which happens to coincide). Halyard's USD 50mm recap dividend does not reduce cost.

### 2.3 Fee is charged on the Fee-Paying Partners' share (98.5%), not 100%

LPA s.8.1(b): 1.50% of Invested Capital *attributable to the Fee-Paying Partners*, attributed pro rata to Commitments (no excused Partners). From `inputs/investor_records/partner_register_GACP_III.csv`: total commitments USD 400.0mm; GP (Granite Arch GP III, LLC) USD 6.0mm is FEE_EXEMPT; fee-paying commitments USD 394.0mm = **98.5%**. (Consistent with the USD 394mm basis on the Q1–Q3 commitment-based invoices in `inputs/manager/management_fee_installments_GACP_III_2026.csv`.) The invoice applies 1.50% to 100% of Invested Capital.

## 3. Recomputation

**Q4-2026 installment (s.8.1(b),(c); basis as of 1 Oct 2026):**
171,600,000 × 98.5% = 169,026,000 × 1.50% = 2,535,390.00 ÷ 4 = **USD 633,847.50**

**Q3-2026 recomputation (s.8.1(d); Q3 = 92 days; 1 Jul–14 Aug inclusive = 45 days; 15 Aug–30 Sep = 47 days):**
* (i) Commitment-basis installment 1,970,000.00 × 45/92 = **963,586.96**
* (ii) Invested-Capital installment at 15 Aug 2026: 227,600,000 × 98.5% = 224,186,000 × 1.50% ÷ 4 = 840,697.50; × 47/92 = **429,486.77**
* Recomputed Q3 fee = **1,393,073.73**
* Paid 1 Jul 2026 (GAM-III-2026-03): 1,970,000.00
* **Credit due to the Partnership: 576,926.27** — to be applied against the next installment (s.8.1(d)).

**Q4 amount payable:** 633,847.50 − 576,926.27 = **USD 56,921.23**; credit carried forward: nil.

**Overbilling:** 817,500.00 − 56,921.23 = **USD 760,578.77**.

Fee Income offsets (s.8.1(e)/8.3): none in 2026 per the LPA extract; none applied.

## 4. What we must do under the services agreement (Schedule 4, `inputs/admin/halcyon_services_agreement_schedule4_fee_payments.md`)

1. **Hold the payment** (4.2) — remove GAM-III-2026-04 from the 5 Oct run.
2. **Notify the Manager's CFO in writing** (4.2) with this recomputation and the basis for each difference (step-down date / Q3 credit; Orla, Wexford, Pellucid basis items; 98.5% attribution). Date-stamp the notice: it starts the 10 Business Day clock.
3. **Request a revised invoice signed by the CFO** for USD 56,921.23 (4.4, 4.5). We cannot pay any amount other than the invoiced amount, and cannot accept a verbal release.
4. **If unresolved within 10 Business Days**, report to the LPAC Chair (Aldermoor SERS representative) and the Partnership's auditor (4.3).
5. **Books:** book the Q3 recomputation (reduce Q3 fee expense / recognise USD 576,926.27 due from Manager), accrue Q4 at USD 633,847.50, and post the long-outstanding Orla USD 14.4mm cost relief flagged in ledger IC-008.
6. **LP reporting (LPA s.8.8):** the Q3-2026 quarterly report must show the basis, rate, the s.8.1(d) recomputation and the USD 576,926.27 credit carried into Q4.

## 5. Assumptions and open points

* We work from Halcyon's operational LPA extract; the executed agreement governs. Please confirm s.8.1(d) wording and that no Section 2.6 key-person event ended the Investment Period before 14 Aug 2026 (if so the step-down is earlier and the credit larger).
* Orla: cost of the 40% portion sold taken as pro rata cost (USD 14.4mm), matching the valuation system's USD 21.6mm remaining cost. The ledger itself never posted the relief.
* Wexford: treated as Realized on the write-off following the Chapter 7 liquidation order (both dates well before 15 Aug 2026).
* Halyard follow-on (USD 4.0mm, 10 Sep 2026): included from 1 Oct 2026 only; assumed inclusive of any capitalised transaction costs.
* No Permanent Write-Down other than Pellucid has been designated in our records; Kittering ("revisit Q3") is carried at cost unless and until the GP issues a written notice to the LPAC.
* No Fee Income offsets in Q3/Q4 2026 (to be confirmed by the Manager).
* We have assumed the Manager has not separately issued a Q3 credit note; if it has, the Q4 payable would be USD 633,847.50 and the credit settled separately.

**Needed from:** Manager CFO (M. Feld) — revised CFO-signed invoice for USD 56,921.23, confirmation on PWD designations, Fee Income and the Halyard follow-on cost; Halcyon legal/compliance — confirm executed LPA wording of s.8.1(d) and absence of key-person event; Fund Accounting — post the Orla cost relief and Q3/Q4 entries above.

Source files relied on: `inputs/lpa/GACP_III_LPA_excerpt_management_fee.md`; `inputs/governance/LPAC_records_GACP_III.txt`; `inputs/manager/GAM_invoice_GAM-III-2026-04.txt`; `inputs/manager/management_fee_installments_GACP_III_2026.csv`; `inputs/portfolio/investment_cost_ledger_GACP_III_20260930.csv`; `inputs/portfolio/valuation_summary_GACP_III_Q2_2026.csv`; `inputs/investor_records/partner_register_GACP_III.csv`; `inputs/admin/halcyon_services_agreement_schedule4_fee_payments.md`.
