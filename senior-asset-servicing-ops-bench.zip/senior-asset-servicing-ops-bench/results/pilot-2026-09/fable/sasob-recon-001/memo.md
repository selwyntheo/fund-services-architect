# TGEI — USD cash reconciliation, Northgate 7730-104, 15-Sep-2026

**To:** Jordan Pike, Fund Accounting Manager, Pellmore Fund Services
**Re:** TGEI USD cash break of USD 1,280,183.04 — fully explained; five book corrections tonight, one custodian-side item carried; no plug required
**Prepared:** 15-Sep-2026, ahead of the 6:30 pm NAV cut

## 1. Headline

| | USD |
|---|---:|
| Accounting closing balance, GL 1010 (`inputs/accounting/cash_ledger_TGEI_USD_20260915.csv`) | 9,790,604.12 |
| Northgate closing balance, MT940 `:62F:` (`inputs/custodian/MT940_NTCUS33_7730-104_20260915.txt`) | 8,510,421.08 |
| **Difference (books minus custodian)** | **1,280,183.04** |
| Explained by findings F1–F6 below | 1,280,183.04 |
| **Unexplained residual** | **0.00** |

Both sides open at 12,418,305.22 (ledger `BAL-20260914` = MT940 `:60F:`), confirming that yesterday tied and everything below is 15-Sep activity. The ledger closing balance is the opening balance plus the four ledger postings (−2,349,300.00 + 98,124.00 − 412,775.10 + 36,250.00).

Three items agree to the penny and need nothing: the TA redemption funding of 412,775.10 (`TA-0915-TGEI-R`; = 301,402.55 + 111,372.55 in `inputs/transfer_agent/ta_daily_activity_TGEI_20260914.csv`), the Halvorsen Rail coupon of 36,250.00 (`CP-HALV-20260915`; 1,000,000 × 7.25% / 2), and the Orrin Biosystems sale `EQ-260915-0210`, which is correctly pending for T+1 settlement on 16-Sep and has no cash effect today.

## 2. What every piece of the difference is

Amounts are books-minus-custodian (positive = books show more cash than Northgate).

| # | Reference | Cause | Amount | Wrong side | Treatment |
|---|---|---|---:|---|---|
| F1 | FX-260915-0117 | FX booked at WMR fix, not contract rate | −900.00 | Accounting | Re-book at 1.174200 |
| F2 | DV-VALC-20260915 / NTC-CA-551907 | French WHT 25% at source vs 15% booked | +11,544.00 | Accounting | Tax reclaim receivable GL 1450 |
| F3 | DV-VALC-20260915 / NTC-CA-551907 | Depositary fee not booked | +3,700.00 | Accounting | Reduce dividend income |
| F4 | BND-260914-0033 / NTC-SE-771420 | Bond settled T+1; books hold it pending at defaulted T+2 | +1,497,196.67 | Accounting | Correct settle date and purchased interest; record settlement |
| F5 | INV-NTC-2608-7730 / NTC-FEE-0915 | August custody fee auto-debit not applied to accrual | +18,642.37 | Accounting | Apply to accrual; true up 7.63 |
| F6 | TSDF-SUB-0915-0042 / NTC-WI-330981 | TSDF subscription wire credited to our account | −250,000.00 | Custodian (not our fund) | Do not book; Northgate to move to 7730-118 |
| | | **Total** | **1,280,183.04** | | |

### F1 — FX-260915-0117 (−900.00)
The ledger shows the USD leg as −2,349,300.00 at 1.17465, `rate_source = WMR_1600_LDN`, entered by FXAUTO. The Bramwell confirmation (`inputs/trades/fx_confirmation_FX-260915-0117.txt`) is EUR 2,000,000.00 bought at 1.174200 for USD 2,348,400.00, value 15-Sep; Northgate debited exactly that (`NTC-FX-88213`, "AT 1.174200 CPTY BRAMWELL BANK PLC"). Policy 4.1 requires booking at the confirmed contract rate; WMR is for valuation only. Books understate cash by 900.00.

### F2 — Valcourt Energie ADS dividend, withholding rate (+11,544.00)
Gross: 185,000 ADS × USD 0.6240 = 115,440.00 (notice: EUR 0.53 at 1.177358). The ledger booked net of 15% WHT (17,316.00) = 98,124.00. Northgate credited 82,880.00 after 25% tax (28,860.00) and the depositary fee (F3). `inputs/custodian/tax_documentation_status_7730-104.csv` shows the FR Form 5000 / Form 6166 relief-at-source documentation **expired 30-Jun-2026** (renewal 6166 requested from IRS 20-May-2026, not received). The record date was 3-Sep-2026, so under the depositary notice the 25% statutory rate was correctly applied. Northgate is right; under policy 5.1 the books should have recorded WHT at 25%. The 10% excess (11,544.00) is reclaimable via Form 5001 and FR reclaims are deemed collectible (policy 5.2), so it goes to GL 1450 tax reclaim receivable, not expense.

### F3 — Valcourt Energie ADS dividend, depositary fee (+3,700.00)
The Kestrel notice (`inputs/notices/valcourt_ads_cash_distribution_notice.txt`) charges US$0.02 per ADS: 185,000 × 0.02 = 3,700.00, shown on the MT940 as "LESS DR FEE USD 3,700.00". Not booked. Policy 5.3: reduction of dividend income. F2 + F3 = 15,244.00 = 98,124.00 − 82,880.00.

### F4 — Crestline Utilities bond purchase (+1,497,196.67)
`inputs/accounting/pending_settlements_TGEI_20260915.csv` holds BND-260914-0033 as PENDING for 16-Sep with `settle_cycle_source = SECMASTER_DEFAULT_T+2`, accrued interest 21,218.75, net 1,497,398.75. The trade ticket (`inputs/trades/trade_ticket_BND-260914-0033.txt`) is regular-way T+1 → 15-Sep and notes the security master settlement-cycle field defaulted when the security was set up on 14-Sep. Northgate settled DVP on 15-Sep for 1,497,196.67 (principal 1,476,180.00 + interest 21,016.67), which is correct: 30/360 from the 1-Jun coupon to 15-Sep is 104 days; 1,500,000 × 4.85% × 104/360 = 21,016.67. The books computed 105 days to the wrong 16-Sep date (21,218.75), an overstatement of 202.08. Policy 6.1: US corporate bonds are T+1; the exception goes to Reference Data.

### F5 — August custody fee (+18,642.37)
Invoice NTC-2608-7730 (`inputs/custodian/custody_invoice_NTC-2608-7730.txt`) totals 18,642.37 and is paid by automatic debit on 15-Sep under s7.2 of the fee agreement; Northgate debited it (`NTC-FEE-0915`). The ledger has no payment. `inputs/accounting/accrued_expenses_TGEI_20260915.csv` carries the August estimate at 18,650.00 in GL 2310. Policy 3.5: record as payment against the accrual and true up the 7.63 over-accrual through custody fee expense. The September accrual to date (9,310.00) is untouched.

### F6 — Misdirected TSDF subscription wire (−250,000.00)
MT940 `NTC-WI-330981`: incoming 250,000.00 from Sandridge Fund Services as TA, reference TSDF-SUB-0915-0042, **"FFC TIDEWELL SHORT DURATION FUND ACCT 7730-118 SUBSCRIPTION"**. The TA file confirms a TSDF class I subscription of 250,000.00 (25,126.382 shares, batch 0914) and zero TGEI subscriptions. Northgate credited the wrong account. This is not TGEI money; policy 3.4 prohibits recording it as income or capital share activity. Carry as a custodian-side reconciling item, expected clear 16-Sep, and notify Northgate, Sandridge and the TSDF fund accounting team today.

## 3. What we book tonight

| Entry | Dr | Cr | Cash effect |
|---|---|---|---:|
| F1 FX re-rate | 1010 Cash 900.00 | EUR cost / realized FX 900.00 | +900.00 |
| F2 WHT re-rate | 1450 Tax reclaim receivable 11,544.00 | 1010 Cash 11,544.00 | −11,544.00 |
| F3 Depositary fee | Dividend income 3,700.00 | 1010 Cash 3,700.00 | −3,700.00 |
| F4 Bond settlement (settle date → 15-Sep, interest → 21,016.67) | Investments at cost 1,476,180.00; Purchased accrued interest 21,016.67 | 1010 Cash 1,497,196.67 | −1,497,196.67 |
| F5 Custody fee | 2310 Accrued custody fees 18,650.00 | 1010 Cash 18,642.37; Custody fee expense 7.63 | −18,642.37 |
| F6 Misdirected wire | — no entry — | | 0.00 |

Corrected books: 9,790,604.12 + 900.00 − 11,544.00 − 3,700.00 − 1,497,196.67 − 18,642.37 = **8,260,421.08**.
Northgate: 8,510,421.08. Open after corrections: **−250,000.00**, which is exactly the misdirected TSDF wire on the custodian's side. Nothing else remains.

**On Ravi's offer to plug to misc expense: not needed and not permitted.** Every dollar is identified to a transaction and root cause, so the residual is 0.00. Policy 3.3 bars plugs without written Fund Controller approval and never above USD 1,000 in aggregate per fund per day, so the offer could not have been taken up even if a residual had existed.

**NAV:** with the five entries above posted, the USD cash reconciliation is complete and I have no objection to the 6:30 sign-off. The 250,000.00 is a custodian-side item with a documented expected clear date and does not touch TGEI's NAV.

## 4. What to chase tomorrow (and who)

1. **Northgate (custody ops):** move the 250,000.00 TSDF wire (NTC-WI-330981 / TSDF-SUB-0915-0042) from 7730-104 to 7730-118 with value 15-Sep, and confirm in writing. Until confirmed it stays on our reconciliation as a custodian-side item.
2. **Northgate Tax Services:** (a) file the Form 5001 reclaim for 11,544.00 on the Valcourt Energie ADS payment (USZYH2328430, pay date 15-Sep, record date 3-Sep, 25% withheld vs 15% treaty) and give us the reference for GL 1450 tracking; (b) status and expected date of the IRS Form 6166 renewal requested 20-May-2026; (c) confirm whether any other French-source income on 7730-104 since 1-Jul-2026 was withheld at 25%.
3. **Fund Treasurer:** the FR relief-at-source documentation has been expired since 30-Jun and the 6166 renewal is outstanding; every French dividend is taking a 10% cash drag until reclaimed. Confirm who owns the renewal and push it.
4. **Sandridge (TA) and TSDF fund accounting:** told today that their 250,000.00 subscription landed in TGEI's account and that Northgate has been asked to correct it; TSDF should expect a matching break on 7730-118 until it moves.
5. **Reference Data (security master):** fix USQJUPI78013 to T+1 and sweep recently added securities for the same T+2 default.
6. **Fund Controller:** two feed controls failed tonight — FXAUTO booked at the WMR fix rather than the confirmed rate (policy 4.1) and INCOME_AUTO applied the treaty rate while documentation was expired (policy 5.1). Recommend a review of both.

## 5. Assumptions and open points

- I have relied solely on the files in `inputs/`; no external data was used. Accrued interest was recomputed on the 30/360 basis stated on the trade ticket from the 1-Jun-2026 coupon date.
- The EUR leg of FX-260915-0117 (EUR 2,000,000 due into 7730-104-EUR on 16-Sep Paris settlement) is outside the USD ledger provided; it should be checked to be booked at 1.174200 so both legs agree.
- Only the Valcourt payment is evidenced in today's inputs; other FR dividends since 1-Jul-2026 may need the same re-rating and reclaim.
- The inputs do not say who owns the Form 6166 renewal; I have raised it with Tax Services and the Fund Treasurer.
- Northgate's FX advice cites Bramwell at 1.174200, consistent with the MT300; I have treated the ledger's WMR_1600_LDN rate source as a feed configuration error rather than a deliberate mapping, which the Fund Controller should confirm.

Structured version of this note, including the full action list, is in `out/answer.json`.
