# GAOF II — Second Closing 30 Sep 2026: equalization numbers and points for the GP

**To:** Priya Sethi, Head of Investor Services
**From:** Investor Services (GAOF II team)
**Date:** 18 Sep 2026
**Re:** Granite Arch Opportunities Fund II, L.P. — second closing equalization, response to Tom Brandt's Fund I first cut

## 1. Bottom line

* Admit **Tamsin Bay (LP-0206, USD 50m)** and **Ostrander (LP-0207, USD 35m)** on 30 Sep. **Sable Point (LP-0208, USD 40m) is not admitted** and must be kept out of the run; the register still shows it in the second-close batch and needs correcting.
* Total Commitments after the closing: **USD 340,000,000**. Every Partner ends **15.4125% funded** on non-fee contributions.
* Incoming wires on 30 Sep: **LP-0206 USD 8,531,400.69**, **LP-0207 USD 6,029,634.59** (total USD 14,561,035.28). Of that, USD 13,523,261.30 goes to the six Existing Partners and USD 1,037,773.98 to the Manager.
* Tom's Fund I method **does not line up with the Fund II LPA on three points** (equalization base, interest base/start date, accounting for the interest). Section 4 sets out the differences and the suggested response. Using the Fund I method would overcharge the two incoming LPs by USD 4,366,875 on equalization alone.

## 2. Sources relied on (all in `inputs/`)

| File | Used for |
|---|---|
| `lpa/GAOF_II_LPA_excerpt_closings_fees.md` | Definitions; s.3.4(a)–(g) Subsequent Closings; s.3.3 drawdowns; s.8.1 Management Fee |
| `investor_records/partner_register_GAOF_II_20260917.csv` | Commitments, admission dates, fee status, side letter refs |
| `investor_records/second_closing_checklist_20260917.csv` | Closing readiness of LP-0206/0207/0208 |
| `investor_records/side_letter_terms_summary_GAOF_II.csv` | Tamsin Bay 1.75% fee rate and declined Additional Amount waiver; Aldermoor MFN |
| `capital_activity/capital_activity_GAOF_II_20260917.csv` | All Capital Contributions to date (CA-00001 to CA-00045) |
| `correspondence/2026-09-16_blackwood_second_close_update.txt` | Closing population; Q4 fee called separately on 1 Oct |
| `correspondence/2026-09-17_brandt_equalization_first_cut.txt` | GP's requested (Fund I) method |

Register and capital activity are as of 17 Sep 2026. I have assumed no further capital activity between 17 Sep and 30 Sep and that no Existing Partner is increasing its Commitment at this closing (open question).

## 3. Closing population

| Partner | Commitment | Status (checklist 17 Sep) | Treatment |
|---|---|---|---|
| LP-0206 Tamsin Bay Insurance Company | 50,000,000 | Docs complete; KYC cleared 4 Sep; side letter SL-OF2-004 executed 11 Sep; GP countersignature ready; wire instructions call-back verified 14 Sep | **Admitted** |
| LP-0207 Ostrander County Firefighters' Retirement Fund | 35,000,000 | Docs complete; KYC cleared 9 Sep; no side letter; GP countersignature ready; board minute received | **Admitted** |
| LP-0208 Sable Point Private Markets Access Fund, L.P. | 40,000,000 | KYC **open** (UBO certification outstanding); side letter **draft**; GP **not signed**; target closing moved to **15 Dec 2026** | **Deferred – excluded** |

What looks off: the partner register still carries LP-0208 as `SECOND 2026-09-30 / SUBSCRIPTION RECEIVED`. Owen Blackwood (16 Sep) asked us to leave the record alone pending his change form. We have excluded LP-0208 from every figure below, but the register must be corrected before 30 Sep so the platform cannot generate a closing notice or a 1 Oct Q4 fee call for an unadmitted investor. The 15 Dec third closing is within the LPA's one-year window (final Subsequent Closing no later than 2 Feb 2027). Sable Point's equalization and Additional Amount will be recomputed to its actual admission date and will be larger than a 30 Sep figure.

## 4. Where the Fund I method differs from the Fund II LPA, and how to respond

| # | Tom's Fund I approach (17 Sep) | GAOF II LPA | Effect / response |
|---|---|---|---|
| 1 | Each new LP pays the cumulative call percentage, 0.40% + 12.10% + 8.05% = **20.55% of Commitment**, plus fees | **s.3.4(a):** Equalization Contribution = the incoming LP's **Commitment Percentage after the closing** x aggregate non-fee Capital Contributions by all Partners. **s.3.4(b):** proceeds are distributed to Existing Partners pro rata to Commitments so that every Partner ends at the same funded percentage | LPA: LP-0206 7,706,250.00 and LP-0207 5,394,375.00 (15.4125% of Commitment). Fund I method: 10,275,000 and 7,192,500 — **USD 4,366,875 too much**, and after distribution Existing Partners would be at 13.70% vs 20.55% for the new LPs, i.e. not equalized. Use the LPA figures. |
| 2 | 8% late-closer interest on **everything paid in, fees included**, running from each call's **notice date** | **s.3.4(d):** 8% simple interest, actual/365, only on the incoming LP's share of each **non-fee** Capital Contribution, from and including the **due date** to but excluding 30 Sep | No interest on the Management Fee catch-up; the clock starts 17 Feb / 1 Apr / 1 Jul (due dates), not 2 Feb / 18 Mar / 16 Jun (notice dates). Actual receipt dates are irrelevant (s.3.3: s.3.8 default interest is separate from s.3.4). |
| 3 | Interest booked to the fund as **other income**, runs through the waterfall | **s.3.4(e):** the Additional Amount is **not a Capital Contribution**, does not reduce the new LP's Unfunded Commitment, is **distributed to Existing Partners (incl. GP) pro rata to Commitments**, is **not income of the Partnership** and is excluded from Article 9 | Pass the USD 422,636.30 straight through to the six Existing Partners. Do not book to partnership other income; do not include in the waterfall or fund performance. Auditor simplicity is not a basis to depart from the LPA. |

Points where the request is consistent with the LPA: the Q4 2026 Management Fee is called separately on 1 Oct to everyone admitted by then (Blackwood) — this matches s.3.4(c), which runs the catch-up only to 30 Sep, the last day of the quarter in which the closing occurs.

Tamsin Bay asked for a waiver of the Additional Amount; the GP declined and LPAC consent was not sought (SL-OF2-004 cl.2.2). Under s.3.4(g) any reduction or waiver needs Advisory Committee consent, so the Additional Amount is charged in full. If the GP now wants to change that, the figures for LP-0206 should be held until the LPAC consent is documented.

## 5. Computation

### 5.1 Base data

Existing Commitments: GP-0200 5,000,000; LP-0201 75,000,000; LP-0202 60,000,000; LP-0203 50,000,000; LP-0204 40,000,000; LP-0205 25,000,000 = **255,000,000**. After closing: 255,000,000 + 50,000,000 + 35,000,000 = **340,000,000**.

Non-fee Capital Contributions before the closing (capital activity, components INVESTMENT and PARTNERSHIP_EXPENSES; MANAGEMENT_FEE lines excluded per s.3.4(a)):

| Drawdown | Notice | Due date | Non-fee amount (all Partners) | % of 255m | Days due date → 30 Sep (excl.) |
|---|---|---|---|---|---|
| Call 1 | 2 Feb 2026 | 17 Feb 2026 | 1,020,000.00 | 0.40% | 225 |
| Call 2 | 18 Mar 2026 | 1 Apr 2026 | 30,855,000.00 | 12.10% | 182 |
| Call 3 | 16 Jun 2026 | 1 Jul 2026 | 20,527,500.00 | 8.05% | 91 |
| **Total** | | | **52,402,500.00** | **20.55%** | |

Funded percentage after closing: 52,402,500 / 340,000,000 = **15.4125%**.

### 5.2 Commitment Percentages after the closing (s.1 definition, incl. GP)

| Partner | Commitment | % |
|---|---|---|
| GP-0200 | 5,000,000 | 1.4706 |
| LP-0201 | 75,000,000 | 22.0588 |
| LP-0202 | 60,000,000 | 17.6471 |
| LP-0203 | 50,000,000 | 14.7059 |
| LP-0204 | 40,000,000 | 11.7647 |
| LP-0205 | 25,000,000 | 7.3529 |
| LP-0206 | 50,000,000 | 14.7059 |
| LP-0207 | 35,000,000 | 10.2941 |
| **Total** | **340,000,000** | **100.0000** |

### 5.3 Incoming LPs — what each wires on 30 Sep

**Equalization Contribution (s.3.4(a))** = Commitment Percentage x 52,402,500.00
* LP-0206: 50/340 x 52,402,500 = **7,706,250.00**
* LP-0207: 35/340 x 52,402,500 = **5,394,375.00**

**Management Fee catch-up (s.3.4(c), s.8.1)** — 2 Feb 2026 to 30 Sep 2026; stub 2 Feb–31 Mar = 58 days counting first and last day (this convention reconciles to the first-close fee lines, e.g. CA-00003 = 75m x 2% x 58/365 = 238,356.16); Q2 and Q3 at one quarter of the annual fee.
* LP-0206 at **1.75%** (SL-OF2-004 cl.2.1): annual 875,000.00; stub 875,000 x 58/365 = 139,041.10; Q2 218,750.00; Q3 218,750.00 = **576,541.10**
* LP-0207 at **2.00%** (s.8.1(a)): annual 700,000.00; stub 700,000 x 58/365 = 111,232.88; Q2 175,000.00; Q3 175,000.00 = **461,232.88**

**Additional Amount (s.3.4(d))** — 8% simple, actual/365, on the LP's Commitment Percentage of each non-fee drawdown, from due date to 30 Sep exclusive, rounded per drawdown (s.3.4(f)):

| Drawdown | LP-0206 share | Days | Interest | LP-0207 share | Days | Interest |
|---|---|---|---|---|---|---|
| Call 1 (due 17 Feb) | 150,000.00 | 225 | 7,397.26 | 105,000.00 | 225 | 5,178.08 |
| Call 2 (due 1 Apr) | 4,537,500.00 | 182 | 181,002.74 | 3,176,250.00 | 182 | 126,701.92 |
| Call 3 (due 1 Jul) | 3,018,750.00 | 91 | 60,209.59 | 2,113,125.00 | 91 | 42,146.71 |
| **Total** | | | **248,609.59** | | | **174,026.71** |

**Wire summary**

| | LP-0206 Tamsin Bay | LP-0207 Ostrander | Total |
|---|---|---|---|
| Equalization Contribution (to Existing Partners) | 7,706,250.00 | 5,394,375.00 | 13,100,625.00 |
| Management Fee catch-up (to Manager) | 576,541.10 | 461,232.88 | 1,037,773.98 |
| Additional Amount (to Existing Partners) | 248,609.59 | 174,026.71 | 422,636.30 |
| **Total wire 30 Sep** | **8,531,400.69** | **6,029,634.59** | **14,561,035.28** |
| Unfunded Commitment after (Commitment − equalization − fee; Additional Amount does not reduce) | 41,717,208.90 | 29,144,392.12 | |

### 5.4 Existing Partners — what each receives

Return of capital under s.3.4(b): 13,100,625.00 pro rata to Commitments (51,375.00 per USD 1m; exact, no rounding). Additional Amount under s.3.4(e): 422,636.30 pro rata to Commitments, each LP rounded to the cent, residual (+0.01) to the GP per s.3.4(f).

| Partner | Capital returned | Additional Amount | Total received | Contributions to date (all) | Unfunded after | Net non-fee after / Commitment |
|---|---|---|---|---|---|---|
| GP-0200 | 256,875.00 | 8,286.99 | 265,161.99 | 1,027,500.00 | 4,229,375.00 | 15.4125% |
| LP-0201 | 3,853,125.00 | 124,304.79 | 3,977,429.79 | 16,400,856.16 | 62,452,268.84 | 15.4125% |
| LP-0202 | 3,082,500.00 | 99,443.84 | 3,181,943.84 | 13,120,684.93 | 49,961,815.07 | 15.4125% |
| LP-0203 | 2,568,750.00 | 82,869.86 | 2,651,619.86 | 10,933,904.11 | 41,634,845.89 | 15.4125% |
| LP-0204 | 2,055,000.00 | 66,295.89 | 2,121,295.89 | 8,747,123.29 | 33,307,876.71 | 15.4125% |
| LP-0205 | 1,284,375.00 | 41,434.93 | 1,325,809.93 | 5,466,952.05 | 20,817,422.95 | 15.4125% |
| **Total** | **13,100,625.00** | **422,636.30** | **13,523,261.30** | | | |

Unfunded after = Commitment − all contributions to date (every capital activity line is `reduces_unfunded = Y`, fees included) + capital returned (added back and recallable per s.3.4(b)). Total Unfunded Commitments of all eight Partners after closing: USD 283,265,205.48.

**Proof:** wires in 14,561,035.28 = 13,523,261.30 to Existing Partners + 1,037,773.98 to Manager. Each Existing Partner's net non-fee contributions after the return (e.g. LP-0201: 15,412,500.00 − 3,853,125.00 = 11,559,375.00 = 15.4125% of 75m) equal the incoming LPs' 15.4125%, which is the s.3.4(b) test.

## 6. Other items flagged

1. **Harrowgate (LP-0205) late payment.** Call 2 (CA-00026/27/28, due 1 Apr 2026) was received 6 Apr 2026. This is a s.3.8 default-interest matter, separate from s.3.4 and with no effect on the Additional Amount (which runs from due dates). No default interest appears in the capital activity — please confirm with Tom whether it was charged, waived or booked elsewhere.
2. **Aldermoor MFN (LP-0201, SL-OF2-003 cl.6.1).** Aldermoor may elect terms granted to investors with equal or smaller Commitments. Tamsin Bay (USD 50m) gets a 1.75% fee rate flagged size-based (>= USD 50m) and "not electable", yet Aldermoor's USD 75m exceeds that threshold. The GP/counsel should confirm the treatment before the post-closing MFN disclosure. Not a closing-day cash item.
3. **Rounding convention (s.3.4(f)).** I treated each drawdown (one due date) as one Capital Contribution. Rounding per component line (INVESTMENT and PARTNERSHIP_EXPENSES separately) would change LP-0206 by −0.03 and LP-0207 by +0.01. Worth agreeing with the GP now so the third closing is done the same way.
4. **Payment instructions.** Only Tamsin Bay's incoming instructions are recorded as call-back verified. Distributions to the six Existing Partners should go only to standing instructions on file, with call-back where our procedures require.

## 7. Accounting treatment to apply on 30 Sep (on cleared funds)

* Equalization Contributions 7,706,250.00 / 5,394,375.00: non-fee Capital Contributions of LP-0206 / LP-0207; reduce their Unfunded Commitments.
* Management Fee catch-up 576,541.10 / 461,232.88: Capital Contributions in respect of Management Fees; paid to the Manager; reduce Unfunded Commitments.
* Return of capital 13,100,625.00 to Existing Partners pro rata to Commitments: return of Capital Contributions, added back to Unfunded Commitments, recallable.
* Additional Amount 422,636.30: received for and paid to Existing Partners pro rata to Commitments; **not** a Capital Contribution, **not** partnership income, **not** in the waterfall; does **not** reduce the incoming LPs' Unfunded Commitments.

## 8. What I need, and from whom

| From | Item |
|---|---|
| Priya / GP (Brandt, Blackwood) | Confirmation the funds flow memo and closing notices will use the LPA figures above rather than the Fund I method; any waiver of Tamsin Bay's Additional Amount needs LPAC consent (s.3.4(g)) |
| Owen Blackwood (IR) | Signed change form moving LP-0208 to the third closing so the register can be corrected before 30 Sep |
| Tom Brandt (Controller) | s.3.8 default interest position on Harrowgate's late Call 2 payment; agreement on the s.3.4(f) rounding convention; confirmation of no capital activity or Commitment increases between 17 Sep and 30 Sep |
| GP IR / counsel | MFN treatment of Tamsin Bay's size-based 1.75% rate vis-a-vis Aldermoor |

Working files: `out/answer.json` (structured figures), `out/calc.py` and `out/_calc.json` (re-performable computation from the CSV inputs).
