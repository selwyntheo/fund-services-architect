# TGEI USD Cash Break (Northgate 7730-104) — 2026-09-15

**To:** Jordan Pike, Fund Accounting Manager
**Re:** Cash reconciliation before 6:30 NAV cut
**Prepared from:** files in `inputs/` as of 2026-09-15 EOD

## Bottom line

The $1,280,183.04 break (books over custodian) is fully explained — six causes, $0.00 left
unexplained. No plug to misc expense is needed or, per policy 3.3, permitted for an unexplained
amount this size anyway (the residual is zero, well under the $1,000/fund/day cap that would even
allow one, and any plug still needs Fund Controller sign-off). Post the five correcting entries
below tonight and the books tie to Northgate to the penny except for one item that is not TGEI's
cash at all and should not hold the NAV.

* Accounting closing balance (before corrections): **$9,790,604.12**
* Northgate statement closing balance (MT940 `:62F:`): **$8,510,421.08**
* Total difference (accounting − custodian): **$1,280,183.04**
* Unexplained residual after the six findings below: **$0.00**
* Corrected accounting closing balance (after posting F1–F5): **$8,260,421.08**
* Open reconciling item remaining after corrections: **−$250,000.00** (F6, custodian-side, see below)

## Opening balance check

Both sides open at $12,418,305.22 (`cash_ledger_TGEI_USD_20260915.csv` OPEN row; `MT940 :60F:`).
Yesterday tied to the penny per your note — confirmed, so the entire break is today's activity, as
expected.

## Findings (each ties a specific transaction to a specific cause)

| # | Reference | Cause | Amount (acctg − custodian) | Side | Treatment |
|---|---|---|---:|---|---|
| F1 | FX-260915-0117 | FX rate applied | −$900.00 | accounting | correct entry |
| F2 | DV-VALC-20260915 | Withholding tax rate | +$11,544.00 | accounting | tax reclaim receivable |
| F3 | DV-VALC-20260915 | Depositary fee not booked | +$3,700.00 | accounting | reduce dividend income |
| F4 | BND-260914-0033 | Settlement date / trade not booked | +$1,497,196.67 | accounting | correct settlement date, book trade |
| F5 | INV-NTC-2608-7730 | Custody fee payment not recorded | +$18,642.37 | accounting | apply payment to accrual |
| F6 | TSDF-SUB-0915-0042 | Misdirected cash (wrong fund) | −$250,000.00 | not our fund | return to correct fund |

**Sum of findings = $1,280,183.04 = total difference. Residual = $0.00.**

### F1 — FX-260915-0117, booked at the wrong rate (−$900.00)

`cash_ledger_TGEI_USD_20260915.csv` books the EUR 2,000,000 spot buy at 1.17465 (source
`WMR_1600_LDN`), a −$2,349,300.00 debit. But `fx_confirmation_FX-260915-0117.txt` (Bramwell Bank
Plc) shows the trade executed at **1.174200**, sell USD 2,348,400.00 — exactly what Northgate's
MT940 line shows debited. Policy §4.1 is explicit: FX trades book at the executed contract rate;
WMR is for valuation of balances only, never for booking trades. **Reverse the ledger entry and
rebook at 1.174200.** Net cash correction: +$900.00.

### F2 + F3 — Valcourt Energie SA ADS dividend, wrong WHT rate and missing depositary fee (+$15,244.00 combined)

Ledger booked $98,124.00 net, assuming the 15% US/France treaty rate (185,000 ADS × $0.6240 gross
= $115,440.00 × 0.85). Northgate's statement shows $82,880.00 net: gross $115,440.00 less **25%**
FR tax ($28,860.00) less a **$3,700.00** depositary fee.

Checked why: `tax_documentation_status_7730-104.csv` shows the FR relief-at-source certification
(Form 5000 + Form 6166) for 7730-104 **expired 2026-06-30** — before the 2026-09-03 record date —
with the 6166 renewal requested from the IRS on 2026-05-20 and still outstanding. Per the
depositary notice (`valcourt_ads_cash_distribution_notice.txt`), without valid relief-at-source
paperwork on file by record date, the statutory 25% applies. Custodian withheld correctly.

Per policy §5.1, dividend WHT should be recorded at the rate expected given documentation status
on the record date — that was 25%, not 15%. Per §5.2, the excess above the *treaty* rate (10% of
$115,440.00 = **$11,544.00**) is booked as a tax reclaim receivable (GL 1450), not written off,
because FR reclaims are treated as collectible. Per §5.3, the $0.02/ADS depositary fee
($3,700.00) reduces dividend income rather than sitting as a separate, unbooked expense.

**Correct entry:** net cash $82,880.00 (matches custodian); dividend income $94,424.00 (gross
less 15% treaty WHT $17,316.00 less $3,700.00 fee); new Tax Reclaim Receivable $11,544.00.

**Action needed from Northgate/Tax Services:** file Form 5001 to reclaim the $11,544.00 excess
withholding. Separately, worth chasing the IRS 6166 renewal status so relief-at-source is restored
before the next FR pay date.

### F4 — Crestline Utilities bond purchase never hit the cash ledger (+$1,497,196.67)

`pending_settlements_TGEI_20260915.csv` shows BND-260914-0033 still **PENDING**, settle date
2026-09-16, `settle_cycle_source = SECMASTER_DEFAULT_T+2`. The trade ticket
(`trade_ticket_BND-260914-0033.txt`) says the note explicitly: *"Security newly added to security
master 2026-09-14; settlement cycle field defaulted"* and confirms **regular way T+1 → 2026-09-15**
— today. Policy §6.1 confirms US corporate bonds settle T+1 under SEC Rule 15c6-1. Northgate's
MT940 shows the DVP purchase actually settled today: principal $1,476,180.00 + accrued interest
$21,016.67 = $1,497,196.67, counterparty Holloway Securities LLC.

I recomputed the accrued interest independently (30/360, semiannual coupon 4.85%, last coupon
2026-06-01, actual settlement 2026-09-15 = 104 days/360): **$21,016.67**, matching Northgate
exactly. The pending-settlement record's $21,218.75 used the wrong (T+2) date (105 days/360) and
is **$202.08 too high** — a byproduct of the same bad date default, not a separate pricing error.

**Post tonight:** the full $1,497,196.67 cash outflow, and correct the settle date on the pending
record to 2026-09-15 so it doesn't also cause a break tomorrow. **Flag to Reference Data:** the
security master default for this newly added CUSIP should be T+1, not T+2 — worth checking whether
other recently onboarded bonds carry the same wrong default.

### F5 — August custody fee auto-debited but not yet posted against the accrual (+$18,642.37)

`custody_invoice_NTC-2608-7730.txt` (August service period) totals $18,642.37, auto-debited today
per Section 7.2 of the fee agreement — matches the MT940 `NCHG` line exactly.
`accrued_expenses_TGEI_20260915.csv` shows an August accrual on GL 2310 of $18,650.00 ("invoice
not yet received at accrual date"). Per policy §3.5, apply the $18,642.37 payment against the
accrual and true up the difference to expense.

**Custody fee true-up: $7.63 over-accrued** (accrual was $7.63 more than the actual invoice).

### F6 — $250,000 wire for a different fund landed in TGEI's account (−$250,000.00)

The MT940 credit references `TSDF-SUB-0915-0042 ... FFC TIDEWELL SHORT DURATION FUND ACCT
7730-118 SUBSCRIPTION`. `ta_daily_activity_TGEI_20260914.csv` confirms this $250,000 subscription
is booked to fund code **TSDF** (Tidewell Short Duration Fund), not TGEI — it's simply on the same
TA batch file because Sandridge services both funds. It is correctly **not** on TGEI's books.

Per policy §3.4, cash that doesn't belong to the Fund must not be booked as Fund income or capital
activity, and must be tracked as a reconciling item until reversed — that's exactly what this is.
**This is the only item still open after tonight's corrections** ($8,260,421.08 corrected book
balance vs. $8,510,421.08 custodian balance = the $250,000 difference).

## What I need from whom tomorrow

1. **Northgate (custodian):** reverse/redirect the $250,000 wire (ref TSDF-SUB-0915-0042) from
   7730-104 to the correct TSDF account 7730-118.
2. **Northgate/Kestrel Tax Services:** file Form 5001 to reclaim the $11,544.00 excess FR
   withholding on the Valcourt dividend.
3. **Fund Treasurer / Tax Ops:** status of the IRS Form 6166 renewal (requested 2026-05-20) so
   relief-at-source is restored for future FR dividends and this doesn't recur.
4. **Reference Data / security master team:** correct the T+2 settlement-cycle default that was
   applied to the newly added Crestline Utilities CUSIP (USQJUPI78013); check other recent
   additions for the same issue.
5. **TSDF fund accounting team / Sandridge (TA):** heads-up that their $250,000 subscription wire
   didn't reach 7730-118, so their own cash position isn't misstated while this gets fixed.

## On Ravi's "plug it if it's small" offer

Not needed — everything ties out to the penny across six identified causes, with nothing left
over. Policy §3.3 wouldn't allow a plug here anyway without your written approval, and only up to
$1,000/fund/day; that's moot since the residual is exactly $0.00.

## Recommendation on tonight's NAV

Post F1–F5 (net correction of roughly −$1.53mm to book cash, bringing it to $8,260,421.08) and
release the NAV. The remaining $250,000 difference (F6) is not TGEI's cash under any scenario and
should be carried as an open, custodian-side reconciling item pending Northgate's reversal — it
should not hold up tonight's cut.

## Open questions / assumptions requiring confirmation

- Whether the Form 6166 renewal has since arrived (if it covers the 2026-09-03 record date,
  relief-at-source might apply retroactively and change the reclaim mechanics for F2) —
  inputs only show "not yet received" as of the last accrual date.
- Expected timing for Northgate to reverse the F6 wire.
- Confirmation that Reference Data has corrected the settlement-cycle default going forward.
- No documented de minimis threshold for the $7.63 custody-fee true-up was found in the policy
  extract; I treated it as a routine true-up to expense per §3.5 rather than a separate approval
  item.

— Prepared for Jordan Pike, Pellmore Fund Services, ahead of the 2026-09-15 6:30 PM ET NAV cut.
