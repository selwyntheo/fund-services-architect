# Aldermoor Global Equity Fund (AGEF) — 18 Sep 2026 class NAVs, EUR-hedged class and independent hedge check

**To:** Henrik Aalto, Fund Accounting Manager, Quayside Fund Administration (Luxembourg) S.A.
**From:** NAV review
**Re:** AGEF 18/09 class NAVs incl. EUR hedged, independent hedge monitoring

Securities pricing and sub-fund P&L are taken as reviewed/signed off, per your note. This memo covers the
remaining class-level work: allocation, the I-EUR-H-Acc hedges (including Friday's roll), the three class NAVs,
and an independent hedge-ratio check.

## 1. Published class NAVs — 18 Sep 2026

| Class | Class ccy | NAV/share (4dp) | **NAV/share published (2dp)** |
|---|---|---:|---:|
| I-USD-Acc | USD | 149.8530 | **149.85** |
| A-USD-Acc | USD | 145.2601 | **145.26** |
| I-EUR-H-Acc | EUR | 120.4858 | **120.49** |

These are struck on 17-Sep closing shares in issue (before today's dealing is applied), consistent with the
Prospectus's forward-pricing convention. Class net assets before today's dealing:

| Class | Net assets, 18-Sep pre-dealing (USD) |
|---|---:|
| I-USD-Acc | 211,643,045.04 |
| A-USD-Acc | 117,835,681.73 |
| I-EUR-H-Acc | 79,809,838.62 (= EUR 67,727,290.07 @ WMR 1.17840) |
| **Total** | **409,288,565.39** |

## 2. Sources and roll-forward

Starting point: `inputs/accounting/nav_final_AGEF_20260917.csv` (17-Sep FINAL, post-17-Sep-dealing) —
I-USD-Acc USD 212,688,904.12 / 1,412,337.5520 sh; A-USD-Acc USD 118,420,556.40 / 811,204.9913 sh;
I-EUR-H-Acc USD 79,843,118.27 (EUR 68,021,058.33) / 562,118.4400 sh.

**Non-class-specific items** (`pnl_and_expenses_AGEF_20260918.csv`, allocation=SUB_FUND): dividend income
+184,220.40, WHT -21,488.11, interest +3,318.62, realised securities gain +1,240,118.55, unrealised securities
change -3,912,440.18, unrealised FX translation +402,337.90, depositary -225.18, admin -450.36, audit -180.82,
directors/other -132.88 → **subtotal USD -2,104,922.06**.

**Portfolio-level FX forward** — `fx_forwards_AGEF_20260917_20260918.csv`, contract FWD-P-0818 (tag PORTFOLIO,
USD/JPY): MTM moved USD -31,006.78 → USD 61,687.39, an 18-Sep result of **+USD 92,694.17**. *This contract's
result is not in `pnl_and_expenses_AGEF_20260918.csv` — I sourced it from the FX forwards file and added it to
the sub-fund pool, per Prospectus 5.5 ("Currency transactions that the Investment Manager enters into for the
Sub-Fund as a whole... are attributed to all Classes in proportion to their net assets"). Recommend this line
item be added to the standard P&L extract so it isn't a manual step each valuation day.*

**Pool allocated pro-rata** to each class's 17-Sep closing (post-dealing) net assets, per Prospectus 8.2:
total pool = -2,104,922.06 + 92,694.17 = **USD -2,012,227.89**.

| Class | Ratio (17-Sep NA / total) | Allocated P&L (USD) |
|---|---:|---:|
| I-USD-Acc | 51.7551% | -1,041,430.49 |
| A-USD-Acc | 28.8161% | -579,845.85 |
| I-EUR-H-Acc | 19.4288% | -390,951.55 |

**Class-specific expense accruals** (`class_expense_accruals_AGEF_20260918.csv`) — rates check out against the
Sub-Fund Particulars (mgmt fee 0.75% / 1.50% / 0.75%; taxe d'abonnement 0.01% / 0.05% / 0.01%); I-EUR-H-Acc
alone also carries the Hedging Agent's 0.03% p.a. fee (-65.62), per Prospectus 5.5:

| Class | Mgmt fee | Taxe d'abonnement | Hedging fee | Total |
|---|---:|---:|---:|---:|
| I-USD-Acc | -4,370.32 | -58.27 | — | -4,428.59 |
| A-USD-Acc | -4,866.60 | -162.22 | — | -5,028.82 |
| I-EUR-H-Acc | -1,640.61 | -21.87 | -65.62 | -1,728.10 |

**I-EUR-H-Acc hedge P&L** (attributed solely to this class — see §3): **+USD 359,400.00**.

Putting it together for I-EUR-H-Acc: 79,843,118.27 + (-390,951.55) + (-1,728.10) + 359,400.00 =
**79,809,838.62** USD = **EUR 67,727,290.07** at WMR 18-Sep 1.17840 (Prospectus 8.3), ÷ 562,118.4400 sh =
**EUR 120.4858/sh** → published **EUR 120.49**.

Cross-check: total new sub-fund NA (409,288,565.39) = 410,952,578.79 (prior) - 2,104,922.06 (subfund items)
+ 92,694.17 (portfolio hedge) - 11,185.51 (class expenses) + 359,400.00 (class hedge P&L). Ties out exactly.

## 3. I-EUR-H-Acc hedges, including Friday's roll

Per `fx_forwards_AGEF_20260917_20260918.csv` and `fx_settlement_report_20260918.csv`, all Brackenridge
Bank S.A., all tagged `I-EUR-H-Acc` (confirmed no cross-attribution with the `PORTFOLIO`-tagged FWD-P-0818,
per Procedure v2 §5(i)):

- **FWD-H-0817** (Buy EUR 34m / Sell USD 39,820,800 @ 1.17120) **matured and rolled on 18-Sep**. Settlement:
  received EUR 34,000,000 at the 18-Sep WMR fix (1.17840) = USD 40,065,600; paid away the USD 39,820,800
  contract amount → **realised gain USD 244,800.00**. USD 61,200.00 of that gain was already recognised as
  unrealised P&L at 17-Sep, so the **incremental 18-Sep result is +USD 183,600.00**. The matured EUR receipt
  was then sold spot at the same fix to fund the new contract (0.00 P&L vs the fix, per the settlement report).
- **FWD-H-0918** (roll, Buy EUR 34,000,000 / Sell USD 40,114,900 @ 1.17985, value 20-Oct): new contract, no
  17-Sep valuation. 18-Sep MTM = **+USD 10,200.00**.
- **FWD-H-0901** (Buy EUR 34,500,000 / Sell USD 40,589,250 @ 1.17650, value 19-Oct): MTM moved
  USD -41,400.00 → USD 124,200.00, an 18-Sep change of **+USD 165,600.00**.

**Total 18-Sep I-EUR-H-Acc hedge result: 183,600.00 + 10,200.00 + 165,600.00 = +USD 359,400.00**, booked
solely to I-EUR-H-Acc (Prospectus 5.5). Open notional after the roll: 34,500,000 + 34,000,000 =
**EUR 68,500,000.00**, matching Brackenridge's report.

## 4. Independent hedge-ratio monitoring (per ManCo Risk's instruction)

Per `governance/AAM_share_class_hedging_procedure_v2.md` §2: hedge ratio = open notional ÷ class NAV **after**
the Valuation Day's subscriptions and redemptions. Today's dealing
(`registrar/dealing_summary_AGEF_DD20260918.csv`), all confirmed before the 12:00 cut-off:
I-EUR-H-Acc subscriptions EUR 250,000.00, redemptions EUR -4,500,000.00, **net -EUR 4,250,000.00**.

- Pre-dealing class NAV (from §2 above): EUR 67,727,290.07
- Post-dealing class NAV: 67,727,290.07 - 4,250,000.00 = **EUR 63,477,290.07**
- Open hedge notional: EUR 68,500,000.00
- **Independent hedge ratio: 68,500,000.00 / 63,477,290.07 = 107.91%**
- Tolerance per Procedure v2 §3 / Prospectus 5.4: 95.00%–105.00%
- **Result: BREACH (over-hedged)**

**This does not match Brackenridge's own 18-Sep 13:05 CEST report**, which shows 100.70% "WITHIN 95%–105% —
no action." Their calculation uses the *17-Sep closing NAV* (EUR 68,021,058.33) as the "hedge basis NAV"
because, in their own words, "dealing adjustments for DD 18 Sep 2026 received: none received at run time."
The reason: `dealing_summary_AGEF_DD20260918.csv` shows the I-EUR-H-Acc dealing batch was sent to the Hedging
Agent only on **2026-09-21 08:05 CEST** — three business days late — due to "RTA interface incident
INC-7730." Brackenridge's report is therefore stale and materially understates the true ratio; this is
exactly the scenario ManCo Risk asked us to catch independently rather than relying on the agent's report.

Required notional adjustment to return to 100%: 63,477,290.07 - 68,500,000.00 = **-EUR 5,022,709.93**
(reduce notional by this amount).

**Per Procedure v2 §4:** the Administrator does not amend, book or cancel hedge contracts, and a breach does
not by itself suspend or delay the NAV — so the 18-Sep NAV above stands and can be released at 11:30. The
Administrator's obligation is to (a) notify the Hedging Agent same-day with the post-dealing class NAV and the
required adjustment, and (b) escalate to ManCo Risk — both recorded in `answer.json` → `actions`.

## 5. Actions recorded (see `answer.json`)

1. **Escalate to ManCo Risk** — I-EUR-H-Acc hedge ratio breach (107.91% vs 105% ceiling).
2. **Notify Brackenridge Bank S.A.** (Hedging Agent) — true 18-Sep post-dealing NAV (EUR 63,477,290.07) and
   required notional reduction (EUR 5,022,709.93), per Procedure v2 §4(a).
3. **Request info from the Transfer Agent** — root cause/resolution of RTA interface incident INC-7730 and
   assurance the same-day dealing feed to the Hedging Agent is restored.
4. **Post entries to the accounting system** — the two FX-forward results not in the standard P&L extract:
   I-EUR-H-Acc hedge P&L (+USD 359,400.00) and the portfolio hedge P&L (+USD 92,694.17, allocated pro-rata).
5. **No action on NAV publication** — the breach does not suspend/delay the NAV; 18-Sep NAV can be released
   at 11:30 once you and the Conducting Officer have reviewed this memo.
6. **Notify you (requester)** — this memo and the figures above constitute that notification.

## 6. Open questions / what I need

- Whether Brackenridge will execute a rebalancing trade once it processes the 21-Sep batch, and at what
  rate/date — not knowable from the inputs; needs their confirmation once notified.
- Whether ManCo Risk wants sign-off *before* 11:30 publication given the breach, or is content with
  same-day post-publication escalation as the procedure's text implies.
- Whether the portfolio FX forward (FWD-P-0818) should become a standing line in the P&L extract instead of
  being sourced manually from the FX forwards file each day.
- No data was provided on I-EUR-H-Acc's hedge ratio history; Prospectus 5.4 says over-hedged positions must
  not be carried forward month to month — please confirm whether this is a one-off (caused by INC-7730) or a
  recurring pattern needing a structural fix to the dealing→hedging-agent feed.
- Confirmation from the Transfer Agent on the INC-7730 fix/SLA has not been received within these inputs.

## Files relied on

- `inputs/accounting/nav_final_AGEF_20260917.csv` — 17-Sep FINAL opening balances
- `inputs/accounting/pnl_and_expenses_AGEF_20260918.csv` — sub-fund level 18-Sep P&L/expenses
- `inputs/accounting/class_expense_accruals_AGEF_20260918.csv` — class-specific fee accruals
- `inputs/fx/fx_forwards_AGEF_20260917_20260918.csv` — hedge and portfolio forward contracts and MTM
- `inputs/fx/fx_settlement_report_20260918.csv` — maturity/roll cash settlement detail
- `inputs/fx/hedging_agent_daily_report_20260918.txt` — Brackenridge's own (stale) hedge-ratio report
- `inputs/fx/wmr_rates_20260917_20260918.csv` — WM/Reuters 4pm London fix rates
- `inputs/governance/AAM_share_class_hedging_procedure_v2.md` — hedge monitoring/attribution/breach procedure
- `inputs/prospectus/AGS_prospectus_extract_hedged_classes.md` — hedging, attribution, allocation, rounding rules
- `inputs/registrar/dealing_summary_AGEF_DD20260918.csv` — 18-Sep subscriptions/redemptions and RTA delay note
