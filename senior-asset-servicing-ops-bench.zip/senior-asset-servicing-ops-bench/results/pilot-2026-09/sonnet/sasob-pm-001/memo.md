# Memo: GACP IV — Call #2 (Project Lanternfly) Allocation

**To:** Nadia Kowalczyk, Client Service Director
**From:** Fund Accounting / Client Service Operations
**Date:** 5 October 2026
**Re:** Per-partner allocation for Call #2 (Lanternfly), and two items to resolve with Marcus Feld before the notice goes live

## Bottom line

I can give you a fully worked, LPA-compliant allocation (below), but I would **not** post the notice to the portal as currently briefed. Two things in Marcus's Friday-night email are inconsistent with the LPA as documented in our files, and both need a decision from Granite Arch before we publish:

1. **The requested Due Date (Fri 16 Oct 2026) is not compliant.** The earliest LPA-compliant Due Date, if we post the notice today, is **Tue 20 Oct 2026** — which happens to be the scheduled closing date itself.
2. **Kestrel Ridge (LP-0107) does not currently qualify as an Excused Partner.** Its request is late and lacks the opinion of counsel the LPA requires. Unless the GP gives us something in writing to the contrary, Kestrel Ridge stays in the Lanternfly allocation pro rata.

Everything else in the call — the investment reallocation for Ostrander's valid excuse, the $180,000 of expenses, the fee rate and proration, and the fee offset — checks out and is documented below.

## 1. Sources used

- `inputs/lpa/GACP_IV_LPA_excerpt_capital_calls_fees.md` — Sections 1 (definitions), 3.3, 3.7, 8.1, 8.2, 8.4, 11.2
- `inputs/investor_records/partner_register_GACP_IV_20260930.csv` — commitments, fee status, side letter refs
- `inputs/investor_records/side_letter_terms_summary_GACP_IV.csv` — SL-IV-001 (LP-0103 fee rate), SL-IV-007 (LP-0106 excuse confirmation)
- `inputs/correspondence/2026-09-15_investment_notice_project_lanternfly.txt` — Investment Notice, delivered 15 Sep 2026, 11:02am ET
- `inputs/correspondence/2026-09-24_ostrander_excuse_request.txt` — Ostrander's 3.7(a) request + GP acceptance stamp
- `inputs/correspondence/2026-10-02_kestrel_ridge_email.txt` — Kestrel Ridge's excuse request
- `inputs/correspondence/2026-10-02_GP_CFO_call_request_call2.txt` — Marcus Feld's Call #2 instructions
- `inputs/manager/fee_income_register_GAM_FundIV_2026.csv` — Fee Income for the 8.2 offset
- `inputs/operations/call_history_GACP_IV.csv` — confirms Call 1 had no Management Fee component
- `inputs/operations/holiday_calendar_2026H2.csv` — Business Day determination

## 2. Excuse determinations (LPA 3.7)

**Deadline:** the Investment Notice is dated/delivered 15 Sep 2026 (Tue, before 5:00pm ET → delivered that day per §11.2). The 10th Business Day after that is **29 Sep 2026** (business days 16–18 Sep, 21–25 Sep, 28–29 Sep; no holidays fall in that window).

| Partner | Request date | Opinion of counsel? | Within deadline? | Determination |
|---|---|---|---|---|
| LP-0106 Ostrander | 24 Sep 2026 | Yes — Pruett & Laine LLP, dated 23 Sep 2026, GP GC accepted 28 Sep 2026 | Yes | **Excused** (3.7(a)) |
| LP-0107 Kestrel Ridge | 2 Oct 2026 | No — cites internal Responsible Investment Policy, not a legal/regulatory opinion | No (3 business days late) | **Not excused** under 3.7(a) |

Kestrel Ridge also has no side letter excuse right (no `side_letter_ref` in the register), and there is no written 3.7(b) discretionary excuse or 3.7(e) Administrator notice from the GP in our files, even though Marcus's email says "Kestrel [has] asked to sit out" — a request is not the same as a GP grant. **Absent a written GP decision, the LPA requires Kestrel Ridge to be called for its pro rata share of the Lanternfly investment.** I've built the numbers on that basis and flagged it as an escalation, not silently excused it or silently included it.

## 3. Portfolio Investment — USD 44,000,000.00

Reallocated pro rata to Commitment among the 8 non-excused partners (LPA 3.7(c)), since Ostrander (USD 50,000,000.00 Commitment) is excused. Non-excused aggregate Commitment = USD 550,000,000.00 (USD 600,000,000.00 total less Ostrander). Each non-excused partner's share = Commitment × 8% (44,000,000 / 550,000,000).

This raises each non-excused partner's contribution to 600/550 = **109.1%** of what it would have been without the excuse — within the 115% cap in 3.7(c). (For reference: if Kestrel Ridge were also excused, that ratio would be 600/525 = 114.3% — still compliant, but close enough to the cap to flag if the GP later excuses Kestrel Ridge or calls a larger amount for a future investment.)

## 4. Partnership Expenses — USD 180,000.00

Marcus confirmed these (Q3 admin fee, audit accrual, fund counsel) are "none of it deal-related." Per LPA 3.3(b)/8.4, non-deal-specific Partnership Expenses are borne by **all 9 partners** pro rata to full Commitment/$600,000,000 — including the GP and Ostrander (LPA 3.7(d) only shifts *investment-specific* expenses off an excused partner; these aren't investment-specific).

## 5. Management Fee — USD 1,983,000.00 gross / USD 396,600.00 offset / USD 1,586,400.00 net

- **Fee-paying partners:** all LPs (LP-0101–LP-0108); GP-0100 is FEE_EXEMPT. Excuse status is irrelevant here — LPA 3.7(d) keeps an excused partner on the hook for its Management Fee.
- **Rate:** 1.75%/year standard (LPA 8.1(a)), except **LP-0103 at 1.50%/year** per side letter SL-IV-001 (a size-based term for Commitments ≥ $150,000,000; LP-0103's $150,000,000 Commitment meets that threshold exactly). That term is explicitly non-MFN-electable, so it doesn't extend to anyone else.
- **Fee Commencement Date:** the date the Partnership first acquires a Portfolio Investment. This is the Partnership's first investment (Call 1 was org expenses only), so Fee Commencement Date = **Lanternfly closing, 20 Oct 2026**.
- **Proration:** first installment covers 20 Oct–31 Dec 2026 inclusive = **73 days**; 73/365 = exactly 0.20 of the annual fee (LPA 8.1(c)).
- **Offset (LPA 8.2):** the installment is reduced by 80% of Fee Income *received on or before the Drawdown Notice date* and not already applied to an earlier installment (Call 1 had none). From `fee_income_register_GAM_FundIV_2026.csv`:
  - **FI-IV-0001, Osprey break-up fee, USD 495,750.00, RECEIVED 14 Aug 2026** → counts. 80% × 495,750 = **USD 396,600.00** offset.
  - FI-IV-0002, Osprey expense reimbursement (USD 118,400.00) — excluded by definition (reimbursement of out-of-pocket expenses is not Fee Income).
  - **FI-IV-0003, Lanternfly transaction fee, USD 1,100,000.00 — status EXPECTED, payable at the 20 Oct 2026 closing.** Marcus's email asks us to net "the ... Lanternfly closing fee," but it has **not been received as of the 5 Oct 2026 notice date** (it's paid at closing, which is after the notice), so LPA 8.2(a) does not let it reduce this installment. It will offset a later installment once actually received.
  - FI-IV-0004, monitoring fee (USD 300,000.00) — EXPECTED, first payment 15 Jan 2027 — same treatment, excluded from this installment.
  - The offset happens to work out to a flat 20% of each partner's gross fee (396,600/1,983,000 = 0.20), allocated pro rata per LPA 8.2(b).

**If Marcus wants the Lanternfly transaction fee reflected in this call's offset, that isn't available under the LPA until it is actually received — which per the engagement letter is at closing (20 Oct), after this notice goes out. That's worth telling him now, so he isn't surprised the net fee is higher than he may be expecting.**

## 6. Due Date (LPA 3.3(a) / 11.2)

LPA 3.3(a): Due Date ≥ 10th Business Day after the Drawdown Notice is delivered. "Business Day" excludes Saturdays, Sundays, and any day the **Federal Reserve Bank of New York is closed** (LPA Art. 1) — note this is a stricter test than "NYSE open."

If we post the notice on the portal today, **Mon 5 Oct 2026**, before 5:00pm ET, it's delivered that day (§11.2). Counting forward:
- Business days: 6, 7, 8, 9 Oct (4) → weekend → **12 Oct (Columbus Day) is NOT a Business Day** (FRBNY closed, even though NYSE is open) → 13, 14, 15, 16 Oct (business days 5–8) → weekend → 19 Oct (9) → **20 Oct (10th Business Day)**.

**Earliest compliant Due Date = 20 Oct 2026.** The requested Due Date of **16 Oct 2026 is only the 8th Business Day and is not compliant** — it's 4 business days too early, largely because Columbus Day doesn't count as a Business Day under the LPA's FRBNY-closure test even though markets are open that day.

Note this actually lines up reasonably well operationally: 20 Oct is the scheduled closing date, so funds would be due the same day they're needed rather than four days earlier as Marcus hoped for buffer. But it does mean he won't have the cushion before closing that he asked for.

One more timing sensitivity: if the notice isn't actually posted until after 5:00pm ET today, §11.2 treats it as delivered the next Business Day (6 Oct), which would push the 10th-Business-Day Due Date out even further.

## 7. Call total and per-partner allocation

**Total call amount: USD 45,766,400.00** (Investment 44,000,000.00 + Expenses 180,000.00 + Net Management Fee 1,586,400.00). See `out/answer.json → figures.partner_allocations` for the full per-partner, per-component breakdown (all 9 partners, rounded to the cent, reconciled to the totals above).

Headline figures:

| Partner | Investment | Expenses | MF Gross | MF Offset | MF Net | **Total** |
|---|---:|---:|---:|---:|---:|---:|
| GP-0100 | 960,000.00 | 3,600.00 | 0.00 | 0.00 | 0.00 | **963,600.00** |
| LP-0101 | 8,000,000.00 | 30,000.00 | 350,000.00 | 70,000.00 | 280,000.00 | **8,310,000.00** |
| LP-0102 | 7,200,000.00 | 27,000.00 | 315,000.00 | 63,000.00 | 252,000.00 | **7,479,000.00** |
| LP-0103 | 12,000,000.00 | 45,000.00 | 450,000.00 | 90,000.00 | 360,000.00 | **12,405,000.00** |
| LP-0104 | 6,000,000.00 | 22,500.00 | 262,500.00 | 52,500.00 | 210,000.00 | **6,232,500.00** |
| LP-0105 | 4,800,000.00 | 18,000.00 | 210,000.00 | 42,000.00 | 168,000.00 | **4,986,000.00** |
| LP-0106 (excused) | 0.00 | 15,000.00 | 175,000.00 | 35,000.00 | 140,000.00 | **155,000.00** |
| LP-0107 (not excused — see above) | 2,000,000.00 | 7,500.00 | 87,500.00 | 17,500.00 | 70,000.00 | **2,077,500.00** |
| LP-0108 | 3,040,000.00 | 11,400.00 | 133,000.00 | 26,600.00 | 106,400.00 | **3,157,800.00** |
| **Total** | **44,000,000.00** | **180,000.00** | **1,983,000.00** | **396,600.00** | **1,586,400.00** | **45,766,400.00** |

All unfunded-commitment checks (LPA 3.3(c)) pass comfortably — partners have only funded Call 1's small organizational-expense draws to date.

## 8. What I need from Granite Arch before we go live

1. **Kestrel Ridge (LP-0107):** written confirmation of whether the GP is exercising its 3.7(b) discretion to excuse it, plus the 3.7(e) notice to us as Administrator. Until then, the notice above includes Kestrel Ridge pro rata.
2. **Due Date:** confirmation to proceed with 20 Oct 2026 (the only LPA-compliant date if we post today), or direction to delay the notice so a later Due Date works instead.
3. Nice-to-have, not a blocker: confirmation no additional Fee Income was received between the register extract and today that should be added to the offset.

I'd flag both open items to Marcus this morning, as you suggested — happy to send a first draft to him once you've reviewed the numbers above. Everything else in the call is ready to post as soon as those two are resolved.

## 9. Assumptions

- The notice is delivered on the portal today, 5 Oct 2026, before 5:00pm ET (per Marcus's request to post today) — see §6 for the sensitivity if it's posted later.
- "Two LPs sitting out" in Nadia's email = Ostrander and Kestrel Ridge per Marcus's email; treated per LPA as above (one excused, one not, absent further GP input).
- The $180,000 of Partnership Expenses is not Lanternfly-specific, per Marcus's explicit statement.
- No Fee Income was received between the fee_income_register extract date and today beyond what's shown in the register.
- The subscription facility is not used for this call (per Marcus's email) — no action needed on that point.
