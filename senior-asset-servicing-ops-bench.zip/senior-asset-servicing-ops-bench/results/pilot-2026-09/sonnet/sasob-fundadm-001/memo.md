# Memo: BFVF 8/31/2026 §851(b)(3) Asset Diversification Review

**To:** Elaine Marsh, Treasurer, Brightwater Series Trust
**From:** Oakhurst Fund Administration, Fund Tax
**Re:** BFVF quarter-end (8/31/2026) RIC diversification test — review of Stella Albright's first cut, for the Tuesday board compliance certificate
**Date:** 2026-09-19

## Bottom line

BFVF **fails both parts** of the IRC §851(b)(3) asset diversification test at 8/31/2026. This
overturns Stella's 9/16 first cut, which showed a clean pass on both tests (68.66% qualifying vs.
the 50% floor; 15.14% largest single-issuer exposure vs. the 25% ceiling). Per policy §7.1, this
difference from the first cut is escalated the same day to the Director of Fund Tax and to you.

The board compliance certificate for BFVF must be **held** (policy §7.3) — it cannot state BFVF met
§851(b)(3) for the quarter — until the cure below is completed and Fund Tax re-tests.

The good news: both discrepancies are attributable to securities acquired during the quarter, so
BFVF retains its statutory cure right (IRC §851(d)(1)/policy §6.1). A single disposal of at least
**$9,435,416.57** of Stonefield Aggregates and/or Harrowgate Materials common stock, trade date on
or before **2026-09-30**, with proceeds held in cash, cures both tests simultaneously.

## What went wrong in the first cut, and why

All figures below are recomputed from `inputs/accounting/BFVF_statement_of_assets_and_liabilities_20260831.csv`
(SOAL), `inputs/accounting/BFVF_portfolio_valuation_20260831.csv` (positions), `inputs/reference/issuer_master_extract_20260831.csv`
(issuer classification), `inputs/trades/repo_confirmations_20260831.txt` (repo collateral), and
`inputs/trades/BFVF_trade_blotter_20260601_20260831.csv` (quarter's trades), against
`inputs/policies/BST_RIC_qualification_compliance_policy.md` ("the policy"). The full issuer-by-issuer
breakdown is in `out/answer.json` → `findings`.

1. **Wrong denominator.** Policy §3.1 defines Total Assets as gross assets *before* deducting
   liabilities. The SOAL shows `TOTAL ASSETS = 634,087,613.72` and `NET ASSETS = 581,160,485.34`
   (the difference is mostly the $45mm line-of-credit borrowing). The first cut
   (`inputs/tax/BFVF_diversification_firstcut_20260831.csv`, line 5 note: "Denominator = net assets
   581160485.34") used Net Assets. This alone moves every percentage in the test.

2. **Republic of Castellan bond (ISS-0107, position P007, $38,501,600) misclassified as a Government
   security.** Policy §3.3 is explicit: only U.S. Treasury/agency/GSE obligations are Government
   securities; "obligations of non-U.S. governments... are not Government securities; each such
   obligor is a separate issuer." Castellan is a non-U.S. sovereign (issuer master: `NON_US_SOVEREIGN`).
   Investment grade, USD-denomination and SEC registration (cited in Dev Kapoor's 9/17 email and the
   issuer master notes) do not change this — the policy's Government-securities test tracks the 1940
   Act §2(a)(16) definition, not credit quality or registration status. At 6.07% of Total Assets, this
   single position exceeds the 5% limit and is **entirely non-qualifying** under the all-or-nothing
   rule (policy §4.2). This is a new position, bought 2026-08-12 (`T-260812-002`), funded from an MMF
   redemption.

3. **Pemberton Securities repo (ISS-0233, P005, $22,000,000) misclassified as a Government security,
   and not aggregated with Pemberton commercial paper.** Per the repo confirmation
   (`repo_confirmations_20260831.txt`), the Fallowmere repo (P004, $20,000,000) is tri-party,
   102%-margined, and collateralized solely by U.S. Treasury securities — this **is** "collateralized
   fully" by Government securities under Rule 5b-3/policy §3.4, so P004 correctly counts as a
   Government security. The Pemberton repo (P005), by contrast, is collateralized by a schedule of
   corporate bonds (investment grade and high yield) — not cash or Government securities — so under
   policy §3.4 it is **not** collateralized fully and must be treated as a security of the repo
   counterparty (Pemberton Securities LLC) and aggregated with all of that counterparty's other
   securities per policy §3.6, i.e. with the Pemberton CP position (P006, $12,030,425, bought new on
   2026-08-28 per `T-260828-003`). Aggregate = $34,030,425 = 5.37% of Total Assets, over the 5% limit
   — entirely non-qualifying.

4. **Ormsby Logistics (ISS-0413) tested per-position instead of per-issuer.** The first cut's line 4
   ("Other securities <=5% (per position)") tested the Ormsby common stock (P013, $20,979,000) and the
   Ormsby 5.25% notes (P014, $13,500,300) separately, each individually under 5%. Policy §3.6 requires
   aggregating *all* securities of the same issuer — common, preferred, debt, CP, qualifying repos —
   for every limit in the policy. Aggregated, Ormsby is $34,479,300 = 5.44% of Total Assets, over the
   5% limit and entirely non-qualifying. No Ormsby trades occurred this quarter (see open question
   below on whether this predates 8/31).

5. **QPTP 10% voting limit not applied to Tallis Midstream (ISS-0414).** Tallis is a qualified
   publicly traded partnership; under IRC §851(c)(5)/policy §4.3 its common units are treated as
   voting securities for the 10% test. The Fund holds 1,500,800 of 13,400,000 outstanding units =
   **11.20%**, over the 10% limit, even though the position's value (1.36% of Total Assets) is well
   under 5%. Under the all-or-nothing rule (§4.2) this disqualifies the entire position. (Corbeck
   Pipeline, the other QPTP holding, is fine at 1.10% of units / 1.77% of Total Assets.)

6. **Harrowgate Materials' move into "controlled" status was not re-tested for controlled-group
   aggregation with Stonefield.** At 5/31/2026 (`inputs/tax/BFVF_diversification_test_20260531_final.csv`),
   Harrowgate was 17.90% of voting shares — not controlled (policy §5.2 threshold is 20%). During the
   quarter the Fund bought 1,828,500 Harrowgate shares in three tranches (`T-260714-003`,
   `T-260715-006`, `T-260716-001`, comment: "PM conviction add; post-trade issuer check <25% OK"),
   taking the position to 6,572,000 / 26,500,000 shares = **24.80%** — now controlled. Stonefield
   Aggregates (ISS-0410) has been controlled at 23.60% of voting shares since at least last quarter
   and shares Harrowgate's `sub_industry` classification ("Construction Materials - Aggregates") in the
   issuer master. Per policy §5.1(ii)/§5.3, two or more issuers the Fund controls in the same
   sub-industry are aggregated for the 25% test unless Tax Counsel has concluded otherwise in writing
   before the testing date — no such letter is in the file, so the presumption applies. Combined value:
   $87,976,080 + $79,981,240 = **$167,957,320 = 26.49% of Total Assets**, over the 25% ceiling. The
   "post-trade issuer check <25% OK" note on the July trade blotter appears to have tested Harrowgate
   alone (12.61%, which is indeed under 25%) without checking for controlled-group aggregation with
   Stonefield — that is the immediate root cause of the 25% test failure.

## The two test results (corrected)

**50% test — FAIL.** Qualifying assets = $314,408,640.39 / Total Assets $634,087,613.72 =
**49.58%** (need ≥50%). Qualifying = cash & receivables ($11,483,825.89) + Government securities
($78,035,662.50: Treasuries P001/P002, FHLB P003, fully-collateralized Fallowmere repo P004) +
other-RIC securities ($43,900,000: Brightwater Govt MMF P008, Arden Street ETF P009) + other
securities within the 5%/10% per-issuer limits ($180,989,152: Corbeck, Norbeck preferred, Pellham,
**Kinsale Robotics**, Aldermoor, Brixton, Cadell, Dunmore, Everly, Fenwick, Galloway).

> Note: **Kinsale Robotics (ISS-0418)** was excluded by the first cut ("Kinsale 5.33% excluded")
> because 5.33% was computed against Net Assets. Against the correct Total Assets denominator it is
> **4.89%** — under 5% — so it does qualify. This is captured in the figures above; it partially
> offsets, but does not cure, the other errors identified.

Non-qualifying: Castellan ($38,501,600), Pemberton repo+CP ($34,030,425), Stonefield ($87,976,080),
Harrowgate ($79,981,240), Quillon Systems ($35,997,840, 5.68% of Total Assets — bought 40,000 more
shares 2026-08-20, `T-260820-005`), Ormsby ($34,479,300), Tallis ($8,599,584), plus prepaid
expenses/other assets ($112,904.33, never qualifying per policy §3.2).

**25% test — FAIL.** Binding exposure is the Stonefield/Harrowgate controlled group at **26.49%**
of Total Assets (need ≤25%). No single issuer alone exceeds 25% (largest is Stonefield at 13.87%),
and the QPTP aggregate (Tallis + Corbeck = 3.12%) is comfortably within the QPTP limit.

## Acquisition attribution and cure eligibility (policy §6)

Both failures are attributable, wholly or partly, to securities acquired during the June–August
quarter (policy §6.1/§6.2 — the Fund's practice is conservative: if it acquired any security of a
contributing issuer during the quarter, the discrepancy is treated as acquisition-attributable):

- The **25% test** breach was created this quarter — Harrowgate's July purchases pushed it from
  17.90% to 24.80% of voting shares, triggering controlled-group aggregation with the already-controlled
  Stonefield. Stonefield itself had no trades this quarter, but under §6.1 a discrepancy need only be
  "wholly or **partly**" the result of an acquisition, and the Harrowgate purchases satisfy that.
- The **50% test** breach involves several issuers with quarter acquisitions (Castellan — new position
  8/12; Pemberton CP — new issue 8/28; Harrowgate — add-on 7/14-16; Quillon — add-on 8/20). Ormsby had
  no trades this quarter, but since the overall 50% shortfall is independently and sufficiently
  explained by the other issuers' quarter acquisitions, the whole 50% discrepancy is treated as
  acquisition-attributable.

This means BFVF does **not** lose RIC qualification for this discrepancy provided it is eliminated
by trade date on or before the **30th calendar day after quarter-end: 2026-09-30** (policy §6.3). De
minimis/reasonable-cause relief under §851(d)(2)/policy §6.5 is a last resort requiring Tax Counsel
and you, not a substitute for a timely cure, and we are not recommending it as a primary path.

## Minimum cure (policy §6.4 — at 8/31 values, proceeds held in cash, Total Assets unchanged)

- **25% test:** need combined Stonefield + Harrowgate ≤ 25.00% × $634,087,613.72 = $158,521,903.43.
  Current combined value $167,957,320.00 → **minimum disposal $9,435,416.57**, from Stonefield and/or
  Harrowgate (adviser's choice under §6.4; either name, or a split, works because the limit is on the
  combined value, not on breaking either name's controlled status).
- **50% test:** need qualifying assets ≥ 50.00% × $634,087,613.72 = $317,043,806.86. Current
  qualifying $314,408,640.39 → shortfall of only $2,635,166.47. Because the disposal proceeds from
  the 25% cure move into cash (a qualifying asset) while leaving Total Assets unchanged, the
  **same $9,435,416.57 sale cures both tests**: post-cure qualifying = $323,844,056.96 = **51.07%**
  (test passes), and the controlled-group aggregate falls to exactly **25.00%** (test passes, "not more
  than 25%").
- **Reported minimum cure disposal value: $9,435,416.57.** We recommend the adviser sell somewhat
  more than the bare minimum (e.g., 25-50% buffer, roughly $12-15mm) given (a) price movement in
  Stonefield/Harrowgate between now and the 9/30 trade date, since the minimum is fixed at 8/31
  values but a later trade will execute at a different price, and (b) the ~$2.6mm-thin margin on the
  50% test on its own.

## On Dev Kapoor's 9/17 note

Two of the points in Dev's email do not change the analysis under the Trust's policy:

- **"Stonefield and Harrowgate are two completely separate companies... nowhere near 25%."** Separate
  management and geography are not the test. Policy §5.1(ii)/§5.3 aggregates issuers the **Fund
  controls** (≥20% of voting shares — both now qualify) that share the same `sub_industry`
  classification in the issuer master ("Construction Materials - Aggregates" for both), unless Tax
  Counsel has concluded in writing, before the testing date, that they are not in the same or similar
  trade or business. No such Tax Counsel letter is in the file. The July Schedule 13D filing on
  Harrowgate is itself consistent with — not contrary to — a control position.
- **"Castellan... is a government bond."** Under the Trust's policy (§3.3, tracking 1940 Act
  §2(a)(16)), "Government securities" means U.S. Treasury and U.S. agency/GSE obligations only.
  Investment grade, USD denomination and SEC registration do not bring a non-U.S. sovereign bond
  within that definition; Castellan is a separate, non-qualifying issuer here.
- Dev also states "no plans to trade either name before quarter-end reporting." The cure trade must
  have a trade date on or before 2026-09-30 (about two weeks after "reporting"); we recommend Fund
  Treasury confirm directly with the adviser's CCO that a compliant trade will be placed in time,
  since the deadline is not one Oakhurst can extend.

## Calls to make

1. **Fund Treasurer (you) → Adviser CCO and Dev Kapoor:** Confirm receipt of the minimum cure figure
   ($9,435,416.57, either name or a split) and the 2026-09-30 deadline; ask for their intended trade
   date and size so Fund Tax can re-test promptly after settlement. Let them know that selling
   Stonefield (rather than Harrowgate) fully satisfies the same dollar minimum, if they prefer not to
   reduce the Harrowgate stake.
2. **Fund Treasurer → Board / certificate process:** Hold the BFVF line of the compliance certificate;
   do not sign it as a clean pass Monday. Consider informing the Board that a cure is in process, if
   your certification process allows a qualified/pending disclosure — this is a governance judgment
   for you and the CCO, not one Fund Tax can make.
3. **Fund Treasurer → Tax Counsel:** Ask Tax Counsel to confirm, in writing, whether they agree with
   the same-sub-industry controlled-group treatment of Stonefield/Harrowgate, ideally before the cure
   trade is placed, since a contrary opinion (if issued before the testing date — which has already
   passed, so this would need discussion with Tax Counsel about timing) could change the 25% test
   conclusion.

## Open items / data we don't have

See `answer.json` → `open_questions` for the complete list, including: no Tax Counsel letter on the
Stonefield/Harrowgate trade-or-business question; no position-level 5/31 workpaper to confirm whether
the Ormsby aggregation issue predates this quarter; and no confirmation yet from the adviser that the
cure trade will be placed by 2026-09-30.

---
*Prepared by Oakhurst Fund Administration, Fund Tax, from the files in the shared review folder as of
2026-09-19. All figures are recomputed from source data; none are carried forward from the first cut
without independent verification.*
