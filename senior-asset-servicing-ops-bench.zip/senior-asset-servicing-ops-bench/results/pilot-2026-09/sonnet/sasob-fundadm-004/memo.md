# Senior validation — BGOF August Form N-PORT Part C

**To:** Graham Sato, Manager, Regulatory Reporting — Oakhurst Fund Administration
**From:** Senior Reviewer, Regulatory Reporting
**Re:** BGOF N-PORT for August 2026 — do not file today; 9 line-level corrections and two new liquidity events

## Bottom line

Please **hold the EDGAR submission**. The draft has nine field errors across six lines (details below), and once
corrected, the fund-level liquidity numbers the auto-checks relied on flip:

| Measure | As drafted | Corrected | Limit | Breach? |
|---|---|---|---|---|
| Illiquid investments (assets) | $36,601,000.00 / 9.95% | **$57,505,000.00 / 15.63%** | ≤15% (Rule 22e-4(b)(1)(iv)) | **Yes** |
| HLIM measure | not computed in draft | **24.59%** | ≥25% (BGOF HLIM) | **Yes** |

Both breaches were identified only during this validation ("after the fact"), which itself triggers reporting
obligations under BGOF's Liquidity Risk Management Program (LRMP). This is not a "fix and file" situation — two
of the corrections are new liquidity-classification exceptions that Oakhurst cannot confirm on its own authority
(NPORT Prep Procedures §3.2) and must go to the Program Administrator first.

Net assets used throughout: **$367,956,922.39** (`inputs/accounting/BGOF_statement_of_net_assets_20260831.csv`,
Total assets $373,516,582.94 − Total liabilities $5,559,660.55; the "Investments at value" line on that statement,
$348,613,282.39, ties exactly to the sum of `market_value_usd` in
`inputs/accounting/BGOF_holdings_valuation_20260831.csv`, confirming the accounting file — not the draft — is the
clean source of truth for value).

## 1. Line-level corrections (`out/answer.json` → `findings`)

Method: every Part C field was re-derived from the source of truth named in
`inputs/policies/BST_Form_NPORT_preparation_procedures.md` §2 and cross-checked programmatically against the draft.

| Line | Field | Draft | Corrected | Why |
|---|---|---|---|---|
| L03 | value_usd | 11,186,000.00 | **12,399,681.00** | Draft used the untranslated EUR value (140,000 sh × EUR79.90); accounting shows this ×fx 1.1085 = USD 12,399,681.00 (`BGOF_holdings_valuation_20260831.csv`). |
| L03 | pct_net_assets | 3.0400 | **3.3699** | Recomputed from corrected value ÷ net assets × 100, 4 dp, per procedures §2. |
| L07 | is_restricted_security | N | **Y** | Carrow Networks bond is Rule 144A (`rule_144a_eligible=Y, restricted_security=Y` in security master). Compare L05, another 144A bond, correctly flagged Y. |
| L09 | issuer_cat | CORP | **UST** | Issuer is the U.S. Treasury; security master `issuer_type=U.S. Treasury` maps to code UST, not CORP. |
| L11 | asset_cat | EC | **STIV** | Holding is Brightwater Government Money Market Fund (a cash-management vehicle per security master `instrument_type`), not common equity. |
| L14 | liquidity_classification | Less Liquid | **Illiquid** | Private placement, not 144A-eligible, no secondary market (security master: `rule_144a_eligible=N, private_placement=Y`, notes "no public market"). LRMP §3.5 makes this Illiquid unless the LRM Committee approved otherwise in writing — no such approval is in the override log. Vendor's "Less Liquid" is an explicit default bucket ("No market data; default bucket for unlisted preferred"), not a real liquidity measurement. **New exception — needs Program Administrator confirmation.** |
| L16 | liquidity_classification | Highly Liquid | **Illiquid** | Norcastle's primary (and only) listing has been halted since 2026-08-27 (`exchange_notice_Norcastle_trading_halt_20260827.txt`, still halted 9/17). The vendor's "Highly Liquid" bucket is built on ADV data through 2026-08-26 — pre-halt and stale. LRMP §3.4 mandates Illiquid for the whole halt period; §2.2 lets the Program Administrator override a stale vendor input. **New exception — needs Program Administrator confirmation.** |
| L19 | liquidity_classification | Illiquid | **Less Liquid** | The LRM Committee already rejected the PM's request to reclassify this loan Illiquid on 2026-08-20 (`BGOF_liquidity_override_log_2026.csv`, OVR-2026-019) and directed reversion to the vendor bucket (Less Liquid) per LRMP §3.7 (sellable in ≤7 days, settles >7 days). This is an already-confirmed correction, not a new exception — safe to apply directly. |
| L22 | fair_value_level | 1 | **2** | Pembury Retail plc was fair-valued via the systematic fair-value factor at month-end, same as L03/L04 (which the draft correctly shows at Level 2); valuation designee memo item 5 groups L03/L04/L22 together as Level 2. |

All other fields on all 25 lines (balance, LEI, remaining asset/issuer codes, country, remaining restricted flags,
remaining fair value levels) were checked line-by-line against the accounting file and security master and tie out.

## 2. Fund-level liquidity numbers I'd stand behind (as of 2026-08-31)

**Illiquid investments that are assets** (corrected classifications: L14, L15, L16, L17):

| Line | Security | Value (USD) |
|---|---|---|
| L14 | Tessaly Biosciences Series C preferred | 21,804,000.00 |
| L15 | Kilnworth Holdings term loan | 17,901,000.00 |
| L16 | Norcastle Mining common | 9,600,000.00 |
| L17 | Amberlane Therapeutics PIPE common | 8,200,000.00 |
| **Total** | | **57,505,000.00** |

57,505,000.00 ÷ 367,956,922.39 = **15.63%** of net assets, above the 15% limit ($55,193,538.36). The draft's implied
9.95% ($36,601,000.00 — L15+L17+the mis-classified L19) is what let the "under 10%" auto-check pass; it's wrong on
two counts (L16 should be in the bucket, L19 should not).

**HLIM measure** (LRMP §5.2: highly liquid investments incl. cash, less highly liquid assets posted as margin for
derivatives classified Moderately/Less Liquid/Illiquid):

- Highly liquid investments/cash before the margin netting: L01 12,099,920.00 + L02 10,400,000.00 + L03
  12,399,681.00 (corrected) + L04 6,200,146.16 + L09 14,499,852.50 + L11 9,000,000.00 + L22 8,799,617.73 + L24
  (FX forward) 181,350.00 + cash at Fallowmere DDA 16,900,000.00 + cash at Kestrow Futures LLC (FCM margin)
  4,600,000.00 = **95,080,567.39** (L16 is excluded — it's now Illiquid).
- Less: the full $4,600,000.00 cash Kestrow Futures LLC holds as initial margin for the equity index futures
  (L23), which is classified Moderately Liquid per LRMP §3.8 — §5.2 requires subtracting the *entire* amount held
  by the FCM, including the $388,000 excess over requirement, not just the required margin
  (`Kestrow_Futures_statement_BGOF_20260831.txt`).
- Net highly liquid = 95,080,567.39 − 4,600,000.00 = **90,480,567.39**.
- 90,480,567.39 ÷ 367,956,922.39 = **24.59%**, below BGOF's 25% HLIM.

Assumption flagged in open questions: I included the FX forward's $181,350 fair value in the highly-liquid
numerator. Excluding it would give 24.54% — the shortfall conclusion is unchanged either way.

## 3. What needs to happen before Monday, and who needs to know

1. **Program Administrator** — confirm the two new classification exceptions (L14, L16) and the L19 reversion.
   Oakhurst does not classify investments and cannot finalize the draft without this (NPORT Prep Procedures §3.2).
2. **Board** — LRMP §4.3 (after-the-fact identification of the >15% illiquid condition): Program Administrator
   must report to the Board and cause **Form N-RN Part B** to be filed no later than one business day after
   identification. I'm treating identification as today, Friday 2026-09-18, so the deadline is **Monday
   2026-09-21**. Form N-RN Part C follows once illiquid returns to ≤15%.
3. **LRM Committee** — the HLIM shortfall (24.59% < 25%) defaults to a report at the Committee's next regular
   meeting (2026-10-14, per LRMP §5.3), *unless* the shortfall has lasted more than 7 consecutive calendar days,
   in which case the 1-business-day Board/Form N-RN Part D track applies instead. I only have the 8/31 snapshot —
   please pull daily data to determine duration.
4. **Fund Treasurer** — sign-off is required before filing (NPORT Prep Procedures §3.4); please withhold it until
   1–3 are resolved.
5. **Pending trade** — `inputs/trades/BGOF_pending_commitments_20260918.csv` shows a signed $6,000,000 Tessaly
   Series D subscription (CMT-2026-044) funding 2026-09-25. It is itself a non-144A private placement (Illiquid
   under §3.5). The 9/15 pre-trade compliance clearance used a daily liquidity report showing illiquid at 9.9% —
   which, on these corrected classifications, understates the true position. Rule 22e-4(b)(1)(iv) bars acquiring
   *any* illiquid investment while the Fund is above 15%. **Recommend holding this funding** until the Program
   Administrator confirms the Fund's then-current illiquid % is at or below 15%.
6. **CCO** — should be aware of both breaches and the held trade; this liquidity information is non-public per
   LRMP §6.2.
7. **Reference data** — the L07/L09/L11 errors above look like mapping bugs (144A restricted flag, Treasury
   issuer-type code, money-market-fund asset-type code) rather than judgment calls; worth a fix in the N-PORT
   build so they don't recur.

Regulatory filing deadline for this report (fiscal Q3 = Jun/Jul/Aug, public month): **60 days after 2026-08-31 =
2026-10-30**. There is no need to rush this out today — better to get the classification confirmations and N-RN
filings right first.

## 4. Assumptions and open items

See `open_questions` in `out/answer.json` for the full list, in particular:
- Whether a written LRM Committee determination already exists for L14 and/or L16 that wasn't in the override log
  I was given (which only had entries for L15, L17, L19, L12).
- Today's (2026-09-18) illiquid % and HLIM measure, as distinct from the 8/31 month-end figures used for this
  N-PORT — needed before the Tessaly funding can be cleared.
- HLIM shortfall duration from daily monitoring data (not in the inputs provided).
- Treatment of the L24 FX forward's value in the HLIM numerator (does not change the shortfall conclusion).

Files relied on: all files under `inputs/nport/`, `inputs/accounting/`, `inputs/reference/`, `inputs/liquidity/`,
`inputs/valuation/`, `inputs/notices/`, `inputs/derivatives/`, `inputs/trades/`, `inputs/correspondence/`, and
`inputs/policies/`.
