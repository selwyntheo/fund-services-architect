# GAOF II — 30 September 2026 Second Closing: Equalization Numbers

**To:** Priya Sethi, Head of Investor Services
**From:** Investor Services / Fund Accounting (Halcyon Private Fund Services)
**Date:** 18 September 2026 (data as of close of business 17 September 2026)
**Re:** Granite Arch Opportunities Fund II, L.P. ("GAOF II") — equalization for the 30-Sep-2026 second closing

This memo works the numbers from the GAOF II LPA excerpt, not from the Fund I precedent Tom Brandt sent
over. Where the two diverge I've said so below and used the LPA. All figures also live in
`out/answer.json`; this memo explains how each number was built, cites the source rows, and lists what
we still need.

---

## 1. Closing population (30 Sep 2026)

Source: `inputs/investor_records/partner_register_GAOF_II_20260917.csv`,
`inputs/investor_records/second_closing_checklist_20260917.csv`,
`inputs/correspondence/2026-09-16_blackwood_second_close_update.txt`.

| Partner | Commitment | Status | In 30-Sep closing? |
|---|---|---|---|
| LP-0206 Tamsin Bay Insurance | $50,000,000 | Docs complete, KYC cleared 04-Sep, side letter SL-OF2-004 executed 11-Sep, GP countersignature ready, wires call-back verified 14-Sep | **Yes** |
| LP-0207 Ostrander County Firefighters' | $35,000,000 | Docs complete, KYC cleared 09-Sep, no side letter, GP countersignature ready, board minute received | **Yes** |
| LP-0208 Sable Point Private Markets Access Fund | $40,000,000 | AML/KYC **open** (UBO cert outstanding), side letter **draft**, GP countersignature **not signed** | **No — deferred** |

**Flag on the closing population itself:** the partner register (dated 17-Sep, i.e. *after* Owen
Blackwood's 16-Sep email) still shows LP-0208's admission as `SECOND 2026-09-30` and status
`SUBSCRIPTION RECEIVED`. Owen's email is explicit that Sable Point is moving to a third closing
(pencilled 15-Dec-2026) because its IC approval slipped and UBO certification is outstanding, and he
asked us to "leave the record alone for now" pending a change form. The second-closing checklist
(also dated 16-Sep) already agrees with Owen and shows `target_closing 2026-12-15` with the comment
"Moved to third closing per O. Blackwood email 2026-09-16." **We have treated LP-0208 as excluded from
the 30-Sep closing** on the strength of the checklist and the email, not the stale register field, and
have not touched the register. Please chase the change form so the register gets corrected (action:
`request_info` → `gp_investor_relations`).

Total commitments after the 30-Sep closing (GP + 7 LPs, excluding LP-0208): **$340,000,000.00**.

---

## 2. Where the GP's requested approach (Fund I) doesn't match the GAOF II LPA

Tom's 17-Sep email describes three mechanics from Fund I. All three differ from GAOF II LPA §3.4:

**(a) Equalization base.** Tom: each new LP pays a flat 20.55% of *its own* commitment — the
cumulative % of commitment first-close LPs have funded to date for investments + partnership expenses.
We verified that number independently: $52,402,500 aggregate non-fee contributions (see §3 below) ÷
$255,000,000 aggregate existing commitment = 20.5500%, matching Tom's figure exactly.

GAOF II LPA §3.4(a), however, defines the Equalization Contribution as the Subsequent Partner's
**Commitment Percentage "determined after giving effect to that Subsequent Closing"** — i.e., measured
against the *post-closing* aggregate commitment, which here includes **both** incoming LPs together
($340,000,000), not the $255,000,000 base implicit in Tom's own-commitment ratio — multiplied by the
$52,402,500 aggregate non-fee contributions. Because two LPs are admitted simultaneously, the LPA's
denominator is larger, so the LPA amount is materially *lower* than the Fund I-style number for each
incoming LP:

| Partner | LPA (§3.4(a)) | Fund I-style (20.55% × own commitment) | Difference |
|---|---:|---:|---:|
| LP-0206 | $7,706,250.00 | $10,275,000.00 | LPA is $2,568,750.00 lower |
| LP-0207 | $5,394,375.00 | $7,192,500.00 | LPA is $1,798,125.00 lower |

We used the LPA figures.

**(b) Additional Amount base and start date.** Tom: 8% interest on "everything they pay in, fees
included," running from each call's *notice* date. LPA §3.4(d): interest runs only on the portion of
the §3.4(a) non-fee base attributable to the incoming partner — **management fee catch-up is excluded
entirely** (§3.4(e) confirms the Additional Amount is separate from the Commitment) — and runs from
each Capital Contribution's **due date** (not notice date) to but excluding the closing date, actual
days/365. The due date is always later than the notice date (§3.3: due date ≥ 10 business days after
notice), so this alone shrinks the interest period versus Tom's method, on top of the narrower base.
We used the LPA's due-date/non-fee-only basis (see §4 for the numbers).

**(c) Additional Amount accounting treatment.** Tom: book the interest to the fund as "other income"
so it runs through the Article 9 waterfall — his stated reason is that it's simpler for the auditors.
LPA §3.4(e) is unambiguous: the Additional Amount **is not a Capital Contribution, is not Partnership
income, and is not taken into account in Article 9 distributions.** It is paid directly to the Existing
Partners (including the GP) pro rata to their Commitments. **We have not booked it as fund income** and
recommend Tom's team not do so either — recorded as a `no_action` on `partnership_other_income` in
`answer.json`, with a `notify` action to flag this to him directly since it affects both the funds flow
memo and how the auditors should expect to see it booked.

---

## 3. Equalization contribution (LPA §3.4(a)/(b))

Source: `inputs/capital_activity/capital_activity_GAOF_II_20260917.csv` (all `INVESTMENT` and
`PARTNERSHIP_EXPENSES` rows — `MANAGEMENT_FEE` rows excluded per the definition in §3.4(a)).

Aggregate non-fee Capital Contributions by the six existing Partners before the closing:

| Call | Due date | Total (non-fee) |
|---|---|---:|
| 1 | 2026-02-17 | $1,020,000.00 |
| 2 | 2026-04-01 | $30,855,000.00 |
| 3 | 2026-07-01 | $20,527,500.00 |
| **Total (C\_before)** | | **$52,402,500.00** |

We confirmed these amounts have been called from every existing Partner exactly pro rata to Commitment
at every call (e.g., Call 1: GP $20,000 = 5,000,000/255,000,000 × $1,020,000 — matches to the cent for
all six Partners), so computing the equalization off the aggregate, rather than call-by-call per
LPA §3.4(f), gives the same result (confirmed by direct recomputation call-by-call as well).

Equalization Contribution = Commitment Percentage **after** the closing (denominator $340,000,000) ×
$52,402,500:

- LP-0206: 50,000,000/340,000,000 × 52,402,500 = **$7,706,250.00**
- LP-0207: 35,000,000/340,000,000 × 52,402,500 = **$5,394,375.00**
- **Total: $13,100,625.00**

Distributed to Existing Partners pro rata to their Commitment (of the $255,000,000 existing base),
per §3.4(b), as a return of Capital Contributions (added back to Unfunded Commitment, recallable):

| Partner | Commitment | Share | Capital returned |
|---|---:|---:|---:|
| GP-0200 | $5,000,000 | 1.9608% | $256,875.00 |
| LP-0201 | $75,000,000 | 29.4118% | $3,853,125.00 |
| LP-0202 | $60,000,000 | 23.5294% | $3,082,500.00 |
| LP-0203 | $50,000,000 | 19.6078% | $2,568,750.00 |
| LP-0204 | $40,000,000 | 15.6863% | $2,055,000.00 |
| LP-0205 | $25,000,000 | 9.8039% | $1,284,375.00 |
| **Total** | $255,000,000 | 100% | **$13,100,625.00** |

No rounding residual arose (all splits divide evenly to the cent), so §3.4(f)'s GP-residual rule did
not need to be invoked.

---

## 4. Management Fee catch-up (LPA §3.4(c)) — paid to the Manager

Each incoming Fee-Paying Partner pays the fee it would have paid from the Initial Closing Date
(2026-02-02) through the last day of the quarter of this closing (2026-09-30, end of Q3), at **its own**
rate — this is not equalized/scaled like the equalization contribution. Structure mirrors the existing
LPs' actual fee history in the capital-activity file (stub 58-day Q1 fragment + two flat full quarters):

- **LP-0206 (Tamsin Bay)** — side letter SL-OF2-004 (cl. 2.1) sets 1.75% p.a. (size-based, ≥$50mm):
  annual fee $875,000. Stub (Feb 2–Mar 31, 58 days, actual/365): $139,041.10. Q2 (flat quarter):
  $218,750.00. Q3 (flat quarter): $218,750.00. **Total $576,541.10.**
- **LP-0207 (Ostrander)** — no side letter, standard 2.00% (LPA §8.1(a)): annual fee $700,000. Stub:
  $111,232.88. Q2: $175,000.00. Q3: $175,000.00. **Total $461,232.88.**
- **Total management fee catch-up: $1,037,773.98**, payable to the Manager.

Per Owen Blackwood's 16-Sep email, the ordinary Q4 management fee call (1 October, billed to everyone
admitted by then) is separate and is correctly **excluded** from these closing numbers.

---

## 5. Additional Amount / late-closer interest (LPA §3.4(d)/(e)) — paid to Existing Partners, not fund income

8% simple interest, actual days/365, on each incoming LP's share (its post-closing Commitment
Percentage) of each call's **non-fee** total, from that call's **due date** to but excluding
2026-09-30:

| Call | Due date | Days to 30-Sep | Non-fee total |
|---|---|---:|---:|
| 1 | 2026-02-17 | 225 | $1,020,000.00 |
| 2 | 2026-04-01 | 182 | $30,855,000.00 |
| 3 | 2026-07-01 | 91 | $20,527,500.00 |

**LP-0206** (CP after = 50/340): Call 1 principal $150,000.00 → interest $7,397.26; Call 2 principal
$4,537,500.00 → interest $181,002.74; Call 3 principal $3,018,750.00 → interest $60,209.59.
**Total $248,609.59.**

**LP-0207** (CP after = 35/340): Call 1 principal $105,000.00 → interest $5,178.08; Call 2 principal
$3,176,250.00 → interest $126,701.92; Call 3 principal $2,113,125.00 → interest $42,146.71.
**Total $174,026.71.**

**Total Additional Amount: $422,636.30.** Distributed to Existing Partners pro rata to Commitment
(same $255,000,000 base as §3):

| Partner | Additional Amount received |
|---|---:|
| GP-0200 | $8,286.99 |
| LP-0201 | $124,304.79 |
| LP-0202 | $99,443.84 |
| LP-0203 | $82,869.86 |
| LP-0204 | $66,295.89 |
| LP-0205 | $41,434.93 |
| **Total** | **$422,636.30** |

**Waiver check (LP-0206):** side letter SL-OF2-004 (cl. 2.2) records that Tamsin Bay asked for a waiver
of the Additional Amount and the GP declined, and notes "LPAC consent not sought." LPA §3.4(g) requires
Advisory Committee consent only to *grant* a reduction/waiver; declining one needs no such consent, so
the full amount above applies to LP-0206.

---

## 6. What each incoming LP wires on 30 September

| Partner | Equalization contribution | Mgmt fee catch-up | Additional Amount | **Total wire** | Unfunded commitment after |
|---|---:|---:|---:|---:|---:|
| LP-0206 Tamsin Bay | $7,706,250.00 | $576,541.10 | $248,609.59 | **$8,531,400.69** | $41,717,208.90 |
| LP-0207 Ostrander | $5,394,375.00 | $461,232.88 | $174,026.71 | **$6,029,634.59** | $29,144,392.12 |

(Additional Amount is not a Capital Contribution and does not reduce Unfunded Commitment, per §3.4(e).)

## 7. What each existing partner receives back

| Partner | Capital returned | Additional Amount received | **Total received** | Unfunded commitment after |
|---|---:|---:|---:|---:|
| GP-0200 | $256,875.00 | $8,286.99 | **$265,161.99** | $4,229,375.00 |
| LP-0201 | $3,853,125.00 | $124,304.79 | **$3,977,429.79** | $62,452,268.84 |
| LP-0202 | $3,082,500.00 | $99,443.84 | **$3,181,943.84** | $49,961,815.07 |
| LP-0203 | $2,568,750.00 | $82,869.86 | **$2,651,619.86** | $41,634,845.89 |
| LP-0204 | $2,055,000.00 | $66,295.89 | **$2,121,295.89** | $33,307,876.71 |
| LP-0205 | $1,284,375.00 | $41,434.93 | **$1,325,809.93** | $20,817,422.95 |
| **Total** | **$13,100,625.00** | **$422,636.30** | **$13,523,261.30** | |

Existing partners' unfunded commitment before the closing was derived as Commitment minus all
capital-activity contributions to date (investment + expenses + management fees, all flagged
`reduces_unfunded=Y`); the capital returned above is then added back per §3.4(b).

Total paid to the Manager (management fee catch-up only): **$1,037,773.98**.

## 8. Commitment percentages after the closing (denominator $340,000,000.00)

| Partner | Commitment | % |
|---|---:|---:|
| GP-0200 | $5,000,000 | 1.4706% |
| LP-0201 | $75,000,000 | 22.0588% |
| LP-0202 | $60,000,000 | 17.6471% |
| LP-0203 | $50,000,000 | 14.7059% |
| LP-0204 | $40,000,000 | 11.7647% |
| LP-0205 | $25,000,000 | 7.3529% |
| LP-0206 | $50,000,000 | 14.7059% |
| LP-0207 | $35,000,000 | 10.2941% |

Sanity check: every Partner's non-fee contributions ÷ Commitment now equals **15.4125%**
($52,402,500 ÷ $340,000,000) — GP, all five original LPs, and both incoming LPs alike — confirming the
equalization achieved its purpose.

---

## 9. Other items flagged in the closing population

- **LP-0201 MFN vs. LP-0206's fee break.** LP-0201 (Aldermoor, $75mm) holds an MFN election right
  (SL-OF2-003, cl. 6.1) over terms granted to investors with equal or smaller commitments. LP-0206
  ($50mm) got a reduced 1.75% fee (SL-OF2-004, cl. 2.1). The side-letter summary marks that specific
  clause `mfn_electable = N`, so on the data we have it does **not** need to be offered to LP-0201 — but
  please confirm that's deliberate.
- **LP-0205 five-day-late payment.** Call 2 (due 2026-04-01) was received from LP-0205 on 2026-04-06
  across all three components ($3,150,000 total — CA-00026/27/28). LPA §3.3 says a late payment "owes
  default interest under Section 3.8," separate from and not affecting the §3.4 amounts above (so it
  doesn't change anything in this memo), but §3.8's rate/mechanics aren't in the excerpt we hold and we
  see no corresponding default-interest transaction in the capital-activity file. Worth chasing
  separately — see open questions.

---

## Assumptions

1. LP-0208 (Sable Point) is excluded from the 30-Sep-2026 closing, per Owen Blackwood's 16-Sep email
   and the second-closing checklist, notwithstanding the partner register's unrevised `SECOND
   2026-09-30` / `SUBSCRIPTION RECEIVED` fields for that partner.
2. "Aggregate Capital Contributions... other than Capital Contributions in respect of Management Fees"
   (§3.4(a)) is read to include both `INVESTMENT` and `PARTNERSHIP_EXPENSES` capital-activity
   components, and to exclude `MANAGEMENT_FEE` rows only.
3. The Management Fee catch-up period runs from the Initial Closing Date through 2026-09-30 (last day
   of Q3, the quarter containing the 30-Sep Subsequent Closing), using the same stub/day-count
   convention (actual/365, first-and-last-day-inclusive) evidenced in the existing LPs' Call 1 fee
   entries, and flat quarter-installments for Q2 and Q3, consistent with LPA §8.1(b).
4. Distribution of both the equalization-contribution pool (§3.4(b)) and the Additional Amount pool
   (§3.4(e)) to Existing Partners is pro rata to their $255,000,000 aggregate existing Commitment (the
   only "Existing Partners... pro rata to their Commitments" base the LPA text supports for a
   Subsequent Closing at which more than one Existing-Partner group exists).
5. No rounding residual required allocation to the GP under §3.4(f); every pro-rata split above divided
   evenly to the cent.

## Open questions (also listed in `answer.json`)

1. Please send the LP-0208 change form so the register can be corrected to match the checklist/email;
   until then we've excluded LP-0208 from this closing based on the checklist and Owen's email, not the
   register.
2. Please send us the full text of LPA Section 3.8 (default interest) so we can determine whether
   default interest is owed on LP-0205's 5-day-late Call 2 payment.
3. Please confirm SL-OF2-004's fee-rate concession to LP-0206 is meant to stay outside LP-0201's MFN
   election (side-letter summary marks it non-electable).
4. Please confirm you want us to proceed on the LPA §3.4 figures above for the funds flow memo and
   closing notices, given they differ from the Fund I-style numbers Tom circulated on 17-Sep.

Happy to walk through any of the above before Tuesday's deadline.
