# ADGF — 18 Sep 2026 NAV Review and Class Strike

**To:** Priya Castellane, NAV Oversight Manager
**From:** NAV Review (covering for Marco)
**Re:** Aldermoor Dividend Growth Fund — final class NAVs, ELA waiver, and Maren Holt's Class A recoupment request

## Bottom line

| Class | Net assets (before 9/18 TD activity) | NAV/share, 4dp | Published NAV |
|---|---:|---:|---:|
| A | $117,687,765.21 | 18.3533 | **$18.35** |
| C | $33,986,943.63 | 17.8368 | **$17.84** |
| I | $218,961,503.55 | 18.4417 | **$18.44** |

Shares outstanding used (unchanged from the 9/17 final NAV report, before today's trade-date
activity): A 6,412,337.218; C 1,905,441.502; I 11,873,205.664.

I corrected one system error before striking (allocation base), added the ELA waiver the system
doesn't calculate, and **declined** to start Class A recoupment tonight. Details and full
re-performance trail below; figures also in `out/answer.json`.

## 1. Allocation-base error in the system draft — corrected

`inputs/accounting/class_allocation_draft_ADGF_20260918.csv` (run `NAVRUN-0918-1602`) used
`alloc_basis=TD_SHARES_INCL_CURRENT`. Its `alloc_base_usd` is **not** the 9/17 final net assets
(`inputs/accounting/nav_report_ADGF_20260917_final.csv`) — it's that figure adjusted by **today's**
(9/18) trade-date capital activity from `inputs/transfer_agent/ta_capital_activity_ADGF_20260917_20260918.csv`:

- A: 118,126,152.53 − 243,300.12 (net 9/18 subs $412,000.00 − redemptions $655,300.12) = 117,882,852.41 ✓ ties to draft
- C: 34,114,262.48 − 53,440.50 (net 9/18 subs $38,000.00 − redemptions $91,440.50) = 34,060,821.98 ✓ ties to draft
- I: 219,775,411.48 + 27,295,443.20 (net 9/18 subs $28,500,000.00, incl. the $27.0mm Linwood
  Retirement Platform omnibus funding, − redemptions $1,204,556.80) = 247,070,854.68 ✓ ties to draft

Per the Multiple Class Plan §3 ("Extract A") and NAV Procedures B.1 (`inputs/policies/
ADGF_multiple_class_plan_and_nav_procedures.md`), capital share transactions trade-dated the
**current** day do not participate in the current day's income, gain, loss or expense allocation —
today's 9/18 flows are PENDING NAV in the TA file and should have no bearing on tonight's
allocation ratios. The correct base is simply the 9/17 final net assets (which already reflect
9/17's own trade-date activity, consistent with B.1's "beginning-of-day" definition):

- Total base: $372,015,826.49
- Ratios: **A 31.752991%, C 9.170111%, I 59.076898%**

I re-ran the fund-level expense and income/gain allocation on this corrected base, line by line,
rounding each line to the cent with any residual assigned to Class I (largest allocation base),
per Procedures B.2. Class-specific expenses (12b-1, sub-TA, TA per-account fees in
`inputs/accounting/expense_accruals_ADGF_20260918.csv`) were already computed correctly on 9/17
final class net assets and are unaffected ($1,019.08 / $1,074.64 / $662.12 for A/C/I — these tie
exactly to the draft's `class_specific_exp_usd`). Net effect of the fix versus the draft (before
waiver): roughly +$30,433.75 to A, +$8,731.04 to C, and −$39,164.79 to I — a reallocation across
classes, not a change in total fund net assets (it sums to ~$0 at the fund level).

**Action needed from you / ops:** please have NAV system support look at why today's run picked
up `TD_SHARES_INCL_CURRENT` instead of the prior-day final base — this looks like a
configuration/flag issue that could recur tomorrow when Class I's mix shifts materially from the
Linwood funding.

## 2. Expense-limitation (ELA) waiver — computed manually and booked

Per NAV Procedures B.3, the NAV system does not compute the ELA waiver (draft shows
`ela_waiver_usd=0.00` for all three classes) — the fund accountant computes it and books it by
manual entry to GL 5900 / 1390. I computed it as follows.

**Excluded Expenses.** Per the Expense Limitation Agreement §2 (`inputs/agreements/
ADGF_expense_limitation_agreement.md`), "Operating Expenses" exclude, among other things,
(i) interest on amounts drawn under a credit facility (but *not* commitment fees on undrawn
amounts) and (vi) extraordinary/litigation expenses. Today's fund-level accruals include two
Excluded Expenses:
- GL 5125, Brightwater Holdings v. Aldermoor Funds Trust litigation estimate: $1,643.84
- GL 5160, LOC interest on the $4,000,000 drawn: $598.14
- (GL 5170, the LOC commitment fee on the *undrawn* facility, $117.81, is **not** excluded and
  stays in Operating Expenses.)

Total excluded: **$2,241.98** (fund-level, before allocation).

**Operating Expense ratios (today, annualized ×365 over corrected allocation base):**

| Class | Class expenses | + allocated fund opex (excl. above) | = Operating Expense $ | ÷ base × 365 | Limit | Excess |
|---|---:|---:|---:|---:|---:|---:|
| A | 1,019.08 | 2,169.73 | 3,188.81 | 0.9853% | 1.00% | none |
| C | 1,074.64 | 626.60 | 1,701.24 | 1.8202% | 1.75% | $65.62 |
| I | 662.12 | 4,036.79 | 4,698.91 | 0.7804% | 0.70% | $484.04 |

Limits per ELA §1 (current, effective 2025-03-01). Class A is comfortably under its limit —
consistent with Maren Holt's email. C and I need waivers of **$65.62** and **$484.04**
respectively (total **$549.66**), each less than that class's own allocated share of the
management fee (A $1,618.17 / C $467.32 / I $3,010.62), so this is a pure waiver of the management
fee with no reimbursement component, and per ELA §3 it is not netted against any other class's
position. Booked as a manual entry to GL 5900 / 1390 before release. Recoupment expiry for these
new accruals: the last day of the 36th month after September 2026, i.e. **2029-09-30**
(consistent with the pattern already in `ela_waiver_recoupment_register_ADGF.csv`).

**Note on classification impact:** had the litigation and LOC-interest items been left in as
Operating Expenses (an easy mistake — they're ordinary fund-level accrual lines), Class A would
have shown a false ~0.34% breach (~$664 spurious waiver), and C/I would have overstated their
waivers by roughly $271 and $1,809 respectively — a combined $2,194.47 overstatement. Flagging
this because it's not obvious from the accrual file alone which lines are Excluded Expenses.

## 3. Maren Holt's Class A recoupment request — declined for tonight

`inputs/correspondence/email_aldermoor_finance_recoupment_20260918.txt` (Maren Holt, Aldermoor
Capital Management, 18 Sep 13:22 ET) asks to start accruing Class A recoupment tonight against the
$16,312.85 of 2024 waivers on the register (four tranches, `ela_waiver_recoupment_register_ADGF.csv`,
earliest expiring 2027-01-31), on the basis that Class A is "comfortably below its 1.00% limit."

I did not accrue any recoupment, for two independent reasons:

1. **No approval on file.** ELA §5(b) requires Board approval, and the Administrator "shall not
   accrue any recoupment until it has received written notice from the Fund Treasurer that Board
   approval has been obtained, specifying the class and maximum amount." NAV Procedures B.6
   separately bars booking any NAV-affecting entry on the Adviser's instruction alone where Board/
   Fund Treasurer approval is required. Maren's own email says the Board only meets 10 December
   2026 — no Fund Treasurer notice exists in the inputs.
2. **No headroom even if approved.** ELA §5(a) caps recoupment so the class's Operating Expenses
   cannot exceed the *lesser* of (x) the limit in effect when the amount was waived and (y) the
   limit in effect at the time of recoupment. The 2024 tranches Maren is targeting were waived
   when Class A's limit was **0.90%** (per the register's `limit_in_effect_pct` column); the
   current limit is 1.00%; the lesser is 0.90%. Class A's actual Operating Expense ratio *today*
   is **0.9853%** (section 2 above) — already above 0.90%. So even with Board approval in hand,
   there is **zero** recoupment headroom for Class A today; recoupment could not start until the
   class's own ratio drops back under 0.90%, independent of the approval question.

I've escalated the approval process to the Fund Treasurer and will notify Maren/Colm Radley of
both points so Aldermoor can plan the Board paper with accurate numbers — recoupment can't
realistically start even once the Board ratifies, unless Class A's expense ratio also falls.
`class_a_recoupment_headroom_usd` in the answer is reported as $0.00 on this basis.

## 4. Other items reviewed, no issue found

- 12b-1 rates (A 0.25%, C 1.00%), sub-TA (I only, 0.10%) and TA per-account fees all tie to the
  Multiple Class Plan §2 and recompute exactly off 9/17 final class net assets — no error.
- Fund-level expense rates (management 0.50%, admin 0.035%, custody 0.015%, and the four fixed
  budget accruals) all recompute exactly off the 9/17 final fund net assets ÷365 — no error.
- The $28.5mm Class I subscription (incl. $27.0mm Linwood omnibus) and $1.2mm redemption
  trade-dated 9/18 are correctly PENDING NAV in the TA file, to be priced at tonight's corrected
  NAV and settled after release; they properly do not participate in tonight's allocation base
  once F1's fix is applied. This will materially change Class I's share of the fund from 9/19.

## Open questions

1. Please confirm the SOFR rate / drawn-and-undrawn facility balances behind the $598.14 LOC
   interest and $117.81 commitment fee accruals — I took the accrual file's dollar amounts as
   given and did not independently recompute them.
2. If a Fund Treasurer written notice of Board approval for Class A recoupment exists but wasn't
   included in tonight's package, please send it — it wouldn't change tonight's outcome (zero
   headroom regardless, see §3), but I want the record straight before the Board's 12/10 meeting.
3. Please have NAV system support confirm whether the `TD_SHARES_INCL_CURRENT` allocation-base
   issue in run `NAVRUN-0918-1602` is isolated to tonight or has affected other dates/funds, so any
   previously released NAVs can be checked.
4. Please confirm the system's own rounding-residual convention (I assumed "largest allocation
   base" per Procedures B.2, and used Class I) so my manual recompute ties to the system's control
   total to the cent once the base is corrected there.

— Re-performance note: all figures above are reproducible from `inputs/accounting/
nav_report_ADGF_20260917_final.csv`, `inputs/accounting/expense_accruals_ADGF_20260918.csv`,
`inputs/accounting/income_and_gains_ADGF_20260918.csv`, `inputs/accounting/
class_allocation_draft_ADGF_20260918.csv`, `inputs/transfer_agent/
ta_capital_activity_ADGF_20260917_20260918.csv`, `inputs/agreements/
ADGF_expense_limitation_agreement.md`, `inputs/agreements/ela_waiver_recoupment_register_ADGF.csv`,
and `inputs/policies/ADGF_multiple_class_plan_and_nav_procedures.md`.
