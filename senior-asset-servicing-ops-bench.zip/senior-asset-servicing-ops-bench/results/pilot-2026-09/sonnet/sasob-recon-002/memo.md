# Memo: TMAI holdings rec vs Northgate — account 7730-131, close of business 2026-09-17

**To:** Graham Voss, Head of Operations Oversight
**From:** Investment Operations (reconciliation review)
**Re:** Four position differences vs Northgate MT535, 17-Sep-2026

Short answer: **don't true the books up to Northgate across the board.** Three of the four
differences are fully explained, policy-compliant reconciling items and the books are already
correct. One (Marlowe Water Technologies) is a genuine accounting break that needs to be booked
today. There is also a time-sensitive securities-lending recall unrelated to the size of any
break. Details, evidence and figures below so this can be re-performed.

## Method

Compared `inputs/accounting/positions_TMAI_7730-131_20260917.csv` (trade-date basis, our book of
record per policy §2.2) line by line against
`inputs/custodian/MT535_NTCUS33_7730-131_20260917.txt` (Northgate's statement of **settled**
holdings as of the same close). Four ISINs differ; all bond (par) and other equity lines tie out
exactly. For each difference I traced the cause through the unsettled-trade blotter, the
Harrowgate on-loan report, the corporate-action event log, the MT566 settlement confirmations, the
issuer notices, and the closing-price file, and applied
`inputs/policies/TFT_position_reconciliation_and_corporate_actions_procedures.md` ("the policy"
below).

## The four differences

| Security | ISIN | Books (trade-date) | Northgate MT535 (settled) | Diff (books − custodian) |
|---|---|---:|---:|---:|
| Brindlewood Industrial Corp | USLPV8NW1399 | 420,000 | 250,000 | **+170,000** |
| Alder Semiconductor Inc | US0C86UQ8545 | 64,000 | 128,000 | **-64,000** |
| Marlowe Water Technologies Inc | US3EP60F8227 | 0 | 46,250 | **-46,250** |
| Pinecrest Health Systems Inc | USE3E5QV1890 | 0 | 90,000 | **-90,000** |

### 1. Brindlewood Industrial Corp — +170,000, two causes, books correct, no adjustment

- **20,000 sh — pending settlement (expected, self-clearing).** Ticket `EQ-260917-0412`, a buy
  executed 17-Sep, settles T+1 on 18-Sep (`inputs/accounting/unsettled_trades_TMAI_20260917.csv`).
  Our books are trade-date; Northgate's MT535 is settled-only. Policy §2.3(a) treats this as an
  expected reconciling item. **No adjustment. Clears 2026-09-18.**
- **150,000 sh — on loan to Harrowgate (expected, books correct).** Loan `HSF-L-2608-11932`, OPEN,
  opened 2026-08-20 (`inputs/lending/harrowgate_onloan_report_TMAI_20260917.csv`). The MT535's own
  footnote confirms loaned-out shares aren't reported in safekeeping. Per policy §2.3(b)/§4.1,
  loaned securities remain Fund assets and stay on our books at full carrying value. **No
  adjustment.** 20,000 + 150,000 = 170,000, which fully explains the gap the desk flagged.

  **This is the one that needs action today, but for a different reason (see "Time-sensitive"
  below): a material proxy vote.**

### 2. Alder Semiconductor Inc — -64,000, corporate-action timing, no NAV impact

Alder's 2-for-1 forward split: record date 10-Sep, **payable date 17-Sep**, ex-date 18-Sep
(`inputs/notices/alder_stock_split_notice.txt`). Northgate credited the extra 64,000 shares on the
payable date, per its own CA confirmation (MT566 message 3, `NTC-CA-26-780115`). Our policy §3.1
books corporate actions on the **ex-date**, even when it falls after the payable date — so our
books correctly still show 64,000 shares at the pre-split price of $188.40 on 17-Sep. Market value
is identical either way: 64,000 × $188.40 = 128,000 × $94.20 = $12,057,600. **No accounting error,
no NAV impact, no adjustment.** The CA event (`CA-26-04702`) is already flagged SCHEDULED in the
CA log for processing tomorrow. Clears 2026-09-18.

### 3. Pinecrest Health Systems Inc — -90,000, custodian statement error, books correct

Pinecrest was taken out in an all-cash merger by Halloran Care Partners ($41.25/sh), delisted
15-Sep. Our books already removed the 90,000 shares effective 15-Sep and booked the $3,712,500
proceeds received 16-Sep (`CA-26-04418`, status PROCESSED). **Northgate's own MT566 settlement
confirmation** (message 2, `NTC-CA-26-744190`) shows exactly the same thing — 90,000 shares debited
effective 15-Sep, posted 16-Sep, cash credited 16-Sep. Yet the 17-Sep MT535 statement still lists
the 90,000-share position. This is Northgate's statement that's stale/wrong, not ours. **No
adjustment to our books.** Per policy §2.4, raise with Northgate Client Service today with the
MT566 as evidence.

### 4. Marlowe Water Technologies Inc — -46,250, real accounting break, book it today

MDH's spin-off of MWT (1 MWT share per 4 MDH held, record date 4-Sep, ex-date 16-Sep) has **never
been booked**. The CA event (`CA-26-04655`) has sat in `PENDING_TERMS` since the ex-date with the
note "new security US3EP60F8227 not yet set up in security master." Policy §3.2 caps
`PENDING_TERMS` at the day before the ex-date (i.e., 15-Sep) — this is already two business days
overdue. Northgate has already credited the shares: MT566 message 1
(`NTC-CA-26-771802`) confirms 46,250 whole shares paid 15-Sep plus a 0.5-share fractional
entitlement (185,002 MDH shares ÷ 4 = 46,250.5), consistent with the MT535's 46,250-share MWT line
at $1,152,087.50.

**Which side is wrong:** ours. This is an accounting break (root cause
`corporate_action_not_booked`), not a custodian or lending issue.

**What gets booked** (issuer's Form 8937 was filed and posted 14-Sep, *before* the ex-date, so
policy §3.3 requires using its actual allocation — 86.40% MDH / 13.60% MWT — not the information
statement's illustrative ~15% estimate):

- MDH pre-distribution cost basis: $7,215,078.00 (185,002 sh, unchanged quantity)
- Allocated to MWT (13.60%, rounded to the cent): **$981,250.61**
- Per-share cost over the 46,250.5-share entitlement (whole + fractional): $21.216
- **MWT position to record: 46,250 whole shares, cost basis $981,240.00**
- Fractional 0.5 share: cost relieved $10.61; cash-in-lieu receivable at the distribution agent's
  rate of $24.3176/whole share = **$12.16**; **realized gain $1.55** (§3.4)
- **MDH cost basis after allocation: $7,215,078.00 − $981,250.61 = $6,233,827.39** (MDH retains the
  remainder per policy §3.3), quantity unchanged at 185,002 shares

**NAV impact — real, but not material.** Because the MWT holding was entirely missing, Fund net
assets were understated on both NAVs struck since the ex-date:

| NAV date | Missing assets (46,250 sh × close + $12.16 receivable) | Reported NAV/sh | Error $/sh (corrected − reported) | Error % of NAV/sh |
|---|---:|---:|---:|---:|
| 2026-09-16 | 46,250 × $24.55 + $12.16 = **$1,135,449.66** | $11.7572 | **+$0.0274** | **0.23%** |
| 2026-09-17 | 46,250 × $24.91 + $12.16 = **$1,152,099.66** | $11.7958 | **+$0.0279** | **0.24%** |

Per the Trust's NAV Error Correction Policy §5.2, an error is material only if it is **both**
≥ $0.01/share **and** ≥ 0.50% of NAV/share. Both dates clear the dollar threshold but fall short of
the 0.50% threshold (0.23% and 0.24%), so **neither error is material.** Per §5.4: no NAV
restatement, no reprocessing of shareholder subscriptions/redemptions struck at the erroneous
NAVs; correct it in the next NAV (today's, 18-Sep), notify the Fund Treasurer, and log it for the
quarterly Board report. 15-Sep's NAV is unaffected — MDH still traded cum-distribution that day, so
the pre-spin-off MDH price already carried the combined economic value.

**Do today:**
1. Set up ISIN US3EP60F8227 in the security master (this is what's blocking the entry).
2. Book the MWT position, the MDH cost reallocation, and the cash-in-lieu receivable as above, as
   of ex-date 16-Sep, before today's NAV is finalized.
3. Notify the Fund Treasurer of the (non-material) NAV error for the log.
4. Flag the CA-data-vendor gap that left the allocation unavailable through the ex-date.

## Time-sensitive item unrelated to the reconciliation itself

**Brindlewood proxy vote — recall the 150,000 loaned shares today.** Brindlewood's special meeting
on the Castellan all-stock merger has a record date of **2026-09-24**; approval needs a majority of
shares **outstanding**, so non-voted (including on-loan) shares count against the deal. The
Adviser's Proxy Voting Committee minuted this as a material vote (minutes 27-Aug, item 4), and PM
Selin Aukland's 17-Sep email confirms Tidewell intends to vote **AGAINST** and wants the full
position on record. Voting rights on the 150,000 loaned shares currently sit with the borrower.
Per the lending agreement (§7.1/7.2), a recall notice given by 11:00 a.m. NY settles back T+1, but
the Lending Agent recommends at least 3 business days' cushion before a material record date given
possible borrower fails — that puts the **last safe notice date at Monday 2026-09-21**. Recommend
the recall notice go out today (Friday) rather than wait for Monday, given quarter-end volumes.
The separate 30,000-share Corvant loan (`HSF-L-2609-12877`, PENDING_DELIVERY, hasn't left the
account yet) is unrelated and doesn't affect Brindlewood.

## What I decided not to do

Declined Pellmore's proposal to true our Brindlewood, Alder, and Pinecrest positions up to
Northgate's figures. Doing so would remove 170,000 legitimately-owned/loaned Brindlewood shares
from the books, prematurely book Alder's split a day early against policy, and copy a stale
Northgate line for Pinecrest that Northgate's own confirmation contradicts — all of which policy
§2.2 prohibits absent a traced, proven accounting error. The one item that is a books error
(Marlowe Water Technologies) is corrected by booking the spin-off properly (cost basis, cash in
lieu, new security setup), not by simply copying Northgate's unit count.

## What I need / assumptions made

- Used the distribution agent's quoted cash-in-lieu rate ($24.3176/whole MWT share) for the $12.16
  receivable; the MT566 CA confirmation itself showed the cash leg as a $0 placeholder pending a
  "replacement message." Please confirm the exact remittance when it settles on/about 22-Sep.
- No cash/sweep statement for account 7730-133 was provided to independently confirm the
  $3,712,500 Pinecrest merger proceeds actually posted; relied on the MT566 cash confirmation and
  the CA event log.
- Assumed the Adviser Operations desk (not this review) is the one to actually transmit the
  Harrowgate recall notice and the Northgate query — recommend confirming both went out today.
  This memo cannot post entries, contact Northgate/Harrowgate, or move money.
- No data was provided for custody accounts 7730-132 or 7730-133; this review covers 7730-131
  only, matching the scope of the materials sent.

Full structured findings, figures, and recommended actions are in `answer.json`.
