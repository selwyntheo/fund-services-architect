# GACP III Q4-2026 Management Fee — Do Not Pay Invoice GAM-III-2026-04 As Presented

**To:** Sam Adeyemi, Fund Controller
**Re:** Granite Arch Management LP invoice GAM-III-2026-04 (USD 817,500.00), due 5 Oct 2026
**Recommendation:** Hold. Correct amount payable is **USD 56,921.23** (USD 760,578.77 less than invoiced).

## Bottom line

1. The Manager's Invested Capital build for Q4 leaves out three required deductions and skips the
   Fee-Paying attribution entirely.
2. The bigger issue: the Investment Period actually ended **14 August 2026**, which falls inside
   **Q3-2026**, not at the start of Q4. LPA Section 8.1(d) required a mid-quarter true-up of the
   Q3-2026 fee that was never done — the Partnership paid Q3 in full at the old rate and is owed a
   **USD 576,926.27** credit against the next installment.
3. Netting the corrected Q4 gross fee (USD 633,847.50) against that Q3 credit gives **USD 56,921.23**
   payable — not USD 817,500.00.

## 1. Investment Period end date (drives everything else)

- LPA Article 1 defines the Investment Period as 5 years from the Initial Closing Date (14 Aug 2020),
  extendable once, by up to one year, with Advisory Committee consent.
  (`inputs/lpa/GACP_III_LPA_excerpt_management_fee.md`, Art. 1, "Investment Period")
- The Advisory Committee minutes of **12 June 2025** record consent to extend the Investment Period
  "to and including 14 August 2026" and note that "the Management Fee steps down from the day after
  the extended Investment Period ends."
  (`inputs/governance/LPAC_records_GACP_III.txt`, item (1))
- **Investment Period end date = 14 August 2026.** This is in Q3-2026 (1 Jul–30 Sep), not Q4. The
  invoice's framing — "the Management Fee steps down from this quarter" (Q4) — glosses over the fact
  that the actual step-down event happened mid-way through the *prior* quarter, which requires its
  own recomputation under LPA 8.1(d) before Q4 is even considered.

## 2. Q3-2026 true-up (LPA Section 8.1(d)) — the fee actually owed for Q3

Section 8.1(d): because the Investment Period ended on a day other than the last day of a calendar
quarter, the Q3-2026 fee = (i) the pre-step-down installment × (days to and including 14 Aug ÷ days
in quarter) + (ii) the post-step-down installment (using Invested Capital as of 15 Aug 2026) × (remaining
days ÷ days in quarter), each part rounded to the cent.

- Q3-2026 has 92 days (Jul 31 + Aug 31 + Sep 30). Pre-step-down days (1 Jul–14 Aug inclusive) = 45;
  post-step-down days = 47.
- **Part (i):** Full pre-step-down quarterly installment = 394,000,000 (Fee-Paying Commitments,
  `inputs/investor_records/partner_register_GACP_III.csv`) × 2.00% ÷ 4 = USD 1,970,000.00.
  × 45/92 = **USD 963,586.96**.
- **Part (ii):** Invested Capital as of 15 Aug 2026 (100%) = USD 227,600,000.00 (see build below) ×
  98.5% Fee-Paying share = USD 224,186,000.00 × 1.50% ÷ 4 = USD 840,697.50 full-quarter installment.
  × 47/92 = **USD 429,486.77**.
- **Q3-2026 fee as recomputed = USD 1,393,073.73.**
- Q3-2026 was actually invoiced and paid in full at USD 1,970,000.00 on 2026-07-01
  (`inputs/manager/management_fee_installments_GACP_III_2026.csv`, row Q3-2026).
- **Q3 credit owed to the Partnership = USD 576,926.27**, to be credited against the next
  installment(s) per 8.1(d) (not repaid in cash separately).

### Invested Capital as of 15 August 2026 (100%, before Fee-Paying attribution)

Starting from `inputs/portfolio/investment_cost_ledger_GACP_III_20260930.csv`, summing all
`cost_change_usd` entries dated on or before 2026-08-14 (i.e., excluding the Sept-2026 Halyard
follow-on and Tessaract sale, which post-date this point) gives **USD 258,000,000** already posted
in the ledger. Two further LPA-required deductions are not yet posted anywhere and must be applied:

- **Orla Specialty Foods partial realization** (event IC-008, 2023-06-20): 40% of shares sold for
  USD 30,000,000 cash; ledger note explicitly flags "cost relief not yet posted." LPA Art. 1
  ("Realized") requires the cost *attributable to the portion disposed of* to be excluded: 40% ×
  USD 36,000,000 acquisition cost (IC-002) = **USD 14,400,000**.
- **Pellucid Diagnostics Permanent Write-Down**: GP notice to the Advisory Committee dated
  22 July 2026 designates a Permanent Write-Down of **USD 16,000,000**, effective 30 June 2026
  (`inputs/governance/LPAC_records_GACP_III.txt`, item (2)). This is a valuation-policy designation,
  not a ledger transaction, so it never appears as a cost-ledger line and must be applied separately.

USD 258,000,000 − 14,400,000 − 16,000,000 = **USD 227,600,000** (100% Invested Capital as of 15 Aug 2026).

## 3. Q4-2026 gross fee (LPA Section 8.1(c)) — corrected Invested Capital

Since Q4-2026 is entirely after the Investment Period end, it is a plain 8.1(c) installment: 1.50% of
Invested Capital attributable to Fee-Paying Partners as of **1 October 2026** (the first day of the
quarter), no further proration.

- Ledger `cost_change_usd` sum through all rows dated through 2026-09-30 (i.e., including the
  Sept-2026 Halyard follow-on IC-014 and the Tessaract full sale IC-015) = **USD 202,000,000**.
- Less the same two LPA deductions still outstanding at that date (Orla USD 14,400,000; Pellucid PWD
  USD 16,000,000, both unaffected by anything that happened in September): USD 202,000,000 −
  14,400,000 − 16,000,000 = **USD 171,600,000** (100% Invested Capital, Q4 basis).
- **The invoice's Invested Capital of USD 218,000,000 is wrong** because it: (a) never removes the
  Wexford Marine Services write-off, (b) never removes the Pellucid Permanent Write-Down, and (c) never
  removes the unposted Orla partial-realization cost — see item-by-item detail below.
- Fee-Paying share (LPA 8.1(b): Invested Capital attributed pro rata to Commitments) = Fee-Paying
  Commitments ÷ total Commitments = 394,000,000 ÷ 400,000,000 (GP's USD 6,000,000 is FEE_EXEMPT per
  `inputs/investor_records/partner_register_GACP_III.csv`) = **98.5%**.
- Invested Capital attributable to Fee-Paying Partners = 171,600,000 × 98.5% = USD 169,026,000.
- **Q4-2026 gross installment = 169,026,000 × 1.50% ÷ 4 = USD 633,847.50.**
  (The invoice applies its 1.50% rate to the full, un-attributed 218,000,000 with no 98.5% factor at
  all — 218,000,000 × 1.50% ÷ 4 = 817,500.00 exactly — so the attribution error is baked into the
  invoiced number.)

## 4. Net amount payable for Q4-2026

Q4 gross (USD 633,847.50) − Q3 credit (USD 576,926.27) = **USD 56,921.23 payable to the Manager**.
Credit fully absorbed by Q4; **carry-forward = USD 0.00**.

**Invoice amount USD 817,500.00 − correct amount USD 56,921.23 = overbilling of USD 760,578.77.**

## 5. Item-by-item basis (what the LPA says vs. the valuation deck)

| Item | LPA treatment | Effect |
|---|---|---|
| Wexford Marine Services write-off (Chapter 7, IC-013, 2025-12-31, USD 16.0mm) | "Realized" includes write-off as worthless following bankruptcy — already posted in the cost ledger but omitted from the invoice's "less" line | **Missing from invoice; reduces Invested Capital by USD 16.0mm** |
| Pellucid Diagnostics Permanent Write-Down (GP notice 22 Jul 2026, USD 16.0mm) | Designated Permanent Write-Down explicitly reduces "Invested Capital" per Art. 1 | **Missing from invoice; reduces Invested Capital by USD 16.0mm** |
| Orla Specialty Foods 40% partial sale (IC-008, 2023-06-20) | Partial realization — cost attributable to the portion sold (USD 14.4mm) is Realized, even though "not yet posted" in the cost ledger | **Missing from invoice and from the ledger's running total; reduces Invested Capital by USD 14.4mm** |
| Kittering Software Group fair-value decline (0.60x MOIC per valuation deck; "impairment indicators... not designated permanent") | Art. 1: unrealized fair-value decreases are **not** Permanent Write-Downs unless the GP so designates by notice to the Advisory Committee — no such notice exists for Kittering | **No effect on Invested Capital.** This is the exact "LPA definitions, not the valuation deck" distinction you flagged — a bad mark alone does not reduce the fee base. |
| Halyard Packaging dividend recap (IC-010, 2024-12-18, USD 50.0mm, no shares sold) | Distributions of recap proceeds where the Partnership disposes of no part of its investment do not Realize any cost | No effect |
| Halyard Packaging follow-on (IC-014, 2026-09-10, +USD 4.0mm) | Follow-ons are included in Invested Capital; correctly included in both the ledger and the invoice's gross figure | No error here |
| Brindle Veterinary Partners full sale (IC-011, 2025-03-18) | Fully Realized; correctly excluded by the invoice | No error here |
| Tessaract Logistics Holdings full sale (IC-015, 2026-09-15) | Fully Realized (before the Oct 1 basis date); correctly excluded by the invoice | No error here |
| Fee Income offsets (LPA 8.3) | LPA excerpt states no Fee Income received in 2026 to date | No offset applies |

## 6. What we do next (per Administration Services Agreement Schedule 4)

Halcyon's recomputation (USD 56,921.23) differs from the invoice (USD 817,500.00) by USD 760,578.77 —
far beyond the lesser-of-USD-5,000-or-1% threshold in Schedule 4.2. Under Schedule 4:

1. **Hold** — do not release GAM-III-2026-04 in Monday's payment run at the invoiced amount
   (Schedule 4.2).
2. **Notify** Marcus Feld (Manager CFO) in writing with this recomputation and the basis for each
   difference (Schedule 4.2).
3. **Request** a revised invoice for USD 56,921.23, signed by the Manager's CFO — Halcyon cannot act
   on a verbal instruction and cannot release a different amount without one (Schedule 4.4/4.5).
4. Once received, **post** the Q3-2026 true-up credit (USD 576,926.27) against the Q4-2026 fee in the
   general ledger, and correct the investment cost ledger to post the outstanding USD 14,400,000 Orla
   cost relief so future quarters' Invested Capital starts from a clean base.
5. If Mr Feld does not resolve or satisfactorily explain the difference within 10 Business Days of
   notice, Schedule 4.3 requires escalation to the Advisory Committee Chair and the Partnership's
   auditor — flagging this now since he personally signed the disputed invoice.

## Assumptions made

- "First day of the quarter" (LPA 8.1(c)) and "30 September 2026" (as used in the invoice) produce
  the same Invested Capital figure here because no cost-ledger event is dated 2026-10-01; if that
  changes, Invested Capital must be re-pulled as of 1 Oct 2026 specifically.
- Fee-Paying attribution (98.5%) is applied uniformly to all of Invested Capital, per the LPA's
  statement that participation is pro rata to Commitments because no Partner has been excused; the
  partner register confirms only the GP (FEE_EXEMPT) is excluded from the Fee-Paying pool.
- The Orla and Pellucid deductions are treated as continuously applicable from their effective dates
  (2023-06-20 and 2026-06-30 respectively) through both the 15 Aug 2026 and 1 Oct 2026 measurement
  dates, since nothing in the inputs reverses or modifies either.

## Open questions / what we need from whom

- **From Fund Accounting/Valuation:** Is there a Q3-2026 (as of 30 Sep 2026) valuation update, and did
  the Valuation Committee "revisit Q3" on Kittering Software Group as flagged in the Q2-2026 note? We
  only have the 30 Jun 2026 valuation summary; if a further Permanent Write-Down has since been
  designated for Kittering or any other name (by GP notice to the Advisory Committee, as was done for
  Pellucid), that would further reduce Invested Capital and is not reflected in this recomputation.
- **From Halcyon/Manager records:** Confirm no Advisory Committee notice or GP designation exists after
  22 July 2026 (further write-down, further Investment Period change under the Section 2.6 key-person
  provision, or another realization) beyond what's in these inputs.
- **From the Manager:** Confirm whether the Orla Specialty Foods 40% partial-sale cost relief
  (USD 14,400,000) has been posted anywhere since 2023, or is still outstanding.
- **Escalation tracking:** the 10-Business-Day clock under Schedule 4.3 should start from the date we
  send Mr Feld the written recomputation, not from this memo.

## Sources cited

- `inputs/lpa/GACP_III_LPA_excerpt_management_fee.md` — Investment Period, Invested Capital, Realized,
  Permanent Write-Down definitions; Section 8.1(a)-(e); Section 8.8.
- `inputs/governance/LPAC_records_GACP_III.txt` — Investment Period extension consent (12 Jun 2025);
  Pellucid Permanent Write-Down notice (22 Jul 2026).
- `inputs/manager/GAM_invoice_GAM-III-2026-04.txt` — invoice as presented (USD 817,500.00).
- `inputs/manager/management_fee_installments_GACP_III_2026.csv` — Q1–Q3 2026 billing/payment history.
- `inputs/portfolio/investment_cost_ledger_GACP_III_20260930.csv` — acquisition, realization, write-off
  and follow-on events through 2026-09-30.
- `inputs/portfolio/valuation_summary_GACP_III_Q2_2026.csv` — fair values and valuation-committee notes
  as of 30 Jun 2026 (used only to confirm Kittering's markdown is unrealized/undesignated, not as a fee
  basis input).
- `inputs/investor_records/partner_register_GACP_III.csv` — Commitments and Fee-Paying status by
  Partner.
- `inputs/admin/halcyon_services_agreement_schedule4_fee_payments.md` — Schedule 4 payment-verification
  and escalation process.
