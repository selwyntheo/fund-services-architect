# Memo: Fenwick claims review — Bracken Foods & Van Oosterlo Holding

**To:** Keisha Osei, Income & Claims Supervisor
**From:** Asset Servicing (Income & Claims)
**Date:** 2026-09-18 (in response to your 10:30 AM ET note re Tomas Albright's list)

## 1. Scope and sources

Reviewed all 13 Fenwick trades shown for accounts 4410-3104 (Bracken Foods, US360MLX2669) and
4410-3107 (Van Oosterlo Holding, NL0013582448) in `inputs/trades/fenwick_trade_settlement_status_20260918.csv`
(one row, EQ-B-260910-5512/Hollister Rail, is a different security with no income event and is excluded).
Cross-referenced against:

- `inputs/notices/MT564_MRDL_BRACKEN_DVCA_20260821.txt` — Bracken quarterly dividend BRKN26DVCA03: gross USD 0.54/sh,
  ex-date = record date = 2026-09-10 (US regular-way T+1 means ex-date equals record date, per notice and policy 3.1),
  pay date 2026-09-25.
- `inputs/notices/MT564_MRDL_VANOOSTERLO_DVCA_20260826.txt` — Van Oosterlo interim dividend VOH26DVCA02: gross
  EUR 0.88/sh, ex-date 2026-09-08, record date 2026-09-09, NL dividend tax 15% standard rate, pay date 2026-09-16,
  T+2 market cycle.
- `inputs/income/fenwick_income_ledger_VOH_BRKN.csv` — confirms the above and also shows a **prior** Van Oosterlo
  event, VOH26DVCA01 (final dividend, EUR 1.24/sh, ex-date 2026-05-12, record date 2026-05-13, paid 2026-05-20,
  0% WHT) — this is the event relevant to trade EQ-B-260511-6620, not the September dividend.
- `inputs/csd/t2s_market_claims_report_VANDNL2A_20260918.csv` — the CSD's own auto-generated market/reverse claims
  for account 4410-3107, used as the authoritative record of what T2S has already detected and generated.
- `inputs/tax/tax_documentation_fenwick.csv` — Fenwick's on-file tax status: US Form W-9 (exempt, 0% US withholding)
  on 4410-3104; NL Form IB 92 USA + pension trust statement (relief at source, 0%) on 4410-3107, valid
  2025-01-01 to 2027-12-31.
- `inputs/policies/meridale_market_claims_procedures.md` v5.0 — entitlement principle (§2), US procedure (§3),
  NL procedure (§4), time-barred handling (§5), booking (§6).

Entitlement rule applied throughout (policy §2.1-2.3): the entitled party is the buyer if trade date is
before the ex-date, the seller if on/after; a market claim runs seller→buyer when a cum-dividend trade fails to
settle by the record date; a **reverse** claim runs buyer→seller when an ex-dividend trade nonetheless settles
on/before the record date; opted-out/special-ex trades never claim (§2.4); only the unsettled quantity is claimed
on a partial (§2.3c).

## 2. Bracken Foods (USD) — trade-by-trade

| Trade | Qty | Trade date vs ex-date 09-10 | Settled by record date? | Result |
|---|---|---|---|---|
| EQ-S-260908-5490 | 5,000 | cum (09-08) | Yes (09-09) | No claim |
| EQ-B-260909-5501 | 12,000 | cum (09-09) | Yes (09-10) | No claim |
| EQ-B-260909-5502 | 30,000 | cum (09-09) | **No** (09-14, counterparty fail) | **Receivable USD 16,200.00** |
| EQ-S-260909-5503 | 8,000 | cum (09-09) | Settled 09-11 (our fail) — **we kept the shares/dividend past record date** | **Payable USD 4,320.00** |
| EQ-B-260909-5504 | 25,000 (18,000+7,000 partial) | cum (09-09) | 18,000 on time; 7,000 late (09-15) | **Receivable USD 3,780.00** on the 7,000-share balance only |
| EQ-B-260910-5511 | 20,000 | ex (09-10, = ex-date) | n/a (seller entitled, settled on time) | No claim |

**Totals: USD 19,980.00 receivable, USD 4,320.00 payable**, both to account 4410-3104.

US claims are raised gross against the counterparty broker on the claims platform on detection (policy §3.2);
Fenwick's W-9 means no withholding applies. Where Fenwick owes a claim (5503), we **accrue a payable now but do
not release cash** until the counterparty broker presents the claim on/after the payable date (policy §3.3) —
Meridale does not pay pre-emptively.

## 3. Van Oosterlo Holding (EUR) — trade-by-trade

| Trade | Qty | Trade date vs ex-date 09-08 | Settled by record date (09-09)? | Result |
|---|---|---|---|---|
| EQ-S-260904-7088 | 9,000 | cum (09-04) | **No** (09-10, our fail) | **Payable** EUR 7,920.00 gross / **6,732.00 net** — CSD-generated (MC-2609-118902), SETTLED |
| EQ-B-260907-7101 | 15,000 | cum (09-07) | **No** (09-11, counterparty fail) | **Receivable** EUR 13,200.00 gross / **11,220.00 net** — CSD-generated (MC-2609-118834), SETTLED |
| EQ-B-260907-7102 | 10,000 | cum (09-07) | **No** (09-14, settled via ICSD link, not T2S) | **Receivable** EUR 8,800.00 gross / **7,480.00 net** — **not CSD-detected; must be raised manually** |
| EQ-B-260907-7103 | 4,000 | flagged special-ex / mkt_claim_opt_out=Y | n/a | No claim (opt-out, price already ex-dividend) |
| EQ-B-260908-7110 | 6,000 | ex (09-08, = ex-date) but bilateral T+1 settlement landed it **on** the record date (09-09) | n/a | **Reverse claim, payable** EUR 5,280.00 gross / **4,488.00 net** — CSD-generated (RC-2609-020417), PENDING, settles 2026-09-21 |
| EQ-S-260908-7111 | 3,000 | ex (09-08) | n/a (seller entitled, settled 09-10 after record date — still holder at record date) | No claim |

**Totals booked: EUR 18,700.00 receivable (11,220.00 CSD + 7,480.00 manual), EUR 11,220.00 payable (6,732.00 +
4,488.00)**, to account 4410-3107.

**7102 needs a manual claim.** It settled across an ICSD link (Euroclear Bank), not T2S matching, so per policy
§4.3 the CSD never auto-detects it — confirmed by its absence from `t2s_market_claims_report_VANDNL2A_20260918.csv`.
It must be raised through NL sub-custodian Vandermeer Bank (VANDNL2A) **no later than 2026-10-07**, the end of the
20-T2S-business-day detection window running from the 2026-09-09 record date (§4.2/4.3). It is still booked as a
receivable now, on detection, per §6.1.

**All NL claim amounts are net of the standard 15% Dutch dividend tax** (policy §4.4), regardless of Fenwick's
own relief-at-source status — see §5 below.

## 4. EQ-B-260511-6620 — a different, and now time-barred, claim

This is **not** part of the September dividend. It relates to the **prior** Van Oosterlo final dividend
(VOH26DVCA01: ex-date 2026-05-12, record date 2026-05-13, EUR 1.24/sh gross, pay date 2026-05-20 — see the income
ledger). Trade date 2026-05-11 is cum-dividend; the trade settled late (counterparty fail, also via an ICSD link)
on 2026-05-20, after the record date — Fenwick was entitled but not holder of record. In substance this is a
market claim: 7,500 sh × EUR 1.24 = **EUR 9,300.00 gross / EUR 7,905.00 net**.

However, the 20-T2S-business-day detection/manual-raise window for that event closed **2026-06-10** — over three
months ago — and there is no record it was ever raised (absent from both the income ledger and the CSD claims
report). Per policy §5, it is now **time-barred**: it cannot be raised through the sub-custodian or the CSD.
**No receivable is booked.** We are notifying you and the relationship manager in writing, and will only pursue
Harlow Global Markets Ltd (the counterparty) directly on Fenwick's written instruction, with no assurance of
recovery, and no receivable until the counterparty agrees.

## 5. What to tell Tomas

**"Pay the Bracken money now, before the 25th" — decline.** The Bracken dividend (projected USD 129,600.00
gross on the 240,000-share record-date position) has a pay date of 2026-09-25. Per policy §3.4 (and standard
custody practice), proceeds are credited to the client only when Meridale actually receives them, and not before
the payable date — Meridale does not advance funds. The related USD claims receivable (USD 19,980.00) are raised
against the counterparty broker and will be credited only once that payment is actually received, which is not
tied to, and could be later than, the 09-25 pay date.

**"We're an exempt pension plan, so we shouldn't lose any Dutch tax on these [claims]" — correct him.** Fenwick's
NL relief-at-source (Form IB 92 USA + pension trust statement, 0%, valid through 2027-12-31) is real and already
applied to the actual Van Oosterlo dividends (both VOH26DVCA01 and VOH26DVCA02 paid at 0% WHT). It does **not**
extend to market-claim or reverse-claim compensation: per policy §4.4, NL claims are always compensated net of the
standard 15% Dutch dividend tax, in either direction, regardless of the payee's own withholding status, because
claim compensation is not itself an issuer distribution — relief-at-source, exemption and reclaim don't apply to
it. This affects the net amounts on 7088, 7101, 7102 and 7110 above.

**"Get claims in for all of them, at the full dividend"** — most already qualify and are handled as above; three
do not, for documented reasons: 5490, 5501 and 5511 (Bracken) and 7103, 7110* and 7111 (Van Oosterlo) either
already have entitlement matching their record-date holding or were priced ex-dividend by explicit agreement
(7103), or generate a payable rather than a receivable (5503, 7088, 7110). 6620 is a real but now time-barred
claim relating to a different (May) dividend, not the September one he listed — flag this distinction to him
directly, since he may not realize it predates the current event.

*7110 does generate a claim, but it is a **reverse** claim that Fenwick owes, not a receivable — a byproduct of
the bilateral T+1 settlement landing exactly on the record date for a trade that was contractually ex-dividend.

## 6. Bookings made today

Four journal entries posted to the income ledger per policy §6.1 (booked at detection for receivables, at the
CSD-generated or accrued amount for payables):

1. USD claims receivable, USD 19,980.00, account 4410-3104.
2. USD claims payable, USD 4,320.00, account 4410-3104 (accrued only; not paid until presented).
3. EUR claims receivable, EUR 18,700.00, account 4410-3107 (includes the EUR 7,480.00 manual claim on 7102,
   still to be raised with Vandermeer Bank).
4. EUR claims payable, EUR 11,220.00, account 4410-3107 (includes the EUR 4,488.00 reverse claim on 7110,
   pending settlement 2026-09-21).

No entry was posted for EQ-B-260511-6620 (time-barred, see §4) or for EQ-B-260907-7103 (opted out, see §3).

## 7. Assumptions and open items (for the reviewer/auditor)

- Assumed the settlement notes in `fenwick_trade_settlement_status_20260918.csv` ("Counterparty fail", "Our fail",
  "special ex-dividend by agreement", "Bilateral T+1 settlement agreed") are accurate and complete; no independent
  confirmation of fail reasons was available in the inputs provided.
- Assumed EQ-B-260511-6620's claim was never raised in 2026 — consistent with its absence from the income ledger
  and the CSD claims report — rather than raised and separately rejected. If it was in fact attempted and lapsed
  differently, the outcome (time-barred, client instruction required, no receivable) is unchanged, but the
  narrative above should be corrected.
- Fenwick's written instruction is still needed on whether to pursue Harlow Global Markets Ltd directly for the
  time-barred 6620 amount (EUR 7,905.00 net); no further action taken until that instruction arrives.
- Confirmation still needed from Vandermeer Bank that the manual claim on 7102 can be accepted and processed
  before the 2026-10-07 detection deadline.

All figures above are also machine-readable in `out/answer.json`, keyed by trade reference, and validated against
`answer_schema.json`.
