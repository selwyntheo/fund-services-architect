# BEIO — September 2026 Section 19(a) Notice: Reviewed Figures and Findings

**To:** Nadia Okonkwo, Treasurer, Brightwater Equity Income Opportunities Fund
**From:** Oakhurst Fund Administration, CEF Administration
**Re:** September 2026 sources-of-distribution notice — reviewed figures, discrepancies found, and the marketing/tax-alignment question
**Date:** 2026-09-24

## Bottom line

The draft notice (`inputs/notices/BEIO_19a_notice_2026-09_DRAFT_v1.txt`) is **not ready to release**. I reworked the
sources of distribution from the Fund's books under the Plan procedures
(`inputs/policies/BEIO_managed_distribution_plan_19a_procedures.md`, "the Procedures") and found two methodology
errors in the draft, one rounding error, and — in the course of the required month-over-month comparison — a
significant, undisclosed inaccuracy in the **August** notice as sent. On the marketing question: **no**, the
notice cannot be aligned to the tax estimate. Corrected figures, evidence and recommended next steps are below;
they are also in `out/answer.json`.

## 1. Corrected sources of distribution (book basis, per Procedures §4)

| Source | Current distribution (Sept) | % of current | Cumulative FYTD (11/1/25–9/30/26) | % of cumulative |
|---|---:|---:|---:|---:|
| Net investment income | $0.0586 | 51.0% | $0.6578 | 52.8% |
| Net realized short-term gains | $0.0092 | 8.0% | $0.3295 | 26.5% |
| Net realized long-term gains | $0.0000 | 0.0% | $0.0000 | 0.0% |
| Return of capital | $0.0472 | 41.0% | $0.2577 | 20.7% |
| **Total** | **$0.1150** | **100.0%** | **$1.2450** | **100.0%** |

Performance disclosures (as of 8/31/2026, the month-end preceding the 9/30/2026 payment date, per Procedures §3.2):
- Average annual total return, 5 years ended 8/31/2026 (NAV): **7.84%** (draft correct)
- Annualized current distribution rate (0.1150 × 12 ÷ NAV $15.4180): **8.95%** (draft correct)
- Cumulative total return, FYTD through 8/31/2026 (NAV): **9.12%** (draft correct)
- Cumulative FYTD distribution rate ($1.2450 ÷ $15.4180): **8.07%** (draft says 8.08% — rounding error)

A Section 19(a) notice **is required** (the September distribution is not 100% NII). No Rule 19a-1(b) deficit
statement is required: FYTD net realized gains ($6,068,600) plus net unrealized appreciation at 9/23/2026
($51,377,815) total $57,446,415, far exceeding FYTD distributions paid ($22,932,900) — no deficit results
even after giving effect to the payment.

## 2. How the figures were built (so this can be re-performed)

**Sources and basis.** Book-basis GAAP figures only, per Procedures §4.1 — never the tax-basis estimate.

- `inputs/accounting/BEIO_capital_accounts_20251031_and_20260923.csv`: undistributed NII at FY start (10/31/2025)
  = **$412,540**; net unrealized appreciation at 9/23/2026 = $51,377,815; shares outstanding = 18,420,000
  (unchanged all year — confirmed no issuance/repurchase).
- `inputs/accounting/BEIO_book_income_and_realized_gains_FY2026.csv`: monthly NII and net realized ST/LT
  gain(loss), FINAL for Nov 2025–Aug 2026, unaudited daily-NAV MTD through 9/23/2026 for September.
- `inputs/accounting/BEIO_nii_accrual_forecast_20260924_20260930.csv`: September 24–30 NII forecast
  (+$265,910) added to September's actual NII per Procedures §4.2 ("for the current month, NII is actual
  through the latest daily NAV plus the accrual forecast to month-end"). Realized gains are **not** forecast
  (§4.3) — September uses actual-to-9/23 only ($468,220 ST, –$298,430 LT).
- `inputs/distributions/BEIO_distribution_history_FY2026.csv`: 11 monthly distributions FY2026 (Nov 2025–Sep
  2026), total $1.2450/share, $22,932,900; record-date shares 18,420,000 throughout.
- `inputs/performance/BEIO_performance_summary_20260831.csv`: NAV, market price, 5-yr/FYTD total return
  as of 8/31/2026.

**NII available** (§4.2) = start-of-year UNII + FYTD book NII:
- Through August (final, for the "previous cumulative" step): $412,540 + $10,625,010 = $11,037,550
- Through September (current + forecast): $412,540 + $11,703,560 = $12,116,100

**Realized gains available** (§4.3–§4.4), net profits measured in aggregate — a net loss in one category
reduces the other, not below zero, and the loss category is shown as zero:
- Through August (final): ST $8,932,730 net LT loss $3,033,920 → ST available $5,898,810, LT $0
- Through September (current): ST $9,400,950 net LT loss $3,332,350 → ST available $6,068,600, LT $0

**Attribution** (§4.5–§4.6): order is NII → ST gains → LT gains → ROC (balancing figure).
- Cumulative through September (a): NII $12,116,100 / ST $6,068,600 / LT $0 / ROC $4,748,200 (of $22,932,900)
- Cumulative through August (b, previous): NII $11,037,550 / ST $5,898,810 / LT $0 / ROC $3,878,240 (of $20,814,600)
- Current distribution (a) − (b): NII $1,078,550 / ST $169,790 / LT $0 / ROC $869,960 (of $2,118,300) ✓ ties to
  the $0.1150 × 18,420,000 sh distribution

Per-share amounts are dollar amounts ÷ 18,420,000 shares, rounded to 4dp; ROC is the balancing figure so each
column sums exactly to the distribution rate / cumulative-per-share total (§4.7). Percentages are of the
distribution/cumulative total, rounded to 1dp (§3.1/§4.7).

## 3. What's wrong in the draft, and why

1. **Current distribution ST/ROC split (methodology error).** The draft used September's raw monthly realized
   ST gain ($468,220 → $0.0254/sh) directly as the current distribution's ST source. That's not what §4.6
   requires: the current-month split must be the *difference* between the cumulative attribution through the
   current month and through the previous month, each net of the §4.4 aggregate-netting rule. Because the FYTD
   net realized long-term loss deepened by $298,430 in September, the correct incremental ST amount is
   $468,220 − $298,430 = $169,790 → **$0.0092/sh (8.0%)**, not $0.0254 (22.1%). This understated ROC by
   $0.0162/sh: correct current ROC is **$0.0472/sh (41.0%)**, not the draft's $0.0310 (27.0%).
2. **Cumulative NII (methodology error).** The draft's cumulative NII ($0.6354/sh) omits the $412,540
   start-of-year UNII carryforward required by §4.2. Correct cumulative NII is **$0.6578/sh (52.8%)**. (The
   August notice as sent got this right — $0.5992/sh ties exactly to $412,540 + FYTD-through-August NII — so
   this omission is new to the September draft.)
3. **Cumulative ST/ROC split (same §4.4 netting error, cumulative level).** The draft's cumulative ST figure
   ($0.5104/sh, 41.0%) is the raw FYTD realized ST gain with no netting against the $3,332,350 FYTD net
   realized LT loss. Netted per §4.4, cumulative ST is **$0.3295/sh (26.5%)**, and cumulative ROC (the
   balancing figure) is **$0.2577/sh (20.7%)**, not the draft's $0.0992 (8.0%).
4. **Cumulative FYTD distribution rate (rounding).** $1.2450 ÷ $15.4180 = 8.0750%, which rounds to **8.07%**,
   not the 8.08% in the draft.

## 4. The August 2026 notice — significant prior-period inaccuracy (Procedures §5.1)

Re-running the "previous cumulative" step (§4.6(b)) through 8/31/2026 on final books — correctly netting the
FYTD LT loss into ST per §4.4 — gives NII $0.5992/sh (unchanged), **ST $0.3202/sh**, LT $0.0000/sh, **ROC
$0.2106/sh**. The notice actually sent 8/25/2026 (`inputs/notices/BEIO_19a_notice_2026-08_AS_SENT.txt`) stated
ST $0.4849/sh and ROC $0.0459/sh — a **$0.1647/sh** difference on both lines, i.e. the same netting error was
already present in August. This exceeds the $0.0100/sh threshold in §5.1, so it must be treated as a
significant inaccuracy in a previously reported estimate:

- (i) **Notify the CCO and the Treasurer before the September notice is released** — recorded as an escalation
  in `answer.json`.
- (ii) **Include a statement in the September notice** that previously reported cumulative estimates have
  changed.
- (iii) **Flag it for the next report to shareholders.**

I don't have the FY2026 notices for November 2025–July 2026 to check whether the same defect reaches further
back; recommend pulling those to confirm the scope of the correction (see Open Questions).

## 5. Talia Ruiz's question — can we align the 19(a) with the tax estimate?

**No.** Procedures §4.1 is explicit: "Tax-basis character estimates prepared for Form 1099-DIV are not used
for Section 19(a) purposes." The tax team's estimate
(`inputs/tax/BEIO_tax_character_estimate_FY2026_20260915.csv`) is a full-year federal-tax projection that
reflects straddle-loss deferrals (IRC §1092), wash-sale deferrals and REIT/MLP recharacterizations — none of
which have any bearing on the book-basis, monthly §19(a) calculation. Book and tax character are legitimately
different, and final tax character isn't even knowable until after fiscal year-end (10/31/2026). The 19(a)
notice should keep showing real return of capital (41.0% of the September distribution, 20.7% cumulative
FYTD) — that reflects the Fund's actual book-basis distribution sourcing under the Plan, and conforming it to
the tax estimate would itself be inaccurate and understate ROC to shareholders. Recommend the Treasurer relay
this to marketing along with the corrected split above for their messaging, rather than changing the notice.

## Assumptions

- "The current month" for §4.1/§4.2 purposes is September 2026 (calendar month containing the 9/30/2026
  payable date).
- September's book close is not final; the current-distribution figures rely on the accrual forecast in
  `BEIO_nii_accrual_forecast_20260924_20260930.csv` for the NII portion of 9/24–9/30, as the Procedures direct.
  Realized gains are not forecast, consistent with §4.3 and the forecast file's own note.
- No shares were issued or repurchased in FY2026 (per the capital-accounts file's note); 18,420,000 shares
  used throughout for both current and cumulative per-share figures, consistent with the record-date share
  counts in the distribution history.
- "The last notice" for the §5.1 comparison is the August 2026 notice as sent (the most recent one provided).

## Open questions / what I need, and from whom

1. **Oakhurst files (self / prior preparer):** the FY2026 19(a) notices for November 2025–July 2026, to
   determine whether the same short-term/long-term netting error (found in August) also affected earlier
   months, and therefore the full scope of the §5.1(iii) shareholder-report flag.
2. **Fund accounting / Treasurer:** confirmation that the September 24–30 accrual forecast is still a
   reasonable estimate as of notice release; if the actual September close (available after month-end) departs
   materially from the forecast, the current-distribution split above should be revisited before the TA insert
   file is finalized, or a subsequent correction disclosed.
3. **Treasurer:** approval of the corrected figures and the required §5.1(ii) "previously reported estimates
   have changed" disclosure language, before anything is released to the transfer agent, press wire, or
   website (per Procedures §6.1 — nothing is released until the Treasurer approves).

## Files relied on

- `inputs/notices/BEIO_19a_notice_2026-09_DRAFT_v1.txt`, `inputs/notices/BEIO_19a_notice_2026-08_AS_SENT.txt`
- `inputs/policies/BEIO_managed_distribution_plan_19a_procedures.md`
- `inputs/accounting/BEIO_book_income_and_realized_gains_FY2026.csv`
- `inputs/accounting/BEIO_capital_accounts_20251031_and_20260923.csv`
- `inputs/accounting/BEIO_nii_accrual_forecast_20260924_20260930.csv`
- `inputs/distributions/BEIO_distribution_history_FY2026.csv`
- `inputs/performance/BEIO_performance_summary_20260831.csv`
- `inputs/tax/BEIO_tax_character_estimate_FY2026_20260915.csv`
- `inputs/correspondence/email_Ruiz_marketing_20260923.txt`
