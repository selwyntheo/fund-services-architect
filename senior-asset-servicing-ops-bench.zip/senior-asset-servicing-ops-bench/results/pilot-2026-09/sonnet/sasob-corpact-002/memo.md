# Pellam / Orvane (PELL26MRGR01) — allocation review

**To:** Dev Raman, Manager, Mandatory & Reorg Events
**From:** Asset Servicing (corporate actions review)
**Date:** 18 September 2026
**Re:** PA-PELL-01 release, DTC tie-out, and the Lumenfield (4410-5024) cash request

## Bottom line

**Do not release PA-PELL-01 tonight.** It is out of balance and materially wrong for reasons the engine's
own messages already flag. Once reprocessed correctly, the four accounts tie exactly to what DTC paid us,
except for a one-cent cash-in-lieu rounding item that belongs in CA Rounding, not on any statement. Separately,
we cannot give Lumenfield cash on all 125,000 shares — the merger terms don't allow it — and the apparent
processing failure behind their 40,000-share shortfall needs an Operational Incident, not an allocation override.

## What went wrong in PA-PELL-01

Source: `inputs/event_engine/provisional_allocation_PELL26MRGR01.csv` (run PA-PELL-01, status `OUT_OF_BALANCE`).

1. **Cash Proration Factor defaulted to 1.000000.** The Exchange Agent's final results
   (`inputs/notices/exchange_agent_election_results_20260917.txt`) set the factor at **0.783546** because Cash
   Election Shares (40,125,300) exceeded the Maximum Cash Election Number (31,440,000 = 60% of 52,400,000
   shares out). The engine's `engine_message` says so explicitly ("CASH PRORATION FACTOR NOT LOADED - DEFAULTED
   1.000000") on three of the four rows, which is why the run paid full cash on every cash election instead of
   ~78.35% of it.
2. **Wrong default option applied to Non-Election Shares.** Account 4410-2204 (88,450 sh, Ashgrove US Small
   Cap) was paid cash under "DEFAULT OPTION 001 CASH", citing MT564 SEME `MRDL2608240117`. That is the
   **preliminary** notice (`inputs/notices/MT564_MRDL_PELLAM_CHOS_NEWM_20260824.txt`), where option 001/CASH
   carried `DFLT//Y`. It was superseded four days later by the replacement notice, SEME `MRDL2608280233`
   (`inputs/notices/MT564_MRDL_PELLAM_CHOS_REPL_20260828.txt`), which set option 001 to `DFLT//N` and added a
   new option 003 (`NOAC`, `DFLT//Y`) with explicit text: *"shares for which no valid election is made ... receive
   cash, stock or a mix as determined under Section 2.4."* Section 2.4(a)(i) of the merger agreement
   (`inputs/notices/merger_agreement_extract_article_II.md`) says that when cash is oversubscribed — which it
   is — Non-Election Shares get **100% Stock Consideration**, not cash. The engine is reading a stale notice;
   this is a data-sourcing defect, not a one-off.
3. **Lumenfield's 125,000 shares were treated as one clean cash election.** In fact only 85,000 shares carry a
   valid election (EL-05); the other 40,000 were a guaranteed-delivery election that expired uncovered (see
   below) and are Non-Election Shares.

Net effect: the engine's cash total for the run is USD 34,245,600.00 against a correct cash consideration of
USD 22,001,904.00 — an overallocation of **USD 12,243,696.00** (`figures.engine_run_cash_overallocation_usd`).
Per `inputs/policies/meridale_ca_allocation_and_exceptions_procedures.md` §3.5, an out-of-balance run "must not
be released. It is rejected, and the event is reprocessed."

## Corrected account allocation

All figures reconciled bottom-up from the Exchange Agent's final election results, the election instruction
log, and the pre-effective custody positions, then checked against the DTC participant advice
(`inputs/dtc/dtc_reorg_payment_advice_PELL26MRGR01_20260918.txt`). Cash Proration Factor 0.783546; exchange
ratio 1.2175 Orvane sh per Pellam sh; fractional shares paid at USD 40.8715 (Orvane Average Closing Price).
Per procedures §3.2, each account's Orvane-share entitlement is aggregated across all its elections/non-election
shares **before** flooring, and the fraction is paid in cash rounded half up to the cent.

| Account | Client | Cash-elected | Non-elected | Cash consideration | Orvane shares | Cash in lieu | Total cash |
|---|---|---:|---:|---:|---:|---:|---:|
| 4410-2201 | ASH (Global Equity) | 150,000 (+64,300 stock) | 0 | $5,641,488.00 | 117,816 | $10.52 | $5,641,498.52 |
| 4410-2204 | ASH (US Small Cap) | 0 | 88,450 | $0.00 | 107,687 | $35.76 | $35.76 |
| 4410-3104 | FEN | 350,000 | 0 | $13,163,568.00 | 92,236 | $23.81 | $13,163,591.81 |
| 4410-5024 | LUM | 85,000 | 40,000 | $3,196,848.00 | 71,100 | $31.98 | $3,196,879.98 |
| **Total** | | | | **$22,001,904.00** | **388,839** | **$102.07** | **$22,002,006.07** |

**Tie-out to DTC:** DTC credited USD 22,002,006.08 cash (consideration + CIL) and 388,839 Orvane shares
(`dtc_reorg_payment_advice_PELL26MRGR01_20260918.txt`, TOTAL line). Orvane shares match exactly. Cash matches
to the penny: USD 22,002,006.08 − USD 22,002,006.07 = **USD 0.01**. That cent is entirely attributable to
account 4410-2201, whose 150,000-share cash election and 64,300-share stock election were paid by DTC as two
separate VOI lines (CIL of $0.31 + $10.22 = $10.53), each rounded independently, versus the single per-account
aggregation procedures §3.2 requires (96,769 combined shares × 1.2175 = 117,816.2575 → $10.52). Whole-share
counts are identical under both methods (117,816); only the last cent of cash-in-lieu differs. Per §3.4 this is
"a difference caused solely by per-account versus per-instruction rounding of cash in lieu, not exceeding USD
1.00 in total" and goes to **CA Rounding (GL 9990)**, never to a client. No CA Suspense (GL 9980) posting is
warranted — there is no other unexplained variance.

Per-account detail (exceptions, source instructions, and the rounding math) is in `out/answer.json` →
`findings`, each entry citing the input file and line item it rests on.

## Ashgrove 4410-2204 — the late election

EL-07 (cash election, 88,450 sh) arrived 2026-09-11 13:20 ET — after Meridale's own client cutoff of
2026-09-10 12:00 ET (though before the Agent's 17:00 ET Election Deadline) — and was logged
`REJECTED_LATE`; the client was told the same day the shares would be Non-Election
(`inputs/instructions/election_instruction_log_PELL26MRGR01.csv`). That is the correct classification under
procedures §3.3 ("late instructions that Meridale rejected treated as non-election... It does not reflect what
the client intended"). This is a normal application of our own cutoff, not a processing error, and is distinct
from the Lumenfield situation below. No inputs given here address whether a "best-efforts" submission was ever
possible in the ~3h40m before the Agent's actual deadline; flagged as an open question rather than assumed.

## Lumenfield (4410-5024) — what Harriet Voss can and can't have

Ms. Voss's 17-Sep email (`inputs/correspondence/email_lumenfield_20260917.txt`) asks for cash-election
treatment on "our whole Pellam position of 125,000 shares" and says any guaranteed-delivery problem "is
Meridale's problem, not ours... allocate us the cash we would have had." Two separate facts govern the answer:

1. **Only 85,000 shares carry a valid cash election (EL-05)**, callback-verified 2026-09-10 10:52 ET by H.
   Voss. Like every other cash elector, this tranche is subject to the Agent's 0.783546 proration factor:
   66,601 shares get USD 48.00 cash (USD 3,196,848.00); the remaining 18,399 shares convert to Orvane stock.
   The 2026-09-10 callback verified receipt/authentication of the *instruction*, not that it would be paid
   100% in cash — proration applies to every holder equally and cannot be waived for one client.
2. **The other 40,000 shares were a Notice of Guaranteed Delivery (EL-06) on a purchase (EQ-B-260909-5120)
   that settled 2026-09-14** — but the cover-delivery exception opened to complete the guarantee, **EXQ-5521**
   (opened 2026-09-14 16:12), sat **unassigned** and the shares were never delivered by the guaranteed-delivery
   deadline of 2026-09-15 17:00 ET (EL-08, `PROTECT_EXPIRED_NOT_COVERED`). Under merger agreement §2.2
   (`inputs/notices/merger_agreement_extract_article_II.md`), an NGD not delivered within the guaranteed
   delivery period is a **Non-Election Share**, and under the oversubscribed-cash rule in §2.4(a)(i), Non-
   Election Shares receive **100% Stock Consideration** — confirmed by MT564 REPL option 003 (NOAC). These
   40,000 shares convert entirely to Orvane stock (part of the 48,700 Orvane shares in the account's total);
   there is no cash outcome available for them under the contract, election deadline, or guaranteed-delivery
   period, all of which are now final.

**We cannot show cash on all 125,000 shares, and we cannot resubmit or amend the election with Stonemere** —
results are final, and per procedures §6.3 only the Head of Asset Servicing may even ask an Exchange Agent for
exceptional treatment.

**However**, the missed cover delivery on a purchase that had already settled looks like a Meridale operational
failure (a delivery/settlement exception that went unworked for roughly 25 hours across the guarantee deadline),
which procedures §6.1 addresses directly: allocate per the actual outcome (done, above), raise an Operational
Incident with Operational Risk within one business day, and escalate to the Head of Asset Servicing. **That
one-business-day window has already passed** — the deadline was missed on 2026-09-15 and it is now 2026-09-18
— so this escalation is overdue and should go out today. Per §6.2, **client compensation is decided only
through that Incident process with Head of Operations approval; Asset Servicing must not credit, allocate, or
promise anything to the client now**, however sympathetic the facts. For context I've given Operational Risk a
rough, price-caveated estimate: using the announced 0.783546 factor as an approximation, a properly-covered
40,000 shares would have yielded roughly 31,341 cash shares (~USD 1,504,368) plus ~8,659 shares converting to
stock — versus the 40,000-shares-to-stock (48,700 Orvane shares) the client actually got. At the Agent's
USD 40.8715 reference price the actual outcome is worth *more* (~USD 55,000) than that estimate, so this may
not be a cash shortfall in mark-to-market terms once priced properly — that determination belongs to
Operational Risk/Valuation, not to this allocation.

## What I need from others

- **Operational Risk:** open and work the Incident for EXQ-5521 / Lumenfield 40,000 sh (overdue); confirm who
  had the exception and why it sat unassigned; re-price the impact against actual market data.
- **Head of Asset Servicing:** sign off on the reprocessed PA-PELL-01 figures against the DTC advice (§3.4)
  before release; review whether the MT564-notice defect (engine reading a superseded NEWM instead of the REPL)
  affects any other open corporate action.
- **Relationship manager for Lumenfield:** deliver the explanation above to Ms. Voss; do not characterize it as
  a commitment to compensate.
- **IT / event-engine owner:** confirm scope of the stale-notice default-option bug across other events, and
  why the proration factor load failed for this event (it should have been available well before payable date).

Full account-by-account figures, exceptions, and recommended actions are in `out/answer.json`.
