# CGEF / Tarrant Hollis 9/17 trades — analysis and recommendation

**To:** Mara Lindqvist, Treasurer & PFO, Corvane Investment Trust
**Re:** Ken Osterhaut's (Stellmark) 9/18 note on the four surveillance-flagged Tarrant Hollis orders in CGEF, trade date 9/17
**Bottom line:** Do not let Ken close the surveillance items at the 9/17 price. Six order lines (not four) are late or partly late. Leaving them as processed costs the Fund a net $118,753.81; the gross Fund Loss on the late purchases alone is $123,758.81. Neither the 9/17 nor the 9/18 published NAV needs to be restated — this is a trade-date/late-trading problem, not a NAV-calculation error.

## 1. What I looked at

- `inputs/agreements/tarrant_hollis_intermediary_agreement_excerpt.md` — Articles 4 (receipt/time-stamping/transmission) and 9 (indemnification) of the Fund Services and Order Processing Agreement.
- `inputs/policies/CIT_order_acceptance_and_late_trading_procedures.md` — pricing/late-order/escalation rules and the impact-measurement formula (§4).
- `inputs/policies/CIT_NAV_error_correction_policy.md` — Material Day test (§1.4), reprocessing and Fund Loss rules (§§4–7).
- `inputs/intermediary/tarrant_hollis_order_entry_audit_CGEF_20260917.csv` — Tarrant Hollis's own order-entry time stamps, branch, time zone, and modification history for the 12 orders.
- `inputs/transfer_agent/fundserv_transmissions_THS_CGEF_tradedate_20260917.txt` — the two Fund/SERV-style batches (FS1, received by Stellmark 2026-09-18 06:52:14 ET; FS2 supplemental, received 2026-09-18 09:41:37 ET) and the trade date/quantity per order as transmitted.
- `inputs/transfer_agent/ta_processing_report_CGEF_tradedate_20260917.csv` — how each order was actually priced, settled, and which four carry Stellmark's `SURV-LATE-REVIEW` exception flag.
- `inputs/nav/published_nav_CGEF_20260915_20260918.csv` — final NAV, total net assets, and shares outstanding for 9/15–9/18.
- `inputs/market/newswire_20260917.txt` — Harrowgate/Selden acquisition announced 16:09 ET 9/17 (a 38% premium), confirming the market-moving event behind the surveillance flag.
- `inputs/correspondence/email_stellmark_ta_supervisor_20260918.txt` — Ken's account of Tarrant Hollis's position and his Monday 9am deadline.

All 12 orders are keyed to the Trust's Article 4 "Close" (4:00:00 pm ET, 9/17/2026, a normal-hours day per the newswire's 4:00 pm close reference).

## 2. Order-by-order determination

Branch times were converted to Eastern (Chicago = ET −1h in September DST; San Francisco = ET −3h). Full detail is in `answer.json → findings`.

| Order | Branch (local time) | Time in ET | Basis/side | Verdict | Reason |
|---|---|---|---|---|---|
| 5501 | NY 10:14:22 | 10:14:22 | $250,000 BUY | Timely | before close |
| 5502 | NY 13:47:05 | 13:47:05 | 3,000 sh SELL | Timely | before close |
| 5503 | Chicago 14:32:10 | 15:32:10 | $80,000 BUY | Timely | before close |
| **5504** | Chicago 15:18:44 | **16:18:44** | $1,500,000 BUY | **Late** | received at/after close |
| **5505** | Chicago 15:26:09 | **16:26:09** | $2,250,000 BUY | **Late** | received at/after close |
| 5506 | NY 15:59:58 | 15:59:58 | $120,000 BUY | Timely | 2 sec before close |
| **5507** | NY 16:00:00 | **16:00:00** | 4,500 sh SELL | **Late** | "at" the close — see note below |
| **5508** | NY 15:52:31 → increase 16:12:40 | 15:52:31 / **16:12:40** | $400,000 BUY + $1,000,000 increase | **Split** | base timely; increase is a new order after close (Agreement §4.4) |
| **5509** | NY 15:47:03 (entered), transmitted in FS2, received by TA 09:41:37 ET 9/18 | — | $300,000 BUY | **Late** | transmitted after the 9:00 am ET deadline (Agreement §4.3) |
| 5510 | NY 11:05:40 | 11:05:40 | 1,200 sh SELL | Timely | before close |
| 5511 | SF 12:40:00 | 15:40:00 | $60,000 BUY | Timely | before close |
| **5512** | SF 13:05:30 | **16:05:30** | 2,000 sh SELL | **Late** | received at/after close |

**Note on 5507 (16:00:00 exactly).** Agreement §4.1 requires receipt "before" the close for same-day treatment; §4.2 sweeps in anything "at or after" the close. A time stamp of exactly 16:00:00 is not strictly *before* 16:00:00, so I have treated it as late under the plain contract language. This is the closest call in the set (see Open Questions) — if Tarrant Hollis can show its clock rounds down or that the true receipt was a fraction of a second before 4:00:00 pm, this order would flip to timely. I did not find any basis in the record to give it the benefit of the doubt on the current evidence, and note that this order was **not** among the four surveillance flagged (surveillance was tuned to large purchases, not redemptions), which is itself a control gap worth flagging.

**Why Ken's/Tarrant Hollis's three arguments don't hold up:**
1. *"Chicago branch timestamps are local, so obviously before the close."* Once converted from Central to Eastern (add 1 hour), 5503 is fine (15:32:10 ET) but 5504 and 5505 land at 16:18:44 and 16:26:09 ET — 18 and 26 minutes **after** the close.
2. *"The 5508 order was placed before 4 and only topped up."* Agreement §4.4 is explicit: an order may not be increased after the close, and any increase made at or after the close "constitutes a new order for the amount of the increase, received at the time of the increase." The $400,000 base order (15:52:31 ET) stays timely; the $1,000,000 increase (16:12:40 ET) is a new, late order regardless of when the original ticket was opened.
3. *"The supplemental file [5509] was a systems delay on their side."* Irrelevant to pricing. Agreement §4.3 requires transmission to reach the Transfer Agent by 9:00 am ET the next Business Day; if it doesn't, the order "shall be treated as received by the Trust when received by the Transfer Agent... **notwithstanding any earlier trade date shown on the transmission**." FS2 arrived at 09:41:37 ET, 41 minutes late. Whose fault the delay was doesn't change the pricing outcome (though it does confirm Tarrant Hollis, not Stellmark, is the Responsible Party — see §5).

None of the four surveillance items and none of the two additional redemptions we found qualify for same-day pricing. Order Acceptance and Late Trading Procedures §2 is categorical: "no officer may authorise" processing a late order at the prior day's NAV, so Ken's proposed default (do nothing by Monday) is not an available option under the Trust's own procedures.

## 3. Dollar impact if left at the 9/17 NAV

Both NAVs are `FINAL` and unrounded per `published_nav_CGEF_20260915_20260918.csv`: 9/17 = $31.42, 9/18 = $32.19 (Harrowgate's 38% takeover premium plus a broad market rally drove the jump — see newswire).

Per Order Acceptance and Late Trading Procedures §4: purchases — (shares issued − shares that would have been issued at the correct NAV) × correct NAV; redemptions — shares redeemed × (NAV applied − correct NAV); shares to 3 decimals, round half up.

| Order | Late $ or shares | Shares @ 31.42 | Shares that should apply @ 32.19 | Impact (USD) |
|---|---|---|---|---|
| 5504 | $1,500,000 | 47,740.293 | 46,598.322 | +36,760.05 |
| 5505 | $2,250,000 | 71,610.439 | 69,897.484 | +55,140.02 |
| 5508 (increase) | $1,000,000 | 31,826.862 | 31,065.548 | +24,506.70 |
| 5509 | $300,000 | 9,548.059 | 9,319.664 | +7,352.04 |
| 5507 | 4,500 sh redeemed | — | — | −3,465.00 |
| 5512 | 2,000 sh redeemed | — | — | −1,540.00 |

- **Late purchase amount:** $5,050,000 (not the $5.45mm Ken cites for four orders — his figure includes the $400,000 portion of 5508 that was genuinely timely).
- **Excess shares issued to late purchasers** (if left at 31.42): 3,844.635 shares.
- **Gross Fund Loss on the late purchases** (§4/§6.1 formula, positive = dilution): **$123,758.81.** This is money the *continuing* CGEF shareholders lose to the late buyers, who got yesterday's (pre-rally) price the day after a 38% take-out premium was announced — textbook late-trading dilution.
- **Late redemption shares:** 6,500 (5507 + 5512). Because these redeemers were paid out at the *lower* 9/17 NAV rather than the higher 9/18 NAV, they were underpaid $5,005.00 combined (−$3,465.00 and −$1,540.00). Per NAV Error Correction Policy §5.1(b), an account that received *less* value than it should have must be made whole by cash payment of the shortfall — the Fund now owes these two sub-accounts $5,005.00. This is **not** a "Fund Loss" under §6.1 (the Fund didn't give up value on those two transactions; it under-paid), so it is not netted against the purchase-side dilution, per §6.2 ("Fund Losses are not reduced by gains... on other transactions").
- **Net USD impact if everything is simply left at the 9/17 NAV** (purchase dilution net of the redemption shortfall, i.e. the schema's `dilution_if_processed_at_0917_nav_usd`): **$118,753.81.**
- **All-in amount to recover from Tarrant Hollis** (gross Fund Loss + funding the redemption make-whole): **$128,763.81**, per Article 9.2's indemnification for Article 4 failures.

(Minor note: summing the individually-rounded per-order impacts above gives $123,758.81 / $118,753.81; computing the same totals from unrounded intermediate figures gives $123,758.80 / $118,753.80 — a $0.01 rounding artifact, immaterial either way.)

## 4. Is today's (9/18) NAV affected? Does 9/17 need to be restated?

No, on both counts. I recomputed each day's net assets and shares outstanding with the six late items pulled out of 9/17's capital stock and reallocated to 9/18 at the corrected $32.19 NAV:

- **9/17:** published NAV $31.42 (unrounded $31.42130...); with the late trades removed, net assets fall to $825,266,450.50 and shares outstanding fall to 26,264,548.252, giving a recomputed NAV of $31.421308 — a move of **+$0.0013/share**.
- **9/18:** published NAV $32.19 (unrounded $32.18740...); with the late trades added back at the correct price, net assets rise to $860,888,605.83 and shares outstanding rise to 26,746,124.720, giving a recomputed NAV of $32.187415 — a move of **−$0.0026/share**.

Both moves are far below the Trust's Material Day threshold (NAV Error Correction Policy §1.4: **both** $0.01/share or more **and** 0.50% of Corrected NAV). This is expected: dollar-for-share subscriptions and redemptions are neutral to NAV per share as long as they're struck at *a* NAV — the harm here is that six line items were struck at the *wrong day's* NAV, which reallocates value between the late-trading investors and continuing shareholders, but doesn't materially move the published price level on either day. Consistent with Order Acceptance and Late Trading Procedures §6, because correcting these orders does not move a NAV already struck, this stays a late-trading matter handled order-by-order rather than a NAV-error matter triggering NAV Error Correction Policy §§4–6 restatement machinery. `nav_0918_restatement_required = false`.

## 5. Who is responsible, and who needs to hear about this

**Responsible Party: Tarrant Hollis Securities LLC (the intermediary).** Every late item traces to an Article 4 failure on Tarrant Hollis's side — orders entered after the close (5504, 5505, 5507, 5512), an order increase made after the close (5508), and a transmission that missed the Article 4.3 deadline (5509, which Tarrant Hollis itself attributes to "a systems delay on their side"). Article 9.2 obligates Tarrant Hollis to indemnify the Trust for exactly this kind of loss.

**Escalations / notifications recommended (see `answer.json → actions` for full detail):**
- **CCO — same day** (Order Acceptance and Late Trading Procedures §5 requires same-day reporting of any order received after the close but priced at that day's NAV; this is already a day overdue). Flag sub-account A-40021 (Chicago) specifically — it placed both $1.5mm and $2.25mm late buys eight minutes apart, immediately after the acquisition news, which the CCO may want to review under Rule 22c-2.
- **Fund Treasurer (you)** — approval of the correction calculation before any reprocessing (NAV Error Correction Policy §8.1), and confirmation that no Material Day resulted.
- **Transfer Agent (Stellmark)** — instructed to hold/not close the surveillance items, then cancel-and-rebill the six late items at the 9/18 NAV and pay the $5,005.00 redemption shortfall.
- **Tarrant Hollis** — formal reimbursement demand for $128,763.81, plus a request for underlying beneficial-owner identity (needed for 22c-2 and for the $10.00 de minimis test under §5.3), the customer authorization for the 5508 increase, and confirmation of branch system clock synchronization.
- **Board** — logged for the quarterly NAV error log report (§8.3); no Material Day, so no immediate Board notice is required unless the CCO decides the A-40021 pattern warrants it.

## 6. Assumptions and what I need from whom

- Assumed 9/17/2026 was a normal 4:00:00 pm ET close (the newswire's Friday 9/18 "CLOSE: 16:02 ET" entry is consistent with normal hours; nothing in the inputs indicates an early close).
- Treated the FS1 batch's TA-receipt timestamp (2026-09-18 06:52:14 ET) as the `ta_receipt_time_et` for every order carried in that file, and the FS2 batch's (2026-09-18 09:41:37 ET) for 5509, since receipt is logged at the file/batch level in the Fund/SERV transmission log provided.
- Treated the TH-260917-5507 (exactly 16:00:00 ET) as late under the plain "before/at-or-after" language of Agreement §4.1–4.2. **Open question below** — please confirm with Tarrant Hollis whether their system timestamp resolution/rounding could actually put this order a fraction of a second before the close.
- Split TH-260917-5508 by allocating the $1,400,000 total processed shares (44,557.607) between a $400,000 base tranche (12,730.745 sh at $31.42) and a $1,000,000 late tranche (31,826.862 sh) — the two amounts foot to the TA's recorded total.
- Did not have, and could not independently verify, underlying beneficial-owner detail behind the Tarrant Hollis omnibus account (900011); per NAV Error Correction Policy §5.4 that allocation is the intermediary's responsibility, and per §5.3 a $10.00 de minimis threshold applies per account, so the two redemption make-whole amounts owed to specific beneficial owners will need Tarrant Hollis's allocation before payment (both amounts as computed at the omnibus/sub-account level, $3,465.00 and $1,540.00, are well above $10.00, so materiality is not in question at that level — this only affects further sub-allocation if a sub-account nets to multiple beneficial owners).

### Open questions (see also `answer.json → open_questions`)
1. Clock synchronization/rounding evidence for the Chicago and San Francisco branch systems, and specifically whether TH-260917-5507's 16:00:00 timestamp could actually predate the close.
2. The customer order ticket/authorization for the TH-260917-5508 increase (to confirm it isn't a correction of a documented error, which §4.4 would treat differently — though an *increase* cannot use that exception regardless).
3. Underlying beneficial owner identities behind the affected sub-accounts, from Tarrant Hollis, for 22c-2 review and individual make-whole recordkeeping.
4. Confirmation from Fund Accounting that no separate, unrelated NAV error is compounding this one (we only tested the effect of the late-trade reallocation itself).
5. Whether Stellmark's TA system can re-date already-settled trades (settle date shown as 9/18, status SETTLED) to trade date 9/18 without an additional manual/off-cycle control step.
