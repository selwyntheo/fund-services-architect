# CMOF — Ostrander Micro Devices (OSMD) pricing error, 9/10–9/17
**To:** Mara Lindqvist, Treasurer & PFO, Corvane Investment Trust
**Re:** Recommendation before your 2pm with Stellmark
**Bottom line:** Don't sign Rafael's proposal as drafted. Reimbursement due from Stellmark is **$43,724.90**, not ~$12k, and only three of the five days should be reprocessed.

---

## 1. What happened

Ostrander Micro Devices (OSMD, ISIN USI13SGK4260) moved its listing from NYSE to Nasdaq effective the open of 2026‑09‑10. The primary pricing vendor's feed continued to reference the delisted NYSE line and kept delivering the stale NYSE close of **$48.20** every day from 9/10 through 9/16 (`inputs/pricing/primary_vendor_notice_QPS-558120.txt`, ticket QPS‑558120). The mapping was fixed in the file delivered 9/17, and 9/17's NAV was struck correctly on the Nasdaq official close.

Stellmark's own pricing exception log (`inputs/pricing/price_exception_log_CMOF_20260910_20260917.csv`) shows OSMD triggered an **unchanged‑price exception every single day 9/10–9/16** and was cleared as `ACCEPT_PRIMARY` (i.e., kept at $48.20) each time:

| Date | Exception type | Secondary (Nasdaq official close) | Resolution basis | Schedule C compliant? |
|---|---|---|---|---|
| 9/10 | UNCHANGED_PRICE | 47.10 | "Within tolerance" | **No** — C.3 bars clearing an unchanged‑price exception on tolerance grounds |
| 9/11 | UNCHANGED_PRICE;TOLERANCE_BREACH | 45.60 | "Vendor says price will update" | **No** — C.4 bars using a vendor's "will update" statement to clear an exception |
| 9/14 | UNCHANGED_PRICE;TOLERANCE_BREACH | 44.90 | "Vendor ticket QPS‑558120 open" | **No** — same C.4 issue |
| 9/15 | UNCHANGED_PRICE | 47.35 | "Within tolerance" | **No** — same C.3 issue |
| 9/16 | UNCHANGED_PRICE;TOLERANCE_BREACH | 51.10 | "Vendor ticket still open" | **No** — same C.4 issue |
| 9/17 | UNCHANGED_PRICE;TOLERANCE_BREACH | 50.62 | Escalated by NAV oversight; Nasdaq official close used | Yes |

Corvane's own PM desk flagged the discrepancy on **9/11** (`inputs/correspondence/email_corvane_pm_desk_20260911.txt`: "It printed 45.60 on Nasdaq today... Can someone ask Stellmark to check before they release?"), yet Stellmark cleared the same exception on the same disallowed basis for three more days.

## 2. Corrected NAVs (policy 1.2: restate OSMD only, published shares outstanding, $0.01 rounding)

Corrected price each day = the Nasdaq official close already sitting in Stellmark's own log as the "secondary" price (this *is* the official closing price of OSMD's primary listing exchange post‑transfer, so it is the correct input under Schedule C.3). Position held: 1,200,000 sh through 9/14; 1,000,000 sh from 9/15 (after the 200,000‑share sale, trade date 9/15/settle 9/16, in `inputs/portfolio/trade_blotter_CMOF_20260910_20260916.csv` — same trade Oren Blakeslee flagged he'd be placing).

| Date | Published NAV | Corrected NAV | Error/sh | % of corrected NAV | Material? |
|---|---|---|---|---|---|
| 9/10 | 24.34 | 24.26 | 0.08 | 0.3298% | No (< 0.50%) |
| 9/11 | 24.24 | 24.05 | 0.19 | 0.7900% | **Yes** |
| 9/14 | 24.37 | 24.13 | 0.24 | 0.9946% | **Yes** |
| 9/15 | 24.37 | 24.32 | 0.05 | 0.2056% | No (< 0.50%) |
| 9/16 | 24.40 | 24.58 | ‑0.18 (understated) | ‑0.7323% | **Yes** |
| 9/17 | 24.52 | 24.52 | 0.00 | — | n/a — already clean |

A Material Day requires **both** ≥$0.01/share **and** ≥0.50% (policy 1.4). 9/10 and 9/15 miss the 0.50% leg and are **not** Material Days: per policy 3.1, no shareholder transactions are reprocessed and no reimbursement is sought for those two days. Note 9/16 flips direction — by then the corrected (Nasdaq) price had risen above the stale primary price, so the published NAV was *understated*, not overstated. No catch‑up book entry is needed for the two non‑Material days: each Material Day is independently re‑struck at the correct price the very next time it's tested (policy 1.2 treats each day on its own facts), so there's no rolling balance‑sheet effect to sweep forward. The two non‑Material misstatements are simply logged for the quarterly Board report (8.3).

## 3. Reprocessing the three Material Days (9/11, 9/14, 9/16)

Recalculated per policy 4.1/4.2 from `inputs/transfer_agent/ta_transaction_detail_CMOF_20260910_20260917.csv`: dollar orders hold the dollar amount constant and recompute shares (round half up, 3dp); share orders hold shares constant and recompute cash (nearest cent).

**Owed to shareholders (value received was less than it should have been — policy 5.1), aggregated by account across the whole Error Period, then screened against the $10.00 de minimis (policy 5.3):**

| Account | Registration | Shares owed | Cash owed | Aggregate value | Result |
|---|---|---:|---:|---:|---|
| 900011 | Tarrant Hollis Securities LLC Omnibus | 782.199 | — | $18,811.89 | Adjust (omnibus — Stellmark/NSCC to sub‑allocate, policy 5.4) |
| 100587 | J Okonkwo & M Okonkwo JTWROS | 0.620 | — | $14.94 | Adjust |
| 103771 | L Sato Roth IRA | — | — | $8.65 | **Below $10 de minimis — no adjustment** |
| 101945 | R Vasquez Traditional IRA | 0.326 | $7.20 | $15.04 | Adjust |
| 900027 | Wexcombe Clearing Corp Omnibus | 306.097 | $2,160.00 | $9,546.12 | Adjust (omnibus) |
| 102310 | Ellery Township Police & Fire Retirement Plan | — | $4,500.00 | $4,500.00 | Adjust |

**Totals after de minimis: 1,089.242 shares + $6,667.20 cash across 5 accounts.**

**Fund Losses (value the Fund gave up — policy 6.1), not charged back to the benefited accounts (policy 5.2), and not netted against the amounts owed above (policy 5.3 last sentence) or against each other (policy 6.2):**

| Date | Account | Registration | Fund Loss |
|---|---|---|---:|
| 9/11 | 102310 | Ellery Township Police & Fire | $11,400.00 |
| 9/11 | 900027 | Wexcombe Omnibus | $3,515.00 |
| 9/14 | 101122 | Pinecrest Hospital Foundation | $4,924.09 |
| 9/14 | 103002 | D Farrow | $1,008.12 |
| 9/16 | 900011 | Tarrant Hollis Omnibus | $22,868.84 |
| 9/16 | 100587 | J Okonkwo & M Okonkwo | $8.85 |
| **Total** | | | **$43,724.90** |

This is the figure that matters for your sign‑off: **policy 6.2 says Fund Losses are summed across all Material Days and are not reduced by gains the Fund made on other transactions or days.** Rafael's memo nets the 9/11/9/14 losses against the 9/16 gain to reach "roughly $12k" — that is not how the policy computes the reimbursement. The Fund is owed $43,724.90 in full.

## 4. Where I'd diverge from Rafael's proposal, and why

1. **Scope of reprocessing.** Rafael proposes re‑striking and reprocessing all five days (9/10–9/16) because it's "cleaner than picking days." Policy 2.1/3.1 require testing each day separately; 9/10 and 9/15 fail the 0.50% materiality leg and must **not** be reprocessed — no shareholder adjustments, no reimbursement sought for those two days, full stop. Reprocessing them would move real money on a basis the policy doesn't authorize.
2. **Amount.** $43,724.90, not ~$12k — see Section 3. Netting across days is explicitly barred (6.2).
3. **Responsible Party.** Rafael frames this as "a vendor data failure" the Fund should carry while Stellmark chases the vendor. I disagree: under agreement §7.2, Stellmark is only excused for a Pricing Source error **if it performed the Schedule C validation procedures**. Its own log shows it didn't — it cleared an unchanged‑price exception on tolerance grounds (barred by C.3) and on the vendor's "will update" assurance (barred by C.4) five times running, including three times *after* your PM desk told them on 9/11 the Nasdaq price was materially different. That takes Stellmark outside the §7.2 carve‑out and into §7.3: Stellmark reimburses the Fund in full and bears its own reprocessing cost. The vendor's liability cap (referenced in the QPS‑558120 notice) is Stellmark's problem to negotiate with its vendor, not a reason to shift cost to the Fund or shareholders (policy 7.2: "The Fund does not bear the cost of a NAV error... does not delay reimbursement to the Fund").
4. **De minimis.** Rafael's $10 threshold matches policy 5.3 — no disagreement there, and I've applied it at the account level, aggregated across the whole Error Period as the policy requires (not day‑by‑day).

## 5. Recommended actions (see `answer.json` → `actions` for full list/targets)
- **Don't sign** the proposal as drafted; hold Stellmark to a revised calculation (no netting, correct day set, correct responsible party) before the Corrections Desk starts.
- **Escalate** to the CCO and to the Board (policy 8.2) covering the three Material Days, root cause, and the Schedule C process failure; log the two non‑Material days for the quarterly report (8.3).
- **Reprocess** TA activity for 9/11, 9/14, 9/16 only, at $24.05 / $24.13 / $24.58.
- **Instruct the TA** to credit/pay the five above‑de‑minimis accounts (Section 3); no adjustment for account 103771.
- **Request** that the intermediaries behind the two omnibus accounts (900011, 900027) push their share/cash adjustments down to underlying beneficial owners (policy 5.4), and confirm back.
- **Reimburse the Fund** $43,724.90 from Stellmark, due within 5 Business Days of your approval of the (corrected) calculation (policy 6.3).
- **Post** the reimbursement receivable and reprocessing effects to the accounting system.

## 6. Assumptions and open items (see `answer.json` → `open_questions` for the full list)
- Position quantity for OSMD is rolled forward on a **trade‑date** basis (1,200,000 sh through 9/14; 1,000,000 sh from 9/15, after the 9/15‑trade‑date sale of 200,000 sh). If the Fund's official convention is settle‑date, the 9/15/9/16 figures would need to be revisited.
- Corrected prices are the "Nasdaq official close" values already recorded in Stellmark's own exception log for each date; I did not have an independent exchange tape to cross‑check them — worth confirming before you sign.
- Only OSMD was treated as an error; the other two log exceptions in this window (Marlow Residential REIT 9/10, Tovey Energy Partners 9/15) were both resolved on a compliant, corroborated basis and are not restated.
- Rounding (shares to 3dp round‑half‑up, cash to the cent) was inferred by reproducing the original TA postings from `gross_amount/nav_applied`, which matched exactly — flagging in case the live reprocessing run uses a different convention.
- Omnibus sub‑allocation to underlying beneficial owners (accounts 900011, 900027) is outside Corvane/Stellmark's own books and needs intermediary confirmation to close out fully.

**Sources:** `inputs/policies/CIT_NAV_error_correction_policy.md`; `inputs/agreements/stellmark_fund_administration_agreement_excerpt.md`; `inputs/nav/published_nav_history_CMOF_20260910_20260917.csv`; `inputs/pricing/price_exception_log_CMOF_20260910_20260917.csv`; `inputs/pricing/primary_vendor_notice_QPS-558120.txt`; `inputs/portfolio/holdings_top_positions_CMOF_20260909.csv`; `inputs/portfolio/trade_blotter_CMOF_20260910_20260916.csv`; `inputs/transfer_agent/ta_transaction_detail_CMOF_20260910_20260917.csv`; `inputs/correspondence/email_corvane_pm_desk_20260911.txt`; `inputs/correspondence/email_stellmark_nav_oversight_20260917.txt`.
