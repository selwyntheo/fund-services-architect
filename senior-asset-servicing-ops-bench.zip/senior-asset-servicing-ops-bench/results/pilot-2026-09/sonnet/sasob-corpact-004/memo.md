# Halvard Industrial Corp Dutch Auction (HALV26DTCH01) — Final Results by Account

**To:** Anya Brandt, Voluntary Events Lead
**Re:** Expected accepted shares / returns / proceeds for our four Halvard accounts, Fenwick and Ashgrove queries, and what to stop before tomorrow

## 1. Final terms used (source: `inputs/notices/stonemere_final_results_notice_20261007.txt`)

- Final Purchase Price: **USD 32.50**
- Final proration factor: **0.748212** (this supersedes the preliminary 0.729 factor from Halvard's Oct 5 press release — `inputs/notices/halvard_press_release_preliminary_20261005.txt` — which per our own Schedule 4 s.8.2 may only be used for indicative client communication, never for booking or crediting)
- Rounding rule: shares purchased = shares subject to proration × final factor, **rounded down**
- Conditional tenders whose minimum is not met by the final factor are returned in full; Stonemere confirms none were selected by random lot this time
- Payment and returns settle via DTC on **Friday, 2026-10-09**

Meridale's Client Response Deadline for this offer (Schedule 4 s.7.1) is 5:00pm ET on the business day before expiration, i.e. **5:00pm ET, Thursday, 2026-10-01** (expiration was 5:00pm ET Friday 2026-10-02).

## 2. Per-account results

All figures recomputed from `inputs/instructions/tender_instruction_log_HALV26DTCH01.csv` and `inputs/positions/custody_positions_HALVARD_20261007.csv`, cross-checked against `inputs/event_engine/projected_tender_proceeds_HALV26DTCH01.csv` (the engine's PJ-HALV-01 run, dated 2026-10-05, which used the **preliminary** 0.729 factor and pre-dates Stonemere's final notice).

| Account | Client | Live shares tendered | Accepted | Returned | Proceeds (USD) |
|---|---|---:|---:|---:|---:|
| 4410-2201 | Ashgrove (Global Equity) | 100,000 | 44,892 | 55,108 | 1,458,990.00 |
| 4410-2204 | Ashgrove (US Small Cap) | 85 | 63 | 22 | 2,047.50 |
| 4410-3104 | Fenwick | 120,000 | 89,785 | 30,215 | 2,918,012.50 |
| 4410-5024 | Lumenfield | 50,000 | 0 | 50,000 | 0.00 |
| **Total** | | **270,085** | **134,740** | **135,345** | **4,379,050.00** |

Reconciliation: 134,740 + 135,345 = 270,085 = total live shares tendered. ✓

### 4410-2201 — Ashgrove, Global Equity
TL-01 tendered 100,000 shares on 9/22 at a USD 31.00 limit (VOI 26092201). TL-02 withdrew that full tender on 9/30, and TL-03/TL-04 re-tendered it the same day as two new VOIs — both well before the Oct 1 cutoff, so this is a clean withdraw-and-retender, not a late instruction:
- VOI 26093004: 60,000 sh @ USD 31.00 limit → at/below the USD 32.50 final price → subject to proration: 60,000 × 0.748212 = 44,892.72 → **44,892 accepted**, 15,108 returned.
- VOI 26093005: 40,000 sh @ USD 33.00 limit → above the final price → **0 accepted, all 40,000 returned**.
- Total: 44,892 accepted / 55,108 returned / **USD 1,458,990.00**.
- The custody extract's 100,000-share TENDERED_AT_DEPOSITARY balance matches 60,000+40,000. ✓
- **Engine error:** PJ-HALV-01's row for VOI 26093004 used the stale 0.729 factor (43,740 accepted / USD 1,421,550.00) and is on a SCHEDULED_AUTO_CREDIT for 2026-10-08 06:00 — tomorrow morning.

### 4410-2204 — Ashgrove, US Small Cap (the "odd lot" claim)
TL-05 tendered all 85 shares "at the Purchase Price" (i.e., deemed tendered at the USD 30.00 minimum — at/below the final USD 32.50 price). The instruction log shows `odd_lot_certified = N`, with a note that the odd-lot box was **not completed at checker review**.

Ashgrove's claim that this is "clearly an odd lot" does not hold under either the Offer's own terms or our policy:
- The Offer (`halvard_offer_to_purchase_extract.md`, Section 1) defines an Odd Lot Holder by **aggregate** beneficial ownership and says the priority is unavailable to a 100+‑share holder "even if those holders have separate accounts... each representing fewer than 100 shares."
- Schedule 4 s.8.1 requires Meridale to aggregate a beneficial owner's holding **across all Meridale accounts** before certifying odd-lot status.
- Ashgrove Pension Trust (client ASH) holds 100,000 shares in 4410-2201 in addition to the 85 in 4410-2204 — an aggregate of **100,085 shares**, above the <100-share threshold. The checker's decision not to certify the box was correct.

Treated as an ordinary prorated tender: 85 × 0.748212 = 63.598 → **63 accepted**, 22 returned, **USD 2,047.50**.

**Engine error:** PJ-HALV-01 flagged this VOI odd-lot ("Y (POSITION < 100)") purely from the single account's size, used a 1.000 factor, and projected all 85 shares accepted for USD 2,762.50 — also on **SCHEDULED_AUTO_CREDIT for 2026-10-08 06:00**.

**What to tell Marcus Leland (Ashgrove):** the 85 shares are not eligible for odd-lot priority because Ashgrove's aggregate Meridale holding (including 4410-2201) exceeds the 100-share threshold, and the odd-lot certification was correctly declined at checker review; the account will receive 63 shares' worth of proceeds (USD 2,047.50) and 22 shares returned.

### 4410-3104 — Fenwick (the withdrawal dispute)
TL-06 tendered 120,000 shares on 9/24 at a USD 32.50 limit (at the final price → at/below → subject to proration).

TL-07 attempted to withdraw all 120,000 shares by email, logged at **2026-10-01T16:40:12-05:00**. Grant/Tomas Albright's claim is that this was sent at 4:40pm ET, before the 5:00pm ET cutoff. But the log's timestamp carries a **-05:00** offset, not the **-04:00** (EDT) offset every other entry in the log uses for early-October dates. Converting 16:40:12 at UTC‑05:00 to New York time (UTC‑04:00 in effect that week) gives **17:40:12 ET — 5:40pm**, i.e. **40 minutes after** the 5:00pm ET Client Response Deadline. This is consistent with the log's own status, `LATE_NOT_TRANSMITTED`, and with the subsequent workflow: referred to the Head of Asset Servicing at 08:50 ET on Oct 2, best-efforts transmission **declined** at 09:40 ET (Schedule 4 s.7.2 — late instructions do not bind Meridale and may only be transmitted on a best-efforts basis with the Head of Asset Servicing's written approval), and the client informed at 09:55 ET the same day.

Because the withdrawal was never transmitted, the original tender (VOI 26092407) was **never withdrawn at the depositary** — the custody extract still shows the full 120,000 shares as TENDERED_AT_DEPOSITARY. It is accepted like any other live tender: 120,000 × 0.748212 = 89,785.44 → **89,785 accepted**, 30,215 returned, **USD 2,918,012.50**.

**Engine error:** PJ-HALV-01 treated the late, untransmitted withdrawal as if it had succeeded ("WITHDRAWAL REQUEST ON FILE (TL-07)") and projected 0 accepted / 120,000 returned / USD 0.00. This is not scheduled for auto-credit (it's flagged `RETURN`), so no cash movement is at risk from this row specifically, but it must not feed the cash forecast or any client message as-is.

**What to tell Grant:** Meridale correctly declined to treat the withdrawal as effective — the timestamp, once converted to the right time zone, shows it arrived after our cutoff, not before it. No Meridale error occurred, so there is nothing to "make right." Fenwick keeps 30,215 of their 120,000 shares and receives USD 2,918,012.50 for the 89,785 accepted — a materially better outcome for them than the 0/120,000/USD 0.00 the flawed projection currently shows. **Grant's commitment to credit Fenwick "the difference" should be withdrawn before it is repeated to the client or treated as a booked obligation** — per Schedule 4 s.9.1, RMs and Asset Servicing staff cannot promise or credit compensation; that can only go through the Operational Incident process with Head of Operations approval, and on these facts there is no basis for it. This should be escalated for the RM conduct point even though no financial correction is needed.

If Grant/Tomas can produce the actual sent email showing a genuine ET (not Central) send time before 5:00pm, that would change the analysis — worth asking for as a check, but the log as it stands supports "late."

### 4410-5024 — Lumenfield (conditional tender)
TL-08 conditionally tendered 50,000 shares "at the Purchase Price" (deemed USD 30.00, at/below the final price) with a stated **conditional minimum of 40,000 shares**. Applying the final factor: 50,000 × 0.748212 = 37,410.6 → 37,410 shares would be purchased under ordinary proration — **below the 40,000 minimum**, so under Section 6 of the Offer the condition is not satisfied. Stonemere's final notice confirms that, after proration, **no conditional tenders were selected by random lot**, and unsatisfied conditional tenders are returned in full. Result: **0 accepted, 50,000 returned, USD 0.00**.

**Engine error (the most serious one):** PJ-HALV-01 ignored the conditional minimum entirely, used the stale 0.729 factor, and projected **36,450 shares accepted for USD 1,184,625.00**, on **SCHEDULED_AUTO_CREDIT for 2026-10-08 06:00**. Even recomputed at the correct final factor the condition still fails (37,410 < 40,000), so this is wrong independent of the factor issue — it's a straight failure to apply the conditional-tender rule. This is the largest single dollar error in the set and is due to auto-credit tomorrow morning.

## 3. What needs stopping before tomorrow (2026-10-08 06:00)

Three of the four accounts are on the event engine's SCHEDULED_AUTO_CREDIT for 06:00 tomorrow, all wrong:

| Account | Scheduled (wrong) credit | Correct outcome | Delta |
|---|---:|---:|---:|
| 4410-2201 (VOI 26093004) | USD 1,421,550.00 | USD 1,458,990.00 | +37,440.00 |
| 4410-2204 | USD 2,762.50 | USD 2,047.50 | -715.00 |
| 4410-5024 | USD 1,184,625.00 | USD 0.00 | -1,184,625.00 |
| **Total scheduled** | **USD 2,608,937.50** | **USD 1,461,037.50** (sum of these three, correct) | **-1,147,900.00** |

**These three auto-credits must be held before 06:00 tomorrow and the engine re-run on final terms** (factor 0.748212, price USD 32.50, corrected odd-lot and conditional-tender logic, and 4410-3104 treated as a live, non-withdrawn tender). Please do not let tomorrow's client cash forecast draw from the current PJ-HALV-01 output — use the totals in Section 2 instead (134,740 shares / USD 4,379,050.00 across all four accounts, settling 2026-10-09).

## 4. Assumptions

1. Ashgrove Pension Trust is treated as a single beneficial owner across 4410-2201 and 4410-2204 (both under client_id `ASH`) for odd-lot aggregation, per Schedule 4 s.8.1 and the Offer's own aggregation language. This is not separately attested in the inputs provided and should be confirmed with the client if disputed.
2. Fenwick's TL-07 timestamp offset (`-05:00`) in the instruction log is taken at face value and converted to New York time; we do not have the underlying email header to independently corroborate it, only the log entry and its already-assigned `LATE_NOT_TRANSMITTED` status, which is consistent with our conversion.
3. Shares tendered "AT_PURCHASE_PRICE" are treated per the Offer's own language as tendered at the USD 30.00 minimum price (i.e., always at/below the final purchase price for proration purposes).
4. No entries have actually been posted or credited yet for this event — the only figures in `client_cash_forecast`/engine terms are projections, so no `reverse_entry` action is needed, only holds and reprocessing before Friday's DTC settlement.

## 5. Open questions / what we need

- Can Stonemere/DTC confirm per-VOI final allocations for 26093004, 26093005, 26092810, 26092407 and 26092915, matching our recomputation, before Friday's settlement?
- Please have the client (or Marcus Leland) confirm Ashgrove's beneficial-ownership structure across 4410-2201/4410-2204 if they wish to dispute the aggregation.
- If Grant/Tomas can produce Fenwick's actual sent email with a verifiable ET timestamp before 5:00pm on Oct 1, we should revisit; absent that, the log stands.
- Who owns fixing the event engine's proration-factor sourcing (must use the depositary's final factor, never a preliminary press-release figure — Schedule 4 s.8.2/8.3), its odd-lot aggregation logic, and its conditional-tender handling, and on what timeline, given this is the second and third times in one event that its auto-credit output would have been wrong.

— Prepared from `inputs/notices/*`, `inputs/instructions/tender_instruction_log_HALV26DTCH01.csv`, `inputs/positions/custody_positions_HALVARD_20261007.csv`, `inputs/event_engine/projected_tender_proceeds_HALV26DTCH01.csv`, `inputs/correspondence/*`, and `inputs/policies/meridale_voluntary_events_terms_extract.md`. Full structured answer in `answer.json`.
