# BMAI December 2026 Distribution — Minimum Required to Avoid 4% Excise Tax

**To:** Owen Latimer, Assistant Treasurer, Brightwater Series Trust
**From:** Oakhurst Fund Administration, Fund Tax
**Re:** Brightwater Multi-Asset Income Fund (BMAI) — December 2026 distribution estimate, IRC §4982
**Date:** 13 Nov 2026 (data as of 12 Nov 2026; October 2026 tax-basis close is PRELIM)

## Bottom line

- **Minimum December 2026 distribution: $7,591,319.78, or $0.0623 per share** (rate rounded up to the next $0.0001 per policy 4.3) on the projected 121,972,650.225 record-date shares for the 12/16/2026 record date.
- This is **2.2x the regular $0.0280 monthly rate** and would require the fund to declare roughly **$4.18mm more than the regular monthly amount** in December.
- **If the Board instead pays only the regular $0.0280 rate in December**, calendar-2026 distributions fall $4,176,085.57 short of the required distribution, and the fund owes **$167,043.42 of 4% excise tax** (Form 8613) for 2026.
- These are the *minimum* figures required by policy 4.2 (floored at zero); Fund Tax has not built in any cushion. See "Recommendation" below.

## How the number was built (policy 4.1–4.3; BST Distribution and Excise Policy v2.4)

### 1. Ordinary income for excise (calendar Jan 1 – Dec 31, 2026): **$40,992,425.00**
Source: `inputs/tax/BMAI_monthly_tax_basis_income_and_gains_202507_202610.csv` (Jan–Oct 2026 actual/prelim) and `inputs/tax/BMAI_income_forecast_20261101_20261231.csv` (Nov–Dec 2026 desk forecast).

Per policy 2.2, ordinary income excludes all realized capital gains/losses (short- and long-term); it is net investment income plus Sec. 988 FX gain/loss, with the Nov/Dec timing rule in policy 2.3 applied:

| Component | Amount |
|---|---:|
| Net investment income, Jan–Oct 2026 (actual) | 33,974,695.00 |
| Net investment income, Nov 2026 (forecast) | 3,530,600.00 |
| Net investment income, Dec 2026 (forecast) | 3,612,450.00 |
| Sec. 988 FX, Jan–Oct 2026 (actual) | 58,980.00 |
| Sec. 988 FX, Nov–Dec 2026 (forecast $25,600) | **excluded** — deemed to arise 1/1/2027 |
| Sec. 988 FX, Nov–Dec **2025** (deferred in from 2025 workpaper) | (184,300.00) |
| **Total ordinary income (100%)** | **40,992,425.00** |

The 2025→2026 Sec. 988 swap comes straight from the memo line in `inputs/tax/BMAI_2025_excise_workpaper_FINAL.csv` ("post-October 2025 specified loss deferred to 2026" = -184,300), per IRC 4982(e)(5)/policy 2.3.

### 2. Capital gain net income (Nov 1, 2025 – Oct 31, 2026): **$5,001,890.00**
Source: `inputs/tax/BMAI_monthly_tax_basis_income_and_gains_202507_202610.csv`, months 2025-11 through 2026-10.

This period is fixed by policy 2.4 (no §4982(e)(4) election) and does **not** move with the calendar year or the fund's July–June fiscal year. Combined short+long-term realized gains/losses for that 12-month window: ST $896,860.00 + LT $4,105,030.00 = $5,001,890.00. Less the excise-basis capital loss carryover recorded in the 2025 excise workpaper ($0.00 — the Nov 2024–Oct 2025 period was itself a net gain) = **$5,001,890.00** used for excise.

The desk's Nov–Dec 2026 forecast of ~$1.25mm of additional realized gains falls in the *next* excise period (Nov 2026–Oct 2027) and does not affect this computation or the December distribution.

### 3. Prior-year (2025) shortfall carried into 2026: **$658,050.00**
Source: `inputs/tax/BMAI_2025_excise_workpaper_FINAL.csv`; policy 2.1(c).

This is the item most likely to be missed, and it is where I disagree with the adviser's framing (see "Points of disagreement" below). Policy 2.1(c) requires comparing 2025's *distributed amount* not to the 98%/98.2% required distribution (which is what the 2025 workpaper tested and cleared), but to the **grossed-up (100%) required distribution**:

| | Amount |
|---|---:|
| 2025 ordinary income (100%) | 39,872,173.71 |
| 2025 capital gain net income (100%) | 6,905,400.00 |
| 2025 grossed-up required distribution | 46,777,573.71 |
| 2025 distributed amount | 46,119,523.71 |
| **Shortfall carried to 2026** | **658,050.00** |

2025 owed **zero** excise tax (distributed $46,119,523.71 exceeded the 98%/98.2% required distribution of $45,855,833.04 by $263,690.67), but that $263,690.67 cushion versus the *discounted* threshold is smaller than the ~2% "haircut" built into the 98%/98.2% safe harbor, so 2025 still finished below the grossed-up (100%) figure by $658,050.00. Under IRC §4982(b)(2), that gap must be added — dollar for dollar — to 2026's required distribution.

### 4. Required distribution for 2026: **$45,742,482.48**
= 98% × $40,992,425.00 ($40,172,576.50) + 98.2% × $5,001,890.00 ($4,911,855.98) + $658,050.00 prior-year shortfall.

### 5. Distributed amount before December: **$38,151,162.70**
Source: `inputs/distributions/BMAI_distribution_register_202507_202611.csv`.

Sum of all 2026 dividends paid Jan–Oct 2026, plus the Aug 2026 §855 special (paid 8/28/2026), plus the Nov 2026 dividend declared 11/2/2026 but not yet paid (included at its estimated $3,403,680.00 per policy 3.3):

| Month | Ref | Amount |
|---|---|---:|
| Jan | BMAI-D-2026-01 | 3,316,830.11 |
| Feb | BMAI-D-2026-02 | 3,319,204.37 |
| Mar | BMAI-D-2026-03 | 3,322,140.61 |
| Apr | BMAI-D-2026-04 | 3,385,532.49 |
| May | BMAI-D-2026-05 | 3,388,205.13 |
| Jun | BMAI-D-2026-06 | 3,391,878.07 |
| Jul | BMAI-D-2026-07 | 3,394,741.61 |
| Aug | BMAI-D-2026-08 | 3,396,825.85 |
| Aug special (§855) | BMAI-D-2026-08S | 1,031,179.28 |
| Sep | BMAI-D-2026-09 | 3,399,280.75 |
| Oct | BMAI-D-2026-10 | 3,401,664.43 |
| Nov (declared, unpaid) | BMAI-D-2026-11 | 3,403,680.00 |
| **Total** | | **38,151,162.70** |

The December 2025 dividend (BMAI-D-2025-12, $3,314,683.91, declared/record-dated Dec 2025 but paid 1/5/2026) is **excluded** — under IRC 852(b)(7)/policy 3.1 it is treated as paid 12/31/2025 and is already in the 2025 workpaper's distributed amount. Including it here would double-count it.

### 6. Minimum December distribution and rate
- Minimum December distribution = $45,742,482.48 − $38,151,162.70 = **$7,591,319.78**.
- Projected record-date shares (12/16/2026) = 121,560,000.000 (11/12/2026 balance, all classes) + 412,650.225 (net projected activity, trailing-60-day flow plus a confirmed 12/1 Class I platform subscription) = **121,972,650.225** (`inputs/transfer_agent/BMAI_shares_outstanding_and_projection_20261112.csv`).
- Rate = $7,591,319.78 ÷ 121,972,650.225 = $0.062238, **rounded up to $0.0623/share** per policy 4.3.
- At $0.0623/share the fund would actually pay $7,598,896.11 (a $7,576.33 rounding cushion above the exact minimum) — routine and immaterial.

### 7. If the Board pays only the regular $0.0280 rate in December
- Amount paid: $0.0280 × 121,972,650.225 = $3,415,234.21.
- Total 2026 distributed: $38,151,162.70 + $3,415,234.21 = $41,566,396.91.
- Shortfall vs. required distribution: $45,742,482.48 − $41,566,396.91 = **$4,176,085.57**.
- **4% excise tax: $167,043.42.**

## Points of disagreement with Marcus's email

1. **"$2.9mm of capital loss carryforwards... should shelter most of this year's gains" — disagree, no effect.** That figure (ST $1,016,340 + LT $1,865,620 = $2,881,960) is the Fund's **fiscal-year** (July 2025–June 2026, IRC §1212) capital loss carryforward from the FY2026 annual report (`inputs/financial_statements/BMAI_annual_report_FY2026_tax_note_extract.md`). Policy 2.4 is explicit that this figure is **not** used in the excise computation — only the excise-basis carryover recorded in the *prior excise workpaper* applies, and that is $0.00 (the Nov 2024–Oct 2025 excise period was a gain, not a loss). It's also moot on the substance: the Nov 2025–Oct 2026 excise period is itself a $5,001,890 **gain**, so there is nothing to shelter even setting the policy point aside.
2. **"Last year we ended up with no excise tax at all, so there's nothing hanging over from 2025" — half right, half wrong.** No excise tax was due for 2025 (confirmed), but that is not the same test as whether a shortfall carries forward. Policy 2.1(c)/IRC §4982(b)(2) separately measures 2025's distributed amount against the **grossed-up (100%)** required distribution, and 2025 fell $658,050.00 short of that figure. That $658,050.00 is added dollar-for-dollar to 2026's required distribution — it is the single largest reason December needs more than double the regular rate.
3. **"The August special was really FY2026 income, so it belongs to last year's numbers" — disagree, but already worked in the fund's favor.** Under policy 3.2/IRC §855, a dividend paid after fiscal year-end under a §855 election counts for excise purposes in the calendar year it is **paid** (August 2026), regardless of which tax year the underlying income relates to. It is correctly included in the 2026 distributed-amount total above. If it had instead been excluded (as Marcus's framing would imply), December's requirement would be **$1,031,179.28 higher** — so the correct treatment is already helping keep the number as lean as the rules allow.

## Recommendation

Report the **$7,591,319.78 / $0.0623 per share** minimum to the Board as computed. Two flags before Monday's pre-clear:

1. Nov and Dec 2026 net investment income and Sec. 988 are still **desk forecasts** (as of 11/10/2026), and the Oct 2026 tax-basis close is marked PRELIM. If either moves materially before month-end, the minimum should be re-run before the 12/16 record date.
2. Per policy 4.4, Fund Tax may recommend a modest cushion above the bare minimum (we have not built one in); given how close 2025 came to a shortfall on the grossed-up test, a small buffer (e.g., rounding to $0.0625–$0.0630/share) would reduce next year's risk of another prior-year carryforward, at a modest cost in distribution-yield optics. That is a business/Board call, not a Fund Tax determination — we report the minimum per policy and leave any cushion decision to Treasury/the Board.

## What we need from whom

- **Transfer agent (Harwick):** a refreshed record-date share projection closer to 12/16/2026 to firm up the per-share rate before declaration (current figure is projected from an 11/12/2026 base).
- **Fund Treasurer / Board:** sign-off on the recommended rate (or a cushion above it) given the reliance on forecast income/gains, before the 11/19 declaration.
- **Independent review:** we recommend an independent reviewer confirm the $658,050.00 grossed-up shortfall calculation (a figure not separately stated in the 2025 workpaper, which stopped at the 98%/98.2% test) before it is relied on for the Board number.

## Inputs relied on

- `inputs/tax/BMAI_monthly_tax_basis_income_and_gains_202507_202610.csv` — actual/prelim monthly tax-basis NII, Sec. 988, ST/LT realized gains, Jul 2025–Oct 2026.
- `inputs/tax/BMAI_income_forecast_20261101_20261231.csv` — desk forecast, Nov–Dec 2026.
- `inputs/tax/BMAI_2025_excise_workpaper_FINAL.csv` — 2025 excise computation, prior-year 988 deferral, prior-year distributed amount, excise-basis capital loss carryover.
- `inputs/distributions/BMAI_distribution_register_202507_202611.csv` — dividend declaration/record/payable dates and amounts.
- `inputs/transfer_agent/BMAI_shares_outstanding_and_projection_20261112.csv` — shares outstanding and projected record-date activity.
- `inputs/financial_statements/BMAI_annual_report_FY2026_tax_note_extract.md` — FY2026 (fiscal-year) tax character of distributions and capital loss carryforwards; confirms August 2026 §855 dividend amount.
- `inputs/policies/BST_distribution_and_excise_policy.md` — governing policy (v2.4) for the §4982(b) computation, distributed-amount rules, and December planning process.
- `inputs/correspondence/email_Whitcombe_20261112.txt` — Marcus Whitcombe's (Brightwater Advisors) views, addressed above.
