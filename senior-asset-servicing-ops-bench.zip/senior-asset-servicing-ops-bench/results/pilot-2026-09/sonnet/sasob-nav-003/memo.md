# AECB — 18-Sep-2026 Dealing NAV: Swing Decision and Final NAVs

**To:** Sophie Lindahl, NAV Team Lead, Quayside Fund Administration (Luxembourg) S.A.
**From:** NAV Valuation Analyst
**Re:** Aldermoor Euro Corporate Bond Fund ("AECB"), Dealing Day 18-Sep-2026 — swing decision, final dealing NAVs, Carrow late order
**Sources:** `inputs/accounting/pre_swing_nav_AECB_20260918.csv`, `inputs/registrar/dealing_register_AECB_DD20260918.csv`, `inputs/nav_system/swing_parameters_extract_20260921.csv`, `inputs/governance/AAM_swing_pricing_policy_v4.md`, `inputs/governance/SPC_minutes_20260827_extract.md`, `inputs/prospectus/AGS_prospectus_extract_general_and_AECB.md`, `inputs/correspondence/email_carrow_late_order_20260918.txt`

## 1. Bottom line

Swing **applies, upward**, at **0.38%**. Final dealing NAV per share for 18-Sep-2026:

| Class | Unswung NAV/share | Swung NAV/share (final) |
|---|---:|---:|
| A-EUR-Acc | 124.32 | **124.79** |
| I-EUR-Acc | 118.24 | **118.69** |
| R-EUR-Dis | 95.95 | **96.32** |

Order AECB-0918-001 (EUR 9,500,000 subscription, I-EUR-Acc) allots **80,040.4414 shares** at 118.69.

Carrow's AECB-0918-012 late redemption is **not** dealt at 18-Sep NAV; it deals at the **21-Sep-2026** NAV, same as it would have without the escalation.

## 2. Net capital activity (Swing Policy §3–§4)

Net capital activity is measured for the AECB Sub-Fund as a whole: subscriptions (incl. conversions **into** AECB) less redemptions (incl. conversions **out of** AECB), each order valued at its EUR amount, or at the unswung, unrounded 18-Sep NAV/share for share-denominated orders. Pre-dealing (unswung) Sub-Fund NAV = 159,688,420.17 + 343,512,904.66 + 39,617,233.94 = **EUR 542,818,558.77** (ties to the TOTAL row in the pre-swing file).

Of the 13 orders in the register, 8 are plain same-class subscriptions/redemptions dealt on 18-Sep at face/share value (AECB-0918-001..008 excluding the switches — see table). The other 5 needed a specific call; full reasoning for each is in `out/answer.json` → `findings`, summarised here:

| Order | Class | Type | Treatment | EUR in net activity |
|---|---|---|---|---:|
| 001 | I-EUR-Acc | Subscription 9,500,000.00 | plain, dealt 18-Sep | +9,500,000.00 |
| 002 | I-EUR-Acc | Subscription 4,200,000.00 | plain, dealt 18-Sep | +4,200,000.00 |
| 003 | A-EUR-Acc | Subscription 1,850,000.00 | plain, dealt 18-Sep | +1,850,000.00 |
| 004 | R-EUR-Dis | Subscription 640,000.00 | plain, dealt 18-Sep | +640,000.00 |
| 005 | A-EUR-Acc | Subscription 2,300,000.00 | plain, dealt 18-Sep | +2,300,000.00 |
| 006 | A-EUR-Acc | Redemption 11,250 sh × 124.32 | plain, dealt 18-Sep | −1,398,600.00 |
| 007 | R-EUR-Dis | Redemption 420,000.00 | plain, dealt 18-Sep | −420,000.00 |
| 008 | I-EUR-Acc | Redemption 18,000 sh × 118.24 | plain, dealt 18-Sep | −2,128,320.00 |
| **009** | A→I (same Sub-Fund) | Switch 40,000 sh | **nets to zero** — conversion within AECB is neither "into" nor "out of" the Sub-Fund (§3), so it does not move the swing test even though it moves shares between classes | 0.00 |
| **010** | I-EUR-Acc → Global Equity Fund I-EUR-Acc | Switch 9,000 sh | **counted as redemption** — conversion OUT of AECB, valued at unswung I-EUR-Acc NAV (9,000 × 118.24) | −1,064,160.00 |
| **011** | I-EUR-Acc | Subscription 6,000,000.00 | **excluded/cancelled** — investor cancelled 11:38, before cut-off, callback verified | 0.00 |
| **012** | I-EUR-Acc | Redemption 3,000,000.00 | **deferred to 21-Sep** — RTA receipt after cut-off (see §3 below) | 0.00 (18-Sep) |
| **0921-001** | A-EUR-Acc | Subscription 750,000.00 | **not for this dealing day** — already correctly booked by RTA for 21-Sep (received 15:12, after cut-off) | 0.00 (18-Sep) |

**Net capital activity (18-Sep) = 18,490,000.00 (subs) − 5,011,080.00 (redemptions incl. cross-Sub-Fund switch) = +EUR 13,478,920.00**, a net inflow.

**% of pre-dealing NAV = 13,478,920.00 / 542,818,558.77 = 2.4831%**, which is **> the 2.00% threshold** (Swing Policy §5, unchanged by the SPC on 27-Aug). Swing therefore applies, **upward** (net inflow, §6).

**Sensitivity — please note at sign-off:** this conclusion depends on excluding AECB-0918-012 from 18-Sep activity. If it were instead forced into 18-Sep as a further EUR 3,000,000 outflow, net activity would fall to EUR 10,478,920.00 = **1.93% of NAV — below threshold, i.e. no swing at all.** The cut-off decision on order 012 is therefore outcome-determinative for the whole swing decision, not just for that one investor.

## 3. Carrow / AECB-0918-012 — late order decision

Carrow's redemption instruction reached Quayside (the RTA) at **12:07:41**, i.e. **7 minutes 41 seconds after** the 12:00 Luxembourg cut-off. Carrow's email argues its own internal order-system timestamp was 11:52 and the delay was a SWIFT-gateway queue on their side, with their relationship manager "aware and supportive."

Prospectus §7.2 is unambiguous on this point: requests must be *received by the Registrar and Transfer Agent* before the cut-off, and **"the time of receipt by a distributor is not relevant."** Carrow acted as nominee/distributor for its underlying client here, so its 11:52 internal log does not satisfy the cut-off — only the 12:07:41 RTA receipt timestamp counts. The Fund also states it "does not permit late trading or market timing practices" (§7.2). The Swing Policy's only exception mechanism (§8) is for deviating from the swing calculation itself, requires prior Conducting Officer approval, and was not invoked here.

**Decision: no same-day exception.** AECB-0918-012 is dealt at the **next Dealing Day's NAV (21-Sep-2026)** — exactly the treatment the RTA itself already applied, without dispute, to order AECB-0921-001 (also received after the 18-Sep cut-off, at 15:12). Treating Carrow differently would be preferential treatment of one investor over others dealing that day and a control/late-trading risk.

**What to tell Carrow:** the order cannot be backdated to 18-Sep NAV; per Prospectus §7.2 the distributor's own receipt time is not relevant; it will be dealt at 21-Sep NAV; recommend they address the SWIFT gateway delay to avoid recurrence. This is a Carrow-side operational failure, not a Quayside/Aldermoor error, so no reimbursement obligation arises from the Fund's side.

## 4. Swing factor used — and a system/control issue you should escalate

The NAV system's swing-parameter extract (`swing_parameters_extract_20260921.csv`) currently shows **SWING_FACTOR_IN_PCT = 0.30%** and **SWING_FACTOR_OUT_PCT = 0.41%**, effective from 2026-06-01. However, the SPC minutes of **27-Aug-2026** approved **new** factors — **in 0.38%, out 0.45%** — effective **Dealing Day 1-Sep-2026**, with written notification sent to Quayside on 28-Aug-2026. The system extract shows a pending change request, **CR-2291**, to apply these new values, but its `cr_status` is **AWAITING_4_EYES** — the second approver has not signed off, so the live system parameters are stale and roughly **three weeks past their effective date**.

Swing Policy §7 covers exactly this situation: *"Until the system is updated the Administrator applies the SPC-approved parameters manually and reports the manual application to the Conducting Officer for valuation."* Accordingly, this NAV run uses the SPC-approved **0.38% swing-in factor manually**, not the stale system value of 0.30%. I have logged a `notify` action to the Conducting Officer to that effect for the sign-off record, and an `escalate` action to get CR-2291's four-eyes approval completed so the system is corrected and manual overrides stop being necessary.

This also raises a control question I cannot resolve from the data I have: **were any AECB dealing days between 1-Sep and 17-Sep swung using the stale 0.30%/0.41% factors instead of the approved 0.38%/0.45%?** I only have the register and pre-swing NAV for 18-Sep, so I cannot check this myself — see the `request_info` action and open question below. If the stale factors were used on a day the threshold was breached, that NAV and any dealing at it may need review/correction.

## 5. Rounding and mechanics

- Unswung NAV/share (unrounded) = pre-dealing net assets ÷ pre-dealing shares in issue, per class (e.g. I-EUR-Acc: 343,512,904.66 / 2,905,118.2200 = 118.244036...), consistent with the published 2dp figures (118.24 etc.).
- Swung NAV/share = unrounded unswung NAV/share × (1 + 0.0038), rounded to 2dp half-up per Prospectus §8.1: A-EUR-Acc 124.79, I-EUR-Acc 118.69, R-EUR-Dis 96.32. The 0.38% adjustment applies equally to all three classes (Prospectus §8.4).
- Shares allotted to AECB-0918-001 = 9,500,000.00 / 118.69 = 80,040.44148... → **80,040.4414** shares (4dp, rounded down per Prospectus §8.1).
- Swing max is 2.00% (unaffected by CR-2291); 0.38% is well within it.

## 6. Assumptions

- 21-Sep-2026 (Monday) is the next Luxembourg Business Day/Dealing Day after 18-Sep-2026 (no intervening holiday) — inferred from the RTA's own booking of AECB-0921-001, not independently confirmed against a Luxembourg holiday calendar (not provided).
- "Net assets_eur_pre_swing" in the pre-swing NAV file is genuinely pre-dealing (before 18-Sep subscriptions/redemptions), consistent with the file's `PRE_SWING_REVIEWED` status and its reconciliation to the unrounded NAV/share figures.
- The AECB-0918-009 switch (A→I) is confirmed eligible for I-class (RTA comment: "I-class eligibility confirmed (institutional nominee)"), so it is dealt as instructed rather than rejected.
- No other AECB orders exist for 18-Sep beyond the 13 rows in the register.

## 7. What I need from whom

- **Conducting Officer (Elena):** valuation sign-off on the manual 0.38%/0.45% swing-factor override, per Swing Policy §7, and on the Carrow cut-off decision.
- **NAV system config owner:** complete the four-eyes approval on CR-2291 so the system reflects the SPC-approved factors, and confirm whether the stale factors were used on any AECB dealing day between 1-Sep and 17-Sep 2026 (needed to assess any retrospective NAV impact).
- **Transfer Agent operations:** re-status AECB-0918-012 from PENDING_OPS_DECISION to accepted for 21-Sep-2026 dealing.
- **Distributor (Carrow):** response declining the same-day exception, as above.

All figures, treatments and the full order-by-order rationale are also recorded in `out/answer.json`.
