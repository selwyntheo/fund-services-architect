# GACP II — Distribution 8 (Delphine) — Waterfall Memo

**To:** Jonas Whitcombe, Director, PE Fund Accounting
**From:** Fund Accounting (this workpaper)
**Re:** LP/GP split for Distribution 8, and reconciliation to Marcus Feld's / Dev's USD 16.4mm carry estimate
**Date:** 19 Sep 2026 (for payment 30 Sep 2026; notices due 24 Sep 2026)

Sources used, all in `inputs/`:
- `lpa/GACP_II_LPA_excerpt_distributions.md` — Article 9 (definitions, Sections 9.1–9.4, 9.6, 9.8)
- `correspondence/2026-09-16_GP_distribution_approval_Delphine.txt` — IC consent, Distribution 8 amount and date
- `correspondence/2026-09-17_feld_email_carry.txt` — Marcus Feld's ask and Dev's deal-by-deal estimate
- `investor_records/partner_register_GACP_II.csv` — commitments, carry status
- `capital_activity/contributions_GACP_II_inception_to_20260917.csv` — full call history (476 calls, inception to 2026-09-17)
- `capital_activity/distributions_GACP_II_inception_to_20260917.csv` — Distributions 1–7 (2018–2025)
- `investor_records/portfolio_realizations_GACP_II.csv` — realization history, cross-check
- `treasury/standing_settlement_instructions_GACP_II.csv` — GP operating account, Carry Escrow account

All figures below are computed directly from the source CSVs (see Section 3 for the exact per-LP methodology used to re-derive every historical distribution's Tier (a)/(b) split, and Section 7 for assumptions); a reviewer can reproduce them with a spreadsheet or script that: (i) compounds each contribution at 8%/yr (1.08^(days/365)) from its due date to each distribution date; (ii) compounds each prior LP cash distribution the same way from its payment date; (iii) applies Sections 9.2(a)–(d) in order at each of Distributions 1–8, in chronological order, carrying forward cumulative unreturned capital, cumulative preferred return paid, and cumulative catch-up paid (both GP and LP shares) per LP.

## 1. Distributable Proceeds (per IC consent, 16 Sep 2026)

| Item | USD |
|---|---:|
| Delphine Logistics — partnership share of net sale proceeds | 115,420,000.00 |
| Varro Security Software — escrow release (recv'd 2026-09-10) | 3,300,000.00 |
| Less: retained for Partnership Expenses & Delphine R&W retention exposure | (6,720,000.00) |
| **Distributable Proceeds** | **112,000,000.00** |

The USD 6,720,000.00 retained amount is **not** part of this distribution and is not addressed by this calculation — see Open Questions.

## 2. Section 9.1 apportionment (pro rata to Commitments, all Partners)

Total fund Commitments = USD 300,000,000.00 (GP USD 6,000,000.00 = 2.00%; 7 LPs USD 294,000,000.00 = 98.00% — `partner_register_GACP_II.csv`). This exact 2.00%/98.00% split is also what Distributions 1–7 used, confirming the apportionment methodology is unchanged.

- GP's own-Commitment apportionment (Section 9.3): 112,000,000.00 × 2.00% = **USD 2,240,000.00** (100% to GP, carry-free, not subject to Section 9.2 or 9.6)
- LP pool apportioned under 9.1: **USD 109,760,000.00**, split pro rata to each LP's Commitment:

| LP | Commitment | Apportioned (9.1) |
|---|---:|---:|
| LP-0021 Commonwealth of Aldermoor | 60,000,000 | 22,400,000.00 |
| LP-0022 Brightwater Teachers' | 50,000,000 | 18,666,666.67 |
| LP-0023 Meridian Crossing FoF II | 45,000,000 | 16,800,000.00 |
| LP-0024 Northfield University Endowment | 35,000,000 | 13,066,666.67 |
| LP-0025 Tamsin Bay Insurance | 40,000,000 | 14,933,333.33 |
| LP-0026 Harrowgate Holdings | 24,000,000 | 8,960,000.00 |
| LP-0027 Corran Valley Foundation | 40,000,000 | 14,933,333.33 |

## 3. Section 9.2 waterfall — whole-of-fund, per LP (the key determination)

**LPA Section 9.2 is explicitly captioned "whole-of-fund, applied separately to each Limited Partner," and requires "taking into account all prior distributions to or in respect of that Limited Partner."** That means each LP's Tier (a)/(b)/(c)/(d) allocation for Distribution 8 must be computed from that LP's *entire* contribution and distribution history since 2015-06-30 — not from Delphine in isolation.

For each LP, at the 30 Sep 2026 distribution date, we computed:
- **Unreturned Capital Contributions** (nominal) = cumulative Capital Contributions to date − cumulative Section 9.2(a) (return-of-capital) amounts paid to date. This required re-deriving, distribution-by-distribution from Distribution 1 forward, how much of each historical distribution was Tier (a) vs Tier (b) (the source data only tags historical distributions "LP_TIERS_1_2" combined) — a fully mechanical exercise since Tier (a) is always exhausted before Tier (b) begins.
- **Preferred Return** per the Article 1 definition = FV(all Capital Contributions to that LP, each compounded at 8%/yr, 1.08^(days/365), from its due date to 30 Sep 2026) minus [FV(all prior cash actually distributed to that LP, compounded at 8%/yr from its distribution date to 30 Sep 2026) + Unreturned Capital Contributions].
- **Section 9.2(c) catch-up target**, life-of-fund per LP: GP's cumulative catch-up receipts must equal 20% × (cumulative Tier (b) paid to that LP + cumulative Tier (c) paid to both GP and LP), solved incrementally at each distribution.

Distributions 1–7 (2018-11-30 through 2025-06-30) never reached Tier (c) for any LP under this reconstruction — consistent with Jonas's statement that "up to now everything has gone to partners pro rata" and confirming this is genuinely the fund's first carry event.

### Distribution 8 result, by LP

| LP | Apportioned | ROC (a) | Pref (b) | Catch-up to LP (c) | 80/20 to LP (d) | **Cash to LP** | Carry attributable |
|---|---:|---:|---:|---:|---:|---:|---:|
| LP-0021 | 22,400,000.00 | 420,000.00 | 14,646,895.95 | 1,466,620.81 | 0.00 | **16,533,516.76** | 5,866,483.24 |
| LP-0022 | 18,666,666.67 | 350,000.00 | 12,205,746.63 | 1,222,184.01 | 0.00 | **13,777,930.63** | 4,888,736.03 |
| LP-0023 | 16,800,000.00 | 315,000.00 | 10,985,171.96 | 1,099,965.61 | 0.00 | **12,400,137.57** | 4,399,862.43 |
| LP-0024 | 13,066,666.67 | 245,000.00 | 8,544,022.64 | 855,528.81 | 0.00 | **9,644,551.44** | 3,422,115.22 |
| LP-0025 | 14,933,333.33 | 280,000.00 | 9,764,597.30 | 977,747.21 | 0.00 | **11,022,344.51** | 3,910,988.82 |
| LP-0026 | 8,960,000.00 | 168,000.00 | 5,858,758.38 | 586,648.32 | 0.00 | **6,613,406.70** | 2,346,593.30 |
| LP-0027 | 14,933,333.33 | 280,000.00 | 9,764,597.30 | 977,747.21 | 0.00 | **11,022,344.51** | 3,910,988.82 |
| **Total** | 109,760,000.00 | 2,058,000.00 | 71,769,790.17 | 7,186,441.97 | 0.00 | **81,014,232.13** | 28,745,767.87 |

Tier (a) and Tier (b) are fully satisfied for every LP within this one distribution. All remaining cash for every LP is consumed by the Tier (c) GP catch-up — **no LP reaches Tier (d)** — and the catch-up is itself **not fully complete**: after Distribution 8, GP's cumulative catch-up receipts remain short of the 20%-of-(pref+catchup) target by roughly **USD 4.08mm in aggregate** (per-LP shortfalls range from ~USD 0.33mm for LP-0026 to ~USD 0.83mm for LP-0021, scaling with each LP's Commitment). Tier (d) — the ongoing 80/20 split — will only be reached in a future distribution once that shortfall closes.

**Carried Interest total (Sections 9.2(c) + 9.2(d)(ii)) = USD 28,745,767.87.**

## 4. Section 9.6 — Carry Escrow

25% of Carried Interest must go to the Carry Escrow Account (Account 4471-2290, Halcyon Trust Services; SSI-II-015), released only on final liquidation or under the Section 9.7 clawback:

- Carry to escrow: 25% × 28,745,767.87 = **USD 7,186,441.97**
- Carry to GP operating account: **USD 21,559,325.90**

## 5. What actually gets wired on 30 Sep 2026

| Destination | Amount | SSI |
|---|---:|---|
| Limited Partners (aggregate, per table above) | 81,014,232.13 | each LP's own SSI (not in this data set — pull individually) |
| GP operating account (Commitment return + carry net of escrow) | 2,240,000.00 + 21,559,325.90 = **23,799,325.90** | SSI-II-014, First Calder Bank N.A., 00-771934-2 |
| Carry Escrow Account | 7,186,441.97 | SSI-II-015, Halcyon Trust Services, 4471-2290 |
| **Total** | **112,000,000.00** | |

Marcus asked that "the carry" be wired to the GP operating account alongside the LP payments on the 30th — confirmed for the **net-of-escrow** carry (USD 21,559,325.90) plus the GP's own carry-free Commitment return (USD 2,240,000.00). The escrowed 25% (USD 7,186,441.97) must go to the separate Carry Escrow Account, not the GP operating account, per Section 9.6.

## 6. Why our number differs from Dev's USD 16.4mm

Dev modeled **Delphine in isolation** (deal-by-deal): return the USD 30,000,000.00 cost, 8% pref on that USD 30mm since 14 Feb 2019, full catch-up, then 80/20 — producing ≈ USD 16,400,000.00 of carry. We reproduced that same isolated calculation independently (ROC 30,000,000.00; 8% pref since 2019-02-14 on that cost = 23,969,586.13; full catch-up = 7,989,862.04 total / 6,391,889.64 to GP; remaining 80/20 split GP share = 10,008,110.36; total to GP = 16,400,000.00) and get Dev's exact USD 16,400,000.00 — so there's no arithmetic error on Dev's side, it's a **methodology** difference.

The LPA does not permit a deal-by-deal calculation. Section 9.2's own heading says **"whole-of-fund, applied separately to each Limited Partner."** Under the whole-of-fund method, this distribution is evaluated against **each LP's full 11-year history** — five prior full-sale exits (Pemberton, Caldera, Norbeck, Silverfern, Quillon), the Ashgrove dividend recap, and the Varro sale — not just Delphine. Because the fund has already distributed USD 324,380,000.00 to LPs in aggregate against USD 270,009,600.00 of cumulative contributions, LPs are (in 8%-compounded future-value terms) already very close to fully caught up on capital and preferred return **fund-wide**. That leaves very little of this distribution still owed as Tier (a)/(b) before the money must flow into Tier (c) GP catch-up — materially more than a Delphine-only view would suggest, because a Delphine-only view ignores the return LPs already earned from the other six realizations.

**Net effect: our whole-of-fund number (USD 28,745,767.87 gross Carried Interest / USD 21,559,325.90 net of escrow) is USD 12,345,767.87 higher than Dev's deal-by-deal USD 16,400,000.00 estimate.** Recommend Jonas relay this to Marcus before Marcus finalizes partners' cash planning on the lower figure, and flag that our figure is still short of full catch-up (Tier (d) not yet reached) — so future distributions will continue at the 80/20 catch-up-then-split cadence rather than jumping straight to 80/20.

## 7. Assumptions

1. All Capital Contributions (Management Fees, Partnership Expenses, and Investments) count toward "Capital Contributions" for both the 8% pref clock and the Section 9.2(a) return-of-capital target, per the Article 1 definition.
2. "Unreturned Capital Contributions" tracks only the Section 9.2(a)-tagged (return-of-capital) portion of prior distributions, not the pref/catch-up/split portions — the standard construction implied by the LPA's own equivalence note ("together with the return of unreturned Capital Contributions, would give the LP an 8% IRR").
3. Because Distributions 1–7 were recorded only as combined "LP_TIERS_1_2," we reconstructed the Tier (a)/(b) split for each of those distributions using the same mechanical LPA formula, applied in chronological order from Distribution 1. This is fully determined by the contribution/distribution cash-flow data (no external assumption), and independently confirms no catch-up or carry ever occurred before Distribution 8.
4. Section 9.1 apportionment (98% LP / 2% GP) is confirmed against the exact ratio embedded in every one of Distributions 1–7.
5. No capital calls or distributions occur between the 2026-09-17 data extract and the 30 Sep 2026 payment date (see Open Questions).
6. GP's carried interest and Commitment-return cash both settle to the GP operating account (SSI-II-014); the fund's Partnership operating account (SSI-II-001) is the presumed funding source for all outbound wires (not explicitly stated in the data but implied by account roles in `standing_settlement_instructions_GACP_II.csv`).

## 8. What we need from the GP / Jonas

See `answer.json` → `open_questions` for the full list, most importantly:
- Confirmation of the treatment/timing of the USD 6,720,000.00 retained from gross proceeds (Partnership Expenses + Delphine R&W retention).
- Confirmation that no contribution/distribution activity occurred between 2026-09-17 and 2026-09-30.
- Each LP's own receiving-account SSI (not present in the treasury extract we were given — only Partnership, GP, and Carry Escrow accounts are listed).
- Dev's underlying workpaper, to fully reconcile beyond the deal-by-deal-vs-whole-of-fund methodology point identified above.
