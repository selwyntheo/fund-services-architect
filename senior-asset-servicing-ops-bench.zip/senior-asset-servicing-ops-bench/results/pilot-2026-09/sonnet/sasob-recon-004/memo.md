# TSIF accrued interest vs Northgate — position-by-position review

**To:** Delphine Okoro, Income & Accruals Team Lead
**Re:** Strategic Income Fund (TSIF) accrued interest rec, NAV 2026-09-17, Northgate account 7730-150
**Bottom line:** Don't sign the USD 62.99 write-off. It's the net of five real, individually explained
differences — one of them USD 265,375.00. Please hold the de minimis close and let fund accounting
book the corrections below instead.

## 1. What I did

I compared, security by security, GL 1300 (`inputs/accounting/accrued_interest_TSIF_20260917.csv`) to
Northgate's Accrued Income Report (`inputs/custodian/northgate_accrued_income_report_7730-150_20260917.csv`),
using "amount owed" = accrued interest + past-due interest receivable (books) / accrued income + income
claims outstanding (custodian), per the reconciliation basis in
`inputs/policies/TFT_income_accrual_and_reconciliation_procedures.md` §3.1. For every position that
differed, I recomputed the correct accrual from the offering terms
(`inputs/reference/offering_terms_extracts_TSIF.txt` — notably, this file covers exactly the five
positions that turn out to differ, which is a useful cross-check that nothing was missed), the Corbin
FRN rate-reset notices, the CPI-U data, and the Valuation Committee minute, and decided which side (if
either) needs to move. Per policy §3.2, I only corrected the side shown to be wrong — the Fund's books
are never adjusted merely to agree with the custodian.

Ten positions total; five match exactly (Harlan Brook, Osgood Media, Vantry Logistics, Pembrook Power,
Ryland Cove — no issues found, not discussed further). Five differ, and the differences net to exactly
USD 62.99 (books total 1,605,265.25 vs Northgate total 1,605,202.26) — which is why the position-level
netting matters: the "small" break is hiding two book errors, one custodian error, one stale-feed error,
and one much larger unbooked reversal.

## 2. Position-by-position findings

| Security | Issue | Books | Northgate | Correct | Who's wrong | Adj. to GL 1300 |
|---|---|---:|---:|---:|---|---:|
| US29DKMU3994 UST 3.875% 8/31 | Day count | 91,493.06 | 89,504.08 | 89,504.08 | Accounting | **-1,988.98** |
| US72IBAI2618 Gantry 5.40% 12/32 | Day count | 251,100.00 | 256,500.00 | 251,100.00 | Northgate | 0.00 |
| USRLI7T61226 Corbin FRN 8/28 | Stale reset | 90,456.89 | 81,269.33 | 81,269.33 | Accounting | **-9,187.56** |
| USFTZ79R4065 UST TIPS 1.625% 7/34 | Stale Index Ratio | 45,462.52 | 45,676.07 | 45,676.07 | Accounting | **+213.55** |
| US6FJH2Q7244 Pellar 8.25% 3/30 | Non-accrual not booked | 265,375.00 | 270,875.00 | 0.00 | Both (see below) | **-265,375.00** |
| **Net** | | | | | | **-276,337.99** |

### a) US Treasury Note 3.875% 15Aug2031 (US29DKMU3994) — day-count set-up error, accounting
The security master (`inputs/reference/security_master_income_setup_TSIF.csv`) has this bond flagged
ACT/360 (loaded 2026-03-02, `RD_BULKLOAD`), giving par × 3.875% × 34/360 = 91,493.06. The offering terms
extract states plainly that Treasury notes accrue actual/actual (ICMA) and that "values in this file...
govern over any system set-up." Actual/actual gives: 34 actual days elapsed / 184 days in the current
15-Aug-to-15-Feb coupon period × the semi-annual coupon (par × 3.875%/2 = 484,375.00) = **89,504.08**,
which is exactly what Northgate carries. **Accounting is wrong; correct = Northgate's number.**

### b) Gantry Industrial Corp 5.40% 15Dec2032 (US72IBAI2618) — day-count set-up error, custodian
Mirror image of (a). The offering terms specify 30/360 (US bond basis). The Fund's books use 30/360
(93 days from 2026-06-15, giving par × 5.40% × 93/360 = 251,100.00). Northgate is instead running this
bond ACT/360 (95 actual calendar days, giving 256,500.00). **Northgate is wrong; the Fund's books are
already correct — no entry needed on our side, but Northgate needs to fix it.**

### c) Corbin Bancorp FRN 15Aug2028 (USRLI7T61226) — missed rate reset, accounting
The Fund's books use 5.0882%, which was the rate for the *prior* interest period
(2026-05-15 to 2026-08-17, per the calculation agent's 2026-05-13 notice). The Calculation Agent's
2026-08-13 notice reset the rate to **4.5714%** for the current period (2026-08-17 to 2026-11-16), and
the security master (`sm_last_updated=2026-05-13`, `sm_updated_by=RESET_FEED`) shows the reset feed
never picked it up. Northgate applied the new rate. Correct accrual: par 20,000,000 × 4.5714% × 32/360
(ACT/360 per offering terms) = **81,269.33**, matching Northgate. **Accounting is wrong.**

### d) US Treasury TIPS 1.625% 15Jul2034 (USFTZ79R4065) — stale CPI feed, accounting
Recomputing the Ref CPI per the offering-terms formula for the accrual end date **2026-09-18**
(policy §5.3: "Index Ratio for the accrual end date (the calendar day after the NAV date)") using the
June/July 2026 CPI-U NSA values gives Ref CPI = 332.09823 and Index Ratio = 332.09823 / 313.04548 (Ref
CPI base) = **1.06091**, matching Northgate exactly. The books show 1.05595, which is exactly the ratio
you get computing Ref CPI as of 2026-07-15 instead — i.e., the ratio has been frozen since 2026-07-15,
the last load date the security master shows for the CPI feed (`CPI_FEED (last load 2026-07-15)`); the
July CPI release (2026-08-12) and August CPI release (2026-09-11) never made it into the feed. This is
the "feed problem" you mentioned. Correct accrual with the current ratio: 45,676.07 vs the books'
45,462.52. **Accounting is wrong.**

### e) Pellar Commercial Finance Corp 8.25% 01Mar2030 (US6FJH2Q7244) — non-accrual reversal not booked
This is the one that actually matters. The issuer missed the 2026-09-01 coupon; Tidewell Asset
Management's Valuation Committee (the Fund's Valuation Designee) met 2026-09-14 and resolved to place
the notes on non-accrual **effective 2026-09-14**, per the minute
(`inputs/notices/tam_valuation_committee_minute_20260914.txt`). TFT policy §5.4 is explicit: *"On
placement, all accrued interest and any past-due interest receivable on the security are reversed
against interest income, and no further interest is accrued."*

What actually happened in the books: the `accrual_status` field was correctly flagged
`NON_ACCRUAL eff 2026-09-14` and new accrual was correctly stopped on that date (13 days at 30/360 =
17,875.00 for 2026-09-01 to 2026-09-13). But the required *reversal* of both that 17,875.00 **and** the
pre-existing 247,500.00 past-due receivable (the unpaid 2026-09-01 coupon, = par × 8.25%/2 exactly) was
never booked. As of the 2026-09-17 NAV, GL 1300 still carries **265,375.00** for this security — it
should carry **zero**.

Northgate shows 270,875.00 (23,375.00 accrued through 2026-09-17 at full contractual rate, plus the same
247,500.00 income claim, with a comment flagging the unpaid coupon). Per policy §3.2, Northgate's feed
does not — and structurally cannot — apply the Fund's non-accrual determination; that's expected and not
a custodian error to chase. So both sides disagree with the correct figure of zero, but for different
reasons: **accounting needs to book the missed reversal; Northgate's number is simply not relevant to
what we should carry.**

## 3. What to book (GL 1300, effective the next entry date)

| Entry | Amount |
|---|---:|
| Reverse Pellar (US6FJH2Q7244) accrued interest + past-due receivable against interest income | -265,375.00 |
| Correct UST 3.875% (US29DKMU3994) to ACT/ACT | -1,988.98 |
| Correct Corbin FRN (USRLI7T61226) to the reset rate | -9,187.56 |
| Correct UST TIPS (USFTZ79R4065) Index Ratio | +213.55 |
| **Net adjustment to GL 1300** | **-276,337.99** |

Corrected GL 1300 total: 1,605,265.25 − 276,337.99 = **1,328,927.26**. After these entries, USD
276,275.00 will remain against Northgate's 1,605,202.26 total — USD 5,400.00 pending Northgate's own
Gantry fix, and USD 270,875.00 that will persist for as long as the Pellar position is non-accrual on
our books but not on Northgate's (expected, per §3.2 — don't true this up).

## 4. Does this move the NAV?

Applying the -276,337.99 net adjustment to the 2026-09-17 net assets (648,332,410.55) against
63,118,402.227 shares moves the reported NAV from 10.2717 (unrounded 10.271686) to an unrounded
**10.267308**, an error of **-USD 0.0044/share (-0.043%)**.

Policy §6.2 requires an error to be **both** ≥ USD 0.01/share **and** ≥ 0.50% of NAV to be material.
This fails both prongs, so per §6.3: **not material** — no restatement of 2026-09-17, correct it in the
next NAV struck, no reprocessing of shareholder activity, and notify the Fund Treasurer same day (logged
for the quarterly Board report).

**Caveat:** I only have security-level detail for 2026-09-17. The Treasury day-count error (set up
2026-03-02), the Corbin FRN reset (effective 2026-08-17), and the TIPS CPI staleness (since around
2026-07-15) are structural, not one-day events — they probably also misstated the 2026-09-15 and
2026-09-16 NAVs. I can't quantify that without the corresponding security-level extracts for those
dates; recommend pulling them and re-running the §6.2 test for each day.

## 5. Who to chase

- **Reference Data** — three set-up errors to fix at source: (1) US29DKMU3994 day-count flag (ACT/360 →
  ACT/ACT); (2) USRLI7T61226 current rate (5.0882% is stale; the reset feed missed the 2026-08-13
  notice); (3) USFTZ79R4065 CPI feed (stalled at 2026-07-15, missing the July/August releases). Given
  the summer feed problems you mentioned, worth asking whether other TSIF holdings or other funds share
  these same three feeds.
- **Northgate Client Service** — Gantry Industrial Corp (US72IBAI2618) is set up ACT/360 at the custodian;
  should be 30/360 per the offering terms.
- **Fund Treasurer** — notify of the (immaterial) NAV impact and flag that the Pellar non-accrual
  determination's required reversing entry wasn't executed when the status flag was set; worth a quick
  control check on how non-accrual placements are processed.
- **Income team / fund accounting** — book the four entries in §3 above.

## 6. Open questions

- Need 2026-09-15 / 2026-09-16 security-level accrued-interest detail to check whether those NAVs carry
  the same day-count / stale-rate / stale-ratio errors, and if so whether they're material on those days.
- Whether other Tidewell Funds Trust series, or other Pellmore-administered funds, hold these same three
  securities off the same stale feeds.
- Whether the Pellar non-accrual reversal not being booked is a one-off miss or a broader control gap in
  how non-accrual determinations flow from the Valuation Committee into the accounting system.
- Confirmation from Reference Data on when each of the three set-up fixes will land, so next week's
  reconciliation isn't run against the same stale data.
- Whether Northgate should be told about the Pellar non-accrual determination for its own
  income-claim/exposure tracking, even though its GL-equivalent won't reflect it.
- The Pellar 30-day grace period on the missed coupon expires 2026-10-01 — if uncured, this becomes an
  Event of Default under indenture §6.1(a); flagging for Treasury/Valuation Designee to track (no action
  requested of this reconciliation).

All figures above are cited to source in `out/answer.json` → `findings[].evidence`.
