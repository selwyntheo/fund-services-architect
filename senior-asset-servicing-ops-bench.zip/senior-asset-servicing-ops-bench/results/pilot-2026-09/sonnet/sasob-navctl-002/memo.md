# CMAF management-fee waiver error — recommendation for Mara

**To:** Priya Ramaswamy, Director, Fund Administration Oversight
**Re:** Stellmark's WVR-CMAF-01 rule-date error — decision requested for tonight's NAV
**Prepared from:** `inputs/` as of 2026-09-17 accrual/NAV data (latest available)

## Bottom line

This is a real, quantifiable error, but under the Trust's own NAV-error policy it is **not** a "NAV
error" in the reprocess-the-shareholders sense. It is corrected **prospectively, in full, in the
next NAV (2026-09-18)** — not by Stellmark's option (a) (spread to fiscal year end) and not by
their option (b) (reprocess shareholder activity). Nobody owes the Fund money for a shareholder-level
loss. The Adviser does owe the Fund an incremental **$42,491.49** under the separate expense-limitation
agreement, as a mechanical consequence of correcting the fee. Net assets fall by **$133,864.32**
(about **$0.0109/share**) when the correction is booked, which is large enough (>$0.01/share) to
require the Treasurer's **written approval before tonight's NAV is released**, even though no
shareholder reprocessing is required.

## What happened (root cause)

* Rule `WVR-CMAF-01` (10 bp contractual management-fee waiver) is set up in Stellmark's fee module
  with `effective_to = 2026-12-31` (`inputs/accounting/fee_module_setup_CMAF.csv`).
* The Adviser's letter of 20 Jan 2026 (`inputs/correspondence/adviser_letter_fee_waiver_20260120.txt`)
  terminated that waiver effective **2026-02-28** and separately extended a different agreement — the
  0.85% **expense limitation** — through 2027-02-28. Stellmark's fee-review note
  (`inputs/correspondence/email_stellmark_fund_accounting_20260918.txt`) confirms the waiver's end
  date was never updated when the expense-cap rule was extended.
* The 2026-02-27-dated prospectus (`inputs/fund_documents/CMAF_prospectus_fee_table_excerpt_20260227.md`)
  already correctly discloses that the 0.10% waiver expired 2/28/2026 — the error is confined to
  Stellmark's fee-module setup, not to the Fund's public disclosure.
* Result: every calendar-day accrual from **2026-03-01** through the **2026-09-17** accrual date
  wrongly continued the 10 bp waiver (`inputs/accounting/mgmt_fee_daily_accrual_CMAF_FY2026_20260917.csv`,
  `waiver_usd` column), understating the management fee expense and overstating net assets.

## The numbers (re-performable from `mgmt_fee_daily_accrual_CMAF_FY2026_20260917.csv`)

* **Missed fee (cumulative, through the 9/17 accrual): $176,355.81**
  = sum of `waiver_usd` for every `accrual_date >= 2026-03-01` (201 accrual days). This ties to
  Priyanka's "rough" $176k figure and to a direct recomputation: summing `gross_fee_usd` less
  `waiver_usd` for accrual dates on/before 2026-02-28, plus full `gross_fee_usd` (no waiver) for
  accrual dates from 2026-03-01, gives a corrected FYTD net management fee of $1,549,630.71 versus
  the booked $1,373,274.90 (matches `expense_summary_CMAF_FYTD_20260917.csv` line 01 exactly) — a
  $176,355.81 difference.
* **First affected NAV: 2026-02-27**, not 2026-03-01. Per Stellmark's accrual convention (procedures
  E1.2), the Friday NAV pre-books the following Saturday/Sunday's calendar-day accruals, so the
  first erroneous calendar day (Sunday 3/1) is actually booked into the **2026-02-27** NAV.
* **Materiality test (CIT NAV-Error Correction Policy §1.4, §2, §3.1):** a Material Day requires
  BOTH (a) published NAV minus corrected NAV (each rounded to the cent) ≥ $0.01/share, AND
  (b) that difference ≥ 0.50% of the corrected NAV. I recomputed both prongs for all 140 NAV dates
  in the Error Period (2026-02-27 through 2026-09-17), using each date's own `total_net_assets_usd`
  and `shares_outstanding` from `nav_history_CMAF_20251030_20260917.csv` less that date's cumulative
  missed-fee error:
  - Prong (a), the penny test, is met on **92 of 140** dates — peaking at a **$0.0143/share**
    cumulative gross misstatement on 2026-09-17.
  - Prong (b), the 0.50%-of-NAV test, is **never** met — the largest was **0.0773%** of the
    corrected NAV, on 2026-08-31 (roughly one-seventh of the threshold). CMAF trades around
    $26/share, so 0.50% of NAV is about $0.13/share — far larger than the actual dollar error ever
    got.
  - **Zero Material Days.** Stellmark's option (b) is based on the penny prong alone ("over a
    penny a share since spring"); the Trust's actual policy requires both prongs, and this error
    does not clear the second one. **No shareholder purchase or redemption should be reprocessed
    and no shareholder account should be adjusted** (policy §3.1). This also means there is no
    Fund Loss under §6, so there is no reimbursement claim against a service provider for
    shareholder-level harm.
* **Correction mechanics (policy §3.2, procedures E3.1):** because the Error Period has no Material
  Day, the full $176,355.81 cumulative correction must be booked **in one entry, in the next NAV to
  be calculated** — i.e., the **2026-09-18** NAV Priyanka is setting up tonight. It **may not** be
  deferred, amortized, or spread over future NAVs (ruling out Stellmark's option (a)), and it may
  not be booked against capital or prior periods.
* **Expense-limitation consequence (procedures E2.1, E2.3; `expense_summary_CMAF_FYTD_20260917.csv`
  lines 91–96):** the FYTD expense-limitation cap ($2,335,383.76 = 0.85% × FYTD average daily net
  assets × FYTD days/365) does not change — E2.3 says FYTD average daily net assets is not restated
  for a non-Material error. But FYTD *covered expenses* rise from $2,201,519.44 to $2,377,875.25
  once the corrected fee is included, which **exceeds the cap by $42,491.49**. That amount becomes
  a new expense-limitation reimbursement receivable from the Adviser (GL 1380), booked together
  with the fee correction in the same 9/18 NAV (E3.1).
* **Net NAV impact:** the $176,355.81 fee correction is largely offset by the $42,491.49 Adviser
  reimbursement it triggers, for a **net $133,864.32 reduction in net assets** — which happens to
  equal the Fund's pre-correction headroom under the cap ($2,335,383.76 − $2,201,519.44). This is
  not a coincidence: once covered expenses cross the cap, the Adviser absorbs everything above it,
  so the Fund's net cost of this error is capped at the amount of headroom that existed before the
  correction, regardless of the size of the underlying fee mistake.
* Using the 2026-09-17 NAV's shares outstanding (12,332,341.362, the last available share count):
  net NAV-per-share effect = $133,864.32 / 12,332,341.362 = **$0.0109/share**. Because that is
  **≥ $0.01/share**, policy §3.3 requires the **Treasurer's written approval before the NAV in
  which it is booked is released**, and the item must go in the NAV error log with an explanation
  of the day's NAV movement — even though, again, no Material Day occurred and no shareholder
  reprocessing is triggered.

## Direct answers to Mara's questions

1. **Is this a "NAV error" in the reprocess-the-shareholders sense?** No. It fails the 0.50%-of-NAV
   prong of the Material Day test on every date tested (peak 0.0773% vs. the 0.50% threshold). It
   is an accrual error corrected prospectively.
2. **What do we book tonight, and what does it do to the NAV?** In the 2026-09-18 NAV: (i) a
   $176,355.81 catch-up management-fee expense, and (ii) a $42,491.49 increase to the
   expense-limitation reimbursement receivable from the Adviser. Net effect: net assets fall
   $133,864.32, NAV per share falls about $0.0109 versus what it would otherwise have been —
   enough to require the Treasurer's prior written sign-off (policy §3.3).
3. **Does anyone owe the Fund money?** Not for a shareholder-level loss (no Material Day → no §6
   Fund Loss → no reimbursement claim against Stellmark for that). The Adviser does owe the Fund an
   incremental **$42,491.49** under the expense-limitation agreement, purely as a mechanical
   consequence of the corrected covered-expense total exceeding the 0.85% cap.
4. **Board materials (Q3):** Because there is no Material Day, this is a quarterly, not urgent,
   disclosure item under policy §8.3 — recommend including: root cause (fee-module rule end date
   not updated when the January 2026 letter was processed), the $176,355.81 correction and its
   $42,491.49 expense-limitation consequence, confirmation that the materiality test was performed
   and found no Material Day, and remediation (second-preparer review of rule-date changes per
   procedures E1.3).

## Assumptions

* The `shares_outstanding` figures in `nav_history_CMAF_20251030_20260917.csv` are the denominators
  actually used to strike each day's published NAV (not independently checked against a subscription/
  redemption ledger, which was not provided).
* "Today" for booking purposes is treated as the 2026-09-18 NAV, per Stellmark's email and the
  latest accrual data provided (through 2026-09-17). If the 9/18 NAV has already been struck and
  released by the time this is acted on, the same treatment (full catch-up, Treasurer approval,
  no reprocessing) should instead attach to the next NAV still open for correction, refreshed off
  that NAV's own shares outstanding.
* The Expense Limitation Agreement's remittance timing for the Adviser's $42,491.49 was not in the
  inputs (only the prospectus excerpt and the January 2026 letter were provided); I have not
  assumed the 5-business-day timeline in NAV-error policy §6.3, since that provision is scoped to
  Material Day Fund Losses, which this is not.
* Scope is limited to CMAF; whether the same fee-module rule-maintenance gap affects any other
  Corvane Investment Trust series was not addressed because no other series' data was provided.

## What I need from whom

* **Stellmark (administrator):** (1) confirmation the WVR-CMAF-01 `effective_to` field has been
  corrected to 2026-02-28 with second-preparer sign-off (procedures E1.3); (2) confirmation no other
  CIT series/classes have a similar rule-date gap; (3) confirmation of the FY2026 fiscal year end
  (10/31, per their email) and that the FYTD expense-limitation inputs used are as of the correct
  latest accrual date.
* **Adviser (Corvane Partners):** confirmation and remittance timing for the $42,491.49 incremental
  expense-limitation reimbursement, and a copy of the full Expense Limitation Agreement (only the
  1/20/2026 letter and prospectus excerpt were available here).
* **Fund Treasurer:** written approval of the correction calculation before the 2026-09-18 NAV is
  released, per policy §3.3.

## Files relied on

* `inputs/correspondence/email_stellmark_fund_accounting_20260918.txt`
* `inputs/correspondence/adviser_letter_fee_waiver_20260120.txt`
* `inputs/fund_documents/CMAF_prospectus_fee_table_excerpt_20260227.md`
* `inputs/accounting/fee_module_setup_CMAF.csv`
* `inputs/accounting/mgmt_fee_daily_accrual_CMAF_FY2026_20260917.csv`
* `inputs/accounting/expense_summary_CMAF_FYTD_20260917.csv`
* `inputs/nav/nav_history_CMAF_20251030_20260917.csv`
* `inputs/policies/CIT_NAV_error_correction_policy.md`
* `inputs/policies/stellmark_fee_and_expense_procedures_excerpt.md`
