**To:** Jordan Pike, Fund Accounting Manager
**Re:** TGEI USD cash, Northgate 7730-104, 15 Sep 2026: difference fully explained

Jordan,

I've explained the full 1,280,183.04 difference and nothing is left over, so we don't need a plug. Five items are errors in our books, which we correct tonight. The sixth is cash that belongs to another fund. Northgate needs to reverse it. Once the entries below are posted, the only open item is that 250,000.00 wire, and you can sign off the NAV.

## The balances
| | USD |
|---|---|
| Books closing (`accounting/cash_ledger_TGEI_USD_20260915.csv`: opening 12,418,305.22 − 2,349,300.00 + 98,124.00 − 412,775.10 + 36,250.00) | 9,790,604.12 |
| Northgate closing (`custodian/MT940_..._20260915.txt`, :62F:) | 8,510,421.08 |
| Difference (books − Northgate) | **1,280,183.04** |

The opening balances agree. The redemption TA-0915-TGEI-R (412,775.10, which ties to the Sandridge batch 0914 I + A) and the Halvorsen coupon (36,250.00) agree on both sides.

## What makes up the difference (books − Northgate)
| # | Ref | Cause | Amount | Wrong side | Treatment |
|---|---|---|---|---|---|
| F1 | FX-260915-0117 | FX booked at the WMR rate 1.17465 instead of the contract rate 1.174200 (Bramwell confirmation: USD 2,348,400.00) | −900.00 | Books | Rebook at contract rate (Policy 4.1) |
| F2 | DV-VALC-20260915 | French WHT withheld at 25% (28,860.00), but we booked 15% (17,316.00). The FR relief-at-source documents expired 30 Jun, before the 3 Sep record date | 11,544.00 | Books | Tax reclaim receivable GL 1450 (Policy 5.1/5.2) |
| F3 | DV-VALC-20260915 | Depositary fee of $0.02 × 185,000 ADS was not recorded | 3,700.00 | Books | Reduce dividend income (Policy 5.3) |
| F4 | BND-260914-0033 | Crestline bond purchase is still pending on the security-master T+2 default. It actually settled T+1 on 9/15. The accrued interest is also wrong | 1,497,196.67 | Books | Correct settle date to 9/15 and settle the purchase |
| F5 | NTC-2608-7730 | Northgate auto-debited the August custody invoice, but the payment isn't recorded | 18,642.37 | Books | Apply the payment to GL 2310 accrual (Policy 3.5) |
| F6 | TSDF-SUB-0915-0042 | A 250,000.00 subscription wire for Tidewell Short Duration Fund (FFC acct 7730-118) was credited to TGEI | −250,000.00 | Custodian / not our fund | Not booked. Carry as reconciling item and return (Policy 3.4) |
| | | **Total** | **1,280,183.04** | | Residual **0.00** |

### Workings
- **Valcourt:** the gross dividend is 185,000 × 0.6240 = 115,440.00. Tax at 25% is 28,860.00 and the depositary fee is 3,700.00, so the net is 82,880.00, which matches Northgate. The tax status file shows FR `RELIEF_AT_SOURCE` as EXPIRED on 2026-06-30. The IRS renewal of Form 6166 is still outstanding, and the Form 5001 reclaim route is available. The depositary notice says 25% applies unless valid documents are received before the record date. Under Policy 5.1, the WHT should be accrued at 25%. The 10% excess (11,544.00) is collectible in FR, so it goes to receivable GL 1450, not to expense. Income stays gross at 115,440.00.
- **Crestline accrued interest:** the ticket gives 30/360 with coupons on 1 Jun and 1 Dec, T+1 settlement on 9/15, and the trade note that "settlement cycle field defaulted". From 1 Jun to 15 Sep is 104 days, so 1,500,000 × 4.85% × 104/360 = **21,016.67**, which is what Northgate paid. The pending record has 21,218.75, which is 105 days to 9/16. That overstates the interest by 202.08. The correct net is 1,476,180.00 + 21,016.67 = 1,497,196.67. Under Policy 6.1, US corporate bonds settle T+1.
- **Custody fee:** the invoice total is 18,642.37 and the August accrual is 18,650.00. The accrual is over by **7.63**, which is trued up through custody expense.
- **Orrin EQ-260915-0210:** this sale is T+1 and settles 9/16, which is correct. It's properly pending, so there's no action.

## Entries to post tonight
1. **FX-260915-0117:** adjust USD cash by +900.00 so the debit is 2,348,400.00, with a matching adjustment to the EUR cost / FX line.
2. **Valcourt WHT:** Dr Tax reclaim receivable GL 1450 11,544.00 / Cr USD cash 11,544.00.
3. **Valcourt depositary fee:** Dr Dividend income 3,700.00 / Cr USD cash 3,700.00.
4. **BND-260914-0033:** change the settle date to 2026-09-15 and the purchased accrued interest to 21,016.67. Settle it with Cr USD cash 1,497,196.67.
5. **Custody fee:** Dr Accrued custody fees GL 2310 (Aug) 18,642.37 / Cr USD cash 18,642.37. Then Dr GL 2310 7.63 / Cr custody fee expense 7.63.

After these, the corrected books balance is **8,260,421.08** against Northgate's 8,510,421.08. The one open item is **−250,000.00**, the misdirected TSDF wire, which is Northgate's error. It should clear once Northgate transfers the cash to 7730-118.

**No plug.** Ravi suggested plugging anything small to misc expense, but nothing is unexplained. Policy 3.3 also bans plugs unless the Fund Controller approves in writing, and even then never above USD 1,000.

**Do not book the 250,000.00 as a TGEI subscription.** The Sandridge TGEI activity file shows 0.00 subscriptions. The 250,000.00 appears there under TSDF.

## What to chase tomorrow
- **Northgate custody ops:** transfer the 250,000.00 (NTC-WI-330981) from 7730-104 to 7730-118 with value 9/15, and give us an expected clear date.
- **Sandridge Fund Services and TSDF fund accounting:** tell them where their subscription cash landed.
- **Northgate Tax Services:**
  - File a French Form 5001 reclaim for 11,544.00.
  - Confirm the status of the Form 5000/6166 renewal.
  - List any other FR dividends paid since 1 Jul that were withheld at 25% but booked at 15%.
- **Reference Data (security master):** change USQJUPI78013 to T+1 and review other new setups that use the default cycle.
- **Fund Treasurer and FX booking control:** the FXAUTO process booked at the WMR rate, which breaches Policy 4.1. Check whether other FX trades are affected.

## Assumptions
- I treated FR reclaims as collectible, as Policy 5.2 states.
- The EUR leg of the FX trade isn't in these inputs, so I've only covered its USD effect.
- I've assumed the Northgate statement is final: the :62F: and :64: balances match.
