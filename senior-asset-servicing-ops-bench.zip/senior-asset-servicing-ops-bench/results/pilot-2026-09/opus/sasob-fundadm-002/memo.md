**To:** Owen Latimer, Assistant Treasurer, Brightwater Series Trust
**From:** Oakhurst Fund Administration, Fund Tax
**Date:** 13 Nov 2026
**Re:** BMAI, estimated December 2026 distribution needed to avoid the 2026 excise tax

## Bottom line
- **Minimum December distribution: $7,591,319.78**
- **Rate per share: $0.0623.** This is rounded up, per policy §4.3, on 121,972,650.225 projected record-date shares. At that rate the December distribution comes to about $7,598,896.11.
- **This is the minimum only. There is no cushion in it.** It is $0.0343 per share above the regular $0.0280.
- **If you pay only the regular $0.0280** ($3,415,234.21), the Fund falls $4,176,085.57 short of the 2026 required distribution. The **4% excise tax on that shortfall is about $167,043.42**. The full shortfall is also added to the 2027 requirement under §4982(b)(2).

## How the number is built (IRC §4982; Trust policy v2.4)

| Line | USD | Source |
|---|---:|---|
| NII, tax basis, Jan–Oct 2026 (actual) | 33,974,695.00 | monthly tax-basis file (Oct is PRELIM) |
| NII, Nov–Dec 2026 (desk forecast 3,530,600 + 3,612,450) | 7,143,050.00 | income forecast file |
| §988 FX, Jan–Oct 2026 | 58,980.00 | monthly file |
| §988 FX loss from Nov–Dec 2025, deferred into 2026 (§4982(e)(5)) | (184,300.00) | 2025 workpaper memo line; monthly file (-121,400 and -62,900) |
| **Ordinary income** | **40,992,425.00** | |
| × 98% | 40,172,576.50 | |
| Net realized ST gain, 1 Nov 2025–31 Oct 2026 | 896,860.00 | monthly file |
| Net realized LT gain, 1 Nov 2025–31 Oct 2026 | 4,105,030.00 | monthly file |
| Excise-basis capital loss carryover from 2025 | 0.00 | 2025 workpaper |
| **Capital gain net income** | **5,001,890.00** | |
| × 98.2% | 4,911,855.98 | |
| 2025 shortfall: grossed-up 2025 requirement 46,777,573.71 less 2025 distributions 46,119,523.71 | 658,050.00 | 2025 workpaper |
| **Required distribution for 2026** | **45,742,482.48** | |
| Regular dividends paid Jan–Oct 2026 | (33,716,323.42) | distribution register |
| August 2026 special (§855), paid 28 Aug 2026 | (1,031,179.28) | register (BMAI-D-2026-08S) |
| November dividend, declared, estimated amount (0.0280 × 121,560,000) | (3,403,680.00) | register (BMAI-D-2026-11) |
| **Distributed before December** | **(38,151,162.70)** | |
| **Minimum December distribution** | **7,591,319.78** | |
| Projected record-date shares: 121,560,000.000 + 412,650.225 | 121,972,650.225 | Harwick projection file |
| Rate: 7,591,319.78 ÷ 121,972,650.225 = 0.062238, rounded up | **$0.0623** | |

Items I left out on purpose:
- **Forecast §988 FX for Nov–Dec 2026 (net +$25,600).** Under §4982(e)(5) this counts as arising on 1 Jan 2027.
- **Capital gains realized in November so far and the $1.25mm Nov–Dec gain forecast.** Both fall in the 2027 excise period, which runs 1 Nov 2026 to 31 Oct 2027. They matter for the FY2027 income-tax distributions, not for the 2026 excise.
- **The December 2025 dividend paid 5 Jan 2026 ($3,314,683.91).** Under §852(b)(7) it counts as paid on 31 Dec 2025, and it was already counted in 2025. Counting it again in 2026 would be double counting.

## Marcus's three points, in plain terms
1. **"No excise tax last year, so nothing carries over."** This is not right.
   - We owed no tax for 2025 because we paid more than the 98%/98.2% threshold.
   - The carryover rule, however, compares 2025 payouts with **100%** of 2025 income and gains: $46,777,573.71.
   - We paid $46,119,523.71, which is $658,050.00 less. That amount is added to the 2026 requirement.
2. **"About $2.9mm of capital loss carryforwards should shelter this year's gains."** This is not right.
   - The annual report shows $1,016,340 short-term and $1,865,620 long-term carryforwards. Those are fiscal-year figures for the year ended 30 June 2026.
   - The excise test has its own measuring period, 1 Nov 2025 to 31 Oct 2026. The losses behind those carryforwards were realized between Nov 2025 and Jun 2026, so they are **already netted** in the $5.0mm figure above.
   - The only loss carryover the excise test allows is the excise-basis carryover from the prior excise period, and that was $0 (policy §2.4).
   - Using the carryforwards again would count the same losses twice and understate the requirement by about $2.83mm.
3. **"The August special was FY2026 income, so it belongs to last year."** This is not right.
   - For excise purposes a dividend counts in the calendar year it is **paid** (policy §3.2). The August special was paid on 28 Aug 2026, so it counts in 2026, and I have given the Fund credit for it here.
   - Moving it to 2025 would take it out of 2026 and **raise** the December number.
   - In any case, the 2025 excise year is final.

The Fund can keep December lean only by paying the minimum above with no cushion. Going below $0.0623 creates excise tax.

## Assumptions and sensitivities
- **October 2026 results are PRELIM** (close dated 6 Nov). Any change to October NII or realized gains moves the minimum by 98% or 98.2% of that change.
- **Nov–Dec NII is the desk forecast of 10 Nov.** If actual NII is higher, the Fund will be under-distributed. I suggest the Treasurer consider a small cushion (policy §4.4), but I have not built one into the minimum.
- **The November dividend is included at its estimate** on 11/12 shares. Once the actual 24 Nov record-date shares are known, the December minimum should be trued up.
- **Record-date shares are Harwick's trailing-flow projection** plus the confirmed 12/01 subscription.
  - At $0.0623 there is only about $7,577 of headroom over the minimum.
  - If record-date shares came in about 121,600 shares lower than projected, the rounded rate would no longer cover the minimum. Please re-run the check with Harwick's updated count before declaration.
- **Source checks.**
  - The 2025 workpaper (FINAL, reviewed by V. Osei) ties out: its totals and its Jul–Dec 2025 dividends agree with the register.
  - Every register amount equals rate × record-date shares.
  - The monthly file's distributable column reconciles to its components.

## What I need, and from whom
- **Fund Treasurer (you or Elaine):** Board pre-clear and declaration on 19 Nov. Please also decide whether to add a cushion.
  - Per policy §4.5, the rate should go to Harwick only **after** the Board declares. Marcus's plan to load it right after the call is fine only if the call is the declaration.
- **PM desk:** refresh the Nov–Dec NII forecast, especially the year-end REIT and preferred dividends.
- **Accounting / close:** finalize October 2026.
- **Harwick, through the Treasurer:** actual 24 Nov record-date shares and an updated 16 Dec projection.
- **Oakhurst Tax Director:** review before the numbers go to the Board.
