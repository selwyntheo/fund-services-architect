**To:** Elaine Marsh, Treasurer, Brightwater Series Trust
**From:** Oakhurst Fund Administration, Fund Tax
**Re:** BFVF 8/31/2026 RIC diversification (IRC §851(b)(3)): review of first cut
**Date:** 19 Sep 2026

## 1. Conclusion
**Do not sign the Board certificate for BFVF as drafted.** At 8/31/2026 BFVF **fails both parts** of the asset test. Stella's first cut showed a pass, but the result was wrong.

| Test | Result | Figure |
|---|---|---|
| 50% test (§851(b)(3)(A)) | **FAIL** | Qualifying assets $314,408,640.39 = **49.58%** of Total Assets. The shortfall is $2,635,166.47. |
| 25% test (§851(b)(3)(B)) | **FAIL** | Stonefield and Harrowgate form a controlled group in the same trade: $167,957,320.00 = **26.49%**. |
| QPTP aggregate | pass | 3.12% (Tallis + Corbeck) |

We can still fix this. The Fund passed at 5/31 (`tax/BFVF_diversification_test_20260531_final.csv`), and both failures were caused, at least in part, by purchases made during the quarter. Under §851(d)(1) and policy 6.1–6.3, the discrepancy is cured if it is eliminated within 30 days. **The cure trades must have a trade date on or before Wednesday 30 September 2026.**

**Minimum cure:** sell at least **$9,435,416.57** (at 8/31 values) of Stonefield Aggregates and/or Harrowgate Materials, with the proceeds held in cash or Government securities. In whole shares, that is about 961,817 Stonefield shares ($9,435,424.77) or 775,302 Harrowgate shares ($9,435,425.34), or a mix. This brings the controlled group to 25.00%. The same sale adds the proceeds to qualifying cash, which lifts the 50% test to **51.07%**. Both tests then pass, so no other sale is needed. **We recommend a buffer.** Bringing the group to 24% or less of Total Assets means selling about $15.78m. Prices will move before the trades are done.

## 2. Denominator
Total Assets = **$634,087,613.72**. This is the gross total from `accounting/BFVF_statement_of_assets_and_liabilities_20260831.csv`, before deducting liabilities, including the $45m line of credit (policy 3.1). The first cut used net assets ($581,160,485.34) instead, which overstated every percentage. Securities are $622,490,883.50, which ties to the sum of the positions in `accounting/BFVF_portfolio_valuation_20260831.csv`.

## 3. Errors in the first cut (`tax/BFVF_diversification_firstcut_20260831.csv`)
1. **Wrong denominator:** it used net assets instead of Total Assets.
2. **Castellan (ISS-0107, $38,501,600, 6.07%)** was counted as a government security. A non-US sovereign is not a Government security under 1940 Act §2(a)(16) or policy 3.3, so it is a separate issuer. At more than 5% it is non-qualifying. Dev's point that the bond is investment grade, USD-denominated and SEC-registered does not change this.
3. **Pemberton repo P005 ($22,000,000)** was counted as government. Its collateral is corporate bonds (39% high yield) per `trades/repo_confirmations_20260831.txt`, so it is not "collateralized fully" under Rule 5b-3. It is therefore a Pemberton security (policy 3.4). Added to the Pemberton CP bought 8/28 ($12,030,425), Pemberton totals $34,030,425 = 5.37%, which is non-qualifying. The Fallowmere repo P004 is correctly treated as government: its collateral is Treasuries only, worth $20.4m, which covers the $20,002,377.78 repurchase price.
4. **Ormsby (ISS-0413)** was tested position by position. The common ($20,979,000) and the notes ($13,500,300) must be combined (policy 3.6). Together they are $34,479,300 = 5.44%, which is non-qualifying.
5. **Tallis QPTP (ISS-0414)** was counted as qualifying. The Fund holds 1,500,800 of 13,400,000 units = 11.20%. QPTP units count as voting securities (§851(c)(5), policy 4.3), so this breaches the 10% limit and Tallis is non-qualifying.
6. **Kinsale (ISS-0418)** was excluded, but it is 4.89% of Total Assets. It only exceeded 5% because of the net-asset denominator, so it is qualifying.
7. **Controlled-group rule was not applied.** Stonefield holds 8,968,000 of 38,000,000 voting shares = 23.60%. Harrowgate holds 6,572,000 of 26,500,000 = 24.80%. Both are at or above 20%, so the Fund controls both (policy 5.2). Both are in the "Construction Materials - Aggregates" sub-industry in `reference/issuer_master_extract_20260831.csv`. Tax Counsel gave no written conclusion before the testing date that they are in different trades, so policy 5.3 treats them as the same trade. Dev's point that they have different management and quarries does not override the policy.

## 4. Issuer-level classification (Total Assets basis)
Qualifying assets:
- Cash and receivables: $11,483,825.89. This is DDA cash 3,406,118.27 + receivable for investments sold 5,812,440.00 + dividends and interest receivable 1,947,062.18 + receivable for fund shares sold 318,205.44.
- Government securities: $78,035,662.50. This is Treasury $42,942,812.50 + FHLB $15,092,850.00 + Fallowmere repo $20,000,000.00.
- Other RICs: $43,900,000.00 (Government MMF + Arden ETF).
- Other issuers at 5% or less and 10% voting or less: **$180,989,152.00**. These are Corbeck 11,199,760; Norbeck preferred (non-voting) 6,001,800; Pellham 9,801,792 (voting 9.60%, close to the limit); Kinsale 30,985,800; Aldermoor 24,500,000; Brixton 22,800,000; Cadell 19,600,000; Dunmore 17,300,000; Everly 15,900,000; Fenwick 14,200,000; Galloway 8,700,000.
- **Total qualifying: $314,408,640.39 = 49.58%.**

Non-qualifying assets:
- Stonefield 13.87%
- Harrowgate 12.61%
- Castellan 6.07%
- Quillon 5.68%
- Ormsby 5.44%
- Pemberton 5.37%
- Tallis 1.36% (voting limit)
- Prepaid and other assets $112,904.33

The per-issuer detail is in `answer.json` → `findings`.

## 5. Why the failure is attributable to acquisitions (policy 6.1/6.2)
The trades are in `trades/BFVF_trade_blotter_20260601_20260831.csv`.
- **Harrowgate:** the Fund bought 1,828,500 shares on 7/14–7/16 (T-260714-003, T-260715-006, T-260716-001). That took its voting stake from 17.90% at 5/31 to 24.80%, which made Harrowgate controlled and created the 25% breach. The trade note "post-trade issuer check <25% OK" tested only the single-issuer limit.
- **Castellan:** bought 8/12 (T-260812-002), funded from the MMF, which moved money from a qualifying asset to a non-qualifying one.
- **Pemberton CP:** bought 8/28. This pushed Pemberton above 5%.
- **Quillon:** 40,000 shares added 8/20.

The failures are therefore attributable to acquisitions, and a cure is required. Relief under §851(d)(2) is a last resort only (policy 6.5).

## 6. Cure sizing (policy 6.4)
- 25% test: the group must fall to 25% of Total Assets or less, i.e. $158,521,903.43 or less. The excess is $167,957,320.00 − $158,521,903.43 = **$9,435,416.57**.
- 50% test: selling that amount turns non-qualifying equity into cash of the same value. Qualifying assets become $323,844,056.96 = 51.07%, which clears the $2,635,166.47 shortfall.
- The other routes each cost more than $9,435,416.57. Taking Harrowgate below 20% voting would need about $15.48m of sales. Taking Stonefield below 20% would need about $13.42m. Trimming Pemberton, Ormsby or Castellan would fix the 50% test but not the 25% test.
- Total Assets must not be increased through borrowing or share activity to reach the cure.

**Assumptions:**
- 8/31 NAV values are used, and sale proceeds are held in cash or Government securities.
- Issuer-master share counts are taken as correct.
- The pending Everly sale is already in receivables.

## 7. Calls to make
1. **Adviser CCO (Brightwater Advisors):** written notice under policy 7.2 covering the discrepancy, the minimum sale of $9,435,416.57 in Stonefield and/or Harrowgate, and the trade-date deadline of 30 Sep 2026. Recommend a buffer to about 24%. Ask them to stop all new purchases of Stonefield, Harrowgate or other non-qualifying names until the re-test, and to consider replacing the rolling Pemberton corporate-collateral repo with Treasury-collateralized repo.
2. **Dev Kapoor (PM):** make clear that selling is not optional. He can choose Stonefield instead of Harrowgate, which avoids selling Harrowgate "at these levels". The size is modest, about 1.5% of Total Assets. The adviser selects the securities; Oakhurst does not place or instruct trades.
3. **Director of Fund Tax (Oakhurst):** same-day escalation under policy 7.1 (done with this memo). V. Osei also reviews the re-test.
4. **Tax Counsel:** confirm the cure analysis. Relief under §851(d)(2) is on standby only.
5. **Board certificate:** hold the BFVF section until the cure trades are confirmed and re-tested (policy 7.3). Deliver it with disclosure of the 8/31 discrepancy and cure.

## 8. What we need
- From the adviser or trading desk: cure trade confirmations with trade date on or before 9/30, and all trades since 8/31.
- From the adviser: confirmation that the Pemberton repo roll is being dealt with.
- Current voting shares outstanding for Stonefield and Harrowgate, to confirm the issuer-master figures.

No accounting entries are required. The books are not in question; the errors are in the tax workpaper.
