# GACP IV Call #2 (Lanternfly): allocation and issues

**To:** Nadia Kowalczyk | **Re:** Marcus Feld's request of Fri 2 Oct 2026 | **Date:** Mon 5 Oct 2026

## Bottom line
- **Call total: USD 45,766,400.00.** Investment 44,000,000.00 + Partnership Expenses 180,000.00 + Management Fee net 1,586,400.00 (gross 1,983,000.00 less offset 396,600.00).
- **We can't post the notice with a 16 Oct due date.** If the notice goes on the portal before 5:00 pm ET today, the LPA says the earliest Due Date is **Tue 20 Oct 2026**, which is the closing day.
- **Only Ostrander (LP-0106) is excused.** Kestrel Ridge (LP-0107) is not excused under the LPA, so it is called for its full share. That can change only if the GP gives written discretionary consent.
- **The Lanternfly USD 1.1m closing fee can't reduce this installment**, because it hasn't been received yet. It will reduce the 1 Jan 2027 installment by USD 880,000. The only offset in this call is the Osprey break-up fee.

## What to take back to Marcus this morning
1. **Due date.** LPA 3.3(a) requires the Due Date to be at least the 10th Business Day after delivery. LPA 11.2 treats a portal notice posted before 5 pm on a Business Day as delivered that day.
   - Counting from 5 Oct, the Business Days are 6, 7, 8, 9, 13, 14, 15, 16, 19 and 20 Oct. Mon 12 Oct is Columbus Day and the FRBNY is closed (holiday_calendar_2026H2.csv), so it does not count.
   - 16 Oct is only the 8th Business Day.
   - His options are: (a) a 20 Oct Due Date, with money arriving on closing day; (b) move the closing; or (c) bridge the closing some other way. He has said the subscription line is earmarked for Kite, so bridging is his call.
2. **Kestrel Ridge.** Kestrel's request came on 2 Oct.
   - The 3.7(a) deadline was Tue 29 Sep, the 10th Business Day after the 15 Sep Investment Notice.
   - Kestrel's reason is its own responsible-investment policy, not a law, and it has no counsel opinion.
   - It has no side letter, so it has no excuse right or MFN right.
   - Under 3.7(b) the GP may excuse it in writing at its sole discretion. If it does, the investment is spread over USD 525m of commitments (8.3810%, still under the 115% cap of 8.4333%) and every figure changes.
   - We need a written answer before we issue.
3. **Fee offset.** Under 8.2(a), only Fee Income received on or before the notice date counts.
   - The Lanternfly transaction fee (FI-IV-0003) is EXPECTED at closing, so it goes to the next installment.
   - The Osprey expense reimbursement (FI-IV-0002, USD 118,400) is excluded from Fee Income.
4. **Fee period.** The fee runs from the Fee Commencement Date, which is the Lanternfly closing (assumed 20 Oct). If closing slips, the fee must be recomputed.
5. **3.7(e).** We need the GP's written notice of Excused Partners (Ostrander only). Rachel should confirm.

Once Marcus confirms the 20 Oct due date and Rachel confirms the Kestrel position, the notices can still go up today, before 5 pm ET.

## Allocation (USD)
| Partner | Commitment | Investment | Expenses | Fee gross | Offset | Fee net | **Total** |
|---|---:|---:|---:|---:|---:|---:|---:|
| GP-0100 Granite Arch GP IV | 12,000,000 | 960,000.00 | 3,600.00 | 0.00 | 0.00 | 0.00 | **963,600.00** |
| LP-0101 Aldermoor SERS | 100,000,000 | 8,000,000.00 | 30,000.00 | 350,000.00 | 70,000.00 | 280,000.00 | **8,310,000.00** |
| LP-0102 Brightwater TPP | 90,000,000 | 7,200,000.00 | 27,000.00 | 315,000.00 | 63,000.00 | 252,000.00 | **7,479,000.00** |
| LP-0103 Meridian Crossing FoF III | 150,000,000 | 12,000,000.00 | 45,000.00 | 450,000.00 | 90,000.00 | 360,000.00 | **12,405,000.00** |
| LP-0104 Sable Point | 75,000,000 | 6,000,000.00 | 22,500.00 | 262,500.00 | 52,500.00 | 210,000.00 | **6,232,500.00** |
| LP-0105 Northfield Univ. | 60,000,000 | 4,800,000.00 | 18,000.00 | 210,000.00 | 42,000.00 | 168,000.00 | **4,986,000.00** |
| LP-0106 Ostrander (excused) | 50,000,000 | 0.00 | 15,000.00 | 175,000.00 | 35,000.00 | 140,000.00 | **155,000.00** |
| LP-0107 Kestrel Ridge | 25,000,000 | 2,000,000.00 | 7,500.00 | 87,500.00 | 17,500.00 | 70,000.00 | **2,077,500.00** |
| LP-0108 Harrowgate | 38,000,000 | 3,040,000.00 | 11,400.00 | 133,000.00 | 26,600.00 | 106,400.00 | **3,157,800.00** |
| **Total** | 600,000,000 | 44,000,000.00 | 180,000.00 | 1,983,000.00 | 396,600.00 | 1,586,400.00 | **45,766,400.00** |

## How each component was calculated (for re-performance)
**Sources:** partner_register_GACP_IV_20260930.csv, side_letter_terms_summary_GACP_IV.csv, GACP_IV_LPA_excerpt_capital_calls_fees.md, fee_income_register_GAM_FundIV_2026.csv, holiday_calendar_2026H2.csv, and the correspondence folder.

- **Investment (LPA 3.3(b) and 3.7(c)).**
  - Ostrander's request and the Pruett & Laine opinion arrived on 24 Sep, before the 29 Sep deadline. The opinion covers a legal prohibition: Retirement Code 7-114(c) bars firearms revenue above 10%, and Halberd's is 28%. GC accepted the opinion on 28 Sep, and side letter SL-IV-007 para 5.2 supports the excuse. **Ostrander is excused.**
  - The USD 44,000,000 is spread over the non-excused commitments of USD 550,000,000, including the GP. That is 8.0000% of each partner's commitment.
  - 115% cap test: with no excuses the share would be 44/600 = 7.3333%, so the cap is 8.4333%. The 8.0000% share (109.09% of the no-excuse amount) is within it.
- **Partnership Expenses (8.4 and 3.7(d)).**
  - The USD 180,000 is spread over all USD 600,000,000 of commitments, including the GP and both LPs that asked to be excused. That is 0.03% of commitment.
  - We rely on Marcus's statement that none of it is deal-related. We have not seen the invoices.
- **Management Fee (8.1).**
  - It is charged to Fee-Paying Partners only. The GP is fee-exempt.
  - The rate is 1.75% for everyone except LP-0103, which pays 1.50% under SL-IV-001 cl. 2.1.
  - The 1.50% rate does not pass to MFN holders LP-0101 and LP-0102. Their MFN covers only terms given to investors with equal or smaller commitments, and the 1.50% rate is a size-based term excluded from MFN.
  - The period is 20 Oct to 31 Dec 2026 inclusive, which is 73 days. Each partner's installment is its annual fee × 73/365: 7,665,000 × 0.2 + 2,250,000 × 0.2 = 1,983,000.
- **Offset (8.2).**
  - FI-IV-0001 is the Osprey break-up fee of 495,750, received 14 Aug and not applied before. 80% of it is 396,600.
  - It is shared pro rata to each partner's gross fee, which works out to exactly 20% of each gross amount.
- **Rounding and limits.** Each component is rounded to the cent (3.3(d)). All totals are well within the 30 Sep Unfunded Commitments (3.3(c)).
- **Delivery.** Brightwater's notice is also emailed to its custodian (SL-IV-002 3.1). Harrowgate's goes by email and courier (SL-IV-005 3.2).

## What we need, and from whom
| From | What we need |
|---|---|
| Marcus Feld | Agreement to a 20 Oct Due Date, or a new closing or funding plan |
| Marcus Feld | Confirmation that closing is still 20 Oct |
| Marcus Feld | The expense invoices |
| Rachel Oyelaran (GC) | The 3.7(e) written notice of Excused Partners |
| Rachel Oyelaran (GC) | The GP's decision on a 3.7(b) excuse for Kestrel, in writing |
| IR | A reply to Kestrel once the GP has decided |
| Manager | FI-IV-0001 marked as applied to installment 1; FI-IV-0003 queued for the 1 Jan 2027 installment |
