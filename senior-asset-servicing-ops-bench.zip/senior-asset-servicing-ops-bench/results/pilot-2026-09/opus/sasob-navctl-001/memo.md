**To:** Mara Lindqvist, Treasurer & PFO, Corvane Investment Trust
**Re:** CMOF: correcting the stale OSMD price, 9/10 to 9/16. My view before your 2pm with Stellmark
**Date:** 18 Sep 2026

## Bottom line
Please don't sign Rafael's proposal as it stands. I agree with his facts but not his approach. Four parts of it conflict with the Trust's NAV Error Correction Policy (v3.1) or with the Stellmark agreement:

| Rafael's proposal | Required approach | Basis |
|---|---|---|
| Reprocess all five days, 9/10 to 9/16 | Reprocess only **9/11, 9/14 and 9/16**. 9/10 and 9/15 are not Material Days | Policy 1.4, 2.1, 3.1 |
| Net loss of about $12k, with gains offsetting losses | Fund Loss is **$43,724.90** gross, with no netting across transactions or days | Policy 6.1, 6.2 |
| Skip each transaction under $10 | Add up what each account is owed across all Material Days and test the **account total** against $10. Benefits are not netted against amounts owed | Policy 5.3 |
| Fund carries the loss; Stellmark is not liable under 7.2 | **Stellmark (administrator) pays.** The 7.2 carve-out only applies if Schedule C was followed, and it wasn't. The Fund bears **$0** | FAA 7.2, 7.3, 7.4; Policy 7.1, 7.2 |

## 1. What happened (sources: `pricing/primary_vendor_notice_QPS-558120.txt`, `pricing/price_exception_log_...csv`)
OSMD moved its listing from NYSE to Nasdaq on 9/10. The primary vendor kept sending the last NYSE close, $48.20, through 9/16. On every one of those days Stellmark's exception log flagged OSMD as UNCHANGED_PRICE, and Stellmark cleared the flag each time:
- On **9/10 and 9/15** it cleared the flag as "Within tolerance". Schedule C.3 says an unchanged-price exception may not be cleared on the basis that prices are within tolerance.
- On **9/11, 9/14 and 9/16** the price was also outside the 5% tolerance (5.70%, 7.35% and -5.68%). Stellmark accepted the primary price anyway, relying on the vendor's statement that the price "will update". That breaches C.2, which requires the exchange official close, and C.4, which says a "will update" statement cannot clear an exception.
- On 11 Sep at 16:47 the PM flagged the problem himself: OSMD had printed 45.60 on Nasdaq (`correspondence/email_corvane_pm_desk_20260911.txt`). Ops forwarded his email to Stellmark Pricing at 16:58, before NAV release. Stellmark cleared the exception at 17:55 without using the exchange close.

Stellmark did not perform the Schedule C validation procedures. That means FAA 7.2 does not protect it, and FAA 7.3 applies: Stellmark reimburses the Fund under our Policy and bears its own reprocessing costs. Under FAA 7.4, the vendor's liability cap does not reduce what Stellmark owes. Under Policy 7.2, whatever Stellmark recovers from the vendor is between Stellmark and the vendor, and it does not delay payment to the Fund.

## 2. Corrected NAVs and materiality (Policy 1.2, 1.4)
Method: take published TNA, subtract (48.20 − Nasdaq official close) × OSMD position, divide by the published shares outstanding, and round to $0.01. The Nasdaq closes are the secondary prices in the exception log. Positions start from 1,200,000 shares in `portfolio/holdings_top_positions_CMOF_20260909.csv`. The 200,000-share sale EQ-260915-0063 in `trade_blotter` (traded 9/15, settled 9/16) is treated as reflected from the 9/16 NAV onward.

| NAV date | OSMD qty | Nasdaq close | Valuation error $ | Published | Corrected | Error/sh | % of corrected | Status |
|---|---|---|---|---|---|---|---|---|
| 9/10 | 1,200,000 | 47.10 | 1,320,000 | 24.34 | 24.26 | +0.08 | 0.3298% | Not material |
| 9/11 | 1,200,000 | 45.60 | 3,120,000 | 24.24 | 24.05 | +0.19 | 0.7900% | **Material** |
| 9/14 | 1,200,000 | 44.90 | 3,960,000 | 24.37 | 24.13 | +0.24 | 0.9946% | **Material** |
| 9/15 | 1,200,000 | 47.35 | 1,020,000 | 24.37 | 24.31 | +0.06 | 0.2468% | Not material |
| 9/16 | 1,000,000 | 51.10 | −2,900,000 | 24.40 | 24.58 | −0.18 | −0.7323% | **Material (understated)** |

The 9/17 NAV was priced at the Nasdaq close (50.62) and is clean. Under Policy 1.2, later NAVs are not re-struck. Days 9/10 and 9/15 are only logged in the NAV error log and reported to the Board quarterly (Policy 3.1, 8.3). No shareholder activity on those days is reprocessed and no reimbursement is sought for them.

## 3. Reprocessing the Material Days (Policy 4 to 6; source `transfer_agent/ta_transaction_detail_...csv`)
Shares are calculated to 3dp, rounding half up. Dollar orders keep the dollar amount fixed. Share orders keep the share count fixed.

The published NAV was too high on 9/11 and 9/14. Buyers on those days got too few shares, and redeemers were overpaid, which is a Fund Loss. On 9/16 the NAV was too low. Buyers got too many shares, which is a Fund Loss, and share-based redeemers were underpaid.

**Fund Loss by transaction (value given up, at the corrected NAV)**
- 9/11: 102310 redeemed 60,000 shares, overpaid $11,400.00. 900027 redeemed 18,500 shares, overpaid $3,515.00. **Total $14,915.00**
- 9/14: 101122 made a $500k dollar redemption; 20,517.029 shares were redeemed against 20,721.094 correct, a shortfall of 204.065 shares × 24.13 = $4,924.09. 103002 redeemed 4,200.5 shares, overpaid $1,008.12. **Total $5,932.21**
- 9/16: 900011 bought $3.1m and received 930.384 excess shares × 24.58 = $22,868.84. 100587 bought $1,200 and received 0.360 excess shares, $8.85. **Total $22,877.69**
- **Fund reimbursement due from Stellmark: $43,724.90**

**Amounts owed to shareholders** (totals before de minimis: 9/11 $18,831.49; 9/14 $7,404.84; 9/16 $6,667.20)

| Account | Registration | Shares credited | Cash | Aggregate value | Result |
|---|---|---|---|---|---|
| 900011 | Tarrant Hollis omnibus | 782.199 (9/11) | – | $18,811.89 | Adjust |
| 900027 | Wexcombe omnibus | 306.097 (9/14) | $2,160.00 (9/16) | $9,546.12 | Adjust |
| 102310 | Ellery Twp P&F | – | $4,500.00 (9/16) | $4,500.00 | Adjust |
| 101945 | R Vasquez IRA | 0.326 + 0.286 = 0.612 | $7.20 | $21.94 | Adjust. Every item is under $10 on its own, so Rafael's per-transaction rule would wrongly skip this account |
| 100587 | Okonkwo JTWROS | 0.293 + 0.327 = 0.620 | – | $14.94 | Adjust. The $8.85 benefit on 9/16 is not netted (5.3) |
| 103771 | L Sato Roth IRA | 0.196 + 0.163 = 0.359 | – | $8.64 | Below $10 de minimis. No adjustment; the Fund keeps the value |

**Totals after de minimis:** 1,089.528 shares credited and $6,667.20 cash, across 5 accounts. Accounts that benefited (102310, 900027, 101122, 103002, 900011, 100587) are not debited (Policy 5.2). The omnibus adjustments go to the intermediaries, who allocate them to their underlying customers (Policy 5.4).

## 4. Who pays, and what the Fund bears
Stellmark, as administrator, pays **$43,724.90** within five Business Days of your approval of the calculation (Policy 6.3). It also bears its own reprocessing costs (FAA 7.3). If Stellmark disputes liability, Policy 7.1 requires the Adviser to reimburse the Fund, subject to Board review, while the dispute with Stellmark is pursued. **The Fund bears $0.** For reference, Rafael's figure of about $12k is roughly the net of Fund Losses ($43.7k) minus the value owed to shareholders ($32.9k). The Policy does not allow that netting.

## 5. What you owe the CCO and the Board (Policy 8)
- **You:** give written approval of this corrected calculation before the TA reprocesses anything (8.1).
- **CCO:** report promptly. There are three Material Days, so the reporting obligation is triggered now (8.2).
- **Board:** report at the next regular meeting. Cover the Material Days, root cause, reimbursement, shareholder adjustments and remediation (8.2). Days 9/10 and 9/15 go in the NAV error log and the quarterly report (8.3). Root cause and remediation should cover two things. First, Stellmark's Schedule C failures, including C.5 supervisor review not catching five consecutive unchanged-price clearances. Second, why the PM's 9/11 challenge did not stop the NAV release.

## 6. Requests before final sign-off
- **Stellmark Pricing / NAV:** (a) confirm the trade-date booking of the 9/15 OSMD sale. If it was booked T+0, the 9/15 corrected NAV is 24.32 and the error is 0.2056%; it is still not material, so nothing else changes. (b) Confirm the Nasdaq official closes from an independent source. (c) Confirm whether any other class or series held OSMD. (d) Provide a root-cause and remediation report.
- **Stellmark Shareholder Services:** confirm the TA extract is the complete activity for the Error Period, with no as-of or cancelled trades.
- **Intermediaries (Tarrant Hollis, Wexcombe):** acknowledge the adjustments and the allocation to beneficial owners.

## Assumptions
- Only the OSMD price was wrong. All other positions and accruals are taken as published.
- The Corrected NAV uses the published shares outstanding (Policy 1.2) and rounds half up to $0.01.
- Every figure above can be re-derived from the cited input files using the method stated in each section.
