**To:** Graham Voss, Head of Operations Oversight
**Re:** TMAI / Northgate 7730-131 holdings rec as of close 17 Sep 2026: do not true up

## Bottom line
- **Do not approve Pellmore's true-up to Northgate.** Under policy §2.2 the accounting records are the book of record. A position is changed only when a difference has been traced to a specific event and the books are shown to be wrong. That is true for only one of the four securities, Marlowe Water Technologies (MWT), and it gets fixed by booking the corporate action, not by forcing a quantity. Forcing the other three would put errors *into* the books: 170k Brindlewood removed, 64k Alder added a day early and 90k Pinecrest shares that no longer exist added back.
- **Act today, before 11:00 a.m. ET:** recall the **150,000 Brindlewood shares** on loan so they are back for the **24 Sep record date** of the Castellan merger vote, which the proxy committee has designated as material.
- **NAV error:** the unbooked MWT spin-off understated the 16 Sep and 17 Sep NAVs by **$0.0274 (0.23%)** and **$0.0279 (0.24%)** per share. Under policy §5.2 an error is material only if it is at least $0.01 **and** at least 0.50%, so this one is **not material**. We correct it in the next NAV (18 Sep), do not restate and do not reprocess, but notify the Treasurer today and log it.

## Differences (books on trade-date basis − Northgate MT535 settled)
| Security | Books | Northgate | Diff | Cause | Wrong side | Treatment |
|---|---|---|---|---|---|---|
| Brindlewood USLPV8NW1399 | 420,000 | 250,000 | +170,000 | 150,000 on open loan + 20,000 buy not yet settled | neither | reconciling items |
| Alder Semi US0C86UQ8545 | 64,000 | 128,000 | −64,000 | 2:1 split credited on payable date (17 Sep) ahead of ex-date (18 Sep) | neither (timing) | reconciling item, clears 18 Sep |
| Marlowe Water Tech US3EP60F8227 | 0 | 46,250 | −46,250 | MDH spin-off (ex 16 Sep) not booked | **Accounting** | book the corporate action |
| Pinecrest Health USE3E5QV1890 | 0 | 90,000 | −90,000 | Northgate still reports shares it debited on 16 Sep in the cash merger | **Custodian** | raise with Northgate, books unchanged |

All other lines agree. I checked two lending items specifically:
- **Ostrander:** loan HSF-L-2607-10455 was returned 17 Sep, and both sides show 200,000.
- **Corvant:** loan HSF-L-2609-12877 is PENDING_DELIVERY, which under SLAA §4.3 means it has not left custody. Both sides show 145,000.

The Keel Harbor sale and the Ribbonwood buy both settled and agree. MDH agrees at 185,002.

### 1. Brindlewood (+170,000): two causes
- **150,000 on loan.** Source: `lending/harrowgate_onloan_report_TMAI_20260917.csv`, loan HSF-L-2608-11932, OPEN since 20 Aug. The MT535 ADDINFO and SLAA §4.2 confirm that loaned shares are not reported in safekeeping. Under §2.3(b) and §4.1 this is an expected reconciling item, and the loaned shares remain fund assets.
- **20,000 unsettled buy.** Source: `accounting/unsettled_trades_TMAI_20260917.csv`, EQ-260917-0412, trade date 17 Sep, settles 18 Sep. This is a reconciling item under §2.3(a).
- Proof: 420,000 − 150,000 − 20,000 = 250,000, which is the MT535 figure.
- **Proxy issue (urgent):**
  - Source: `notices/brindlewood_special_meeting_notice.txt`. The record date is **24 Sep** and the meeting is 22 Oct. Approval requires a majority of outstanding shares.
  - Source: `correspondence/email_pm_brindlewood_vote.txt`. The PM intends to vote AGAINST, and the committee minuted the vote as material on 27 Aug, item 4.
  - Voting rights on the loaned shares sit with the borrower (SLAA §6.2).
  - Recall timing (SLAA §7.1): a notice received by 11:00 ET is communicated to the borrower the same day, and the borrower redelivers T+1. Today is Fri 18 Sep, so a notice in by 11:00 today means redelivery Mon 21 Sep. That is 3 business days before the record date, which is Harrowgate's recommended buffer for material votes (§7.2).
  - If the notice misses 11:00, redelivery slips to 22 Sep and the buffer shrinks.
  - **Recall quantity: 150,000.** With the 20k buy, the voting position is 420,000 shares.

### 2. Alder Semiconductor (−64,000): timing
- Sources: `custodian/MT566` message 3 and `notices/alder_stock_split_notice.txt`.
- The 2-for-1 split is paid as a stock dividend. The payable date is 17 Sep after the close, and the NYSE ex-date is 18 Sep. Northgate credited 64,000 shares on the payable date.
- Policy §3.1 requires booking on the ex-date even when the ex-date falls after the payable date, and CA-26-04702 is correctly SCHEDULED for 18 Sep. This is a reconciling item under §2.3(c).
- Market value is identical on both sides: 64,000 × 188.40 = 128,000 × 94.20 = 12,057,600. There is **no NAV impact**, and no entry beyond the scheduled one.

### 3. Marlowe Water Technologies (−46,250): accounting error
**What happened**
- Sources: `custodian/MT566` message 1, `notices/marlowe_spinoff_notice_and_form8937_extract.txt` and `accounting/corporate_action_events_TMAI.csv` (CA-26-04655).
- Terms: 1 MWT for every 4 MDH, record date 4 Sep, distribution 15 Sep, **ex-date 16 Sep**.
- Northgate credited 46,250 MWT. The entitlement was 185,002 / 4 = 46,250.5, so 0.5 shares are paid as cash in lieu.
- Pellmore left the event in PENDING_TERMS "awaiting cost allocation from vendor feed", and MWT was never set up in the security master. Policy §3.2 caps PENDING_TERMS at the day before the ex-date, after which Fund Accounting must book from issuer information. Form 8937 had been posted on 14 Sep, so there was no reason to wait. This is a break caused by the accounting record (§2.5).

**Entry, effective 16 Sep** (policy §3.3–3.4). The 15% figure in the information statement is illustrative and is not used.
| Item | Calculation | USD |
|---|---|---|
| MDH pre-distribution cost | per positions file | 7,215,078.00 |
| Allocated to MWT (13.60%) | 7,215,078.00 × 0.136 = 981,250.608 → | 981,250.61 |
| **MDH cost after allocation** (remainder) | 7,215,078.00 − 981,250.61 | **6,233,827.39** |
| Fractional-share cost relieved | 981,250.61 × 0.5 / 46,250.5 | 10.61 |
| **MWT cost, 46,250 whole shares** | 981,250.61 − 10.61 | **981,240.00** |
| **Cash-in-lieu receivable** | agent notice: 0.5 sh → USD 12.16 (0.5 × 24.3176), paid about 22 Sep | **12.16** |
| **Realized gain** | 12.16 − 10.61 | **1.55** |

**NAV impact** (policy §5.1; share counts and NAVs from `accounting/nav_history_TMAI.csv`; prices from `pricing/closing_prices_20260915_17.csv`)
| NAV date | Missing value | Shares outstanding | Error / share | % of reported NAV | Material? |
|---|---|---|---|---|---|
| 16 Sep | 46,250 × 24.55 + 12.16 = 1,135,449.66 | 41,380,112.405 | **+0.0274** | **0.23%** of 11.7572 | No |
| 17 Sep | 46,250 × 24.91 + 12.16 = 1,152,099.66 | 41,362,540.118 | **+0.0279** | **0.24%** of 11.7958 | No |

- The 15 Sep NAV is not affected: MDH was still trading cum-distribution at 44.62.
- The error is corrected minus reported, so a positive figure means reported NAVs were understated.
- Both errors are at least $0.01 but below 0.50%, so they fail limb (ii) of §5.2 and are **not material**.
- Under §5.4: correct in the next NAV struck, do not restate, do not reprocess shareholder activity, notify the Fund Treasurer the same day, and record the error in the NAV error log for the quarterly Board report.
- Excluding the $12.16 cash in lieu changes nothing at 4dp.

### 4. Pinecrest Health (−90,000): custodian error
- Pinecrest was cashed out in a mandatory merger at $41.25, effective and delisted on 15 Sep.
- Accounting removed the 90,000 shares on 15 Sep and received the $3,712,500 proceeds on 16 Sep (CA-26-04418).
- Northgate's own MT566 message 2 (SEME NTC566-7730131-0916-03) shows the 90,000 shares **debited on 16 Sep** and the cash credited. Yet the 17 Sep MT535 still reports 90,000 shares worth $3,712,500.
- This is a stale custodian balance. Under §2.4, raise it with Northgate Client Service today with the MT566 as evidence. The books do not change.

## Actions
**Today**
1. Harrowgate: recall 150,000 BWI (HSF-L-2608-11932) **before 11:00 ET**. Ask them to confirm the recall was communicated to the borrower and that redelivery happens 21 Sep. Place no new BWI loans through the record date.
2. PM (Selin Aukland) and Proxy Voting Committee: confirm the recall is in, and confirm that settlement of the 20k buy and of the recall both land before 24 Sep.
3. Pellmore:
   - Set up MWT in the security master.
   - Book CA-26-04655 as shown above, effective 16 Sep, so the correction is in the 18 Sep NAV.
   - Book the cash-in-lieu receivable.
4. Fund Treasurer: send the NAV error notification (§5.4) and add the error to the NAV error log.
5. Northgate Client Service: raise the Pinecrest statement error and ask for a corrected MT535.

**Next week**
- Escalate the vendor cost-allocation gap and Pellmore's §3.2 breach.
- True up the cash in lieu to the amount received about 22 Sep, when Northgate's replacement MT566 arrives.
- Confirm the Alder split posted on 18 Sep and that the break cleared.

## Assumptions and open items
- The 16 and 17 Sep NAVs priced MDH at its exchange close: 38.40 ex-distribution and 38.95 respectively. The 17 Sep figure is confirmed in the positions file; Pellmore should confirm the 16 Sep figure. On that basis, the only omission is the MWT shares plus the cash in lieu.
- Cash in lieu is taken at the agent's $12.16 until the amount is actually received.
- No other data was assumed. All figures come from the files cited above in `inputs/`.
