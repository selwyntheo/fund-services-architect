# GACP II – Distribution 8 (Delphine), 30 Sep 2026: Article 9 waterfall

**To:** Jonas Whitcombe · **Re:** Marcus Feld's email of 17 Sep and the IC consent of 16 Sep

## Bottom line
- Distributable Proceeds: **USD 112,000,000.00** (IC consent, `inputs/correspondence/2026-09-16_GP_distribution_approval_Delphine.txt`).
- **Carried Interest is USD 28,745,767.86**, not about USD 16.4mm. But under LPA s.9.6, 25% of it (**USD 7,186,441.99**) has to go to the Carry Escrow Account (4471-2290, SSI-II-015). **Only USD 21,559,325.87 of carry can be wired to the GP** on the 30th.
- The GP operating account (SSI-II-014) gets **USD 23,799,325.87** in total. That is the GP-commitment distribution of USD 2,240,000.00 (not carry) plus USD 21,559,325.87 of carry.
- The Limited Partners get **USD 81,014,232.14** in total.
- The GP catch-up is **not complete** after this distribution. The GP is still USD 5,440,416.18 short, so no amount reaches the 80/20 split.

## Method (LPA extract, `inputs/lpa/GACP_II_LPA_excerpt_distributions.md`)
1. **s.9.1 apportionment by Commitment.** Total Commitments are USD 300mm (`investor_records/partner_register_GACP_II.csv`). GP-0020 holds 6mm, or 2%, which gives it **2,240,000.00**. Under s.9.3 that goes 100% to the GP. It is not carry and is not escrowed. The LPs' share is **109,760,000.00**.
2. **s.9.2, whole-of-fund, applied to each LP separately**, using all Capital Contributions for any purpose (investments, fees, expenses, organisational costs) and all prior distributions.
   - Contributions come from `capital_activity/contributions_...csv` (475 rows). LPs total **270,009,600.00**. Every LP has paid in 91.84% of its commitment, so the results are pro rata.
   - Prior distributions come from `capital_activity/distributions_...csv`, Distributions 1–7. LPs total **324,380,000.00**. All were booked as tiers 1–2 with no carry.
3. **Tier (a).** Capital was already fully returned before this distribution, so tier (a) is **0**.
4. **Tier (b) preferred return.** For each LP: the value of its contributions compounded to 30 Sep 2026, minus the value of its prior distributions compounded to the same date. Compounding uses 1.08^(days/365), counted from each due date or distribution date.
   - Example, LP-0021: 110,615,948.45 − 95,549,052.50 = 15,066,895.95.
   - Total for all LPs: **73,827,790.16**, paid in full.
5. **Tier (c) catch-up.** The GP is entitled to 20% of (all amounts ever paid under (b) plus all catch-up amounts). That makes the GP target 0.2 × B ÷ 0.75.
   - Cumulative (b) is **128,198,190.16**. That is the 54,370,400.00 by which prior distributions exceeded contributions, plus the 73,827,790.16 paid now.
   - The GP target is therefore 34,186,184.04.
   - Only 35,932,209.84 is left for this tier. At 80/20 that gives the **GP 28,745,767.86** and the **LPs 7,186,441.98**.
   - The GP ends the distribution 5,440,416.18 short. Carry this shortfall forward to the next distribution.
6. **Rounding (s.9.4).** Amounts are computed for each partner and each tier and rounded to the cent. Escrow is 25% of each LP's carry, rounded, then summed: 7,186,441.99. Taking 25% of the total instead gives 7,186,441.97.

## Per-investor amounts (USD)
| Partner | Apportioned | Pref (b) | Catch-up LP 20% | **Net to LP** | Carry arising | of which escrow | carry to GP |
|---|---|---|---|---|---|---|---|
| LP-0021 | 22,400,000.00 | 15,066,895.95 | 1,466,620.81 | **16,533,516.76** | 5,866,483.24 | 1,466,620.81 | 4,399,862.43 |
| LP-0022 | 18,666,666.67 | 12,555,746.63 | 1,222,184.01 | **13,777,930.64** | 4,888,736.03 | 1,222,184.01 | 3,666,552.02 |
| LP-0023 | 16,800,000.00 | 11,300,171.96 | 1,099,965.61 | **12,400,137.57** | 4,399,862.43 | 1,099,965.61 | 3,299,896.82 |
| LP-0024 | 13,066,666.67 | 8,789,022.64 | 855,528.81 | **9,644,551.45** | 3,422,115.22 | 855,528.81 | 2,566,586.41 |
| LP-0025 | 14,933,333.33 | 10,044,597.30 | 977,747.21 | **11,022,344.51** | 3,910,988.82 | 977,747.21 | 2,933,241.61 |
| LP-0026 | 8,960,000.00 | 6,026,758.38 | 586,648.32 | **6,613,406.70** | 2,346,593.30 | 586,648.33 | 1,759,944.97 |
| LP-0027 | 14,933,333.33 | 10,044,597.30 | 977,747.21 | **11,022,344.51** | 3,910,988.82 | 977,747.21 | 2,933,241.61 |
| **Total LPs** | 109,760,000.00 | 73,827,790.16 | 7,186,441.98 | **81,014,232.14** | 28,745,767.86 | 7,186,441.99 | 21,559,325.87 |
| GP-0020 (commitment) | 2,240,000.00 | – | – | 2,240,000.00 to GP | – | – | – |

Tier (a) and tier (d) are zero for every LP.

**Payments on 30 Sep:**
| Payee | Amount (USD) |
|---|---|
| LPs | 81,014,232.14 |
| Carry Escrow 4471-2290 | 7,186,441.99 |
| GP operating 00-771934-2 | 23,799,325.87 |
| **Total** | **112,000,000.00** ✔ |

## Why our number differs from the GP finance team's USD 16.4mm (for Marcus)
Dev's figure is (112mm − 30mm Delphine cost) × 20% = 16.4mm. That is a deal-by-deal calculation on Delphine alone. The LPA works differently in four ways:
1. **Whole-of-fund, not deal-by-deal (s.9.2).** The hurdle and the catch-up look at every contribution and every distribution since 2015, not at one deal.
   - Contributions include USD 270mm of LP capital, of which management fees and expenses are part.
2. **The catch-up is on all preferred return ever paid.** Distributions 1–7 paid LPs about USD 54.4mm above their capital. Under s.9.2 that was preferred return, and the GP took no catch-up on it at the time.
   - The GP's catch-up entitlement covers that history too. That is why gross carry here is larger than Dev's figure (28.75mm).
   - Even so, the catch-up is not finished. There is no 80/20 split yet.
3. **The GP's own 2% share is not carry base (s.9.1/9.3).** Carry arises only on the USD 109.76mm apportioned to LPs. The GP's USD 2.24mm is paid to it as a partner.
4. **The escrow (s.9.6).** 25% of carry is held in escrow. The cash the GP partners can plan on from this distribution is **USD 21,559,325.87** of carry, plus the 2.24mm commitment return.

We cannot follow the instruction to wire "the carry" in full to the GP operating account. The escrow portion goes to SSI-II-015.

## Assumptions
- Preferred-return dates run from each contribution due date and each distribution payment date to 30 Sep 2026, on an actual/365 basis, using the formula in the LPA definition.
- The prior distributions were paid as recorded, and all LP amounts over capital were tier (b).
- The operational LPA extract reflects the executed agreement.
- Ashgrove is unrealised (FV 41.5mm), and the R&W retention is 6.72mm. Neither affects the calculation, because the LPA has no NAV or holdback test.

## Needed from whom
- **Marcus Feld (GP CFO):** acknowledge the Article 9 figures and the escrow requirement, stop using the 16.4mm, and approve the notices by 24 Sep.
- **Halcyon treasury / investor services:** callback-verified LP SSIs. None are in the inputs.
- **GP / legal:** the s.9.7 (clawback) text, and confirmation that the rounding for the escrow is done per partner.
- **Fund auditor:** notify them that this is the first carried-interest distribution, and provide this workpaper.
