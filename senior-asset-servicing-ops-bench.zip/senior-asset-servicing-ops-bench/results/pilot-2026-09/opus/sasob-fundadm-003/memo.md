# BEIO September 2026 Section 19(a) notice: final figures

**To:** Nadia Okonkwo, Treasurer
**From:** Oakhurst Fund Administration, CEF Administration
**Date:** 24 Sep 2026

## Bottom line
- Draft v1 (K. Doyle, 23 Sep) is **not correct** and should not go to Harwick as drafted. The corrected figures are below.
- A 19(a) notice **is required** because the distribution is partly from ST gains and ROC.
- **We cannot align the notice with the tax estimate.** Procedures §4.1 require book-basis sources (Rule 19a-1(e)) and state that tax-basis 1099 estimates are not used.
- **The August notice was significantly wrong** (§5.1). The **CCO** (and you) must be notified before September is released, and the September notice must say that previously reported estimates have changed.

## Corrected figures (shares 18,420,000; per share rounded to 4dp, ROC is the balancing figure, §4.7)

| Source | Current $ | Current % | Cumulative FYTD (11/1/25-9/30/26) $ | Cumulative % |
|---|---|---|---|---|
| Net investment income | 0.0586 | 51.0% | 0.6578 | 52.8% |
| Net realized ST gains | 0.0092 | 8.0% | 0.3295 | 26.5% |
| Net realized LT gains | 0.0000 | 0.0% | 0.0000 | 0.0% |
| Return of capital | 0.0472 | 41.0% | 0.2577 | 20.7% |
| **Total** | **0.1150** | 100.0% | **1.2450** | 100.0% |

Plan disclosures, as of 8/31/2026 (NAV $15.4180, `performance/BEIO_performance_summary_20260831.csv`):
- 5-yr average annual total return (NAV): 7.84%
- Annualized current distribution rate: 0.1150×12/15.4180 = **8.95%**
- Cumulative FYTD total return (NAV): 9.12%
- Cumulative FYTD distribution rate: 1.2450/15.4180 = 8.0750% → **8.07%** (the draft's 8.08% is wrong)

Deficit statement (Rule 19a-1(b)): **not required**. Accumulated realized gains started at 0 (FY2025 fully distributed), and FYTD net realized gains of $6,068,600 are fully used by the distribution. Unrealized appreciation of $51,377,815 at 23 Sep leaves no deficit.

## Workings (re-performable)
Sources: `accounting/BEIO_book_income_and_realized_gains_FY2026.csv`, `accounting/BEIO_capital_accounts_20251031_and_20260923.csv`, `accounting/BEIO_nii_accrual_forecast_20260924_20260930.csv`, `distributions/BEIO_distribution_history_FY2026.csv`, `policies/BEIO_managed_distribution_plan_19a_procedures.md`.

**Distributions**
- Nov-Feb 4 × $2,026,200 plus Mar-Sep 7 × $2,118,300 = **$22,932,900** ($1.2450/sh).
- Through August: $20,814,600 ($1.1300/sh).

**(a) Cumulative through 30 Sep**
- NII available = UNII $412,540 + Nov-Aug NII $10,625,010 + Sep MTD $812,640 + forecast $265,910 = $12,116,100.
- ST = $9,400,950; LT = −$3,332,350. Netted in aggregate (§4.4): ST $6,068,600, LT 0.
- Attribution: NII $12,116,100 / ST $6,068,600 / LT 0 / ROC $4,748,200.

**(b) Previous cumulative through 31 Aug (final books)**
- NII available $11,037,550.
- ST $8,932,730; LT −$3,033,920, netted to ST $5,898,810.
- Attribution of $20,814,600: NII $11,037,550 (all available NII) / ST $5,898,810 / LT 0 / ROC $3,878,240. Per share: NII 0.5992, ST 0.3202, LT 0, ROC 0.2105.

**Current = (a) − (b)**
- NII $1,078,550 → 0.0586
- ST $169,790 → 0.0092
- ROC balancing 0.0472 ($869,960)

## What was wrong with draft v1
1. **Cumulative NII left out UNII of $412,540** (§4.2): 0.6354 → 0.6578.
2. **The LT net loss was zeroed instead of netted against ST** (§4.4): cumulative ST 0.5104 → 0.3295, and current ST 0.0254 → 0.0092 (September LT loss of −$298,430 against ST of $468,220).
3. **The current column was computed on its own** instead of as (a) − (b) (§4.6).
4. ROC is therefore understated: current 0.0310 → 0.0472, cumulative 0.0992 → 0.2577. All percentages change.
5. The cumulative FYTD distribution rate should be 8.07%, not 8.08%.
6. **Missing content** (§3.3):
   - the Plan paragraph
   - the "should not draw any conclusions" legend
   - the estimates / Form 1099-DIV legend
   - the §5.1(ii) changed-estimates statement

## Marketing request (T. Ruiz, 23 Sep): declined
The tax estimate (`tax/BEIO_tax_character_estimate_FY2026_20260915.csv`) is a federal tax-basis projection for 1099 planning. It includes straddle and wash-sale deferrals and REIT/MLP recharacterisations, and it assumes an October distribution. Section 19(a) sources must come from the book records to the close of the payment month (§4.1). Using the tax figures would make the notice non-compliant. The existing legend already tells shareholders that 1099 character may differ. Marketing preference is not a permitted input to the sources. I suggest the CCO is made aware of the request.

## Last month's notice: goes to the CCO before release
I recomputed August cumulative under §4.6(b):

| Source | Recomputed | August notice | Difference |
|---|---|---|---|
| NII | 0.5992 | 0.5992 | none |
| ST | 0.3202 | 0.4849 | 0.1647 |
| ROC | 0.2105 | 0.0459 | 0.1646 |

The difference is more than $0.0100. The cause was the same failure to net the LT loss. Under §5.1 you must:
1. Notify the **CCO** and the Treasurer before the September notice is released.
2. Include a changed-estimates statement in the September notice.
3. Flag the item for the next shareholder report.

Suggested statement: "The Fund's estimates of the sources of cumulative fiscal year-to-date distributions reported in the August 2026 notice have changed. Distributions previously estimated to be from net realized short-term capital gains are now estimated to include a greater portion of return of capital, reflecting the netting of the Fund's net realized long-term capital losses." The CCO and you should agree the wording.

## Assumptions and open items
- September NII uses daily NAV through 23 Sep (unaudited) plus the accrual forecast. Realized gains for 24-30 Sep are not forecast (§4.3). Final September books will be trued up through next month's previous-cumulative comparison.
- Shares on the record date are 18,420,000 (no issuance or repurchase).
- You and the CCO need to decide whether the August website notice or press release should be annotated.

## Timetable (§6.2)
- Final figures to you today (24 Sep).
- TA insert file by 12:00 ET Fri 25 Sep.
- Press release by Mon 28 Sep.
- Payment Wed 30 Sep.

Nothing is released until you approve (§6.1) and the CCO has been notified (§5.1).
