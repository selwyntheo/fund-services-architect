# TSIF: GL 1300 accrued interest vs Northgate 7730-150, NAV 17 Sep 2026

**To:** Delphine Okoro | **Re:** USD 62.99 break

## Summary
Do not sign the write-off. The USD 62.99 is the net of five position-level differences that add up to **USD 22,290.09 gross**. Section 3.3 of the procedures does not allow the de minimis rule to net off offsetting differences. Once every position is explained, the unexplained residual is **nil**.

- Our records are wrong on four positions. All four trace back to Reference Data feed or set-up problems, plus one missed non-accrual reversal.
- The net correcting entry to GL 1300 is **USD -276,337.99**.
- The correct GL 1300 balance is **USD 1,328,927.26**.
- After we book, we will differ from Northgate by **USD -276,275.00**. That difference is entirely on Northgate's side and is explainable.
- NAV impact is **USD -0.0044/share** (-0.043%). That is not material, so we correct it in the next NAV and do not restate.

## Sources
- `inputs/accounting/accrued_interest_TSIF_20260917.csv`: GL 1300 detail. Total is 1,357,765.25 accrued plus 247,500.00 past-due, which gives **1,605,265.25**.
- `inputs/custodian/northgate_accrued_income_report_7730-150_20260917.csv`: 1,357,702.26 accrued plus 247,500.00 claims, which gives **1,605,202.26**. The break is +62.99.
- `inputs/reference/offering_terms_extracts_TSIF.txt`: the governing terms.
- `inputs/reference/security_master_income_setup_TSIF.csv`, `inputs/reference/cpi_u_nsa_index_2026.csv`.
- `inputs/notices/corbin_frn_rate_reset_notices.txt`, `inputs/notices/tam_valuation_committee_minute_20260914.txt`.
- `inputs/policies/TFT_income_accrual_and_reconciliation_procedures.md`, sections 3, 5 and 6.
- `inputs/accounting/nav_summary_TSIF_20260917.csv`.

**Convention:** the NAV for date T accrues through T inclusive, so each accrual end date is 18 Sep 2026, exclusive (s.5.1).

## Position-level findings (USD)

| # | Security | Ours (GL) | Northgate | Correct | Wrong side | Entry | Cause |
|---|---|---:|---:|---:|---|---:|---|
| F1 | UST 3.875% 2031 US29DKMU3994 | 91,493.06 | 89,504.08 | 89,504.08 | Accounting | -1,988.98 | Day count |
| F2 | Gantry 5.40% 2032 US72IBAI2618 | 251,100.00 | 256,500.00 | 251,100.00 | Northgate | 0.00 | Day count |
| F3 | Corbin FRN 2028 USRLI7T61226 | 90,456.89 | 81,269.33 | 81,269.33 | Accounting | -9,187.56 | Missed rate reset |
| F4 | UST TIPS 1.625% 2034 USFTZ79R4065 | 45,462.52 | 45,676.07 | 45,676.07 | Accounting | +213.55 | Stale index ratio |
| F5 | Pellar 8.25% 2030 US6FJH2Q7244 | 265,375.00 | 270,875.00 | 0.00 | Both | -265,375.00 | Non-accrual |
| | **Differences, net (ours minus Northgate)** | | | | | | +1,988.98 -5,400.00 +9,187.56 -213.55 -5,500.00 = **+62.99** |

The other five positions agree on both sides and match the offering terms.

**F1, UST 3.875%**
- The terms say actual/actual (ICMA). The security master has ACT/360, from bulk load RD_BULKLOAD on 2026-03-02.
- Correct accrual: 25,000,000 × 3.875%/2 × 34/184. The 184 days are the period from 15 Aug 2026 to 15 Feb 2027. Result: **89,504.08**.
- We carry 25,000,000 × 3.875% × 34/360 = 91,493.06.
- Northgate is right.

**F2, Gantry 5.40%**
- The terms say 30/360. From 15 Jun to 18 Sep is 93 days on that basis, which gives **251,100.00**. We are right.
- Northgate has it set up as ACT/360 on 95 days, which gives 256,500.00. That is a Northgate set-up error.

**F3, Corbin FRN**
- The Calculation Agent's notice of 13 Aug sets 3M Term SOFR at 3.6214% plus 0.95%, giving **4.5714%** for the period from 17 Aug to 16 Nov 2026.
- 15 Aug 2026 was a Saturday, so under Modified Following the period starts on 17 Aug. Both sides have 32 days, which is correct.
- The security master still has 5.0882%. That rate was last updated by RESET_FEED on 2026-05-13, so the 17 Aug reset was never loaded.
- Correct accrual: 20,000,000 × 4.5714% × 32/360 = **81,269.33**.

**F4, TIPS**
- Reference CPI for 18 Sep 2026 is 331.862 (June) + 17/30 × (332.305 − 331.862). That is 332.113033, which rounds to 332.11303.
- Index ratio: 332.11303 / 313.04548 = **1.06091**.
- Correct accrual: 15,000,000 × 0.8125% × 65/184 × 1.06091 = **45,676.07**.
- We applied 1.05595. CPI_FEED has not loaded since 2026-07-15, so our ratio is stale. Northgate is right.

**F5, Pellar**
- The Valuation Committee (the Valuation Designee) put the notes on non-accrual effective **14 Sep 2026** under s.5.4(c).
- Section 5.4 requires that, on placement, *all* accrued interest and past-due interest receivable are reversed.
- We froze the accrual at 17,875.00 and kept the unpaid 1 Sep coupon of 247,500.00 as past-due. Both should be reversed, so the correct balance is **nil**.
- Northgate does not apply our non-accrual determinations (s.3.2). It still shows 23,375.00 accrued (17 days) plus an open income claim of 247,500.00.
- The income claim should stay open for collection purposes. It is a permanent reconciling item until the notes are resolved.

## Entries to book in the 18 Sep 2026 NAV

| Security | Entry | USD |
|---|---|---:|
| UST 3.875% | Dr Interest income / Cr GL 1300 | 1,988.98 |
| Corbin FRN | Dr Interest income / Cr GL 1300 | 9,187.56 |
| TIPS | Dr GL 1300 / Cr Interest income | 213.55 |
| Pellar | Dr Interest income / Cr GL 1300 (accrued 17,875.00 + past-due 247,500.00) | 265,375.00 |
| **Net to GL 1300** | | **-276,337.99** |

- Correct GL 1300 is 1,605,265.25 − 276,337.99 = **1,328,927.26**.
- The difference remaining against Northgate is **-276,275.00**, made up of Gantry -5,400.00 and Pellar -270,875.00. Both are Northgate-side items.
- Do **not** true up to Northgate (s.3.2), and do **not** write off the 62.99.

## NAV impact (s.6)
The error below is corrected minus reported net assets, divided by shares outstanding, on unrounded figures. I recomputed each position for each date.

| NAV date | Net asset error | Shares | Per share | % of NAV |
|---|---:|---:|---:|---:|
| 15 Sep | -275,657.09 | 63,140,551.906 | -0.00437 | -0.043% |
| 16 Sep | -275,997.78 | 63,129,877.310 | -0.00437 | -0.043% |
| 17 Sep | -276,337.99 | 63,118,402.227 | **-0.0044** | -0.043% |

- For 15 and 16 Sep: the index ratios are 1.06082 and 1.06086, and the Pellar amount is unchanged at 265,375.
- Every date is below USD 0.01/share and below 0.50%, so the errors are **not material** (s.6.2). Both tests would have to be met.
- Section 6.3 applies: correct in the next NAV struck, do not restate, do not reprocess shareholder activity, notify the Fund Treasurer the same day, and log the errors for the quarterly Board report.
- The 14 Sep NAV also carries the Pellar error, about -265k or roughly -0.0042/share. It is not in the file, but it is expected to be non-material.
- Earlier NAVs carry smaller UST and Corbin effects. The UST day-count error has existed since March. Its peak was about 2.7k before the 15 Aug coupon, which is immaterial.

## Who to chase
1. **Reference Data (security master).** Correct at source and sweep for other affected securities (s.3.4):
   - UST day count: find every security in the 2026-03-02 bulk load, especially other Treasuries.
   - Corbin rate: load 4.5714% effective 17 Aug with next reset 16 Nov, and find out why RESET_FEED missed the notice for any other floaters.
   - TIPS: CPI_FEED has been stale since 15 Jul. Load the Jul and Aug CPI and check all inflation-linked securities.
   - Pellar: confirm the non-accrual flag.
2. **Northgate Client Service, account 7730-150.**
   - Gantry should be set up as 30/360.
   - Tell them Pellar is on non-accrual in the Fund's books. The income claim stays open.
3. **Fund Treasurer.** Same-day notification of the non-material NAV errors and the Pellar reversal.
4. **Dev.** The write-off is declined. Post the entries above.

## Assumptions and open items
- Offering terms govern over system set-up, as the extract file states.
- CPI values are final.
- Ref CPI uses truncation to 6dp and then rounding to 5dp.
- Missing from the folder: the 14 Sep NAV and GL detail, so I could not quantify the Pellar error for that date. Also missing: historical UST and Corbin accruals before 15 Sep.
