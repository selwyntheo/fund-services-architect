**To:** Anneliese Kroft, NAV Oversight Manager
**Re:** TCBF 17 Sep 2026: shadow break of 1.8c. Release at 10.34 with one correction and no hold

## Bottom line
- The gap is **USD 719,893.44** (shadow 416,460,103.31 less draft 415,740,209.87), or 1.79c a share. All of it is explained by four positions, with **zero residual**.
- Three of the four items (+745,618.44) are errors in Tidewell's shadow. One item (−25,725.00) is an error in our draft.
- **Correct Calloway Freight Lines to the Vendor B price.** Corrected net assets are **415,714,484.87**. On 40,215,337.482 shares the NAV is **10.3372**, which is **10.34 at 2dp**. The published 2dp figure does not change, but policy 6.3 requires us to correct the error anyway.
- **Do not hold. Do not reprice to Tidewell's marks.** Policy 6.4 says differences traced to the shadow do not delay release, and we may not adopt shadow prices. No delay means no Treasurer approval is needed (6.5).
- After our correction, 745,618.44 of difference remains, all on Tidewell's side.

## Reconciliation (shadow minus draft, USD)
| # | Security | Cause | Draft | Shadow | Impact | Who is right |
|---|---|---|---|---|---|---|
| F1 | Kestrel Auto 2025-2 A-3 (USTSSMTX1062) | Paydown factor | factor 0.64118 → face 7,694,160, MV 7,790,337.00, AI 2,962.25 | factor 0.68240 → face 8,188,800, MV 8,291,160.00, AI 3,152.69 | +501,013.44 (MV 500,823.00 + AI 190.44) | Administrator |
| F2 | Brackett Specialty Retail (USCOHZR54060) | Accrual status | Non-accrual effective 9/16, AI 0, past-due 0 | Still accruing: AI 2,625.00 plus past-due coupon 157,500.00 | +160,125.00 | Administrator |
| F3 | Harrow Point Energy (US4NCZQ04871) | Pricing hierarchy | Vendor A 97.842 → 5,870,520.00 | Coverdale broker mid 99.25 → 5,955,000.00 | +84,480.00 | Administrator |
| F4 | Calloway Freight Lines (USPH76AX8211) | Price carried forward | Prior-day 101.115 → 3,539,025.00 | Vendor B 100.380 → 3,513,300.00 | −25,725.00 | **Adviser** (we correct) |
| F5 | Quenby Health Partners (USHOWLOR8717) | Amortization method | Effective interest: amortized cost 4,315,302.17, income 679.08 a day | Straight-line: amortized cost 4,307,349.21, income 660.05 a day | 0.00 | Administrator |
| | **Total** | | | | **719,893.44** | Residual 0.00 |

Tie-out:
- **Investments at value:** 407,033,080.00 − 406,473,502.00 = 559,578.00. This equals the market-value differences in F1, F3 and F4.
- **Interest receivable:** 4,611,154.07 − 4,450,838.63 = 160,315.44. This equals F1 accrued interest (190.44) plus F2 (160,125.00).
- **Other lines:** every other summary line, including custodian cash of 6,017,407.33 and shares outstanding, is identical on both sides.
- **Position files:** I summed both position files, and they agree with their summary files.

## Basis for each item
**F1 Kestrel (the shadow is wrong)**
- The servicer report dated 2026-09-15 shows the Class A-3 ending factor as 0.64118000. That was principal of 41.22 per 1,000, which is 494,640 on our 12,000,000 original face.
- Policy 5.3 says the paydown is recorded on the distribution date, and interest then accrues on the current face.
- The shadow still carries the beginning factor, 0.68240.
- The principal was received on 9/15 and is already in custodian cash, which is the same on both sides. The shadow therefore counts it twice.
- Accrued interest is 7,694,160 × 4.62% / 360 × 3 days (9/15 to 9/17) = 2,962.25.

**F2 Brackett (the shadow is wrong)**
- The trustee notice (9/15) says the 9/15 coupon was not paid. The issuer filed Chapter 11 on 2026-09-16 (press release).
- Policy 5.4(a) says non-accrual starts on the bankruptcy filing date. All accrued interest and past-due receivable are then reversed.
- Under the same policy, the bond is valued at the flat price, which includes the interest claim. Both sides use Vendor A's flat price of 38.500.
- The shadow's past-due receivable of 157,500 (4,000,000 × 7.875% / 2) and its 2,625 of accrued interest (3 days × 875) must therefore come out.

**F3 Harrow Point (the shadow is wrong)**
- The PM, Tobias Renner, told the shadow team to carry 99.25, the Coverdale mid quote (email at 15:10).
- Policy 4.6 says a PM challenge does not change the NAV price, and PMs may not supply prices.
- Vendor A logged the challenge as VA-CH-2609-4471. Because it came in after 14:00, it will be reviewed next business day, and the current price stands until then.
- A broker quote would only be usable under 4.3: bid side, from a VD-approved broker, with written VD approval, and only when no vendor price exists. None of those conditions is met, and a mid quote would not qualify anyway.
- Vendor A 97.842 (status OK) is the correct price.

**F4 Calloway (our draft is wrong)**
- Vendor A returned "NP – insufficient observable inputs". We carried forward the prior-day price of 101.115.
- Policy 4.2 requires the Vendor B evaluated bid when Vendor A gives no price. Vendor B was 100.380, status OK.
- Carry-forward under 4.5 is only allowed when no source under 4.1 to 4.3 is available, so it was not allowed here.
- The correction is 3,500,000 × (100.380 − 101.115)% = −25,725.00.

**F5 Quenby (no NAV impact; our draft is right)**
- Tax lot L-2025-0915-017: bought at 108.500, cost 4,340,000, settled 2025-09-15, 30/360, amortized to maturity on 2036-03-15. That is 21 semi-annual periods.
- I solved for the effective (constant) yield: 5.66490% on a bond-equivalent basis.
- Premium amortization is 12,071.58 in period 1 and 12,413.50 in period 2, giving a book value of 4,315,514.92 at 9/15/26.
- Period 3 amortization is 12,765.11, or 70.92 a day. Taking 3 days through 9/17 gives amortized cost of **4,315,302.17** and daily income of 750.00 − 70.92 = **679.08**. Both match our draft exactly.
- The shadow's straight-line figures are 340,000 / 21 = 16,190.48 per period, or 89.95 a day. That gives 4,307,349.21 and 660.05.
- The amortized cost difference (adviser minus administrator) is **−7,952.96**.
- Policy 5.2 requires the effective-interest method, applied straight-line within each period. The difference only moves value between net investment income and unrealized; market value and net assets are the same.
- The shadow labels every position STRAIGHT_LINE. All the other holdings are carried at par, so the label produces no numbers that differ.

## Actions tonight
1. **Post the entry:** reprice Calloway to 100.380 (−25,725.00 to investments and unrealized).
2. **Release** TCBF at **10.34** (10.3372) before 19:00 ET. Do not hold, and do not ask the Treasurer for a delay.
3. **Hollis Mbeki (Tidewell Fund Oversight):** send this reconciliation and decline the request to reprice to their marks (6.4). Ask them to fix the Kestrel factor, Brackett non-accrual, HPE price and Quenby amortization in the shadow.
4. **Valuation Designee:**
   - Report the Vendor A NP on Calloway and the carry-forward, now corrected to Vendor B (4.5 and 6.4 require same-day reporting of pricing matters).
   - Report the PM challenge on HPE. The 97.842 price stands unless Vendor A revises it or the VD approves an override in writing.
   - Confirm the Brackett non-accrual.
5. **Tobias Renner (PM):** remind him of 4.6. PM-supplied prices cannot be used.

## Open items and assumptions
- **HPE:** the result of the Vendor A challenge will come on the next business day. It affects 9/18 onward, not 9/17, unless the VD approves an override in writing.
- **Calloway:** we should find out why Vendor A returned NP. Our carry-forward control also needs review.
- **Brackett:** the VD may want to revisit whether the 38.500 flat price is still appropriate after the Chapter 11 filing.
- **Premium or discount lots:** I assumed that `tax_lots_premium_discount_TCBF.csv` lists every lot with a premium or discount, so all other holdings are carried at par.

Sources: all files are under `inputs/`:
- `administrator/draft_nav_*`
- `adviser/shadow_nav_*`
- `administrator/tax_lots_premium_discount_TCBF.csv`
- `pricing/vendor_prices_TCBF_20260917.csv`
- `notices/*`
- `correspondence/*`
- `policies/TFT_valuation_income_and_shadow_nav_procedures.md`
