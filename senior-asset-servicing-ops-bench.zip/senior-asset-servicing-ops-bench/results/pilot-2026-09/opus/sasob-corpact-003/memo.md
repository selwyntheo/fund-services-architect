# Fenwick claims review — Bracken Foods & Van Oosterlo

**To:** Keisha Osei, Income & Claims Supervisor · **Re:** Tomas Albright's email of 17 Sep 2026 · **Date:** 18 Sep 2026

## Bottom line
- 8 of the 13 Fenwick trades give rise to a claim. 3 of those 8 are claims **Fenwick pays**, not receives.
- Only one of Tomas's 10 items is correct exactly as he asked for it (7101). One reverse claim payable (7110) is missing from his list.
- **Bracken money:** we cannot pay it now. Policy 3.4 says claim proceeds are credited only when we receive them, and not before the 25 Sep payable date. Meridale does not advance claims.
- **Dutch tax:** Fenwick's exemption does not cover claim compensation. NL claims are always settled net of 15% (policy 4.4).
- **June/May Van Oosterlo claim (6620):** this is a valid claim but it is time-barred. We do not book it. We need Fenwick's written instruction before we go to Harlow directly.

## Sources
- `inputs/trades/fenwick_trade_settlement_status_20260918.csv`: trades, settlement dates, locations, opt-out flags
- `inputs/notices/MT564_MRDL_BRACKEN_DVCA_20260821.txt`: BRKN26DVCA03, ex = record 2026-09-10, USD 0.54, pay 2026-09-25
- `inputs/notices/MT564_MRDL_VANOOSTERLO_DVCA_20260826.txt`: VOH26DVCA02, ex 2026-09-08, record 2026-09-09, EUR 0.88, pay 2026-09-16
- `inputs/income/fenwick_income_ledger_VOH_BRKN.csv`: May event VOH26DVCA01, ex 05-12, record 05-13, EUR 1.24
- `inputs/csd/t2s_market_claims_report_VANDNL2A_20260918.csv`: CSD claims MC-2609-118834, MC-2609-118902, RC-2609-020417
- `inputs/tax/tax_documentation_fenwick.csv`: W-9 (US exempt) and IB 92 (NL relief at source)
- `inputs/policies/meridale_market_claims_procedures.md` v5.0, sections 2 to 6

**How entitlement works (policy 2):** the buyer is entitled if the trade date is before the ex-date. A claim exists only where the entitled party is not the holder of record at close of the record date. Settling after the record date is not, on its own, a reason to claim (2.5).

## Trade-by-trade findings
| Trade | Tomas asked? | Analysis | Claim | Fenwick | Amount | Route |
|---|---|---|---|---|---|---|
| 5490 SELL 5,000 BRKN | no | TD 9/8 < ex, settled 9/9 ≤ record | none | – | 0 | – |
| 5501 BUY 12,000 BRKN | no | TD 9/9 < ex, settled 9/10 = record | none | – | 0 | – |
| 5502 BUY 30,000 BRKN | yes | TD 9/9 < ex, settled 9/14 (Aldwych fail) | market claim | receives | USD 16,200.00 (30,000 × 0.54) | raise vs Aldwych |
| 5503 SELL 8,000 BRKN | yes (as receivable) | TD 9/9 < ex, so buyer entitled; our fail (lending recall) to 9/11 | market claim | **pays** | USD 4,320.00 | accrue payable; pay on presentation ≥ 9/25 |
| 5504 BUY 25,000 BRKN | yes (full) | 18,000 settled 9/10; 7,000 settled 9/15 | market claim (partial) | receives | USD 3,780.00 (7,000 × 0.54) | raise vs Aldwych |
| 5511 BUY 20,000 BRKN | yes | TD 9/10 = ex, so seller entitled; seller held at record | none | – | 0 | – |
| 7088 SELL 9,000 VOH | yes (as receivable) | TD 9/4 < ex; our fail to 9/10 | market claim (CSD MC-2609-118902) | **pays** | EUR 6,732.00 (7,920 gross − 15%) | CSD auto; settled 9/16; reconcile |
| 7101 BUY 15,000 VOH | yes | TD 9/7 < ex; settled 9/11 in T2S | market claim (CSD MC-2609-118834) | receives | EUR 11,220.00 (13,200 − 15%) | CSD auto; settled 9/16; do not duplicate |
| 7102 BUY 10,000 VOH | yes | TD 9/7 < ex; settled 9/14 via ICSD link, which the CSD does not detect | market claim | receives | EUR 7,480.00 (8,800 − 15%) | **manual via Vandermeer by 2026-10-07** |
| 7103 BUY 4,000 VOH | yes | opt-out Y (special ex, priced ex EUR 0.88) | none (2.4) | – | 0 | – |
| 7110 BUY 6,000 VOH | **no** | TD 9/8 = ex, so seller entitled; bilateral T+1 settled 9/9 = record | reverse claim (CSD RC-2609-020417) | **pays** | EUR 4,488.00 (5,280 − 15%) | CSD auto; pending settles 9/21 |
| 7111 SELL 3,000 VOH | yes | TD 9/8 = ex, so Fenwick (seller) entitled; Fenwick held at record | none | – | 0 | – |
| 6620 BUY 7,500 VOH (May) | yes | TD 5/11 < ex 5/12; settled 5/20 > record 5/13 via ICSD link | market claim, **time-barred** | would receive | EUR 7,905.00 net (9,300 gross) | not booked; notify; client instruction |

The NL detection period for the September event runs to the end of the 20th T2S business day after the 9 Sep record date, which is **2026-10-07**. I assumed there are no T2S closing days in that window. For the May event (record 13 May) the period ended around 10 Jun 2026. The 6620 claim is therefore outside the window and time-barred (policy 5.1).

## Entries to book today
| Ledger | Receivable | Payable |
|---|---|---|
| 4410-3104 (USD) | 19,980.00 (5502 16,200 + 5504 3,780) | 4,320.00 (5503) |
| 4410-3107 (EUR) | 18,700.00 (7101 11,220 CSD + 7102 7,480 manual) | 11,220.00 (7088 6,732 + 7110 4,488) |
| Not booked | EUR 7,905.00 time-barred (6620) | – |

- US claims are at gross. The W-9 exempt governmental plan suffers no withholding (policy 3.2).
- NL claims are booked at the amounts the CSD generated. The manual claim uses the same net-of-15% basis.
- 7088 and 7101 have already settled at the CSD (16 Sep), so they should be matched to cash.
- USD net receivable is 15,660.00. EUR net receivable is 7,480.00.

## Suggested reply to Tomas
1. **Paying Bracken now:** We don't advance claim proceeds. The Bracken claims will be credited when we receive them from the counterparty, and no earlier than the 25 Sep payable date.
2. **Which trades give rise to a claim:**
   - The date a trade settles doesn't by itself create a claim.
   - 5511 and 7111 were traded on or after the ex-date, and the dividend went to the right party, so there is nothing to claim.
   - 7103 was traded special ex by agreement, so there is no claim.
   - 5504 claims on the 7,000 shares that settled late, not the full 25,000.
3. **Claims Fenwick owes:**
   - 5503 (USD 4,320) and 7088 (EUR 6,732) are claims Fenwick owes. In each case Fenwick delivered late and so received the dividend that belonged to the buyer.
   - 7110 (EUR 4,488) is a reverse claim Fenwick owes. It settled early on a bilateral T+1 basis.
   - The 5503 payment is made only when the counterparty presents a valid claim.
4. **Dutch tax:** Market claim compensation in the Netherlands is always settled net of 15% dividend tax, whatever the status of the payer or payee. It is not an issuer dividend, so Fenwick's IB 92 relief at source does not apply to it and it cannot be reclaimed. Fenwick's own record-date dividends were paid at 0%.
5. **6620 (May):** This was a valid claim of EUR 7,905 net, but the claims window closed in June. We can't raise it through the CSD or Vandermeer. If Fenwick wants us to pursue Harlow Global Markets directly, please send a written instruction. Nothing will be booked unless Harlow agrees.
6. **What we are doing:** Claims on 5502 and 5504 are being raised with Aldwych. A manual claim on 7102 is going through Vandermeer, well before the 7 Oct deadline. 7101 has been received through the CSD.

## Actions and who we need things from
- **Aldwych Securities:** raise claims for USD 16,200 and USD 3,780.
- **Vandermeer Bank (VANDNL2A):** raise the manual claim on 7102 for EUR 7,480 before 2026-10-07.
- **Income ledger:** post the entries in the table above.
- **CSD claims:** monitor RC-2609-020417, which should settle 21 Sep. Do not duplicate the CSD claims.
- **Client cash credit:** hold. Nothing is paid out before we receive the money, and not before 25 Sep.
- **Relationship manager:** send written notice of the time-barred 6620 claim.
- **Fenwick:** ask for a written instruction on whether to pursue Harlow.
- **Securities lending desk:** 5503 and 7088 failed because of the recall and the late return from the lending agent. They need to confirm whether the shares were on loan over the record date and whether manufactured dividends offset the payables.
- **Open control point:** 6620 settled late in May and was never reviewed for income. Head of asset servicing to note.

## Assumptions and open questions
- I found no T2S or TARGET closing days between 10 Sep and 7 Oct 2026, so I counted weekdays only.
- The record-date positions in the income ledger (240,000 BRKN and 180,000 VOH) have not been checked against the lending activity.
- I booked the CSD-generated amounts as reported. The manual 7102 amount is my own calculation, pending confirmation from Vandermeer.
