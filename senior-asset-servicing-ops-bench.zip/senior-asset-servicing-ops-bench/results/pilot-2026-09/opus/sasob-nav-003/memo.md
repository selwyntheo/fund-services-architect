# AECB: swing decision and dealing NAVs, Dealing Day Fri 18 Sep 2026

**To:** Sophie Lindahl (NAV Team Lead), for Elena Marchetti's valuation sign-off
**Re:** Aldermoor Euro Corporate Bond Fund (AECB), pre-swing NAV status PRE_SWING_REVIEWED

## 1. Decision
- **Swing up by 0.38%.** Net capital activity is +EUR 13,478,920.00, which is **2.4831%** of the unswung Sub-Fund NAV of EUR 542,818,558.77. That is above the 2.00% threshold.
- **Do not publish what the NAV system produces.** The system still holds the old factors: 0.30% in and 0.41% out, with change request CR-2291 awaiting four-eyes approval. The Swing Pricing Committee (SPC) approved 0.38% in and 0.45% out from Dealing Day 1 Sep 2026. Policy s.7 requires us to apply the approved parameters by hand and report that to the Conducting Officer.
- **Carrow order AECB-0918-012 is dealt on Mon 21 Sep, not 18 Sep.**

| Class | Net assets pre-swing (EUR) | Shares pre-dealing | Unswung NAV (unrounded) | Unswung NAV (2dp) | **Swung NAV (x1.0038)** | System would give (x1.0030) |
|---|---|---|---|---|---|---|
| A-EUR-Acc | 159,688,420.17 | 1,284,512.4410 | 124.318313 | 124.32 | **124.79** | 124.69 |
| I-EUR-Acc | 343,512,904.66 | 2,905,118.2200 | 118.244036 | 118.24 | **118.69** | 118.60 |
| R-EUR-Dis | 39,617,233.94 | 412,880.1000 | 95.953363 | 95.95 | **96.32** | 96.24 |

Source: `inputs/accounting/pre_swing_nav_AECB_20260918.csv`. Policy s.6 applies the swing to the unrounded NAV per share and then rounds to 2dp, half up (prospectus s.8.1). The same factor applies to every class (prospectus s.8.4). The factor is within the 2.00% cap.

**AECB-0918-001 (Verwood Pensionskasse):** EUR 9,500,000 / 118.69 = **80,040.4414 I shares**, rounded down to 4dp.

## 2. Net capital activity test
Sources: `inputs/registrar/dealing_register_AECB_DD20260918.csv` and policy v4 s.3–5 (`inputs/governance/AAM_swing_pricing_policy_v4.md`). Share-denominated orders are valued at the unswung 2dp NAV.

| Order | Class / type | Treatment | EUR |
|---|---|---|---|
| 0918-001 | I sub | counted | +9,500,000.00 |
| 0918-002 | I sub | counted | +4,200,000.00 |
| 0918-003 | A sub | counted | +1,850,000.00 |
| 0918-004 | R sub | counted | +640,000.00 |
| 0918-005 | A sub | counted | +2,300,000.00 |
| 0918-006 | A red 11,250 sh x 124.32 | counted | -1,398,600.00 |
| 0918-007 | R red | counted | -420,000.00 |
| 0918-008 | I red 18,000 sh x 118.24 | counted | -2,128,320.00 |
| 0918-009 | switch A to I (same sub-fund), 40,000 x 124.32 = 4,972,800 each leg | nets to zero | 0.00 |
| 0918-010 | switch I AECB to Global Equity, 9,000 x 118.24 | conversion out = redemption | -1,064,160.00 |
| 0918-011 | I sub 6,000,000 | cancelled 11:38 before cut-off, callback verified: excluded | 0.00 |
| 0918-012 | I red 3,000,000 (Carrow) | received 12:07:41, after cut-off: deferred to 21 Sep | 0.00 |
| 0921-001 | A sub 750,000 | for DD 21 Sep: excluded | 0.00 |
| **Net** | | | **+13,478,920.00** |

Inflows are 18,490,000.00 and outflows are 5,011,080.00. 13,478,920.00 / 542,818,558.77 = **2.4831%**, which is above 2.00%, so the swing applies upward.

Sensitivities (for information only):
- If 0918-012 had been included, net activity would be 1.9305% and there would be **no swing**.
- If the cancelled 0918-011 had been included, net activity would be 3.5885%.

The threshold denominator is the pre-activity NAV, as policy s.5 requires.

## 3. Swing parameters
- SPC minutes of 27 Aug 2026 (`inputs/governance/SPC_minutes_20260827_extract.md`): threshold 2.00%, in 0.38%, out 0.45%, effective from Dealing Day 1 Sep 2026. The stressed 0.55% factor was not approved and is not relevant here.
- NAV system extract (`inputs/nav_system/swing_parameters_extract_20260921.csv`): in 0.30% and out 0.41%, both effective from 1 Jun 2026. CR-2291 is still AWAITING_4_EYES, even though written notification was sent on 28 Aug.
- The approved 0.38% has been applied manually. This must be reported to the Conducting Officer (policy s.7) and CR-2291 needs to be approved urgently.
- **Look-back needed:** any AECB swing between 1 and 17 Sep would have used the stale factors. The NAV history needed to check this is not in the folder.

## 4. Carrow: AECB-0918-012
- The RTA received the MT502 at **12:07:41 CEST**. Cut-off is 12:00 Luxembourg time on the Dealing Day.
- Prospectus s.7.2: requests received after cut-off are treated as received for the next Dealing Day, and "the time of receipt by a distributor is not relevant". The Company does not permit late trading.
- Carrow's 11:52 internal timestamp and its SWIFT queue delay are on Carrow's side. The Aldermoor relationship manager's support does not change the rules.
- Dealing this order at the 18-Sep price would be late trading. It would also remove a swing that the threshold test triggers, to the detriment of remaining shareholders. I don't recommend taking this to the Conducting Officer as a policy s.8 exception.

**Suggested reply to Carrow** (copying Aldermoor Relationship Management):

> "Your MT502 for AECB-0918-012 (EUR 3,000,000, I-EUR-Acc) was received by the Registrar and Transfer Agent at 12:07:41 CEST on 18 Sep, after the 12:00 cut-off. In line with section 7.2 of the Prospectus, where only the time of receipt by the RTA is relevant, the order has been accepted for Dealing Day Monday 21 Sep 2026 and will be dealt at that day's NAV. You do not need to re-send it. We are unable to deal it at the 18 Sep NAV."

The Conducting Officer and compliance should be told about the request, including the relationship-team involvement. The order's register status should change from PENDING_OPS_DECISION to accepted for DD 21 Sep, and it counts in the 21-Sep swing test.

## 5. Other points
- The I-class leg of conversion 0918-009 is at swung prices. Assumed working: 40,000 x 124.79 / 118.69 = 42,055.7755 I shares. **The RTA should confirm its conversion method.**
- Conversion 0918-010 is dealt out of AECB at 118.69.
- Performance fees, if any, are calculated on the unswung NAV (prospectus s.8.4).

## 6. Actions and requests
1. **NAV team:** hold the system NAV. Publish A 124.79 / I 118.69 / R 96.32 after a four-eyes check of the manual swing, by 11:00.
2. **E. Marchetti (Conducting Officer, Valuation):** report of the manual application of the SPC parameters. Look-back on 1–17 Sep. Note of the Carrow late-trading request.
3. **System change control:** approve CR-2291 (0.38/0.45, effective 2026-09-01) and log the delay.
4. **TA:** price the 18-Sep orders at the swung NAVs (0918-001 = 80,040.4414 shares). Move 0918-012 to DD 21 Sep.
5. **Carrow and Aldermoor Relationship Management:** send the reply above.
