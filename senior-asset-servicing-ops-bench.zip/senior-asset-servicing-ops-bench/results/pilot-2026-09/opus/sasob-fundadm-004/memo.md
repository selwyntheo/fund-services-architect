**To:** Graham Sato, Regulatory Reporting
**Re:** BGOF August 2026 N-PORT, senior validation
**Date:** Fri 18 Sep 2026

## Bottom line
Please don't submit this afternoon. The draft has three liquidity classification exceptions. Once they are corrected, the Fund is **above the 15% illiquid limit (15.63%)** and **below its 25% HLIM (24.59%)**. The auto-checks passed because they used wrong buckets for L14, L16 and L19 and counted the futures margin cash as highly liquid. Under our procedures (s3.2, s3.4) and LRM Program s6.1, we can't file with open classification exceptions. The filing isn't due until **30 Oct 2026** (60 days after the 31 Aug fiscal Q3 end; FYE 30 Nov), so waiting costs nothing.

## Line corrections
Net assets: USD 367,956,922.39 (statement of net assets). Percentages = value ÷ net assets × 100 (4 dp).

| Line | Field | Draft | Corrected | Basis |
|---|---|---|---|---|
| L03 Vaudrey | value_usd | 11,186,000.00 | 12,399,681.00 | Draft used the EUR local value. Accounting: EUR 11,186,000 × 1.1085 |
| L03 | pct_net_assets | 3.0400 | 3.3699 | Recalculated |
| L07 Carrow 144A | is_restricted_security | N | Y | Security master: 144A, restricted = Y |
| L09 UST Note | issuer_cat | CORP | UST | Security master issuer type |
| L11 Govt MMF | asset_cat | EC | STIV | MMF shares are STIV (procedures s2 code list) |
| L14 Tessaly Ser. C | liquidity | Less Liquid | Illiquid | LRM 3.5: private placement with no secondary market. Vendor gave a default bucket with no market data. No Committee approval of another bucket |
| L16 Norcastle | liquidity | Highly Liquid | Illiquid | LRM 3.4: halted since 27 Aug, no other venue, still halted (17 Sep update). Vendor inputs stale (ADV to 26 Aug) |
| L19 Dellbrook TLB | liquidity | Illiquid | Less Liquid | Override OVR-2026-019 was REJECTED on 20 Aug. LRM 2.2/3.7; vendor bucket = Less Liquid |
| L22 Pembury | fair_value_level | 1 | 2 | Accounting level 2; FV factor triggered 31 Aug (designee memo item 5) |

These lines are correct as drafted and should not change:
- L12 stays Moderately Liquid. The PM override OVR-2026-021 is still PENDING, so it has no effect.
- L05 and L25 (144A) stay on the vendor model under rule 3.6.
- L15 and L17 stay Illiquid under rule 3.5 and the approved overrides.
- All other values and fair value levels tie to `accounting/BGOF_holdings_valuation_20260831.csv`. The investments total ties to the SNA at 348,613,282.39.

We can correct the data fields ourselves. The three liquidity changes are **for the Program Administrator (LRM Committee, J. Amsel) to confirm** (procedures s3.2). Oakhurst does not classify.

## Fund-level liquidity figures (on corrected classifications)
**Illiquid investments (assets):**
- L14 21,804,000 + L15 17,901,000 + L16 9,600,000 + L17 8,200,000 = **USD 57,505,000 = 15.63%** of net assets. **Limit exceeded.**
- The draft showed L15 + L17 + L19 = 36,601,000 (9.95%).

**HLIM measure (LRM 5.2):**
- Highly liquid assets: L01, L02, L03 (corrected), L04, L09, L11, L22, L24 = 73,580,567.39.
- Add cash at Fallowmere 16,900,000 and cash at Kestrow 4,600,000.
- Deduct the full 4,600,000 Kestrow margin, including the 388,000 excess. It is posted for the futures (L23), which are classified Moderately Liquid.
- Result: 90,480,567.39 / 367,956,922.39 = **24.59%. Below the 25% HLIM: shortfall.**
- The draft's figure was about 28.12% (L16 counted as Highly Liquid, margin not deducted).

Assumptions:
- Receivables are not investments and are excluded.
- The FX forward is highly liquid on the vendor model.
- The percentages use month-end values. The Program Administrator should re-run them on current data.

## Who needs to hear what, before Monday
1. **Program Administrator (LRM Committee), today.**
   - Send the classification exceptions above.
   - This is an after-the-fact identification of an excess over 15% (LRM 4.3). The Board report and **Form N-RN Part B are due by Mon 21 Sep 2026**, one business day after identification on 18 Sep, with an explanation of why it was identified late.
   - The Fund is treated as above 15% from today until the Program Administrator confirms otherwise.
   - They also need to size the HLIM shortfall from daily data. If it has lasted more than 7 consecutive days (probable if it dates from the 27 Aug halt), a Board report and **N-RN Part D** are also due within one business day. Otherwise, it goes to the Board at the 14 Oct meeting.
2. **Hold the Tessaly Series D purchase (USD 6.0m, CMT-2026-044, funding 25 Sep).**
   - Under LRM 4.1 the Fund may not acquire an illiquid investment while above 15%. After this purchase, illiquid would be about 17.26%.
   - Pre-trade clearance on 15 Sep relied on the stale 9.9% daily report (Lindqvist email, 17 Sep).
   - Oakhurst should not pass the 24 Sep funding/custody instruction to Fallowmere without Program Administrator and CCO confirmation.
   - Tell the PM (R. Castell / M. Lindqvist) and the **CCO**.
3. **Treasurer:** the N-PORT is on hold, and filing needs their sign-off.
4. **Liquidity vendor (via the Program Administrator):** L16 is not reflecting the halt, and L14 is sitting in a default bucket.

The Harwood TLB add-on (USD 2.5m) is Less Liquid, not illiquid. No action is needed on it.

## Open items
- The Program Administrator needs to confirm L14, L16 and L19, and supply daily data to establish when the excess and the HLIM shortfall began.
- Is there any written LRM Committee approval for L14? None appears in the override log.
- L16 inv_country is reported as CA (ISIN prefix CA), but the security master notes a primary US listing. The inputs don't give the issuer's country of organization, so I haven't changed it; the security master team should confirm.
- N-RN and liquidity data are non-public (LRM 6.2). The public part of the N-PORT (month 3) excludes classifications.

## Sources
- nport/BGOF_NPORT_draft_2026-08_PartC_holdings.csv
- accounting/BGOF_holdings_valuation_20260831.csv; accounting/BGOF_statement_of_net_assets_20260831.csv
- reference/BGOF_security_master_extract.csv
- liquidity/BGOF_vendor_liquidity_classification_20260831.csv; liquidity/BGOF_liquidity_override_log_2026.csv
- notices/exchange_notice_Norcastle_trading_halt_20260827.txt
- derivatives/Kestrow_Futures_statement_BGOF_20260831.txt
- valuation/BGOF_valuation_designee_memo_20260831.txt
- trades/BGOF_pending_commitments_20260918.csv; correspondence/email_Castell_team_Tessaly_SeriesD_20260917.txt
- policies/BGOF_liquidity_risk_management_program_extract.md; policies/BST_Form_NPORT_preparation_procedures.md
