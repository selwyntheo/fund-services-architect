# Halvard Dutch auction (HALV26DTCH01): final allocation, Fenwick, Ashgrove

**To:** Anya Brandt | **Re:** your note of 7 Oct 16:00 ET | **Basis:** Stonemere final results notice, 7 Oct 14:10 ET

## Bottom line
- Final terms: **Purchase Price USD 32.50, final proration factor 0.748212**, rounded down per VOI. Payment and return of unaccepted shares via DTC on **Fri 9 Oct** (`notices/stonemere_final_results_notice_20261007.txt`). The preliminary factor of about 72.9% is superseded.
- **Stop the event engine auto-credit** scheduled for **8 Oct 06:00 ET** (USD 2,608,937.50, `event_engine/projected_tender_proceeds_HALV26DTCH01.csv`). It uses the preliminary factor and is wrong on three of the four accounts. Under Terms 8.2/8.3, prorated tender proceeds are credited only when the depositary pays, and a projection has to be re-run on final terms.
- Expected totals: **134,740 shares accepted, 135,345 returned, USD 4,379,050.00 proceeds**.
- Fenwick's withdrawal came in late and was not transmitted, so their tender stands. We will not ask Stonemere to reverse it, and Grant cannot promise or pay a credit.
- Ashgrove 4410-2204 is **not** an odd lot, so it is prorated.

## Expected outcome per account (for the cash forecast)
| Account | Client | VOI | Tendered (live) | Basis | Accepted | Returned | Proceeds USD | Engine projection (USD) |
|---|---|---|---|---|---|---|---|---|
| 4410-2201 | Ashgrove Global Eq | 26093004 | 60,000 | LIMIT 31.00 ≤ 32.50; 60,000 × 0.748212 = 44,892.72 | 44,892 | 15,108 | 1,458,990.00 | 1,421,550.00 |
| 4410-2201 | | 26093005 | 40,000 | LIMIT 33.00 > 32.50, not purchased | 0 | 40,000 | 0.00 | 0.00 |
| 4410-2204 | Ashgrove Small Cap | 26092810 | 85 | At PP, prorated: 85 × 0.748212 = 63.598 | 63 | 22 | 2,047.50 | 2,762.50 (wrong odd-lot) |
| 4410-3104 | Fenwick | 26092407 | 120,000 | LIMIT 32.50 = PP: 120,000 × 0.748212 = 89,785.44 | 89,785 | 30,215 | 2,918,012.50 | 0.00 (wrongly treated as withdrawn) |
| 4410-5024 | Lumenfield | 26092915 | 50,000 | Conditional, minimum 40,000: 37,410 < 40,000, not met; no random lot | 0 | 50,000 | 0.00 | 1,184,625.00 |
| **Total** | | | **270,085** | | **134,740** | **135,345** | **4,379,050.00** | 2,608,937.50 |

The accepted and returned figures add back to the positions tendered at the depositary on 7 Oct (100,000 + 85 + 120,000 + 50,000 = 270,085, from `positions/custody_positions_HALVARD_20261007.csv`). Proceeds = shares accepted × 32.50. Put the cash in the forecast for 9 Oct, conditional on receipt from Stonemere, and not for 8 Oct.

On 4410-2201, the original 100,000 @31.00 (VOI 26092201) was withdrawn and re-tendered as 60,000 @31.00 and 40,000 @33.00 on 30 Sep at 11:02 ET, which is before the cut-off (log entries TL-02 to TL-04). That was valid.

## Fenwick (4410-3104): facts and what to tell Grant
- The tender was 120,000 shares at a 32.50 limit (TL-06, 24 Sep).
- The withdrawal email (TL-07) is logged at **2026-10-01 16:40:12 −05:00**. That is 4:40 pm Central time, which is **5:40 pm ET**.
- Our Client Response Deadline is **5:00 pm ET on 1 Oct** (Terms 7.1: "All times are New York time"). The withdrawal was therefore 40 minutes late. Tomas's "4:40 pm" is his local time.
- Late instructions do not bind Meridale. They can go on a best-efforts basis only with the Head of Asset Servicing's written approval (Terms 7.2). The request was referred at 08:50 ET on 2 Oct and **declined at 09:40 ET**, and Fenwick was emailed at 09:55 ET. Meridale has no liability for a late instruction that is not transmitted.
- The tender was live at expiration. Fenwick sells **89,785 shares for USD 2,918,012.50**, and **30,215 shares come back** on 9 Oct. This is not all 120,000, which is what our engine currently shows.
- After expiration, Meridale does not ask a depositary to reverse or amend a tender (Terms 9.1). We cannot get the sold shares back.

**What to say to Grant:**
> "Fenwick's withdrawal reached us at 5:40 pm New York time on 1 Oct. That is after our 5:00 pm ET deadline: the 4:40 pm on Tomas's email is Central time. The Head of Asset Servicing declined best-efforts transmission on the morning of 2 Oct, and Fenwick was told at 09:55 ET that day. The tender was live at expiration. On final terms Fenwick sells 89,785 shares at USD 32.50 (USD 2,918,012.50), and 30,215 shares are returned on Friday. We cannot ask Stonemere to reverse the tender. Please don't promise or pay any credit: under Terms 9.1, compensation can only go through the Operational Incident process with Head of Operations approval. If Fenwick wants to dispute the outcome, we'll log it as a complaint and incident, and that process decides. Please correct what you told Tomas."

The escalation is needed because the RM has already told a top-10 client that Meridale will "credit the difference". That breaches Terms 9.1. I am logging it with Operational Risk, and Head of Asset Servicing needs to know. **No compensation entry** is to be posted.

## Ashgrove (4410-2204): odd-lot claim
- Ashgrove Pension Trust is one beneficial owner across 4410-2201 and 4410-2204. On 7 Oct it holds **180,085 shares** with Meridale: 2201 has 100,000 tendered plus 80,000 free, and 2204 has 85 tendered.
- The Offer (Sec. 1, Odd Lots) excludes beneficial holders of 100 or more shares "even if those holders have separate accounts … each representing fewer than 100 shares". Terms 8.1 aggregates separate accounts of the same beneficial owner.
- The checker correctly left the odd-lot box uncompleted (TL-05 note), and the tender was prorated.
- Expected result: **63 accepted (USD 2,047.50), 22 returned**. The engine's "Y (POSITION < 100)" flag is wrong because it looked at the single account.
- Reply to Marcus Leland (his email of 5 Oct): odd-lot priority does not apply, for the reasons above.

## Lumenfield (4410-5024)
- The tender was conditional on a 40,000-share minimum (TL-08). Final proration gives 37,410, which is below the minimum.
- Stonemere confirms no conditional tenders were selected by random lot. **All 50,000 shares are returned and there are no proceeds.**
- The engine would auto-credit USD 1,184,625.00 tomorrow at 06:00. It must not.

## What needs stopping before tomorrow morning
1. **Hold** the PJ-HALV-01 SCHEDULED_AUTO_CREDIT for 8 Oct 06:00 on 2201, 2204 and 5024 (USD 2,608,937.50 in total).
2. **Re-run** the projection on final terms: 0.748212, round down per VOI, no odd-lot on 2204, Lumenfield condition applied, Fenwick as a live tender. Then check it against the table above.
3. **Do not** release the client cash forecast on engine figures. Use the table above, value date 9 Oct, on depositary payment.
4. **No** instruction to Stonemere on Fenwick, and **no** credit to Fenwick.
5. **Log an Operational Incident** covering the Fenwick complaint and the RM's promise, plus the engine defect. The engine used the preliminary factor, auto-credited a prorated offer, and got the odd-lot, conditional and withdrawal logic wrong.

## What I need from whom
- **Head of Asset Servicing:** to be informed of the engine hold, the RM's promise, and the Fenwick position.
- **Operational Risk / Head of Operations:** open an incident and complaint for Fenwick. Any compensation decision is theirs alone.
- **Grant Whitcomb:** walk back the promise made to Tomas Albright.
- **Event engine owner:** hold the auto-credit and re-run on final terms.
- **Stonemere, via DTC, on 9 Oct:** per-VOI confirmation of accepted and returned shares and cash, to reconcile before crediting.
- **IT / mail:** server receipt time for Fenwick's email, to support the 17:40 ET timestamp if it is challenged.

## Assumptions and sources
- Inputs: `notices/stonemere_final_results_notice_20261007.txt` (price, factor, rounding, conditional treatment, 9 Oct dates); `notices/halvard_offer_to_purchase_extract.md` (priority, odd-lot definition, conditional tenders); `notices/halvard_press_release_preliminary_20261005.txt` (the superseded 72.9%); `instructions/tender_instruction_log_HALV26DTCH01.csv` (TL-01 to TL-08); `positions/custody_positions_HALVARD_20261007.csv`; `event_engine/projected_tender_proceeds_HALV26DTCH01.csv`; `policies/meridale_voluntary_events_terms_extract.md` (7.1, 7.2, 8.1–8.3, 9.1); both correspondence emails.
- These figures are expected on final terms. Stonemere's per-VOI figures on 9 Oct govern the booking.
- I assume the log timestamp −05:00 is the true receipt time (CDT). New York was on EDT (−04:00) on 1 Oct.
