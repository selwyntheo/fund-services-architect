**To:** Sam Adeyemi, Fund Controller
**Re:** GACP III — Invoice GAM-III-2026-04 (Q4 2026 management fee)
**Date:** 2 Oct 2026

## Bottom line
**Do not pay the invoice as presented. Take it off Monday's (5 Oct) run.** The invoice is for USD 817,500.00. By my recomputation under the LPA, USD **56,921.23** is payable for Q4 2026. The invoice overbills by **USD 760,578.77**. That is well over the Schedule 4.2 threshold (the lower of USD 5,000 or 1%). So we must hold the payment and send Marcus Feld (CFO) written notice. We also can't pay even the corrected amount until he sends a revised invoice that he has signed (Sch. 4.4/4.5).

## Sources
- `lpa/GACP_III_LPA_excerpt_management_fee.md`: definitions of Investment Period, Fee-Paying Partner, Invested Capital, Realized and Permanent Write-Down; s.8.1(a)–(e); s.8.8
- `governance/LPAC_records_GACP_III.txt`: minutes of 12 Jun 2025 (Investment Period extended to and including 14 Aug 2026) and notice of 22 Jul 2026 (Pellucid Permanent Write-Down of USD 16.0mm, effective 30 Jun 2026; no other designation)
- `portfolio/investment_cost_ledger_GACP_III_20260930.csv`: events IC-001 to IC-015
- `investor_records/partner_register_GACP_III.csv`: commitments and fee status
- `manager/management_fee_installments_GACP_III_2026.csv`: Q3 paid USD 1,970,000.00 on 2026-07-01
- `manager/GAM_invoice_GAM-III-2026-04.txt`: the invoice
- `admin/halcyon_services_agreement_schedule4_fee_payments.md`: our obligations
- `portfolio/valuation_summary_GACP_III_Q2_2026.csv`: used only to corroborate. The fee basis follows the LPA definitions, not fair values.

## 1. Step-down date
The LPAC consented to extend the Investment Period to and including **14 Aug 2026**. The fee therefore steps down from **15 Aug 2026**, which is in the middle of Q3, not from Q4 as the invoice says. Section 8.1(d) requires Q3 to be recomputed:
- Q3 has 92 days: 45 days from 1 Jul to 14 Aug, then 47 days from 15 Aug to 30 Sep.

## 2. Fee-paying share
The GP (GP-0300, USD 6.0mm) is fee-exempt. Fee-paying commitments are USD 394.0mm out of USD 400.0mm total, which is **98.5%**. Under s.8.1(b), Invested Capital is attributed pro rata to Commitments because no partner has been excused. The invoice charges on 100%.

## 3. Invested Capital (100%, USD)
| Item | Ledger | 15 Aug 2026 | 1 Oct 2026 | Invoice |
|---|---|---|---|---|
| Acquisitions: Tessaract 60, Orla 36, Brindle 30, Kittering 40, Pellucid 28, Wexford 16, Halyard 38, Corvid 32, Tamarind 24 | IC-001–007, 009, 012 | 304,000,000 | 304,000,000 | incl. |
| Halyard follow-on (10 Sep 2026) | IC-014 | – | +4,000,000 | +4,000,000 ✓ |
| Brindle full sale (2025) | IC-011 | (30,000,000) | (30,000,000) | ✓ |
| Tessaract full sale (15 Sep 2026) | IC-015 | – (not yet closed) | (60,000,000) | ✓ |
| Wexford: written off as worthless after Ch.7 liquidation, so it counts as Realized | IC-013 | (16,000,000) | (16,000,000) | **omitted** |
| Orla: 40% of shares sold for cash (2023), cost attributable to that portion is 40% × 36.0mm | IC-008 | (14,400,000) | (14,400,000) | **omitted** |
| Pellucid: Permanent Write-Down designated by LPAC notice, effective 30 Jun 2026 | LPAC notice | (16,000,000) | (16,000,000) | **omitted** |
| Kittering: unrealized markdown to FV 24mm, not designated permanent | – | 0 | 0 | ✓ (no effect) |
| Halyard dividend recap: no shares sold | IC-010 | 0 | 0 | ✓ (no effect) |
| **Invested Capital** | | **227,600,000** | **171,600,000** | 218,000,000 |

Note: the Orla cost relief was never posted in the cost ledger (see the IC-008 note). The valuation system shows USD 21.6mm of remaining cost, which is consistent with 60% of 36.0mm.

## 4. Q3 2026 recomputation (s.8.1(d), each part rounded to the cent)
- (i) Commitment basis: 1,970,000.00 × 45/92 = **963,586.96**
- (ii) Invested Capital basis: 227,600,000 × 98.5% × 1.50% / 4 = 840,697.50, then × 47/92 = **429,486.77**
- Recomputed Q3 fee: **1,393,073.73**. The Manager was paid 1,970,000.00, so the Manager holds a credit of **576,926.27** that must be applied against the next installment.

## 5. Q4 2026
- Gross fee: 171,600,000 × 98.5% × 1.50% / 4 = **633,847.50**. Under s.8.1(c) the basis is Invested Capital at 1 Oct.
- Less the Q3 credit of (576,926.27): **payable 56,921.23**. No credit is left to carry forward.
- There is no Fee Income offset. Section 8.1(e) says none was received in 2026 to date.
- Invoice 817,500.00 − correct amount 56,921.23 = **overbilling of 760,578.77**.

The invoice's USD 817,500 is 1.5% × 218.0mm / 4. It has five errors:
- it leaves out the Wexford write-off, the Orla partial realization and the Pellucid Permanent Write-Down (together 46.4mm)
- it charges on 100% instead of the 98.5% fee-paying share
- it has no Q3 true-up

It handles the Halyard follow-on, the Brindle and Tessaract sales, the Kittering markdown and the Halyard recap correctly.

## What we must do (Services Agreement, Schedule 4)
1. **Hold:** take GAM-III-2026-04 off the 5 Oct run. We may not release payment when the difference is above the threshold (4.2). We also may not pay a different amount without a revised invoice (4.5).
2. **Notify in writing:** send Marcus Feld (CFO) this recomputation and the basis for each difference (4.2).
3. **Request:** a revised Q4 invoice signed by the CFO for USD 56,921.23. Verbal instructions to release are not acceptable (4.4). Also ask him to confirm that no Fee Income has been received.
4. **Escalate if needed:** if the difference is not resolved or satisfactorily explained within 10 Business Days of our notice, report it to the LPAC Chair (Aldermoor SERS) and to the Partnership's auditor (4.3).
5. **Accounting:**
   - book the Q3 true-up, reducing Q3 fee expense by 576,926.27 against a credit or receivable from the Manager
   - post the missing Orla cost relief of USD 14.4mm in the cost ledger
   - make sure the next LP quarterly report discloses the basis, the rate, the s.8.1(d) recomputation and the credit (s.8.8)

## Assumptions and open items
- The LPA extract (maintained by Halcyon) matches the executed LPA. No key-person event under s.2.6 ended the Investment Period early.
- Cost-ledger acquisition amounts include capitalised transaction costs.
- Tessaract stays in the 15 Aug basis because the sale closed on 15 Sep. The signed SPA from 18 Jun was not a disposal.
- I don't have the Business Day calendar, so I can't yet fix the date the 10-Business-Day clock runs out.
