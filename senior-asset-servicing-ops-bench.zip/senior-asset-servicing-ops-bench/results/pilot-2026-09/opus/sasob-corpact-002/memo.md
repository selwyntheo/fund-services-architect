# Pellam / Orvane (PELL26MRGR01): allocation, tie-out and release

**To:** Dev Raman | **Re:** your 18 Sep 3:30 PM note | **Date:** 18 Sep 2026

## Bottom line
- **Do not release engine run PA-PELL-01.** It is out of balance. Under policy 3.5 it has to be rejected and the event reprocessed.
- The correct allocation (below) **ties to the DTC receipt**. Cash consideration and Orvane shares match exactly. Cash in lieu (CIL) is USD 0.01 short of what DTC paid, and that cent goes to CA Rounding GL 9990.
- If the event is reprocessed and the checker agrees it to DTC this evening, it can be released tonight and will show on Monday's statements.
- **Lumenfield:** we can only allocate 85,000 shares as cash election. The other 40,000 have to be allocated as non-election shares, which converted to Orvane stock. The missed guaranteed-delivery cover on those 40,000 was our failure. It needs an Operational Incident and escalation to the Head of Asset Servicing. We cannot promise or book any compensation.

## Sources
- `inputs/dtc/dtc_reorg_payment_advice_PELL26MRGR01_20260918.txt`: cash 22,001,904.00 + CIL 102.08 = **22,002,006.08**; **388,839** Orvane shares.
- `inputs/notices/exchange_agent_election_results_20260917.txt`: cash was oversubscribed, so Section 2.4(a) applies. Cash proration factor **0.783546**, exchange ratio 1.2175, CIL price **40.8715**.
- `inputs/notices/merger_agreement_extract_article_II.md`, sections 2.2, 2.4 and 2.5. Cash shares = floor(cash election shares × factor). All stock election shares, non-election shares and the remaining cash election shares get stock.
- `inputs/notices/MT564_..._REPL_20260828.txt`: the default became NOAC (non-election). It replaced the NEWM notice, which had CASH as the default. Meridale's client deadline was 10 Sep 12:00 ET.
- `inputs/instructions/election_instruction_log_PELL26MRGR01.csv`, `inputs/positions/custody_positions_PELLAM_20260916_pre_effective.csv`, `inputs/event_engine/provisional_allocation_PELL26MRGR01.csv`
- `inputs/policies/meridale_ca_allocation_and_exceptions_procedures.md`, sections 3.1–3.5 and 6.1–6.3.

## Allocation by account
Method (policy 3.2): each account is treated as one holder. All the Orvane stock due to an account is added up before rounding down to whole shares. The leftover fraction × 40.8715 is paid as CIL, rounded half up to the cent.

| Account | Cash elect. | Stock elect. | Non-elect. | Exception | To cash | Cash USD | Stock basis | Orvane | CIL USD |
|---|---|---|---|---|---|---|---|---|---|
| 4410-2201 ASH | 150,000 | 64,300 | 0 | none | 117,531 | 5,641,488.00 | 96,769 → 117,816.2575 | 117,816 | 10.52 |
| 4410-2204 ASH | 0 | 0 | 88,450 | late instruction rejected | 0 | 0.00 | 88,450 → 107,687.8750 | 107,687 | 35.76 |
| 4410-3104 FEN | 350,000 | 0 | 0 | election partially withdrawn (402k − 52k) | 274,241 | 13,163,568.00 | 75,759 → 92,236.5825 | 92,236 | 23.81 |
| 4410-5024 LUM | 85,000 | 0 | 40,000 | NGD cover not delivered | 66,601 | 3,196,848.00 | 58,399 → 71,100.7825 | 71,100 | 31.98 |
| **Total** | | | | | 458,373 | **22,001,904.00** | | **388,839** | **102.07** |

## Tie-out to DTC (policy 3.4)
- **Cash consideration:** 22,001,904.00 allocated vs 22,001,904.00 received. No difference.
- **Orvane shares:** 388,839 allocated vs 388,839 received. No difference.
- **CIL:** 102.07 allocated vs 102.08 received, a difference of **USD 0.01**.
  - DTC rounds each VOI and the non-election position separately.
  - Lumenfield's stock comes from two DTC lines: 18,399 shares under VOI 26091007 (fraction 0.7825) and 40,000 shares in the non-election position (no fraction).
  - Ashgrove 2201's stock also comes from two lines: VOI 0001 fraction 0.0075 plus VOI 0002 fraction 0.25, which aggregate to 0.2575 (10.52 vs 0.31 + 10.22 = 10.53).
  - The whole 0.01 is a rounding difference and is under USD 1.00, so it goes to **GL 9990**. It is never allocated to a client.
- **Total cash:** 22,001,904.00 + 102.07 + 0.01 = 22,002,006.08, which matches the amount DTC credited.

## What is wrong with PA-PELL-01
Engine totals: cash 34,245,600.00 + CIL 10.22 = 34,245,610.22, against DTC's 22,002,006.08. **The engine overallocates cash by USD 12,243,604.14** (12,243,696.00 of consideration, offset by 91.86 less CIL). It is also **short 310,554 Orvane shares** (78,285 vs 388,839).

Causes:
1. The proration factor was not loaded, so the engine defaulted it to 1.000000. Every cash election share was paid USD 48.00, and no stock was allocated for the prorated shares (accounts 2201, 3104 and 5024).
2. For 4410-2204 the engine used the NEWM default (option 001 CASH, SEME MRDL2608240117). That default was superseded by REPL MRDL2608280233, under which the default is NOAC, so the shares are non-election and go to stock.
3. Lumenfield's 40,000 void NGD shares were treated as cash election.
4. CIL was taken per VOI rather than calculated per account.

The 4410-3104 quantity (350,000) is correct.

## Lumenfield (Harriet Voss): what we can and can't do
**Facts**
- EL-05 elected cash on 85,000 settled shares. This was verified and accepted.
- EL-06 elected cash on 40,000 shares by notice of guaranteed delivery. The cover was due by 15 Sep 17:00 ET.
- The purchase EQ-B-260909-5120 settled on **14 Sep**, but cover exception EXQ-5521 (opened 14 Sep 16:12) was **left unassigned**. The shares were never delivered, and the election became PROTECT_EXPIRED_NOT_COVERED (EL-08).
- Under Merger Agreement section 2.2 those 40,000 shares are Non-Election Shares, and DTC paid them as stock (advice line 0005 VOID, included in line 0006). This was a Meridale processing failure.

**What we can't do**
- Allocate the 40,000 shares as cash election. Policy 3.3 requires us to allocate what the agent actually applied.
- Credit or promise compensation, or move other clients', rounding or suspense money to make up the difference (policy 6.2).
- Resubmit or amend the election with Stonemere (policy 6.3). Only the Head of Asset Servicing may ask the agent for exceptional treatment.

**What we can do**
- Allocate the actual outcome correctly.
- Tell her plainly that the 40,000 shares were treated as non-election because the delivery was missed.
- Tell her that Meridale has opened an Operational Incident, and that any remediation is decided through that process with Head of Operations approval.

**Impact estimate for the incident**

| | Shares to cash | Cash USD | Orvane | CIL USD |
|---|---|---|---|---|
| Valid 125,000 cash election (hypothetical) | 97,943 | 4,701,264.00 | 32,941 | 36.68 |
| Actual | 66,601 | 3,196,848.00 | 71,100 | 31.98 |
| Difference | | 1,504,416.00 less cash | 38,159 more | |

Whether this is an economic loss depends on the Orvane price. At the CIL reference price of 40.8715, the stock leg is worth about USD 49.76 per Pellam share against USD 48.00 in cash. The client also carries market exposure on the extra shares.

Ashgrove 4410-2204 is a different case. That instruction was late and was rejected under our deadline, and the client was told on 11 Sep. It is not a Meridale failure, so no incident is needed.

## Actions and owners
1. **Checker / Event Engine team:** reject PA-PELL-01 and reprocess with the parameters above.
2. **Checker:** agree the reprocessed run to DTC, post USD 0.01 to GL 9990, then release to client accounts.
3. **Dev / Asset Servicing:** raise an Operational Incident with Operational Risk by Mon 21 Sep (within one business day), then escalate to the Head of Asset Servicing (policy 6.1).
4. **Relationship manager / Dev:** reply to Harriet Voss as set out above, with no promise of compensation.
5. **Engine support:** find out why the factor was not loaded and why a superseded default was applied. Check other events for the same problem.

## Assumptions and open questions
- No tax withholding (Merger Agreement section 2.6) is shown on the DTC advice, so I have assumed none applies.
- Lumenfield's existing 26,000 Orvane shares are a separate holding and do not affect the rounding.
- Open questions:
  - Why EXQ-5521 was never assigned.
  - Why the engine picked up the NEWM default.
  - Whether the same engine defects affect other events.
