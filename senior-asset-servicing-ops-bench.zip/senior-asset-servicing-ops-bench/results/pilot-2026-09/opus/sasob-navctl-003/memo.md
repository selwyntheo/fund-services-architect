**To:** Mara Lindqvist, Treasurer & PFO, Corvane Investment Trust
**Re:** CGEF / Tarrant Hollis trade date 9/17. Which orders get the 9/17 price

## Bottom line
- **Six of the twelve Tarrant Hollis orders are wholly or partly late:** 5504, 5505, 5507, 5512, the $1.0mm increase on 5508, and 5509. They are not entitled to the 9/17 NAV of $31.42. They must be cancelled and re-billed at the 9/18 NAV of $32.19.
- **We cannot leave them.** Procedures s.2 (Rule 22c-1): *"The Transfer Agent may not process a late order at the prior day's NAV, and no officer may authorise it to do so."* Ken's proposal is not an option we can approve.
- **Cost to the Fund if left: $118,753.81 net.** That is $123,758.81 of dilution on $5.05mm of late purchases, less a $5,005.00 gain on 6,500 late-redeemed shares.
- **Today's 9/18 NAV of $32.19 does not need restating.** The effect is +$0.0045/share, and it still rounds to $32.19.
- **Tarrant Hollis is responsible.** It breached Articles 4.2, 4.3 and 4.4 and owes indemnity under Article 9.2.
- **Report to the CCO today** (procedures s.5). The post-close purchases came after the 4:09 pm ET Harrowgate takeover headline.
- **We unwind only what we have to.** The other six orders and the original $400k of 5508 stay at 9/17. The three direct-account trades are not affected.

## Sources
- `inputs/intermediary/tarrant_hollis_order_entry_audit_CGEF_20260917.csv`: entry times, branch time zones, and the 5508 modification.
- `inputs/transfer_agent/fundserv_transmissions_THS_CGEF_tradedate_20260917.txt`: FS1 received by the TA 2026-09-18 06:52:14 ET (11 records); FS2 "SUPPLEMENTAL" received 09:41:37 ET (5509 only).
- `inputs/transfer_agent/ta_processing_report_CGEF_tradedate_20260917.csv`: all 15 trades processed at $31.42 and settled 9/18.
- `inputs/nav/published_nav_CGEF_20260915_20260918.csv`: 9/17 NAV $31.42; 9/18 TNA $856,047,840.83, 26,595,743.702 shares, NAV $32.19.
- `inputs/agreements/tarrant_hollis_intermediary_agreement_excerpt.md`: Articles 4.1–4.5 and 9.2.
- `inputs/policies/CIT_order_acceptance_and_late_trading_procedures.md`: ss.2–6.
- `inputs/policies/CIT_NAV_error_correction_policy.md`: ss.1.4 and 8.3.
- `inputs/correspondence/email_stellmark_ta_supervisor_20260918.txt` and `inputs/market/newswire_20260917.txt` (headline at 16:09 ET).

## Order-by-order test
The Close is 4:00:00 pm ET. An order is timely only if it was received **before** the Close (4.1). An order "at or after" the Close is next-day (4.2). The file must reach the TA by 9:00 am ET on 9/18 (4.3). An increase after the Close is a new order (4.4). I converted Chicago times +1h and San Francisco times +3h to ET.

| Order | Sub-acct | Side | Local entry | ET entry | Received by TA | Result | At 9/17 | At 9/18 |
|---|---|---|---|---|---|---|---|---|
| 5501 | A-10442 | Buy $ | 10:14:22 ET | 10:14:22 | FS1 06:52 | Timely | $250,000 | – |
| 5502 | A-20918 | Sell sh | 13:47:05 ET | 13:47:05 | FS1 | Timely | 3,000 sh | – |
| 5503 | A-31177 | Buy $ | 14:32:10 CT | 15:32:10 | FS1 | Timely | $80,000 | – |
| **5504** | A-40021 | Buy $ | 15:18:44 CT | **16:18:44** | FS1 | **Late**: after the Close | – | $1,500,000 |
| **5505** | A-40021 | Buy $ | 15:26:09 CT | **16:26:09** | FS1 | **Late**: after the Close | – | $2,250,000 |
| 5506 | A-52210 | Buy $ | 15:59:58 ET | 15:59:58 | FS1 | Timely (2 s before) | $120,000 | – |
| **5507** | A-52877 | Sell sh | 16:00:00 ET | **16:00:00** | FS1 | **Late**: *at* the Close (4.2) | – | 4,500 sh |
| **5508** | A-61034 | Buy $ | 15:52:31 ET; increased 16:12:40 to $1.4mm | – | FS1 | **Split**: increase after the Close (4.4) | $400,000 | $1,000,000 |
| **5509** | A-70315 | Buy $ | 15:47:03 ET | 15:47:03 | **FS2 09:41:37 on 9/18** | **Late**: missed the 9:00 am deadline (4.3) | – | $300,000 |
| 5510 | A-10442 | Sell sh | 11:05:40 ET | 11:05:40 | FS1 | Timely | 1,200 sh | – |
| 5511 | A-83390 | Buy $ | 12:40:00 PT | 15:40:00 | FS1 | Timely | $60,000 | – |
| **5512** | A-83391 | Sell sh | 13:05:30 PT | **16:05:30** | FS1 | **Late**: after the Close | – | 2,000 sh |

Surveillance flagged four orders (5504, 5505, 5508, 5509). It missed 5507 (entered at exactly 4:00:00) and 5512 (Pacific time).

Answers to Tarrant's arguments:
- **"Chicago times are local, so obviously before the close."** Converted to Eastern, 15:18 and 15:26 CT are 16:18 and 16:26 ET. That is after the Close.
- **"5509 was taken at 3:47."** Under 4.3, an order the TA receives after 9:00 am is received when the TA gets it, *"notwithstanding any earlier trade date."* The system delay is Tarrant's problem.
- **"5508 was only topped up."** Under 4.4, the $1.0mm increase is a new order received at 16:12:40.

## Impact if the late orders stay at the 9/17 NAV
Method: procedures s.4. For purchases, impact = (shares at $31.42 − shares at $32.19) × $32.19, with shares to 3dp (round half up). For redemptions, impact = shares × ($31.42 − $32.19). A positive figure is a loss to the Fund.

| Order | Late qty | Shares @31.42 | Shares @32.19 | Excess sh | Impact $ |
|---|---|---|---|---|---|
| 5504 | $1,500,000 | 47,740.293 | 46,598.322 | 1,141.971 | 36,760.05 |
| 5505 | $2,250,000 | 71,610.439 | 69,897.484 | 1,712.955 | 55,140.02 |
| 5508 (increase) | $1,000,000 | 31,826.862 | 31,065.548 | 761.314 | 24,506.70 |
| 5509 | $300,000 | 9,548.059 | 9,319.664 | 228.395 | 7,352.04 |
| **Purchases** | **$5,050,000** | 160,725.653 | | **3,844.635** | **123,758.81** |
| 5507 | 4,500 sh | | | | (3,465.00) |
| 5512 | 2,000 sh | | | | (1,540.00) |
| **Net** | | | | | **118,753.81** |

For 5508, the TA issued 44,557.607 shares. Of these, 12,730.745 relate to the timely $400k ($400,000 / 31.42) and 31,826.862 to the late $1.0mm.

The late redeemers were *under*-paid at $31.42. Re-billing them at $32.19 pays them $5,005.00 more ($144,855.00 for 5507 and $64,380.00 for 5512). That is the correct result under Rule 22c-1, and it is not a loss to the Fund. Leaving the trades in place would not save that money legitimately.

## Is today's (9/18) NAV affected?
The 9/18 shares outstanding (26,595,743.702) equal the 9/17 shares plus all 9/17 TA activity (+176,969.797 sh). So the 9/17 capital stock, including the late orders, was in the 9/18 strike.

- Published, unrounded: $856,047,840.83 / 26,595,743.702 = **32.1874**.
- Remove the late orders from 9/17 capital stock. Subtract the $5,050,000 of late subscriptions (160,725.653 sh). Add back the late redemptions (6,500 sh / $204,230.00).
- Corrected: $851,202,070.83 / 26,441,518.049 = **32.1919**.

The effect is **+$0.0045/share (0.014%)**, and both figures round to $32.19. The difference is below the $0.01 test and the 0.50% test in NAV policy s.1.4. So this is not a Material Day and **no restatement or reprocessing of 9/18 activity is needed**. Log it in the NAV error log for the quarterly Board report (s.8.3).

Assumption: the late cash was treated as capital stock receivable that did not earn the 9/18 market move.

## Actions (who needs to hear)
1. **Stellmark TA (Ken Osterhaut), before 9 am Monday.** Do not close the surveillance items. Cancel the late trades and re-bill them at trade date 9/18 / $32.19, as in the table above. Split confirm SSS260951208. Leave all other trades alone.
2. **CCO, today** (procedures s.5). Send the evidence package. A-40021 placed $3.75mm and A-61034 added $1.0mm between 16:12 and 16:26 ET, after the 16:09 ET Harrowgate headline (acquisition at a 38% premium; the stock closed 9/18 +36.1%). The CCO decides on 22c-2 restrictions and on Board and regulator reporting.
3. **Tarrant Hollis.** Request under 4.5/4.6:
   - beneficial-owner identity and history for the late sub-accounts;
   - the reason for the 5508 increase;
   - logs for the FS2 delay;
   - confirmation of time zones;
   - reallocation of the re-billed trades to sub-accounts.

   Put Tarrant on notice of its Article 9.2 indemnity for any unrecovered loss and for reprocessing costs.
4. **Stellmark Fund Services (accounting).** Book the as-of capital stock adjustments. On 9/17, net flows fall by $4,845,770. The same activity moves to 9/18.
5. **PM.** Tell them about the flow restatement.
6. **Board.** The CCO reports the incident at the next meeting. Separately, the 9/18 item goes in the NAV error log (s.8.3).

## Open items and assumptions
- The NYSE closed at the normal 4:00 pm on 9/17; there is no early-close notice in the inputs.
- Tarrant's local timestamps are in the time zones its records label.
- The trades settled 9/18. Stellmark must confirm the cancel/re-bill can be applied to the omnibus position. Any shortfall becomes a Tarrant indemnity claim.
- Only the CGEF Tarrant data was provided. Other funds and intermediaries for 9/17 were not reviewed.
