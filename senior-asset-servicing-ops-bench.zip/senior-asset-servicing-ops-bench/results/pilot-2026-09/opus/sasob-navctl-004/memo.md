# CIT payment run PR-20260918-01 — what you can approve today

**To:** Nadia Brennholt, Assistant Treasurer | **Re:** Stellmark run 18 Sep 2026 (Brackwater portal approval by 13:30 ET)

## Bottom line
- **Approve today: 4 lines, USD 90,048.35.** Each payee is within your USD 100,000 per-payee/day limit and each line is covered by its accrual (one needs a minor true-up).
- **Do not release the Lanthorn lines. Treat them as a suspected fraud attempt.** The "Mara" email is almost certainly spoofed. Report it to the CCO and Information Security now.
- The Treasurer must approve the Stellmark Fund Services invoices and the Haverleigh audit invoice when she's back on Monday. Neither is past due.
- Take Norland (an Adviser expense) and Ashgrove (a duplicate) off the run.

Run total: 12 lines, USD 400,258.35 = 90,048.35 released + 61,560.00 held for suspected fraud + 221,800.00 held for the Treasurer + 26,850.00 rejected.

## Line by line
Sources: `payments/stellmark_payment_proposal_20260918.csv` (the run), `accounting/accrued_expenses_by_fund_20260917.csv` (accruals), `payments/payment_history_CIT_20260619_20260917.csv`, `payments/vendor_master_*.csv`, `policies/CIT_expense_payment_and_authority_policy.md` (Policy), `agreements/corvane_advisory_agreement_expense_excerpt.md` (IAA).

| # | Invoice | Fund | Payee | USD | Decision | Why |
|---|---|---|---|---:|---|---|
| 1 | BTC-2608-CMOF | CMOF | Brackwater (V1001) | 31,882.40 | **Release** | Accrual GL2310 32,000.00 covers it. Verified internal debit ...4410. |
| 2 | BTC-2608-CGEF | CGEF | Brackwater (V1001) | 27,115.60 | **Release with minor true-up** | Accrual 26,900.00 leaves a shortfall of 215.60 (0.80% of the invoice, under USD 2,500), so it's a minor true-up under Policy 3.1. Stellmark books 215.60 to expense. V1001 total for the day is 58,998.00, which is under 100k. |
| 3 | SFS-2608-0117 | CMOF | Stellmark Fund Services (V1002) | 58,200.00 | Hold for Treasurer | Beyond your authority. V1002 total for the day is 176,800.00, over your USD 100k limit (Policy 2.1–2.2). Splitting the payments is prohibited, and authority can't be delegated by email (2.3). Accruals match exactly. Due 2026-10-04. |
| 4 | SFS-2608-0118 | CMAF | Stellmark Fund Services (V1002) | 41,700.00 | Hold for Treasurer | Same as line 3. |
| 5 | SFS-2608-0119 | CGEF | Stellmark Fund Services (V1002) | 76,900.00 | Hold for Treasurer | Same as line 3. |
| 6 | SSS-2608-4471 | CGEF | Stellmark Shareholder Services (V1003) | 22,410.35 | **Release** | This is a separate legal entity and payee from V1002 (see vendor master note), so it doesn't count toward the V1002 total. Accrual GL2330 23,000.00 covers it. |
| 7 | LPP-7781R | CGEF | Lanthorn (V1010) | 48,600.00 | **Hold: suspected fraud** | Bank change pending (see below). Invoice amendments are under the same hold (4.3). It exceeds the CGEF printing accrual of 19,000.00 by 29,600.00. The 30,180.00 proxy line needs Board approval (IAA 6.3), and there is no evidence of that approval in the file. |
| 8 | LPP-7782 | CMAF | Lanthorn (V1010) | 12,960.00 | **Hold: suspected fraud** | Bank change pending. No payment to the new or the old account (4.3). The invoice itself isn't in the folder. Accrual 13,500.00 would cover it. |
| 9 | HO-26-0915 | CMAF | Haverleigh & Ormond (V1015) | 45,000.00 | Hold for Treasurer | Accrual shortfall. Accrual GL2320 is 38,100.00, leaving 6,900.00 uncovered (15.3%, over USD 2,500). Policy 3.2 requires the Treasurer to approve the variance and a true-up first. Billed-to-date of 59,676.99 = 14,676.99 paid on 3 Aug + 45,000.00, so it isn't a duplicate. Due 2026-10-15. |
| 10 | WB-118204 | CMOF | Whitlow Brandt (V1020) | 8,640.00 | **Release** | Accrual GL2340 12,000.00 covers it. |
| 11 | NIS-2026-3319 | CGEF | Norland Index (V1031) | 22,500.00 | **Reject: Adviser expense** | The licence covers use in marketing and distribution materials, so under IAA 6.1(b) and Policy 1.1 the Adviser pays it. The regulatory-use licence is free of charge. There is no fund accrual, and it is coded to GL5900. Refer to Corvane Partners Finance. |
| 12 | AFS-22917 | CGEF | Ashgrove Filing (V1044) | 4,350.00 | **Reject: duplicate** | Already paid 2026-08-28 (PAY-260828-0044, Pellbrook ...8804, approved by you). Policy 1.2 applies. |

**Released today:** 31,882.40 + 27,115.60 + 22,410.35 + 8,640.00 = **USD 90,048.35**.

## Lanthorn: why this looks like fraud
- **The bank change request came from a look-alike domain.** It came from `accounts@lanthorn-print.example`, but the vendor master has `lanthornprint.example`. The phone number in the request, +1 (617) 555-0148, is different from the number on file, +1 (617) 555-0193. The genuine invoice LPP-7781 uses billing@lanthornprint.example and 555-0193.
- **The call-back was invalid.** VMC-2026-0441 shows L. Pardo called the number supplied in the request email, which Policy 4.2(a) forbids. There is also no Treasurer approval, and the status is KEYED_AWAITING_APPROVAL.
- **The "revised" invoice adds work and money.** It turns an 18,420.00 invoice due 2 Oct into 48,600.00 due on receipt, adding 30,180.00 for a proxy solicitation with no Board approval on file.
- **The "Mara" approval email is almost certainly spoofed.** It came from `mara.lindqvist@corvane-partners.example`, but her real address is `mlindqvist@corvanepartners.example`. It was sent at 08:12, after her 07:02 autoreply said she has no email access. It urges you to bypass Stellmark. Even if it were genuine, Policy 2.3 and 4.2(c) mean it cannot approve the change.
- **Treatment.** Hold both lines. Report to the CCO and Information Security now (Policy 4.4). Contact Lanthorn only through the details on file. Recommend the Treasurer reject VMC-2026-0441. The original LPP-7781 (18,420.00, Harbison ...3052) looks like the genuine obligation and isn't due until 2 Oct, so it can go in a later run once the change request is resolved.

## What I need from whom
- **CCO and Corvane Information Security (today):** report the suspected fraud, covering the spoofed Treasurer email and the look-alike Lanthorn domain and phone.
- **Helena Marsh, President (today):** let her know, since Mara's autoreply names her as the urgent contact. The policy gives the President no authority of her own, so the held items still wait for Mara.
- **Mara Lindqvist, Treasurer (Mon 21 Sep):** three decisions:
  - Approve the V1002 invoices totalling 176,800.00.
  - Approve the 6,900.00 CMAF audit variance and true-up, then release HO-26-0915.
  - Reject VMC-2026-0441.
- **Stellmark AP:**
  - Take AFS-22917 and NIS-2026-3319 off the run, and explain why the duplicate check missed AFS-22917.
  - Book the 215.60 true-up.
  - Keep VMC-2026-0441 unapproved.
- **Lanthorn (on-file contacts only):** verify the change request and the revision, and send invoice LPP-7782.
- **Corvane Partners Finance:** take over the Norland invoice, and have Norland re-address it to the Adviser.
- **Board / Secretary:** confirm whether a CGEF proxy solicitation was approved.

## Assumptions and open points
- LPP-7782 isn't in the inputs. I relied on the run's figures (12,960.00, CMAF).
- The shortfall on LPP-7781R is measured against the whole CGEF GL2350 FY2026 accrual (19,000.00).
- None of the held items will be past due before the Treasurer returns: the Stellmark invoices are due 4 Oct and Haverleigh 15 Oct. Lanthorn's "due on receipt" term appears only on the suspect revised invoice.
