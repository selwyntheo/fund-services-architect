# Tollbridge Aggregates rights (CA-26-0915-TOLL): checker review of batch B-TOLL-01

**To:** Priya Castellanos | **From:** Checker, Asset Servicing | **Date:** Mon 28 Sep 2026

## Bottom line
I **can't sign off the batch as drafted**. All four lines are wrong. The engine picked the "latest recorded SI" for each account. It ignored the SI validity dates (Terms 4.2) and the call-back status (4.4), and it did no Available Cash check (5.1). The corrected elections are below. They are the only version I will approve. They can go to Carrow before the 29-Sep 12:00 London cut-off (07:00 ET).

Lumenfield's take-up **cannot** be put in. The reasons are in section 3.

## 1. Corrected elections

Price is GBP 1.85 per new share. One right = one new share. The deadline is the 28-Sep 12:00 ET Client Response Deadline (CRD), and the market payment date is 01-Oct.

| Account | Governing SI | Rights held | Take up (EXER) | Excess (OVER) | Sell nil paid (SLLE) | Lapse | Available GBP | GBP debit | Engine draft |
|---|---|---|---|---|---|---|---|---|---|
| 4410-2201 ASH | SI-0412 (client, verified) | 357,142 | 331,027 | 0 | 26,115 | 0 | 612,400.00 | **612,399.95** | LAPS 357,142 (SI-0951) |
| 4410-2202 ASH | SI-0877 (account, verified) | 139,000 | 139,000 | 23,162 | 0 | 0 | 300,000.00 | **299,999.70** | LAPS 139,000 (SI-0951) |
| 4410-3107 FEN | SI-0931 (client, verified) | 258,096 | 249,613 | 0 | 0 | 8,483 | 461,785.60 | **461,784.05** | SLLE 258,096 (SI-0520) |
| 4410-5020 LUM | SI-0605 (account, verified) | 114,285 | 0 | 0 | 0 | 114,285 | 150,000.00 | **0.00** | EXER 114,285 / 211,427.25 (SI-0944) |
| **Total** | | **868,523** | **719,640** | **23,162** | **26,115** | **122,768** | | **1,374,183.70** | |

The rights held match the record-date positions × 2/7, rounded down. For example, 1,250,000 × 2/7 = 357,142.86 → 357,142. The total, 868,523, agrees with the Carrow MT564 ELIG of 868,523. Lapsed rights need no MT565 because LAPS is the default. Any lapsed-rights premium of GBP 5 or more is credited when received.

## 2. Working by account

**4410-2201 (Ashgrove Global Equity)**
- SI-0951 (LAPSE) has `valid_from` 2026-10-15, so it doesn't cover the CRD date. There is no account-level SI, so client-level SI-0412 governs: take up in full, with the balance sold nil paid.
- Full take-up would cost 357,142 × 1.85 = 660,712.70.
- Available Cash is the cleared GBP of 612,400.00. The GBP 60,000 FX (AGP-FX-0928-01, value 30-Sep, "no counterparty confirmation") is a projected inflow. It doesn't count under 5.1, and `auto_fx`=N.
- 612,400 / 1.85 = 331,027.03, so we take up **331,027** rights for 612,399.95.
- The remaining **26,115** rights are sold nil paid under SI-0412's `balance_if_unfunded` (5.3).
- Marcus's 08:52 email only confirms "per our standing instruction". It changes nothing and isn't call-back verified anyway. Telling us "funding is sorted" doesn't make the FX Available Cash.

**4410-2202 (Ashgrove UK Value)**
- Account-level SI-0877 governs, and the email says "SI as usual".
- Available Cash is the cleared 300,000.00. The Harcourt sale proceeds of 40,112.35 (value 29-Sep) are excluded.
- Take-up of 139,000 costs 257,150.00, leaving 42,850.00.
- The SI caps excess at 25% × 139,000 = 34,750. The remaining cash covers floor(42,850 / 1.85) = **23,162**, which costs 42,849.70.
- Total debit is **299,999.70** (5.4). The excess may be scaled back pro rata, and any refund comes back without interest.

**4410-3107 (Fenwick Intl Equity)**
- SI-0520 v1 was superseded (`recorded_to` 2026-09-16). SI-0520 v2 ended on 2026-09-14. The governing SI is SI-0931 (TAKE_UP_FULL, balance LAPSE, verified 16-Sep by callback to T. Albright).
- Available Cash = 520,000.00 − 58,214.40. The 58,214.40 is matched purchase EQ-B-260925-2207, value 29-Sep, which is on or before 01-Oct, so it is reserved. That gives **461,785.60**.
- EQ-B-260928-2291 (30,006.00, value 05-Oct) falls after the payment date, so it isn't reserved.
- Full take-up would be 477,477.60. Cash covers floor(461,785.60 / 1.85) = **249,613** rights, costing 461,784.05. The other **8,483** rights lapse.

**4410-5020 (Lumenfield Global Equity)**
- SI-0944 (TAKE_UP_FULL) is PENDING_CALLBACK. The callbacks on 25-Sep and 28-Sep went unanswered, so it isn't effective (4.4). Verified account-level SI-0605 = **LAPSE** governs.
- Harriet's email is timestamped 17:05 +0100, which is **12:05 ET**. That is after the 12:00 ET CRD, so it is a late instruction (7.2). It is also an unverified email.
- The late best-efforts route needs all of: (i) Head of Asset Servicing written approval, (ii) Carrow's written acceptance, and (iii) cleared GBP covering the full election.
- Condition (iii) fails. Cleared GBP is 150,000.00 against 211,427.25 needed. We can't use the USD 2.31m (no FX, `auto_fx`=N, 5.2), and we can't lend (5.2). Conditions (i) and (ii) aren't in hand either.
- So the account is processed as if the email had not been received: **all 114,285 rights lapse** and no MT565 is sent. The engine's EXER line must be cancelled.
- Note that even a verified SI-0944 would only have funded 81,081 rights.

## 3. On "just get it in" for Lumenfield
- "The market doesn't close until Thursday" doesn't help. Our binding deadline was 12:00 ET today (notice; Terms 7.1), and Carrow's is 29-Sep 12:00 London.
- Submitting it would mean either sending an unfunded instruction, which Carrow will reject ("instructions not fully funded in cleared GBP will be rejected"), or extending credit, which 5.2 prohibits.
- Terms 7.3 **requires** us to tell Lumenfield in writing **today** that the instruction won't be actioned, and why. We have to have that conversation.
- Separately, the SI change and today's email both came by email, and the registered-number callbacks went unanswered. Verification should be done on the registered number, not by replying to the email.

## 4. Client messages (for you to send)
- **Lumenfield (Harriet Voss), 4410-5020:**
  - Your take-up email was received at 12:05 ET, after our 12:00 ET deadline. The account also held GBP 150,000.00 cleared against the GBP 211,427.25 needed, and we can't fund subscriptions by credit or FX.
  - We have therefore processed your verified standing instruction (lapse) for all 114,285 rights. Any lapsed-rights premium of GBP 5 or more will be credited when received.
  - Your 24-Sep SI amendment isn't yet effective because we couldn't complete the call-back. Please call us from, or be available on, your registered number.
- **Ashgrove (Marcus Leland):**
  - 2201: the GBP 60,000 FX (value 30-Sep, unconfirmed) isn't cleared cash at the deadline. We are taking up 331,027 rights (GBP 612,399.95) and selling 26,115 rights nil paid, best efforts, with proceeds net of costs, per SI-0412.
  - 2202: full take-up of 139,000 plus an excess application of 23,162 shares (GBP 299,999.70) per SI-0877. The excess is subject to scale-back and refund.
  - Reminder: SI-0951 (lapse) applies to events with deadlines from 15-Oct-2026.
- **Fenwick:**
  - 3107 was processed under SI-0931. We are taking up 249,613 rights (GBP 461,784.05) and 8,483 rights lapse for lack of cash, after reserving the 29-Sep purchase.
  - The account will have about GBP 1.55 left, so please fund the 05-Oct Harcourt purchase of GBP 30,006.00.

## 5. Actions / what I need
- Replace batch B-TOLL-01 with the corrected MT565s:
  - 2201: EXER 331,027 + SLLE 26,115
  - 2202: EXER 139,000 + OVER 23,162
  - 3107: EXER 249,613
  - 5020: none
- Release them before 07:00 ET on 29-Sep.
- **Head of Asset Servicing:** raise the engine SI-selection defect. It chooses the latest `recorded_from` row, ignoring `valid_from`/`valid_to` and `callback_status`.
- **Carrow:** confirm the SLLE of 26,115 rights for 2201 is executed best efforts before 01-Oct 11:00 London.
- **Relationship manager:** heads-up on the Lumenfield lapse.

## Assumptions
- Cash is taken from the 12:00 ET snapshot (`cash_availability_GBP_20260928_1200ET.csv`), which is at the CRD.
- The market payment date is 01-Oct-2026 (MT564 cash PAYD).
- Share counts are rounded down to whole new shares.
- Sources: all files under `inputs/` (positions, SI register, cash, MT564, client notice, prospectus extract, Service Terms v6.1 sections 4, 5 and 7, the engine draft, and the two client emails).
