**To:** Priya Ramaswamy
**Re:** CMAF management fee waiver applied after expiry: recommendation for Mara
**Date:** 18 Sep 2026

## Bottom line
- **This is not a "NAV error" in the reprocess-the-shareholders sense.** The penny test was met on 92 NAV dates. The largest error, though, was $0.0143/share, which is **0.055%** of NAV. The Trust's policy (s.1.4) makes a day a Material Day only if the error is **both** ≥ $0.01 **and** ≥ 0.50%, so there are **0 Material Days**. Under s.3.1, nothing is reprocessed, no account is adjusted and no reimbursement is sought.
- **Reject both of Stellmark's options.** Option (a), spreading the catch-up to 10/31, is expressly prohibited by s.3.2 ("may not be deferred, amortized or spread"). Option (b), reprocessing, is not permitted because there is no Material Day. Stellmark's "over a penny since the spring" test only applies the first half of the definition.
- **Tonight (9/18 NAV):** book the full catch-up of **$176,355.81** of management fee and the knock-on **$42,491.49** expense-limitation receivable from the Adviser. The **net fall in net assets is $133,864.32, which is $0.0109/share** on 12,332,341.362 shares.
- Because that is ≥ $0.01, **the Treasurer must approve the 9/18 NAV in writing before it is released** (s.3.3), and the item goes in the NAV error log with an explanation of the day's move.
- **The Fund is owed $0** from Stellmark or anyone else. There is no Fund Loss without a Material Day. The Fund is made whole by the accrual itself, and the Adviser's expense cap absorbs $42,491.49 of it.

## What happened
- The Adviser's letter of 20 Jan 2026 (`correspondence/adviser_letter_fee_waiver_20260120.txt`) ended the 10 bp waiver on **28 Feb 2026**. The prospectus of 27 Feb 2026 (`fund_documents/...fee_table_excerpt`) discloses the same thing.
- The fee module rule **WVR-CMAF-01** still has `effective_to` = 2026-12-31 (`accounting/fee_module_setup_CMAF.csv`). Stellmark changed EXPLIM-CMAF-01 on 2 Feb but did not change the waiver rule (Priyanka's email, 18 Sep).
- The fee module's accrual file (`accounting/mgmt_fee_daily_accrual_CMAF_FY2026_20260917.csv`, 321 rows) shows the 10 bp waiver on every day through 9/17. I recomputed every row: basis = prior NAV net assets per `nav/nav_history...csv`, rate/365, rounded to the cent. Gross fee, waiver and net fee all tie, and the net fees sum to $1,373,274.90, which matches expense summary line 01. **The waiver's expiry date is the only error.**

## Figures (re-performable)
| Item | Value | Source / method |
|---|---|---|
| Missed fee (waiver on accrual days 3/1–9/17, 201 days) | **$176,355.81** | Sum of `waiver_usd` where accrual_date ≥ 2026-03-01 |
| First NAV affected | **2026-02-27** | The Friday NAV carries accruals for 2/27, 2/28 and 3/1 (procedures E1.2). The 3/1 accrual of $858.45 is the first error |
| Last NAV affected | 2026-09-17 | 140 NAV dates in the Error Period |
| Peak cumulative error | $176,355.81 / 12,332,341.362 = **$0.0143/share** (9/17) | Gross, before any cap effect (policy s.2.2) |
| Peak % of corrected NAV | 0.0143 / 26.03 = **0.055%** | Corrected NAV = (TNA − cumulative error)/published shares, rounded (s.1.2) |
| Days with rounded difference ≥ $0.01 | 92 (first 2026-03-17) | Published NAV − corrected NAV |
| Material Days (both tests) | **0** | 0.50% test never met |
| FYTD covered expenses, as reported | $2,201,519.44 | Expense summary line 94 (sum of COVERED lines ties) |
| Covered expenses, corrected | $2,377,875.25 | + $176,355.81 |
| FYTD cap | $2,335,383.76 | 85 bp × ADNA $312,411,608.50 × 321/365 (line 95; I re-derived the ADNA from NAV history and it ties) |
| Expense-limitation receivable increase (GL 1380) | **$42,491.49** | max(0, 2,377,875.25 − 2,335,383.76) − 0.00 |
| Net reduction in net assets | **$133,864.32** | 176,355.81 − 42,491.49 |
| NAV/share effect | **$0.0109** (gross $0.0143) | ÷ 12,332,341.362 shares (9/17 NAV) |
| Treasurer approval | **Required** | ≥ $0.01 (s.3.3) |
| Fund reimbursement due | **$0** | No Material Day, so no Fund Loss (s.3.1, s.6) |

## Entries for the 9/18 NAV
1. Dr Management fee expense (5100) / Cr Advisory fee payable: **$176,355.81**.
2. Dr Expense limitation reimbursement receivable (1380) / Cr Expense reimbursement (contra-expense): **$42,491.49**. This is the FYTD true-up measured as of the 9/17 accrual date (E3.1). ADNA is not restated (E2.3).
3. Fee module: set WVR-CMAF-01 `effective_to` to 2026-02-28 with second-preparer review, so that the 9/18–9/20 accruals run at the full 60 bp. **Stellmark must confirm the rule change will not also re-accrue the back period automatically**, which would double-count entry 1.

On top of the $0.0109 correction, the 9/18 NAV will also move for the normal three days of accruals (Fri–Sun) and the daily cap true-up. From now on the expense limitation is binding, so the Adviser reimburses every day.

## Board materials (Q3, going out next week)
Report under policy s.8.3 (non-material errors are reported quarterly; the s.8.2 prompt reporting of a Material Day does not apply). Include:
- Description, Error Period (NAVs 2/27–9/17/2026), gross amount $176,355.81, peak $0.0143/share (0.055%), and the conclusion that there are 0 Material Days, so no reprocessing.
- The correction booked in full in the 9/18 NAV: net −$133,864.32 (−$0.0109/share), approved by the Treasurer under s.3.3.
- The expense-cap consequence: the Adviser now reimburses under the Expense Limitation Agreement ($42,491.49 at 9/17), and the Fund's net expense ratio moves to the 0.85% cap, which is consistent with the prospectus.
- Root cause and remediation: the administrator did not update the rule end date and the E1.3 second-preparer review missed it. Stellmark should review all fee-module rules against their source documents.

## Assumptions
- Corrected NAV is computed by the policy default (s.1.2). Materiality is measured gross (s.2.2).
- The cap computation uses the 9/17 FYTD figures as reported. No other expense items are in error.

## What I need from whom
- **Treasurer (Mara):** written approval of the correction calculation and of releasing the 9/18 NAV (s.3.3/8.1).
- **Stellmark (Priyanka):** the 9/18 entries for review before the NAV is struck; confirmation of fee-module re-accrual behavior; a root-cause and remediation memo; confirmation that all CMAF and other Trust fee rules have been reviewed.
- **Adviser (Corvane Partners):** acknowledgement of the $176,355.81 fee now payable and the $42,491.49 cap reimbursement owed to the Fund.
- **CCO and auditor:** for information (administrator control failure; out-of-period correction before the 10/31 year-end).

## Open questions
- When will the Adviser be paid the additional fee, net of the cap reimbursement? This does not affect the NAV entries.
- If the Treasurer directs a method other than s.1.2 for the Corrected NAV, re-run the test. With a peak of 0.055%, the conclusion will not change.
