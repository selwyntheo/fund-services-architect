# ADGF: 18 Sep 2026 NAV review and expense cap worksheet

**To:** Priya Castellane | **Re:** NAVRUN-0918-1602 | **Status:** the corrected NAVs are ready to release once entries 1 and 2 are booked and reviewed. Do not release the system draft.

## Final NAVs
| Class | BOD net assets (alloc base) | Alloc % | Class net assets 18 Sep | Shares | NAV 4dp | Published | System draft |
|---|---|---|---|---|---|---|---|
| A | 118,126,152.53 | 31.752991 | 117,687,765.21 | 6,412,337.218 | 18.3533 | **18.35** | 18.3581 / 18.36 |
| C | 34,114,262.48 | 9.170111 | 33,986,943.63 | 1,905,441.502 | 17.8368 | **17.84** | 17.8413 / 17.84 |
| I | 219,775,411.48 | 59.076898 | 218,961,503.55 | 11,873,205.664 | 18.4417 | **18.44** | 18.4383 / 18.44 |

Class net assets are BOD net assets, plus allocated income and gains, minus allocated fund expenses, minus class expenses, plus the ELA waiver. They are before 18 Sep trade-date capital activity (B.5). Rounding is half up. The published NAV is rounded from the unrounded value.

## 1. Allocation base (corrected)
- `class_allocation_draft_ADGF_20260918.csv` uses the basis `TD_SHARES_INCL_CURRENT`. Its bases equal the 17 Sep final net assets plus 18 Sep trade-date net activity:
  - A: -243,300.12
  - C: -53,440.50
  - I: +27,295,443.20, which includes the 27.0m Linwood onboarding.
- This breaches Plan §3 and B.4. Current-day trades must not participate in the day's income and expenses.
- The 17 Sep final (`nav_report_ADGF_20260917_final.csv`) already reflects trade-date 17 Sep activity. Its net assets divided by its shares equal the 17 Sep NAV exactly, and the 17 Sep TA shares tie at the published NAVs. So the BOD base is the 17 Sep final net assets: 372,015,826.49 in total.
- I re-allocated each line of income, gains and fund expenses (`income_and_gains…csv` net -1,368,332.82; fund expenses 9,075.10) at the unrounded ratios. Each line is rounded to the cent, with the residual going to Class I (B.2).
- Fund-level net per class, corrected vs draft:
  - A: -437,368.24 vs -406,934.49
  - C: -126,309.83 vs -117,578.79
  - I: -813,729.85 vs -852,894.64
- The draft had shifted $39,164.79 of losses onto Class I.

## 2. Expense limitation worksheet (ELA §§1–4, B.3)
- **Accrual rates:** I re-performed every accrual in `expense_accruals…csv` on the BOD bases (for example, management fee 0.50% × 372,015,826.49 / 365 = 5,096.11). All of them agree.
- **Excluded Expenses (§2), 2,241.98 in total:**
  - GL 5125 Brightwater litigation: 1,643.84 (extraordinary/litigation)
  - GL 5160 LOC interest on the drawn amount: 598.14
  - The commitment fee (GL 5170, 117.81) stays in Operating Expenses.

| Class | Operating Expenses (alloc. fund op + class exp) | Daily limit (limit × BOD / 365) | Annualised | Waiver |
|---|---|---|---|---|
| A | 2,169.73 + 1,019.08 = 3,188.81 | 1.00% → 3,236.33 | 0.9853% | 0.00 |
| C | 626.60 + 1,074.64 = 1,701.24 | 1.75% → 1,635.62 | 1.8202% | **65.62** |
| I | 4,036.79 + 662.12 = 4,698.91 | 0.70% → 4,214.87 | 0.7804% | **484.04** |

- The total waiver is **549.66**. Each class waiver is smaller than its allocated management fee (C 467.32, I 3,010.62), so all of it is a fee waiver and none of it is a reimbursement.
- It should be booked at GL 5900/1390.
- These waivers can be recouped until **2029-09-30**. Please add them to the register as September MTD for C and I.

## 3. Aldermoor request: start Class A recoupment tonight (declined, referred to the Fund Treasurer)
Maren Holt's email of 13:22 asks us to start accruing Class A recoupment tonight, with Board ratification on 10 Dec. We cannot accrue it, for these reasons:
- **Approvals are missing.** ELA §5(b) requires Board approval first. §5 also says the Administrator shall not accrue any recoupment until it has written notice from the Fund Treasurer giving the class and maximum amount. B.6 bars NAV entries made on the Adviser's instruction alone. Ratification after the fact and the GC's consent do not meet either requirement.
- **There is no headroom anyway.**
  - The Class A register entries (2024-01 to 2024-04, 16,312.85 in total, first expiry 2027-01-31) were waived under a **0.90%** limit.
  - Recoupment is capped at the lesser of 0.90% and 1.00%. Today's cap is 0.90% × 118,126,152.53 / 365 = 2,912.70.
  - Class A Operating Expenses are 3,188.81 (0.9853%), which is above that cap.
  - So even with all approvals in place, headroom today is **$0**. Class A is not "comfortably below" the limit that applies.
- **Tonight's treatment:** recoupment accrued is $0. The Class A NAV includes no recoupment.

## 4. 18 Sep capital activity
All 18 Sep trade-date batches are PENDING NAV. The TA should price them at the final published NAVs (A **18.35**, not the draft 18.36; C 17.84; I 18.44). Nothing was priced at the draft, so no reprocessing is needed.

## Actions / what I need from whom
1. **Accounting:** override the allocation base to the BOD net assets above, and rerun the allocation.
2. **Accounting:** book the ELA waiver (C 65.62, I 484.04).
3. **Priya:** 4-eye review, then release to NASDAQ. It may go after 6:45.
4. **Fund Treasurer:** decide on the Class A recoupment request. Tell us whether the Board has approved any recoupment, and the maximum amount.
5. **Adviser (Maren Holt, cc Colm Radley):** tell them recoupment was not accrued, and why.
6. **TA:** price the 18 Sep activity at the final NAVs.
7. **NAV system support:** find the root cause of the `TD_SHARES_INCL_CURRENT` basis and fix it before the 21 Sep run.
8. **Trust counsel, through the Fund Treasurer:** confirm the Brightwater litigation estimate (600,000/365, dated 2026-09-01) is still current.

## Assumptions
- The 17 Sep final net assets include trade-date 17 Sep activity. The file's `capital_activity_through` field says this, and NAV × shares ties.
- Limits are those in effect from 2025-03-01.
- No waiver is needed for Class A.
