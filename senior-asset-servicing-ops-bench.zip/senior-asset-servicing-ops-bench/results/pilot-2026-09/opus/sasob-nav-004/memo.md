# AGEF — NAV 18 Sep 2026: class NAVs and independent hedge monitoring

To: Henrik Aalto | Re: AGEF 18/09 class NAVs incl. EUR hedged

## Headline
- NAVs are ready to publish at 11:30: **I-USD-Acc USD 149.85 | A-USD-Acc USD 145.26 | I-EUR-H-Acc EUR 120.49**
- **Action needed today:** our independent check shows the EUR hedged class is **over-hedged at 107.91%**, above the 105% limit. Brackenridge's report showed 100.70% ("no action"), but it was based on the 17 Sep NAV and **did not include the 18 Sep dealing**. The RTA dealing file for 18 Sep reached them only on 21 Sep at 08:05 (INC-7730), and that day included EUR 4.5m of redemptions.
- Under procedure s.4, the breach does not hold the NAV. Brackenridge must be notified and ManCo Risk escalated **the same day**.

## Inputs relied on
accounting/nav_final_AGEF_20260917.csv, accounting/pnl_and_expenses_AGEF_20260918.csv, accounting/class_expense_accruals_AGEF_20260918.csv, fx/fx_forwards_AGEF_20260917_20260918.csv, fx/fx_settlement_report_20260918.csv, fx/wmr_rates_20260917_20260918.csv, fx/hedging_agent_daily_report_20260918.txt, registrar/dealing_summary_AGEF_DD20260918.csv, prospectus extract (5.4, 5.5, 8.2, 8.3), AAM hedging procedure v2.1.

## 1. Allocation base (Prospectus 8.2)
The base is the class net assets from the final 17 Sep NAV, after DD 17 Sep dealing. Total is USD 410,952,578.79.

| Class | Net assets 17/09 (USD) | Allocation % |
|---|---|---|
| I-USD-Acc | 212,688,904.12 | 51.7551% |
| A-USD-Acc | 118,420,556.40 | 28.8161% |
| I-EUR-H-Acc | 79,843,118.27 | 19.4288% |

## 2. Hedge results
**Class hedges (I-EUR-H-Acc only, Prospectus 5.5).** The realised result on the matured forward is shown net of the unrealised MTM already booked in the 17 Sep NAV.

| Contract | Calculation | USD |
|---|---|---|
| FWD-H-0817 (matured/rolled) | realised 244,800.00 − reversal of 17/09 MTM 61,200.00 (= 34m × (1.17840 − 1.17300)) | 183,600.00 |
| FWD-H-0901 | 124,200.00 − (−41,400.00) | 165,600.00 |
| FWD-H-0918 (new roll) | 10,200.00 − 0 | 10,200.00 |
| FX-S-0918-01 (spot near leg at WMR) | nil | 0.00 |
| **Total** | | **359,400.00** |

Adding the realised amount to the current MTMs without reversing the prior MTM gives 379,200. That would double count USD 61,200.

**Portfolio hedge.** FWD-P-0818 (tag PORTFOLIO, buy USD / sell JPY 2.5bn): 61,687.39 − (−31,006.78) = **USD 92,694.17**.
- This amount is not in the signed-off sub-fund P&L extract.
- It is allocated to all classes pro rata: I-USD 47,973.96, A-USD 26,710.86, I-EUR-H 18,009.36.
- None of it goes to the hedged class alone.

## 3. Class-specific expenses
I re-performed every accrual as prior-day class net assets × rate / 365. All agree to the accruals file:

| Class | Management fee | Taxe d'abonnement | Hedging agent fee (0.03%) | Total |
|---|---|---|---|---|
| I-USD-Acc | 4,370.32 (0.75%) | 58.27 (0.01%) | – | −4,428.59 |
| A-USD-Acc | 4,866.60 (1.50%) | 162.22 (0.05%) | – | −5,028.82 |
| I-EUR-H-Acc | 1,640.61 (0.75%) | 21.87 (0.01%) | 65.62 | −1,728.10 |

The sub-fund level fees also agree: depositary 225.18, admin 450.36, audit 180.82, directors/other 132.88.

## 4. Class NAVs
The non-class-specific pool is USD −2,012,227.89. It is the sub-fund P&L of −2,104,922.06 plus the portfolio hedge of +92,694.17.

| | I-USD-Acc | A-USD-Acc | I-EUR-H-Acc |
|---|---|---|---|
| Opening NA (USD) | 212,688,904.12 | 118,420,556.40 | 79,843,118.27 |
| Allocated pool | −1,041,430.49 | −579,845.85 | −390,951.55 |
| Class expenses | −4,428.59 | −5,028.82 | −1,728.10 |
| Class hedge result | – | – | +359,400.00 |
| **NA 18/09 pre-dealing (USD)** | **211,643,045.04** | **117,835,681.73** | **79,809,838.62** |
| NA in class currency | 211,643,045.04 | 117,835,681.73 | EUR 67,727,290.07 (÷ WMR 1.17840) |
| Shares | 1,412,337.5520 | 811,204.9913 | 562,118.4400 |
| NAV/share (4dp) | 149.8530 | 145.2601 | 120.4858 |
| **Published (2dp)** | **149.85** | **145.26** | **EUR 120.49** |

## 5. Independent hedge monitoring (procedure s.2 and s.3)
- **Open notional:** EUR 68,500,000. This is FWD-H-0901 at 34.5m plus FWD-H-0918 at 34.0m. The matured FWD-H-0817 is excluded.
- **Post-dealing class NAV:** 67,727,290.07 + 250,000.00 subscriptions − 4,500,000.00 redemptions = **EUR 63,477,290.07**.
- **Hedge ratio:** 68,500,000 / 63,477,290.07 = **107.91%**. The tolerance is 95–105%, so this is a **BREACH (over-hedged)**.
- **Adjustment to reach 100%:** reduce notional by **EUR 5,022,709.93**.
- Brackenridge's 100.70% is 68.5m ÷ 68,021,058.33. That divisor is the 17 Sep NAV with no dealing adjustments, because none had been received by their 13:05 run.

## 6. Actions for you
1. **Publish** the NAVs above at 11:30. The breach does not delay the NAV, and the hedge contracts are valued as they stand.
2. **Notify Brackenridge today.** Send the post-dealing NAV of EUR 63,477,290.07, the ratio of 107.91% and the required reduction of EUR 5,022,709.93. We do not book or cancel hedge trades ourselves. We record only trades the counterparty confirms.
3. **Escalate to ManCo Risk today.** This is a Prospectus 5.4 breach, and its root cause is RTA incident INC-7730. Risk should also make sure the over-hedge is not carried forward.
4. **Accounting entries.** Book the class hedge result of +359,400.00 to I-EUR-H-Acc only. Book the portfolio forward result of +92,694.17 as a sub-fund item for all classes.
5. **Ask the TA/RTA** for an explanation of INC-7730 and the control fix.

## Assumptions and open points
- The 17 Sep final NAV already reflects DD 17 Sep dealing (its dealing_through field says so), and I used it as the allocation base.
- Forward MTMs are taken as provided in the forwards extract. I re-performed them from notional × (valuation rate − contract rate), and they agree.
- The signed-off sub-fund P&L excludes all FX forwards. That is why the portfolio forward was added separately.
- **Still open:**
  - Brackenridge needs to confirm the execution of the notional reduction.
  - ManCo Risk needs to decide on breach-register treatment.
  - Were other hedged classes affected by INC-7730?
