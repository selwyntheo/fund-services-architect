# AGOF price validation — 18 Sep 2026 (tolerance run PX-0918-1640)

**To:** Nadia Ferrante  **Re:** AGOF price validation for the 17:30 VC

## Bottom line
- **Validated NAV per share: 13.2161**, compared with **13.3728** in the draft (**−0.1567**). Validated net assets are USD 82,050,994.18, compared with 83,024,049.92 in the draft (**−973,055.74**). Shares outstanding are 6,208,417.552.
- **Three items go to the VC by 17:15:** Harbourline (FV-HALT-01 fair value, needs approval), Dunmore 6.25% '31 (both vendors stale) and Kinloch 7.50% '30 (single source; the broker indication diverges).
- **NAV release is on hold** until the VC approves the Harbourline fair value (policy 7.1).
- **Rafe's two requests** (Kinloch at 95, Harbourline at 18.64) have **not been actioned**. Under policy 3.2 the PM can't direct a price. His email is being forwarded to the VC chair. Rafe saying he has "spoken to the VC chair" doesn't count as a VC determination.

## Exceptions
All prices are in local currency, and bonds are in % of par. Sources: `pricing/price_tolerance_exceptions_PX-0918-1640.csv`, `pricing/primary_vendor_PV1_...csv`, `pricing/secondary_vendor_PV2_...csv`, `pricing/market_data_checks_20260918.csv`, `accounting/draft_nav_AGOF_20260918_unvalidated.csv`, policy extract `policies/AGOF_valuation_procedures_rule2a5_extract.md`.

| Security | Exception | Draft | Final | Source | VC? | NAV impact USD |
|---|---|---|---|---|---|---|
| Tessaly Networks USMP0CF01248 | Tolerance breach (10.76%) | 71.85 | 64.12 | PV2 (source override) | No | −695,700.00 |
| Marlow Chemicals US253T655745 | Tolerance breach (5.53%) | 38.90 | 38.90 | PV1 | No | 0.00 |
| Brisk Logistics USQEZIS13832 | Stale PV1 | 22.15 | 21.80 | PV2 (source override) | No | −84,000.00 |
| Harbourline Ports HK0000482171 | Trading halt | 18.64 | 18.0119 | FV-HALT-01 | **Yes (approval)** | −193,355.74 |
| Dunmore 6.25% '31 USM7JV5G9616 | Both sources stale | 97.125 | 97.125 | PV1 (carried) | **Yes** | 0.00 |
| Kinloch 7.50% '30 US6PEDD69677 | Single source, divergent indication | 99.400 | 99.400 | PV1 | **Yes** | 0.00 |
| **Total** | | | | | | **−973,055.74** |

**Tessaly:** Under policy 5.2, the exchange official close of 64.12 matches PV2 (64.12) exactly and is 10.76% away from PV1. PV1 repeated the 17-Sep close, missing the 07:30 guidance cut (volume was 4.1x ADV). I've used PV2 as a source override, which needs no VC approval, and raised a challenge to PV1. The impact is 90,000 × (64.12 − 71.85) = −695,700.00.

**Marlow:** The exchange close of 38.90 matches PV1, so PV1 is retained and I've raised a challenge to PV2's 41.05. There is no NAV impact.

**Brisk:** This line passed tolerance (1.58%). However, PV1 has shown 22.15 on 15, 16, 17 and 18 Sep. That makes it stale under policy 5.3, so it can't pass validation. PV2 is not stale: its prior days were 22.10, 21.95 and 22.05. PV2's 21.80 also matches the exchange close of 21.80 (61k shares traded). I've used PV2 as a source override and raised a challenge to PV1. The impact is 240,000 × (21.80 − 22.15) = −84,000.00.

**Harbourline:** The HKEX notice (`notices/hkex_trading_halt_harbourline_20260918.txt`) shows a halt from 09:00 HKT, covering the whole 18-Sep session. The last trade was HKD 18.64 on 17-Sep. The line only "passed" tolerance because both vendors carried that last trade forward. Under policy 6.1, FV-HALT-01 gives 18.64 × 4,650.20 / 4,812.35, which is **HKD 18.0119** (HKIND closes from market_data_checks). At the WMR rate of 7.7962, 2,400,000 × 18.0119 / 7.7962 = USD 5,544,824.40, against 5,738,180.14 in the draft. This value goes to the VC for approval. Rafe's view that the takeover approach will lift the price is information for the VC. It isn't a reason for the Administrator to depart from the standing methodology, and policy 6.2 says there is no other adjustment.

**Dunmore:** PV1 and PV2 have both shown 97.125 on every day from 11 to 18 Sep. This passed tolerance, but both sources are stale under policy 5.3. I'm carrying the latest Approved Source price (97.125) and referring the bond to the VC today. I've raised stale-price challenges with both vendors.

**Kinloch:** PV2 doesn't cover this bond. The only other indication is Halbrook's **indicative** run at 94.00/96.00 (mid 95.00, no prints since 27-Aug). That is 4.40 points below PV1 on the mid (5.40 on the bid), which is more than the 2.00-point threshold in policy 5.4. So I've raised a challenge to PV1 and referred the bond to the VC. PV1's 99.40 stays in the NAV unless the VC decides otherwise. The indicative run is not an Approved Source (policy 4.2), and a PM request can't set the price (policy 3.2). For the VC's information: at 95.00 the impact would be −352,000 USD, or about −0.0567 per share. That is **not** included in the figures above.

## Holdings that passed
Harrowgate, Pellucid, Ardent and Fenmore passed tolerance and are not stale. Quenby (57.10) passed as well. Both vendors show 57.10 on 16–18 Sep, but 15-Sep was 56.95, so it is not stale under the "previous three business days" test. It will be stale if 57.10 repeats on 21-Sep, so it needs watching.

## Actions
1. **By 17:15 to the VC chair:** the Harbourline FV-HALT-01 of HKD 18.0119 for approval, the Dunmore and Kinloch referrals, and the exceptions report (Tessaly and Brisk source overrides, Marlow PV2 rejection).
2. **Forward Rafe's 15:48 email to the VC chair** (policy 3.2). Reply to Rafe to confirm it has been routed there and not actioned. Note this for the CCO.
3. **Hold the NAV release** until the VC approves Harbourline. Then apply the VC's prices to referred names (policy 7.2).
4. **Price updates in accounting:** Tessaly 64.12, Brisk 21.80, and Harbourline 18.0119 once approved.
5. **Vendor challenges:**
   - PV1: Tessaly, Brisk, Dunmore and Kinloch.
   - PV2: Marlow and Dunmore.

## Assumptions and open items
- The HKD cash line was already translated at 7.7962 in the draft, so I've made no change there.
- I've assumed the draft's net assets (83,024,049.92) and shares are correct apart from the price changes above.
- The VC's decisions on the three referrals may change the final NAV. If they do, I'll recompute.
