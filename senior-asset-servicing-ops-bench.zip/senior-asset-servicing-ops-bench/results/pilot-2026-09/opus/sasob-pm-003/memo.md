# GAOF II – Second Closing 30 Sep 2026: Equalization

**To:** Priya Sethi | **Re:** Tom Brandt's request (17 Sep) | **Basis:** Fund II LPA §3.4, §3.3, §8.1 (not the Fund I method)

## 1. Bottom line
- **Admitted on 30 Sep:** LP-0206 Tamsin Bay (USD 50mm) and LP-0207 Ostrander County FF (USD 35mm).
- **Not admitted:** LP-0208 Sable Point (USD 40mm). It moves to the third closing (15 Dec). **The platform register still shows it in the second-close batch**, so we have left it out of every figure.
- **Total commitments after closing:** USD 340,000,000. **Funded % after closing:** 15.4125% for every Partner.
- **Tom's Fund I method doesn't follow the Fund II LPA on three points** (see §4). All numbers below follow the LPA.

## 2. Sources
- `inputs/lpa/GAOF_II_LPA_excerpt_closings_fees.md`: §3.4(a)–(g), §3.3, §8.1 (Halcyon's operational excerpt; the executed LPA governs)
- `inputs/investor_records/partner_register_GAOF_II_20260917.csv`: commitments, fee status
- `inputs/investor_records/second_closing_checklist_20260917.csv`: closing readiness
- `inputs/investor_records/side_letter_terms_summary_GAOF_II.csv`: SL-OF2-004 (1.75% fee; request to waive the Additional Amount was declined), SL-OF2-003 MFN
- `inputs/capital_activity/capital_activity_GAOF_II_20260917.csv`: calls 1–3 (CA-00001..45)
- `inputs/correspondence/2026-09-16_blackwood_second_close_update.txt`, `2026-09-17_brandt_equalization_first_cut.txt`

## 3. Workings
**Non-fee contributions before closing** (investments plus partnership expenses; management fees excluded per §3.4(a)):

| Call | Due date | Amount (USD) | % of 255mm | Days to 30 Sep (excl.) |
|---|---|---|---|---|
| 1 | 2026-02-17 | 1,020,000.00 | 0.40% | 225 |
| 2 | 2026-04-01 | 30,855,000.00 | 12.10% | 182 |
| 3 | 2026-07-01 | 20,527,500.00 | 8.05% | 91 |
| **Total** | | **52,402,500.00** | 20.55% | |

**Equalization contribution (§3.4(a)):** Commitment % after closing × each call, rounded per call. 52,402,500 / 340,000,000 = 15.4125% of commitment.
- LP-0206 (14.7059%): 150,000.00 + 4,537,500.00 + 3,018,750.00 = **7,706,250.00**
- LP-0207 (10.2941%): 105,000.00 + 3,176,250.00 + 2,113,125.00 = **5,394,375.00**

**Management fee catch-up (§3.4(c), §8.1):** covers 2 Feb to 30 Sep, the end of the quarter the closing falls in. The first period is 58 days (2 Feb–31 Mar), charged at annual fee × 58/365. Q2 and Q3 are each annual fee / 4.
- LP-0206 at the **1.75%** side-letter rate (annual fee 875,000): 139,041.10 + 218,750.00 + 218,750.00 = **576,541.10**
- LP-0207 at 2.00% (annual fee 700,000): 111,232.88 + 175,000.00 + 175,000.00 = **461,232.88**
- Q4 is called separately on 1 Oct (Blackwood), which is consistent with the LPA.

**Additional Amount (§3.4(d)):** 8% simple interest, actual/365, on each call's equalization share. It runs from the due date (inclusive) to 30 Sep (exclusive), rounded per call.
- LP-0206: 7,397.26 + 181,002.74 + 60,209.59 = **248,609.59**
- LP-0207: 5,178.08 + 126,701.92 + 42,146.71 = **174,026.71**
- The GP declined Tamsin Bay's waiver request, and a waiver needs LPAC consent under §3.4(g). The full amount therefore applies.

### What each incoming LP wires on 30 Sep
| LP | Equalization | Mgmt fee | Additional Amount | **Wire** | Unfunded after |
|---|---|---|---|---|---|
| LP-0206 Tamsin Bay | 7,706,250.00 | 576,541.10 | 248,609.59 | **8,531,400.69** | 41,717,208.90 |
| LP-0207 Ostrander | 5,394,375.00 | 461,232.88 | 174,026.71 | **6,029,634.59** | 29,144,392.12 |
| **Total** | 13,100,625.00 | 1,037,773.98 | 422,636.30 | **14,561,035.28** | |

The Manager receives the fees (1,037,773.98). The Additional Amount does not reduce unfunded commitment.

### What each Existing Partner receives
Both pots are shared pro rata to commitment over USD 255mm (§3.4(b), (e)). The rounding residual goes to the GP and is nil here. Returned capital is added back to unfunded commitment and can be recalled. Unfunded after = commitment − all contributions including fees + capital returned.

| Partner | Capital returned | Additional Amount | **Total received** | Unfunded after |
|---|---|---|---|---|
| GP-0200 | 256,875.00 | 8,286.99 | **265,161.99** | 4,229,375.00 |
| LP-0201 | 3,853,125.00 | 124,304.79 | **3,977,429.79** | 62,452,268.84 |
| LP-0202 | 3,082,500.00 | 99,443.84 | **3,181,943.84** | 49,961,815.07 |
| LP-0203 | 2,568,750.00 | 82,869.86 | **2,651,619.86** | 41,634,845.89 |
| LP-0204 | 2,055,000.00 | 66,295.89 | **2,121,295.89** | 33,307,876.71 |
| LP-0205 | 1,284,375.00 | 41,434.93 | **1,325,809.93** | 20,817,422.95 |
| **Total** | 13,100,625.00 | 422,636.30 | **13,523,261.30** | |

Check: 14,561,035.28 received = 13,523,261.30 paid to Existing Partners + 1,037,773.98 paid to the Manager.

### Commitment percentages after closing (USD 340mm, GP included)
GP-0200 1.4706% · LP-0201 22.0588% · LP-0202 17.6471% · LP-0203 14.7059% · LP-0204 11.7647% · LP-0205 7.3529% · LP-0206 14.7059% · LP-0207 10.2941% (sum 100.0000%)

## 4. How Tom's Fund I method differs, and how we should respond
1. **Base % (20.55%).** Fund I charged each new LP the same % of commitment that existing LPs have paid. §3.4(a) sets the base as the post-closing Commitment % × aggregate non-fee contributions, which is 15.4125%. Under Fund I, the new LPs would over-pay (Tamsin 10,275,000 vs 7,706,250; Ostrander 7,192,500 vs 5,394,375). Partners would also end up funded unequally, which §3.4(b) prohibits.
2. **Interest base and start date.** Fund I charged interest on everything paid in, fees included, starting from the notice dates. §3.4(d) charges interest only on the non-fee equalization share, starting from each **due date**.
3. **Treatment of the interest.** Fund I booked it as fund other income that runs through the waterfall. §3.4(e) says the Additional Amount is not partnership income, stays outside Article 9, and is paid straight through to Existing Partners pro rata to commitment.

Suggested reply to Tom: we will issue the LPA-based figures above and cite §3.4(a)–(f). If the GP wants the Fund I approach, it would need an LPA amendment or legal sign-off. We can't apply it under the agreement as drafted.

## 5. Issues with the closing population and other flags
- **Sable Point (LP-0208):** the checklist shows UBO certification still open, the side letter in draft and the GP not yet signed. The register still reads "SECOND 2026-09-30 / SUBSCRIPTION RECEIVED". If Sable Point were left in, total commitments would be 380mm and every figure would be wrong. At Owen's request we have not changed the record, and we need his change form. 15 Dec is before the 2 Feb 2027 final-closing deadline. Sable Point will need its own equalization at the third closing.
- **Harrowgate (LP-0205)** paid call 2 late (6 Apr against a 1 Apr due date). Any default interest falls under §3.8, which §3.3 keeps separate from §3.4. It has no effect on these numbers.
- **MFN:** LP-0201's MFN (SL-OF2-003) covers terms given to investors with equal or smaller commitments. Tamsin Bay (50mm) gets 1.75%. The side-letter summary marks this term as not MFN-electable because it is size-based (≥50mm), but LP-0201 (75mm) also meets that threshold. The GP should confirm the position. This does not affect the closing numbers.

## 6. Assumptions
- Figures use the capital activity as at 17 Sep. I assumed no further calls before 30 Sep; if there are any, the numbers need to be re-run.
- I assumed the Existing Partners are paid on 30 Sep, once the incoming wires arrive.
- Rounding is to the nearest cent for each partner and each call (§3.4(f)).
- I relied on Halcyon's excerpt of the LPA. The executed LPA governs.

## 7. Needed from whom
- **Tom Brandt (GP controller):** written agreement to the LPA-based method before the closing notices go out, and the GP's position on LP-0201's MFN.
- **Owen Blackwood (GP IR):** the change form moving LP-0208 to the third closing, and confirmation that Sable Point gets no 30 Sep notice or wire instructions.
