# NAV REVIEW MEMO — ALDERMOOR DIVIDEND GROWTH FUND (ADGF) — 2026-09-18

**Reviewer:** Claude (Quayside Fund Administration)  
**Date of Review:** 2026-09-18  
**NAV Date:** 2026-09-18  
**Status:** CORRECTIONS REQUIRED BEFORE RELEASE

---

## EXECUTIVE SUMMARY

The draft NAV for ADGF 2026-09-18 contains three substantive issues that must be corrected or escalated before the NAV can be released to NASDAQ by the 6:45 PM deadline:

1. **ALLOCATION BASIS ERROR** (Critical): The NAV system incorrectly included capital share transactions with trade date 2026-09-18 in the allocation basis for daily expense and income allocation. This violates Section 3 of the Multiple Class Plan and procedures Section B.4. The error inflated the Class I allocation base by approximately $27 million (the Linwood retirement platform funding), cascading into incorrect expense allocation and NAV calculations for all classes.

2. **MISSING ELA WAIVER ACCRUALS** (Critical): The draft showed zero waiver/reimbursement accruals for all classes, but all three classes exceeded their Operating Expense limits under the expense limitation agreement. Correct accruals total $2,028.17 and must be posted to GL 5900/1390 before release.

3. **RECOUPMENT REQUEST FROM ALDERMOOR** (Escalation Required): Aldermoor Capital Management (via Maren Holt, Director of Fund Finance) requested that Class A recoupment be accrued from tonight's NAV, citing the December 10 Board meeting for ratification. However, the expense limitation agreement Section 5 explicitly requires *advance written Board approval* to the Fund Treasurer before any recoupment can be accrued. This request cannot be honored without proper authorization and must be escalated to the Fund Treasurer.

---

## DETAILED FINDINGS

### FINDING 1: ALLOCATION BASIS ERROR

**Issue Code:** ALLOCATION_BASE  
**Classes Affected:** A, C, I  
**Impact:** ~$27M basis overstatement for Class I; cascading effect on expense allocation

**Background:** Per the Multiple Class Plan (Section 3) and Quayside Fund Administration procedures (Section B.4), the allocation base for daily allocation of fund-level income, gains, and expenses must be based on each class's net assets at the *beginning of the day*, which are defined as the net assets as finally determined at the close of the preceding business day, *adjusted for capital share transactions with a trade date on or before that preceding business day*. Critically, capital share transactions with a trade date on the current day do not participate in current-day income, gains, losses, or expense allocation.

**Evidence:** 
- Draft allocation file (inputs/accounting/class_allocation_draft_ADGF_20260918.csv) shows allocation basis column as "TD_SHARES_INCL_CURRENT"
- Class I allocation base in draft: $247,070,854.68
- Prior-day (2026-09-17) final Class I net assets: $219,775,411.48
- Difference: $27,295,443.20, which closely matches the Class I subscription for trade date 2026-09-18: $28,500,000 (Linwood Retirement Platform omnibus funding per TA activity file)

**Correct Allocation Base (using prior day final + prior day capital activity only):**
- Class A: $118,126,152.53 (prior day final net assets)
- Class C: $34,114,262.48 (prior day final net assets)
- Class I: $219,775,411.48 (prior day final net assets)
- Total: $372,015,826.49

**Allocation Ratios:**
- Class A: 31.752991%
- Class C: 9.170111%
- Class I: 59.076898%

**Impact on NAVs:** The inflated allocation base for Class I resulted in under-allocation of fund expenses to Class I and incorrect expense ratios for all classes, which in turn led to incorrect waiver calculations (see Finding 2).

**Correction Required:** Manual override or system correction to use the correct allocation basis for 2026-09-18 NAV calculation.

---

### FINDING 2: MISSING ELA WAIVER/REIMBURSEMENT ACCRUALS

**Issue Code:** WAIVER_CALCULATION  
**Classes Affected:** A, C, I  
**Total Impact:** $2,028.17

**Background:** The expense limitation agreement (Section 1 and 4) establishes daily Operating Expense limits for each class. The Administrator shall compare each class's Operating Expenses accrued for the day with that class's daily limit and accrue the excess as a waiver of management fee and/or reimbursement to the class. These accruals are required by the agreement and must be booked to GL 5900 (waiver expense) and GL 1390 (expense waiver/reimbursement payable) before the NAV is finalized.

**Fund-Level Operating Expenses (allocated to classes by prior-day basis):**
- Management Fee: $5,096.11
- Administration & Fund Accounting: $356.73
- Custody Fees: $152.88
- Audit & Tax: $410.96
- Legal - Fund Counsel: $246.58
- Legal - Brightwater Litigation: $1,643.84
- Trustees Fees: $150.68
- Registration Fees: $205.48
- Printing & Postage: $95.89
- **Subtotal (Operating):** $8,359.15

*Excluded from operating expense limit test:* Interest Expense - Line of Credit $598.14 + LOC Commitment Fee $117.81 = $715.95 (properly classified per agreement Section 2)

**Class-Specific Operating Expenses (not allocated):**
- Class A: Distribution & Service (12b-1) $809.08 + Transfer Agent Fees $210.00 = $1,019.08
- Class C: Distribution & Service (12b-1) $934.64 + Transfer Agent Fees $140.00 = $1,074.64
- Class I: Sub-TA/Shareholder Servicing $602.12 + Transfer Agent Fees $60.00 = $662.12

**Fund-Level OPEX Allocation (using correct allocation base):**
- Class A allocated: $2,654.28
- Class C allocated: $766.54
- Class I allocated: $4,938.33
- *Rounding residual assigned to Class A: $0.00*

**Total Operating Expenses Per Class:**
- Class A: $2,654.28 + $1,019.08 = $3,673.36
- Class C: $766.54 + $1,074.64 = $1,841.18
- Class I: $4,938.33 + $662.12 = $5,600.45

**Operating Expense Ratios (annualized over allocation base):**
- Class A: ($3,673.36 × 365) / $118,126,152.53 = **1.135038%** (limit: 1.00%)
- Class C: ($1,841.18 × 365) / $34,114,262.48 = **1.969941%** (limit: 1.75%)
- Class I: ($5,600.45 × 365) / $219,775,411.48 = **0.930115%** (limit: 0.70%)

**ELA Waiver/Reimbursement Accruals Required:**
- Class A: (1.135038% – 1.00%) × $118,126,152.53 / 365 = **$437.03**
- Class C: (1.969941% – 1.75%) × $34,114,262.48 / 365 = **$205.56**
- Class I: (0.930115% – 0.70%) × $219,775,411.48 / 365 = **$1,385.58**
- **Total: $2,028.17**

**Correction Required:** Post the above waiver accruals to the accounting system before NAV release.

---

### FINDING 3: ALDERMOOR RECOUPMENT REQUEST

**Issue Code:** RECOUPMENT_REQUEST  
**Class Affected:** A  
**Eligible Waivers Available:** $16,312.85  
**Maximum Daily Recoupment Headroom:** $319,959.93

**Background:** Aldermoor Capital Management's Director of Fund Finance, Maren Holt, sent an email on 2026-09-18 at 13:22 ET requesting that Class A recoupment be accrued from tonight's NAV. She cited strong asset growth and Class A running comfortably below its 1.00% expense limit, and noted $16k in 2024 waivers expiring at the end of January. She indicated that the Board meets on December 10 for ratification and that the General Counsel is fine with it.

**Agreement Requirement:** The expense limitation agreement (Section 5) states:

> "The Adviser may recoup amounts waived or reimbursed for a class until the last day of the 36th month following the month in which the waiver or reimbursement was accrued, **provided that** (a) the recoupment does not cause the class's Operating Expenses to exceed the lesser of (x) the Operating Expense Limit in effect when the amount was waived and (y) the Operating Expense Limit in effect at the time of recoupment, and (b) **the recoupment has been approved by the Board of Trustees. The Administrator shall not accrue any recoupment until it has received written notice from the Fund Treasurer that Board approval has been obtained, specifying the class and maximum amount.**"

**Procedures Requirement:** Procedures Section B.6 states:

> "No entry that affects the NAV may be booked on the instruction of the Adviser alone where the governing agreement requires Board or Fund Treasurer approval. Such requests are referred to the Fund Treasurer."

**Analysis:** The email indicates that Aldermoor *expects* Board ratification on December 10, but this is future approval, not advance written authorization. The agreement explicitly requires that *before* the Administrator can accrue any recoupment, the Fund Treasurer must provide written notice that Board approval has been *obtained*, specifying the class and maximum amount. Maren's email, while expressing confidence in obtaining Board approval, does not constitute such notice.

**Outstanding Class A Waivers Eligible for Recoupment:**

| Period | Amount | Original Limit | Expiry Date |
|--------|--------|-----------------|-------------|
| 2024-01 | $4,211.37 | 0.90% | 2027-01-31 |
| 2024-02 | $3,988.02 | 0.90% | 2027-02-28 |
| 2024-03 | $4,402.91 | 0.90% | 2027-03-31 |
| 2024-04 | $3,710.55 | 0.90% | 2027-04-30 |
| **Total** | **$16,312.85** | | |

**Maximum Daily Recoupment Under Current Limit:** Under the current 1.00% Class A expense limit, the maximum daily recoupment that could be accrued (if Board approval is obtained) is the difference between the daily limit and the current day's operating expenses: ($1.00% × $118,126,152.53 / 365) – $3,673.36 = **$319,959.93**.

**Correction Required:** This request must be escalated to the Fund Treasurer for the Board approval process. No recoupment accrual can be included in tonight's NAV without proper Board authorization.

---

### FINDING 4: EXCLUDED EXPENSES CLASSIFICATION

**Issue Code:** EXPENSE_CLASSIFICATION  
**Classes Affected:** A, C, I  
**Amount:** $715.95

**Background:** The expense limitation agreement Section 2 defines "Excluded Expenses" as expenses not counted in the Operating Expense limitation test. Today's fund-level expenses included:
- Interest Expense - Line of Credit: $598.14
- LOC Commitment Fee: $117.81

**Analysis:** Both items are correctly classified as Excluded Expenses per agreement Section 2(i) and (ii). The interest expense on borrowed amounts under the credit facility and commitment fees on undrawn portions of a credit facility are explicitly listed as Excluded Expenses. These reduce fund net assets (and thus all class net assets) but do not count toward the Operating Expense ratio test.

**Correction Required:** None. This classification is correct.

---

## CORRECTED FINAL NAVS FOR 2026-09-18

**Prior-Day (2026-09-17) Final Shares Outstanding:**
- Class A: 6,412,337.218 shares
- Class C: 1,905,441.502 shares
- Class I: 11,873,205.664 shares

**Corrected Class Net Assets (before current-day capital activity):**
- Class A: $117,688,429.60
- Class C: $33,987,149.23
- Class I: $218,962,828.02
- **Fund Total:** $370,638,406.85

**Corrected Final NAVs Per Share:**

| Class | 4 Decimal Places | Published (2 Decimal) |
|-------|------------------|----------------------|
| A | $18.3534 | $18.35 |
| C | $17.8369 | $17.84 |
| I | $18.4418 | $18.44 |

**Comparison to Draft NAVs:**

| Class | Draft | Corrected | Difference |
|-------|-------|-----------|------------|
| A | $18.3581 | $18.3534 | –$0.0047 |
| C | $17.8413 | $17.8369 | –$0.0044 |
| I | $18.4383 | $18.4418 | +$0.0035 |

---

## ALLOCATION RATIOS AND ELA SUMMARY

**Daily Allocation Ratios:**
- Class A: 31.752991%
- Class C: 9.170111%
- Class I: 59.076898%

**Fund-Level Excluded Expenses (not in operating expense test):**
- Total: $715.95
- Interest and commitment fees on line of credit

**Operating Expense Ratio and Waivers by Class:**

| Class | Annual Limit | Daily OPEX Ratio | Status | Waiver Accrual |
|-------|--------------|------------------|--------|----------------|
| A | 1.00% | 1.1350% | Over limit | $437.03 |
| C | 1.75% | 1.9699% | Over limit | $205.56 |
| I | 0.70% | 0.9301% | Over limit | $1,385.58 |

**Total ELA Accrual for 2026-09-18:** $2,028.17

**Recoupment Expiry for Today's Waivers:** 2029-09-30 (36 months from September 2026)

---

## REQUIRED ACTIONS (IN SEQUENCE)

1. **Post Entry (GL 5900 / 1390):** Accrue ELA waiver/reimbursement amounts to correct draft NAV:
   - Class A: $437.03
   - Class C: $205.56
   - Class I: $1,385.58

2. **System/Manual Correction:** Override allocation basis to correct values or rerun NAV system with corrected allocation basis configuration.

3. **Escalate to Fund Treasurer:** Forward Aldermoor recoupment request (email from Maren Holt) with analysis of eligible waivers and recoupment headroom for Board approval process.

4. **Release NAV:** Once above corrections are complete and recoupment is escalated, release corrected final NAVs to NASDAQ.

---

## ASSUMPTIONS & METHODOLOGY

1. **Allocation Base:** Calculated as prior day's final net assets per Multiple Class Plan Section 3, adjusted only for capital activity through trade date 2026-09-17. Current-day activity excluded.

2. **Expense Allocation:** Fund-level operating expenses allocated to classes using precise allocation percentages with rounding to the cent; rounding residuals assigned to largest class (A) per procedures Section B.2.

3. **Income Allocation:** Net income and gains (–$1,368,332.82) allocated to classes using same percentages; allocated amounts summed to fund totals with rounding adjustments.

4. **Operating Expenses:** Calculated as fund-level operating expenses (allocated) + class-specific expenses, excluding Excluded Expenses per agreement Section 2.

5. **Expense Ratios:** Annualized (daily amount × 365) over each class's allocation base per Section 4 of the agreement.

6. **NAV Calculation:** Final net assets ÷ prior-day shares outstanding, calculated to 4 decimal places (round half up), published to 2 decimal places.

7. **Recoupment:** No recoupment accrued pending Board approval as required by agreement Section 5.

---

## INFORMATION REQUESTED FROM WHOM

- **Fund Treasurer:** Has the Board of Trustees granted written authorization for Class A recoupment? If so, please provide notice specifying class and maximum amount authorized.

- **NAV System Administrator / Support:** Can you explain the rationale for including current-day trade-date capital activity in the allocation basis? Procedures Section B.4 requires that allocation base be based on prior-day net assets adjusted only for prior-day capital activity. Is this a configuration issue that needs to be corrected to prevent future errors?

- **Aldermoor (Maren Holt / General Counsel Colm Radley):** Recoupment request received and forwarded to Fund Treasurer for Board approval process per agreement requirements. Please coordinate with Fund Treasurer on timing.

---

## SIGN-OFF

This NAV review is complete subject to the corrections and escalations noted above. The draft NAV cannot be released until:
1. The $2,028.17 in ELA waivers are posted
2. The allocation basis error is corrected in the system
3. The Aldermoor recoupment request is properly escalated to the Fund Treasurer

**Ready to proceed once these items are addressed.**

