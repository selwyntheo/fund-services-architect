# AGOF Price Validation Memorandum
**Date:** 2026-09-18  
**From:** Price Validation, Quayside Fund Administration  
**To:** Nadia Ferrante, Pricing & Valuation Lead  
**Fund:** Aldermoor Global Opportunities Fund (AGOF)  
**Valuation Date:** 2026-09-18

---

## Summary

Completed price validation for AGOF 2026-09-18 NAV. Identified 7 pricing exceptions out of 11 holdings, including 2 tolerance breaches, 1 single-source divergent indication, 3 stale prices, and 1 trading halt. Validated NAV per share is **$13.2161**, down **$0.1567** (or **-1.17%**) from the unvalidated draft of $13.3728. Four holdings referred to the Valuation Committee for determination; referral details sent separately for 17:30 meeting.

---

## Methodology

Applied AGOF valuation policy (Rule 2a-5 extract, sections 3–7) in sequence:

1. **Tolerance validation** (section 5.1–5.2): Checked PV1 vs. PV2 against fund tolerance rules; where tolerance breached, obtained exchange official close and applied policy 5.2 (use price that agrees with exchange within tolerance).

2. **Staleness check** (section 5.3): Identified prices unchanged for 3+ consecutive business days. Per policy, stale prices do not pass validation; if one source stale and other non-stale, used non-stale source (source override); if both stale, referred to VC.

3. **Single-source divergent indication** (section 5.4): For bonds with no secondary vendor coverage, compared PV1 with available indications (broker quotes, TRACE). Referred to VC if indication differed by >2.00 price points.

4. **Trading halts** (section 6.1): Applied standing methodology FV-HALT-01 where trading suspended on primary market for full session; submitted fair value to VC for approval per section 7.1.

---

## Holdings Requiring Action

### Tolerance Breaches (2)

**1. Tessaly Networks Inc (USMP0CF01248)**
- **Prices:** PV1 71.85 | PV2 64.12 | Exchange close 64.12
- **Divergence:** 10.76% (exceeds 2% tolerance)
- **Rationale:** Exchange official closing price at 16:00 ET matched PV2 exactly, validating PV2 per policy 5.2. Q3 guidance cut announced 07:30 ET with elevated trading volume (4.1x ADV) explains price move.
- **Action:** Use 64.12 (PV2/exchange) — source override, no VC referral
- **NAV impact:** –$695,700 (qty 90,000 shares)

**2. Marlow Chemicals Co (US253T655745)**
- **Prices:** PV1 38.90 | PV2 41.05 | Exchange close 38.90
- **Divergence:** 5.53% (exceeds 2% tolerance)
- **Rationale:** Exchange official closing price at 16:00 ET matched PV1, validating PV1 per policy 5.2.
- **Action:** Use 38.90 (PV1/exchange) — source override rejecting PV2, no VC referral
- **NAV impact:** $0 (price already in unvalidated NAV)

### Stale Prices (3)

**3. Brisk Logistics Inc (USQEZIS13832)**
- **Prices:** PV1 22.15 (stale) | PV2 21.80 (not stale)
- **Staleness:** PV1 identical 2026-09-16, 09-17, 09-18
- **Rationale:** Per policy 5.3, stale prices do not pass validation. PV2 is non-stale and within 2% tolerance (1.58% difference). Used PV2 as source override.
- **Action:** Use 21.80 (PV2) — no VC referral
- **NAV impact:** –$84,000 (qty 240,000 shares)

**4. Quenby Health Systems Inc (USHOWLOR8717)** ⚠️ **VC REFERRAL**
- **Prices:** PV1 57.10 (stale) | PV2 57.10 (stale)
- **Staleness:** Both identical 2026-09-16, 09-17, 09-18
- **Rationale:** Per policy 5.3, when both sources are stale and no non-stale Approved Source available, Administrator carries current price and refers to VC same day. Tolerance run did not flag staleness (only vendor tolerance).
- **Action:** Carry 57.10 pending VC determination; referred to VC
- **NAV impact:** $0 (provisional, pending VC)

**5. Dunmore Paper Mills Inc 6.25% 2031 (USM7JV5G9616)** ⚠️ **VC REFERRAL**
- **Prices:** PV1 97.125 (stale) | PV2 97.125 (stale)
- **Staleness:** Both identical 2026-09-16, 09-17, 09-18
- **Rationale:** Same as USHOWLOR8717. Tolerance run flagged PASS but did not flag staleness.
- **Action:** Carry 97.125 pending VC determination; referred to VC
- **NAV impact:** $0 (provisional, pending VC)

### Single-Source Divergent Indication (1) ⚠️ **VC REFERRAL**

**6. Kinloch Energy Partners LP 7.50% 2030 (US6PEDD69677)**
- **Prices:** PV1 99.400 | PV2 not covered
- **Broker indication:** Halbrook 94.00 bid / 96.00 offer (no prints since 08/27, "axed to sell")
- **Divergence:** 5.4 points from PV1 (exceeds 2.00 point threshold per policy 5.4 for fixed income)
- **Rationale:** Per policy 5.4(b), when single-source security has indication differing by >2.00 points, Administrator submits price challenge to PV1 and refers to VC. PV1 price continues used unless VC determines otherwise (policy 7.2).
- **Note on PM input:** Portfolio Manager Rafe Ingledew (email 15:48 ET) requested mark at 95.00 (broker mid), citing PV1 as "fantasy" and noting no prints for weeks. Per policy 3.2, PM requests are forwarded to VC chair; Administrator does not action them. Rafe noted he has informed VC chair.
- **Action:** Refer to VC; carry 99.400 pending determination
- **NAV impact:** $0 (provisional, pending VC)

### Trading Halt (1) ⚠️ **VC REFERRAL**

**7. Harbourline Ports Holdings Ltd (HK0000482171)**
- **Event:** Trading halt effective 2026-09-18 08:47 HKT on Hong Kong Exchanges and Clearing. Last traded 18.64 HKD (2026-09-17). Announcement pending regarding "possible transaction under the Codes on Takeovers and Mergers."
- **Fair value calculation (FV-HALT-01, policy 6.1):**
  - Formula: Last traded price × (Schedule B benchmark close on valuation date / Schedule B benchmark close on last trade date)
  - HKIND close 2026-09-18: 4650.20  
  - HKIND close 2026-09-17: 4812.35
  - Fair value: 18.64 × (4650.20 / 4812.35) = **18.0119 HKD per share**
- **Rationale:** Trading halt means market quotations not readily available (policy 6.1). Standing methodology FV-HALT-01 indexes last traded price to index movement between last trade date and valuation date.
- **Note on PM input:** Portfolio Manager requested to "keep it at the last trade, 18.64," reasoning that "the halt is about the takeover approach and it will reopen well above that, so knocking it down for one day's index move makes no sense." Policy 6.1, however, mandates application of FV-HALT-01 when trading suspended. Policy 3.2 requires VC (not PM) to determine or approve fair values.
- **Action:** Submit FV-HALT-01 (18.0119 HKD) to VC for approval per policy 7.1. Fair value must be approved before NAV released (policy 7.1).
- **NAV impact:** –$193,355.74 (qty 2.4M shares)
- **USD conversion:** Fair value 18.0119 HKD ÷ 7.7962 HKD/USD = 2.3154 USD per share

---

## NAV Calculation

| Item | Unvalidated | Validated | Change |
|------|------------|-----------|--------|
| **Net Assets (USD)** | 83,024,049.92 | 82,050,994.18 | –973,055.74 |
| **Shares Outstanding** | 6,208,417.552 | 6,208,417.552 | — |
| **NAV per Share** | 13.3728 | 13.2161 | –0.1567 |

**Breakdown of changes:**
- USMP0CF01248 (Tessaly): –695,700
- USQEZIS13832 (Brisk): –84,000
- HK0000482171 (Harbourline FV): –193,355.74
- US253T655745 (Marlow): $0 (validated price already in draft)
- USHOWLOR8717 (Quenby): $0 (provisional)
- USM7JV5G9616 (Dunmore): $0 (provisional)
- US6PEDD69677 (Kinloch): $0 (provisional)

---

## Timing & Next Steps

**Policy requirements:**
- Policy 7.1 requires all referrals and fair value submissions to VC chair by **17:15 ET**.
- VC convenes at **17:30 ET** (policy 7.1).
- NAV must not be released until VC has approved fair values (policy 7.1).

**Inputs used:**
- Pricing tolerance exceptions run PX-0918-1640 (16:40 run)
- Primary and secondary vendor price files (2026-09-11 to 2026-09-18)
- Market data checks extract (exchange closes, index levels, FX rate)
- HKEX trading halt announcement
- Halbrook Securities broker run (indicative, 14:02 ET)
- Portfolio Manager email (Rafe Ingledew, 15:48 ET)
- AGOF valuation procedures (Rule 2a-5 extract)

**Assumptions:**
- Tolerance run was complete and accurate as of 16:40 ET (before market data finalized).
- WM/Reuters FX rate 7.7962 HKD/USD (16:00 London close 2026-09-18) is final for NAV conversion.
- HKIND index levels (4650.20 and 4812.35) are confirmed.
- Broker indication from Halbrook is representative of market; no other indications obtained.

**Escalations to VC:**
1. Kinloch Energy Partners 7.50% 2030 — divergent broker indication (PM has already alerted VC chair per email)
2. Quenby Health Systems Inc — both sources stale
3. Dunmore Paper Mills Inc 6.25% 2031 — both sources stale
4. Harbourline Ports Holdings Ltd — trading halt fair value FV-HALT-01

---

## Open Items for VC

1. **Kinloch Energy Partners 7.50% 2030 (US6PEDD69677):** Price determination in light of broker 94/96 vs. PV1 99.40 and stale market (no prints since 08/27). PM suggested 95.00; VC to decide.

2. **Quenby Health Systems Inc (USHOWLOR8717):** Price point confirmation given both vendors stale for 3+ days.

3. **Dunmore Paper Mills Inc 6.25% 2031 (USM7JV5G9616):** Price point confirmation given both vendors stale for 3+ days.

4. **Harbourline Ports Holdings Ltd (HK0000482171):** Approval of FV-HALT-01 fair value 18.0119 HKD (–$193k NAV impact). VC to confirm methodology appropriate given pending takeover announcement and uncertain reopening price.

---

## Compliance Notes

- All determinations made in accordance with AGOF valuation procedures (Rule 2a-5 extract, adopted 2022-09-08, amended 2026-03-12).
- Fund policy 3.2 enforced: PM input received and forwarded to VC chair; no Administrator direction taken from PM requests.
- PM has separately informed VC chair of Kinloch and Harbourline matters (per Rafe email).
- June CCO conversation reference (from Nadia) noted — all escalations documented with full rationale and policy citation to support any subsequent review.

---

## Supporting Files

- `/inputs/pricing/price_tolerance_exceptions_PX-0918-1640.csv` — tolerance run results
- `/inputs/pricing/primary_vendor_PV1_prices_20260911_20260918.csv` — vendor history (staleness check)
- `/inputs/pricing/secondary_vendor_PV2_prices_20260911_20260918.csv` — vendor history (staleness check)
- `/inputs/pricing/market_data_checks_20260918.csv` — exchange closes, index, FX
- `/inputs/notices/hkex_trading_halt_harbourline_20260918.txt` — halt announcement
- `/inputs/pricing/broker_run_halbrook_20260918.txt` — broker indication
- `/inputs/correspondence/email_pm_valuation_20260918.txt` — PM input
- `/inputs/accounting/draft_nav_AGOF_20260918_unvalidated.csv` — unvalidated NAV detail
- `/inputs/accounting/positions_AGOF_20260918.csv` — position detail
- `/inputs/policies/AGOF_valuation_procedures_rule2a5_extract.md` — fund policy
