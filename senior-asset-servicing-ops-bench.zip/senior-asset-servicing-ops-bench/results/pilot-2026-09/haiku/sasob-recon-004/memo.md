# TSIF Accrued Interest Reconciliation — NAV 2026-09-17

**To:** Delphine Okoro, Income & Accruals Team Lead, Pellmore Fund Services  
**From:** Reconciliation analysis  
**Date:** 2026-09-18  
**Subject:** GL 1300 vs Northgate accrued income report — full investigation

---

## Summary

The USD 62.99 difference between our GL 1300 accrued interest (1,605,265.25) and Northgate's accrued income report (1,605,202.26) is **fully explained** by five position-level differences totaling USD 22,290.09 that net to the reported break. The break is not de minimis noise or a minor timing issue — it reflects real accounting and custodian setup errors that must be corrected.

**Three are our errors** (totaling USD 11,176.54): Offering terms mismatch on US Treasury day-count convention, missing Corbin FRN rate reset, and incorrect TIPS inflation index ratio.

**Two are Northgate errors** (totaling USD 11,113.55): Gantry day-count convention misapplication and Pellar continuing to accrue after non-accrual.

**Required correction to GL 1300: −USD 10,962.99** (our three errors). After correction, our GL 1300 will run USD 10,900 lower than Northgate's reported total, which represents their unresolved errors on Gantry and Pellar.

**NAV impact: immaterial.** Error is −0.0002 per share (0.0017% of NAV). Released NAV for 2026-09-17 stands; no restatement needed.

---

## Position-by-Position Findings

### **Finding 1: US29DKMU3994 — US Treasury Note 3.875% 15Aug2031**

**The problem:** Accounting applied ACT/360 day-count; offering terms require ACT/ACT.

| Measure | Value |
|---------|-------|
| GL 1300 accrued | USD 91,493.06 (wrong) |
| Northgate accrued | USD 89,504.08 (correct) |
| Correct amount | USD 89,504.08 |
| Required adjustment | −USD 1,988.98 |

**Analysis:**  
The offering terms state: "Accrued interest: actual/actual (ICMA), i.e. actual days elapsed in the current coupon period / actual days in the coupon period x semi-annual coupon."

Our GL 1300 shows accrual as: 25M × 3.875% × 34/360 = 91,493.06 (ACT/360)  
Northgate calculated: 25M × 3.875% × 34/184 = 89,504.08 (ACT/ACT)

The coupon period (15-Aug to 15-Feb) is 184 days. Accrual from 15-Aug to 18-Sep is 34 days. Correct accrual is 484,375 × 34/184 = 89,504.08.

**Responsibility:** Accounting error. Likely security master day-count setup or calculation error in the accrual system.

---

### **Finding 2: US72IBAI2618 — Gantry Industrial Corp 5.40% 15Dec2032**

**The problem:** Northgate applied ACT/360 day-count; offering terms require 30/360.

| Measure | Value |
|---------|-------|
| GL 1300 accrued | USD 251,100.00 (correct) |
| Northgate accrued | USD 256,500.00 (wrong) |
| Correct amount | USD 251,100.00 |
| Required adjustment | None to our records |

**Analysis:**  
Offering terms and security master both specify 30/360. The coupon period (15-Jun to 15-Dec) is 180 days under 30/360. Accrual from 15-Jun to 18-Sep is 93 days.

Our GL 1300: 486,000 × 93/180 = 251,100.00 (correct)  
Northgate: 18M × 5.40% × 95/360 = 256,500.00 (ACT/360 applied incorrectly)

**Responsibility:** Northgate error. Must request Northgate Client Service to correct their accrued income calculation.

---

### **Finding 3: USRLI7T61226 — Corbin Bancorp FRN 15Aug2028 (3M SOFR + 95 bps)**

**The problem:** Accounting failed to apply the rate reset effective 2026-08-17.

| Measure | Value |
|---------|-------|
| GL 1300 accrued | USD 90,456.89 (wrong — old rate) |
| Northgate accrued | USD 81,269.33 (correct — new rate) |
| Correct amount | USD 81,269.33 |
| Required adjustment | −USD 9,187.56 |

**Analysis:**  
Linden Street Bank (Calculation Agent) issued Notice of Interest Rate on 2026-08-13 for the new interest period commencing 2026-08-17:
- Previous period (to 2026-08-17): 4.1382% SOFR + 0.95% margin = 5.0882%
- New period (from 2026-08-17): 3.6214% SOFR + 0.95% margin = **4.5714%**

The accrual period (2026-08-17 to 2026-09-18, 32 days) falls entirely within the new interest period and should accrue at 4.5714%.

Our GL 1300: 20M × 5.0882% × 32/360 = 90,456.89 (old rate, wrong)  
Northgate: 20M × 4.5714% × 32/360 = 81,269.33 (new rate, correct)  
Correct: same as Northgate.

**Responsibility:** Accounting error. Security master shows next_reset = 2026-08-17 but the rate was not updated to 4.5714% on the reset feed. Check whether reset feed processed the rate notice; Reference Data should update security master rate and trigger accrual recalculation.

---

### **Finding 4: USFTZ79R4065 — US Treasury Inflation-Indexed Note 1.625% 15Jul2034 (TIPS)**

**The problem:** Accounting calculated inflation index ratio at 1.05595 instead of correct 1.06091.

| Measure | Value |
|---------|-------|
| GL 1300 accrued | USD 45,462.52 (wrong index ratio) |
| Northgate accrued | USD 45,676.07 (correct index ratio) |
| Correct amount | USD 45,676.07 |
| Required adjustment | +USD 213.55 |

**Analysis:**  
Offering terms specify the Reference CPI index ratio calculation:

> Index Ratio for a given date = Ref CPI for that date / Ref CPI base, rounded to five decimals.
> Ref CPI for a date in month M = CPI-U NSA for month M-3 + [(d − 1) / (number of days in month M)] × (CPI-U NSA for month M-2 − CPI-U NSA for month M-3), where d is the calendar day of the date.

For accrual end date 2026-09-18:
- Use CPI-U for Jul-2026 (M-3): 332.305
- Use CPI-U for Aug-2026 (M-2): 332.690
- Interpolate for Sep-18: 332.305 + (18-1)/30 × (332.690 − 332.305) = 332.113
- **Index Ratio = 332.113 / 313.04548 = 1.06091** (rounded to 5 decimals)

Real coupon accrual (unadjusted): 15M × 1.625%/2 × 65/184 = 43,031.07  
Correct adjusted accrual: 43,031.07 × 1.06091 = 45,676.07

Accounting shows: 45,462.52 (implies index ratio 1.05595), which is incorrect.

**Responsibility:** Accounting error. CPI feed or index ratio calculation in accrual system may have processing error. Check reference data and confirm CPI interpolation formula is applied correctly.

---

### **Finding 5: US6FJH2Q7244 — Pellar Commercial Finance Corp 8.25% 01Mar2030**

**The problem:** Northgate continued accruing interest after the security was placed on non-accrual status.

| Measure | Value |
|---------|-------|
| GL 1300 (accrued + past-due) | USD 265,375.00 (correct) |
| Northgate report (accrued + claims) | USD 270,875.00 (wrong) |
| Correct amount | USD 265,375.00 |
| Required adjustment | None to our records |

**Analysis:**  
Valuation Committee meeting 2026-09-14 (special):
- Coupon payment due 2026-09-01 was not received.
- Issuer announced restructuring discussions; grace period expires 2026-10-01.
- Committee determined: "collection of interest on the notes is not reasonably assured."
- **Resolution: Non-accrual status effective 2026-09-14.**

Policy section 5.4 states: "On placement, all accrued interest and any past-due interest receivable on the security are reversed against interest income, and no further interest is accrued."

Correct GL 1300 treatment:
- Unpaid coupon (past-due interest receivable): USD 247,500.00
- Accrued interest from coupon date (2026-09-01) to non-accrual date (2026-09-14): 6M × 8.25% × 13 days / 180 = USD 17,875.00
- **Total GL 1300: USD 265,375.00**

Accounting records (from GL 1300 detail): 17,875.00 + 247,500.00 = USD 265,375.00 ✓ Correct  
Northgate report: 23,375.00 (accruing through 2026-09-18, 17 days) + 247,500.00 = USD 270,875.00 ✗ Wrong

Northgate calculation error: 6M × 8.25% × 17/180 = 23,375.00 (17 days from Sep-01 to Sep-18). Northgate did not respect the non-accrual status.

**Responsibility:** Northgate error (and/or custodian did not receive income team's non-accrual notice). Income team updated our GL 1300 correctly; custodian continued accruing. Request Northgate Client Service to reflect non-accrual status and correct accrual amount to 17,875.00.

---

## Accounting Entry Required

**Date:** 2026-09-18 (or ASAP for NAV 2026-09-17 correction)

```
Debit:  Interest Income                      10,962.99
  Credit: GL 1300 - Accrued Interest Receivable         10,962.99
```

**Narrative:** Correction for accrual calculation errors: (1) US Treasury ACT/ACT day-count per offering terms; (2) Corbin FRN floating-rate reset effective 2026-08-17; (3) TIPS inflation index ratio per CPI interpolation method.

**Post to segments:**
- US29DKMU3994: −1,988.98
- USRLI7T61226: −9,187.56
- USFTZ79R4065: +213.55

---

## Corrected GL 1300 and Remaining Reconciliation

| Amount | Value |
|--------|-------|
| **Accounting GL 1300 (as reported)** | 1,605,265.25 |
| **Less: Accounting adjustments** | (10,962.99) |
| **Corrected GL 1300** | **1,594,302.26** |
| **Northgate report total** | 1,605,202.26 |
| **Remaining difference** | **(10,900.00)** |

The remaining USD 10,900.00 difference represents Northgate's unresolved errors:
- Gantry (F002): Northgate overstates by +5,400.00
- Pellar (F005): Northgate overstates by +5,500.00
- **Total Northgate overstatement: +10,900.00**

This must be reported to Northgate Client Service as their responsibility to correct.

---

## NAV Impact

**2026-09-17 NAV status:** FINAL (already released)

| Metric | Value |
|--------|-------|
| Reported net assets | 648,333,292.16 |
| Reported shares outstanding | 63,118,402.227 |
| Reported NAV per share | 10.2717 |
| Correction to GL 1300 | (10,962.99) |
| **Corrected net assets** | 648,322,329.17 |
| **Corrected NAV per share** | 10.2715 |
| **NAV error per share** | (0.0002) |
| **% error vs NAV** | 0.0017% |

**Materiality test per policy 6.2:**
- Criterion 1: Error ≥ USD 0.01 per share? **No** (error is 0.0002)
- Criterion 2: Error ≥ 0.50% of NAV? **No** (error is 0.0017%)

**Conclusion:** Error is **NOT MATERIAL**. Per policy 6.3, the error is corrected in the next NAV struck (2026-09-18 or later). Prior NAV is not restated, and shareholder transactions executed at the 2026-09-17 NAV are not reprocessed. Fund Treasurer will be notified today.

---

## Actions Required

1. **Immediate (same day if possible):**
   - Post adjusting journal entry (−10,962.99 GL 1300)
   - Notify Fund Treasurer (error is immaterial; NAV stands)
   - Log for quarterly Board report

2. **This week:**
   - Submit correction request to Northgate Client Service for Gantry (F002) and Pellar (F005) — detailed findings attached
   - Request Northgate confirm receipt and timeline for correction

3. **Following week:**
   - Reference Data: investigate Corbin FRN rate reset feed (F003) and TIPS CPI interpolation (F004)
   - Update security master rates and index ratios if errors are confirmed in source data
   - Confirm income team received non-accrual notice for Pellar (F005); reconcile any communications gaps

4. **De minimis write-off:** Not applicable. The 62.99 break is fully explained; no unexplained residual remains.

---

## Questions / Information Needed

1. **Corbin FRN (USRLI7T61226) rate reset:** Was the rate update from 5.0882% to 4.5714% processed by the reset feed on or after the Linden Street Bank notice date (2026-08-13)? When was security master last updated with the new rate? Confirm reset is now live for future accruals.

2. **TIPS CPI interpolation (USFTZ79R4065):** Is the CPI feed applying the offering terms formula (truncate to 6dp, round to 5dp) correctly? Accounting shows 1.05595 vs correct 1.06091 — this suggests a systematic error, not a one-time mistake.

3. **Pellar income team notification (US6FJH2Q7244):** Confirm income team received the Valuation Committee non-accrual notice on 2026-09-14. Did they update GL 1300 on the same day? Northgate did not receive notice; request timestamp of communication to Northgate Client Service.

---

## Summary for Supervisor Approval

**Recommendation:** Approve the −10,962.99 adjustment to GL 1300. Do NOT apply de minimis write-off rule. The break is fully explained by specific, correctable errors: three accounting setup/calculation errors (day-count, rate reset, index ratio) and two custodian errors (day-count, non-accrual status). Each is traceable to source documents (offering terms, rate notices, valuation committee minutes, CPI data, policies). Northgate errors are operational — likely system setup or manual calculation — and should be reported for their correction. No material impact to released NAV.

