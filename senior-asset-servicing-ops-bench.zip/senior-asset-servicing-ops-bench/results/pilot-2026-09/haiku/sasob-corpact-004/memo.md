# MERIDALE TRUST & CUSTODY — VOLUNTARY EVENTS MEMO

**TO:** Anya Brandt, Voluntary Events Lead  
**FROM:** Analysis and Reconciliation  
**DATE:** October 7, 2026  
**RE:** Halvard Industrial Corp Modified Dutch Auction — Final Results and Account Outcomes  
**PERIOD:** Offer Expiration Oct 2, 2026, 5:00 PM ET; Stonemere Final Notice Oct 7, 2026

---

## EXECUTIVE SUMMARY

Stonemere Shareholder Services released final results for the Halvard tender offer this afternoon:
- **Purchase Price:** USD 32.50 per share
- **Final Proration Factor:** 0.748212
- **Total Accepted:** 4,780,000 shares (approximately)

Meridale holds four accounts that tendered:

| Account | Client | Tendered | Accepted | Returned | Proceeds |
|---------|--------|----------|----------|----------|----------|
| 4410-2201 | Ashgrove | 100,000 | 44,892 | 55,108 | $1,459,002.00 |
| 4410-2204 | Ashgrove | 85 | 63 | 22 | $2,047.50 |
| 4410-3104 | Fenwick | 120,000 | 89,785 | 30,215 | $2,918,012.50 |
| 4410-5024 | Lumenfield | 50,000 | 0 | 50,000 | $0.00 |
| | **TOTAL** | **270,085** | **134,740** | **135,345** | **$4,379,062.00** |

**Two client issues requiring immediate action:**
1. **Ashgrove (odd lot):** Client insists 85-share account 4410-2204 qualifies for full purchase without proration. It does not.
2. **Fenwick (withdrawal):** Client says withdrawal was submitted before cutoff; shares should not have been accepted. Meridale received it timely but did not transmit to depositary.

---

## DETAILED FINDINGS BY ACCOUNT

### Account 4410-2201 — Ashgrove Pension Trust, Global Equity Sleeve

**Tender Timeline:**
- Sept 22: Tender 100,000 @ 31.00 (TL-01)
- Sept 30: Withdraw 100,000 (TL-02) + re-tender 60,000 @ 31.00 (TL-03) + re-tender 40,000 @ 33.00 (TL-04)

**At Expiration (Oct 2, 5 PM):** 100,000 shares in effect (60k @ 31 + 40k @ 33)

**Analysis:**
- Purchase price set at 32.50
- 60,000 shares @ 31.00 are **at or below** purchase price → subject to proration
- 40,000 shares @ 33.00 are **above** purchase price → returned without acceptance per offer terms

**Result:**
- Shares subject to proration: 60,000
- Shares accepted: 60,000 × 0.748212 = 44,892.72 → **44,892 shares** (rounded down)
- Shares returned: (60,000 - 44,892) + 40,000 = **55,108 shares**
- Proceeds: 44,892 × 32.50 = **$1,459,002.00**

**VOI Allocation:**
- VOI 26093004 (60k @ 31.00): 44,892 accepted, 15,108 returned, $1,459,002.00
- VOI 26093005 (40k @ 33.00): 0 accepted, 40,000 returned, $0.00

**Status:** Settlement Friday, Oct 9. Scheduled auto-credit on Oct 8 for $1,421,550 using preliminary factor must be held and recalculated ($1,459,002 new amount, delta +$37,452).

---

### Account 4410-2204 — Ashgrove Pension Trust, US Small Cap Sleeve (ODD LOT ISSUE)

**Tender:** Sept 28, 85 shares @ AT_PURCHASE_PRICE with client request for odd-lot priority

**Client Position (email Oct 5):** "That's clearly an odd lot. Please confirm that all 85 will be bought and not prorated like the Global Equity sleeve."

**Tender Log Status:** "Client narrative requested odd-lot priority; odd-lot box not completed at checker review" — Odd-lot certification NOT transmitted on MT565

**Policy Framework (Meridale 8.1):**
"Meridale completes an odd-lot certification only if the beneficial owner's aggregate holding, across all Meridale accounts and as confirmed by the client, is below the offer's odd-lot threshold on both the date of tender and the expiration date. Separate accounts of the same beneficial owner are aggregated."

**Offer Terms (Halvard, Section 1):**
"'Odd Lot Holder' means a person who owns beneficially or of record an aggregate of fewer than 100 shares as of the close of business on the date of tender and on the Expiration Date, and so certifies... The priority is not available to partial tenders or to beneficial holders of 100 or more shares, even if those holders have separate accounts or certificates each representing fewer than 100 shares."

**Critical Finding:**
Ashgrove is the beneficial owner of BOTH accounts:
- 4410-2201: 100,000 shares tendered
- 4410-2204: 85 shares tendered
- **Aggregate: 100,085 shares — NOT < 100**

Even though account 4410-2204 individually holds 85 shares, Ashgrove's aggregate Halvard position exceeds the 100-share threshold. Therefore, **Ashgrove does not qualify as an "Odd Lot Holder"** per offer terms. The individual account size is irrelevant when the beneficial owner has multiple accounts.

**Result:**
- 85 shares treated as regular AT_PURCHASE_PRICE tender, subject to proration
- Shares accepted: 85 × 0.748212 = 63.5979 → **63 shares** (rounded down per Stonemere rule)
- Shares returned: **22 shares**
- Proceeds: 63 × 32.50 = **$2,047.50**

**Status:** Scheduled auto-credit of $2,762.50 (assuming odd-lot priority with factor 1.0) must be held and recalculated. Recalculated amount: $2,047.50 (delta -$715.00).

**Action Required:** Notify Marcus Leland / Ashgrove Investment Operations that:
1. Odd-lot priority was not available because Ashgrove's aggregate Halvard holding exceeds 100 shares
2. All 85 shares subject to standard proration per offer terms
3. 63 shares accepted, 22 returned, proceeds $2,047.50
4. Settlement Friday, Oct 9

---

### Account 4410-3104 — Fenwick County Retirement System, US Equity (WITHDRAWAL ISSUE)

**Tender Timeline:**
- Sept 24: Tender 120,000 @ 32.50 limit (TL-06)
- Oct 1, 4:40 PM ET: Email withdrawal instruction (TL-07)

**Withdrawal Status in Tender Log:** LATE_NOT_TRANSMITTED

**Background from Email (Grant Whitcomb, Oct 6, 5:21 PM):**
"Tomas Albright at Fenwick is very unhappy. He says they withdrew their Halvard tender at 4:40 pm on Oct 1st, which was before your 5 pm cut-off, and he has the sent email to prove it... I've told Tomas we'll make it right - just credit them whatever the difference is and we'll sort out the internals later. This is a top-10 relationship."

**Policy Framework:**
- **Meridale Service Terms 7.1:** Client Response Deadline for withdrawals is 5:00 PM ET on the business day before expiration (Oct 1, 5 PM).
- **Meridale Service Terms 7.2:** "Late instructions, including withdrawals, do not bind Meridale. Asset Servicing may transmit one on a best-efforts basis only with the written approval of the Head of Asset Servicing. Meridale has no liability for a late instruction that is not transmitted."

**Timeline of Events:**
- Oct 1, 4:40 PM ET: Fenwick withdrawal instruction arrives at Meridale (**timely to Meridale**)
- Oct 2, 8:50 AM ET: Referred to Head of Asset Servicing
- Oct 2, 9:40 AM ET: Best-efforts transmission **DECLINED**
- Oct 2, 9:55 AM ET: Client notified
- Oct 2, 5:00 PM ET: Offer expiration (withdrawal now too late for depositary)
- Oct 7: Stonemere releases final results; withdrawal was never received by them

**Analysis:**
The withdrawal was TIMELY to Meridale (4:40 PM, 20 min before 5 PM deadline). However, Meridale did NOT transmit it to Stonemere. Per service terms, this does not bind Meridale to any obligation. However, from the client's perspective, they made a good-faith withdrawal request before the Meridale deadline.

The tender instruction log notes the best-efforts transmission was **declined** at 09:40 AM on Oct 2. It is unclear whether:
- Written approval from Head of Asset Servicing was formally requested
- Whether declination was discretionary or policy-based
- Why the client was not contacted until 09:55 AM (too late for remediation)

**Result from Depositary Perspective:**
Since Stonemere never received the withdrawal, 120,000 shares remained tendered at depositary and were accepted subject to proration:
- Shares tendered @ 32.50 (at/below purchase price): 120,000
- Shares accepted: 120,000 × 0.748212 = 89,785.44 → **89,785 shares** (rounded down)
- Shares returned: **30,215 shares**
- Proceeds: 89,785 × 32.50 = **$2,918,012.50**

**Result from Client Perspective:**
Fenwick expected to retain their 120,000-share position (withdrawal request @ 4:40 PM = timely). They will receive 89,785 shares + $2.9M in proceeds. The RM (Grant) told them Meridale will "make it right" and compensate the difference.

**Policy Violation:**
Per Meridale Service Terms 9.1: "Compensation may be offered only through the Operational Incident process, with Head of Operations approval. Relationship managers and Asset Servicing staff may not promise or credit compensation."

Grant's email promise is NOT binding and violates policy. Any compensation requires formal incident review.

**Status:** 
- Scheduled auto-credit of $0 (shown as return in projection) must be recalculated
- Actual proceeds: $2,918,012.50 (delta +$2,918,012.50)
- Settlement Friday, Oct 9
- Escalation required: operational risk, Head of Asset Servicing, and CCO

---

### Account 4410-5024 — Lumenfield Endowment, US Equity (CONDITIONAL TENDER)

**Tender:** Sept 29, 50,000 @ AT_PURCHASE_PRICE with **conditional minimum 40,000 shares**

**Conditional Tender Framework (Halvard Offer, Section 6):**
"A shareholder may make its tender conditional on [the issuer] purchasing a specified minimum number of the shareholder's tendered shares. If, because of proration, that minimum would not be purchased, none of the shareholder's shares will be purchased (subject to random lot selection)."

**Stonemere Final Notice:**
"Conditional tenders: after proration, no conditional tenders were selected by random lot. Conditional tenders whose specified minimum is not met by applying the final proration factor are not accepted, and all shares covered by them are returned."

**Analysis:**
- 50,000 shares @ AT_PURCHASE_PRICE = tendered at minimum 30.00
- With proration factor 0.748212: 50,000 × 0.748212 = 37,410.6 → **37,410 shares would be accepted**
- Conditional minimum required: **40,000 shares**
- Condition met? **NO** (37,410 < 40,000)

Per offer terms, since the minimum is not met by proration, the entire tender is rejected.

**Result:**
- Shares accepted: **0 shares**
- Shares returned: **50,000 shares**
- Proceeds: **$0.00**

**Status:** Scheduled auto-credit of $1,184,625 (using preliminary factor 0.729) must be held and canceled. Settlement Friday, Oct 9; 50,000 shares returned to account.

---

## SCHEDULED AUTO-CREDITS — HOLD AND RECALCULATE

Engine projection file (PJ-HALV-01, run Oct 5) scheduled automatic credits for Oct 8, 06:00 AM using **preliminary proration factor 0.729**:

| Account | VOI | Scheduled | Basis | Recalculated | Delta |
|---------|-----|-----------|-------|--------------|-------|
| 4410-2201 | 26093004 | $1,421,550.00 | 60k × 0.729 | $1,459,002.00 | +$37,452.00 |
| 4410-2201 | 26093005 | $0.00 | 40k returned | $0.00 | — |
| 4410-2204 | 26092810 | $2,762.50 | Odd-lot (incorrect) | $2,047.50 | -$715.00 |
| 4410-3104 | 26092407 | $0.00 | Withdrawal assumed | $2,918,012.50 | +$2,918,012.50 |
| 4410-5024 | 26092915 | $1,184,625.00 | 50k × 0.729 | $0.00 | -$1,184,625.00 |
| | | **$4,426,187.50** | | **$4,379,062.00** | **-$47,125.50** |

Per Meridale Service Terms 8.3: "Proceeds of a tender offer subject to proration are credited when the depositary pays, not earlier. Any engine projection scheduled for automatic credit must be held and re-run on final terms."

**ACTION:** Hold all scheduled credits on Oct 8. Re-run projection with:
- Final proration factor 0.748212 (not preliminary 0.729)
- Correction: 4410-2204 no odd-lot priority (factor 0.748212, not 1.0)
- Correction: 4410-3104 withdrawal not transmitted (89,785 accepted, not 0)
- Correction: 4410-5024 condition unmet (0 accepted, not 36,450)

Post recalculated credits on/after Oct 9 depositary settlement.

---

## CLIENT CASH FORECAST — TOMORROW IMPACT

**What Anya needs to tell the cash forecast team:**

Settlement expected **Friday, Oct 9, 2026** per Stonemere notice.

**Inbound Credits (Proceeds):**
- Ashgrove (2201 + 2204): $1,461,049.50
- Fenwick (3104): $2,918,012.50
- Lumenfield (5024): $0.00
- **Total: $4,379,062.00**

**Custody Adjustments (Share Returns):**
- Ashgrove 2201: +55,108 shares (55,108 returned, 44,892 accepted)
- Ashgrove 2204: +22 shares (22 returned, 63 accepted)
- Fenwick 3104: +30,215 shares (30,215 returned, 89,785 accepted)
- Lumenfield 5024: +50,000 shares (50,000 returned, 0 accepted)
- **Total shares returned to clients: 135,345**

**Timing Notes:**
- Stonemere payment and return: Friday, Oct 9
- DTC processing: typically same day
- Meridale posting: should occur Friday or earliest Monday
- **This Friday is cutting it close for Anya's forecast sign-off "tomorrow."** If cutoff is Friday morning, actual settlement may post Monday.

---

## ACTIONS AND ESCALATIONS

### IMMEDIATE (Within 24 hours)

1. **HOLD the Oct 8 scheduled auto-credits** — Stop the engine from posting $4,426,187.50. Do not proceed until recalculation complete.

2. **ESCALATE Fenwick issue to Head of Asset Servicing, Operational Risk, and CCO:**
   - TL-07 withdrawal declined for best-efforts transmission (why?)
   - Was written Head of Asset Servicing approval sought and denied?
   - Grant's compensation promise violates policy 9.1
   - Need incident determination before any credit posted

3. **ESCALATE Grant's compensation commitment to requester (Anya) and CCO:**
   - Email dated Oct 6 explicitly promises: "just credit them whatever the difference is"
   - This violates policy and binds no one; RM cannot promise compensation
   - Must be resolved through formal operational incident process

### SHORT TERM (Before Friday settlement)

4. **NOTIFY Ashgrove** (via RM) of proration outcome:
   - 4410-2204: 85 tendered, 63 accepted, 22 returned
   - Reason: Ashgrove's aggregate Halvard position (100,085 across both accounts) exceeds 100-share odd-lot threshold
   - Proceeds: $2,047.50 (not $2,762.50)
   - Settlement: Friday, Oct 9

5. **NOTIFY Fenwick** (via RM) of settlement outcome:
   - 120,000 tendered, 89,785 accepted, 30,215 returned
   - Proceeds: $2,918,012.50
   - Settlement: Friday, Oct 9
   - DO NOT mention Grant's compensation promise; handle separately via incident process

6. **HOLD and RECALCULATE** the projected allocation:
   - New run should show correct allocations with final proration factor
   - Only release to posting after recalculation confirmed
   - Request depositary confirmation of VOI processing and return timing

### FOLLOW-UP (After settlement)

7. **POST tender proceeds** to client cash accounts on depositary settlement (Friday, Oct 9):
   - Ashgrove 2201 + 2204: $1,461,049.50
   - Fenwick 3104: $2,918,012.50
   - Lumenfield 5024: $0.00

8. **POST custody adjustments** (share returns) for the 135,345 shares returned

9. **CLOSE incident files** for Fenwick and compensation review

---

## OPEN QUESTIONS FOR INVESTIGATION

1. **Fenwick withdrawal TL-07:** Was the 09:40 AM decision to decline best-efforts transmission documented with written Head of Asset Servicing approval per policy 7.2? Why was client not contacted until 09:55 AM (too late for remediation)?

2. **Ashgrove MT565 amendment:** Did Meridale transmit any amended MT565 for 4410-2204 after Sept 28 to add odd-lot certification before Oct 2 expiration? (Tender log shows only one entry, TL-05.)

3. **Beneficial owner confirmation:** Were both Ashgrove accounts (2201 and 2204) confirmed at time of tender and expiration as being under the same beneficial owner per policy 8.1 requirement for aggregate odd-lot calculation?

4. **Projection logic:** Why did engine projection (PJ-HALV-01) assign odd_lot_priority=Y and factor 1.0 to account 2204 when tender log shows odd-lot box not completed and Ashgrove's aggregate exceeds 100?

5. **Depositary confirmation:** Did Stonemere provide any VOI-level confirmation of the allocation and proration, or only the aggregate notice? Need itemized processing confirmation for settlement.

6. **Return logistics:** What is the process and exact timing for the 135,345 returned shares to be released from DTC contraposition back to the four client accounts?

---

## SUMMARY FOR ANYA'S CLIENT CASH FORECAST

**For Tomorrow's Sign-Off:**

- **Inbound (Proceeds):** $4,379,062 (Stonemere payment Friday)
- **Custody Movements:** +135,345 shares returned (custody restored Friday)
- **Timing Risk:** If your cutoff is Friday morning, settlement may post Friday afternoon or Monday. Confirm with depositary.
- **Holds in Place:** Oct 8 auto-credit hold pending recalculation (will complete Friday).
- **Client Notifications:** Ashgrove and Fenwick outcomes being handled separately by RMs.
- **Policy Escalations:** Fenwick compensation and RM compliance issues elevated separately.

You are clear to forecast the transaction with confidence in these figures, but FYI the settlement is cutting close to your sign-off window.

---

*Analysis prepared from inputs: tender instruction log, custody positions, projected allocation, Stonemere final results notice, Meridale policy extract, offer terms extract, and client correspondence dated Oct 5–6.*

*For questions or additional information, contact [Vol Events Analysis].*
