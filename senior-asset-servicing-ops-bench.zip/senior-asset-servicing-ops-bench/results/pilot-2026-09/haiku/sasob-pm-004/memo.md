# MEMORANDUM

**TO:** Sam Adeyemi, Fund Controller, Halcyon Private Fund Services

**FROM:** Fund Administration Review

**DATE:** 2 October 2026

**RE:** Q4 2026 Management Fee Invoice — GAM-III-2026-04 — CANNOT APPROVE FOR PAYMENT

---

## SUMMARY

The Q4 2026 management fee invoice submitted by Granite Arch Management ($817,500) cannot be approved for payment on Monday 5 October. Our recomputation per the Limited Partnership Agreement (GACP III, amended and restated 14 August 2020) shows that the correct amount payable is only **$56,921.22**, after applying a prior-quarter adjustment. The invoice overstates the fee by **$760,578.78**.

The invoice contains three material errors in the Invested Capital calculation (missing $46.4M in required deductions) and fails to apply the management fee step-down that occurred mid-Q3 when the Investment Period ended on 14 August 2026.

---

## BACKGROUND & STRUCTURE

- **Fund:** Granite Arch Capital Partners III, L.P. (LEI 549300CRR40EVAFU1915)
- **Manager:** Granite Arch Management LP
- **Servicer:** Halcyon Private Fund Services (Halcyon)
- **Governing Document:** GACP III LPA, Amended and Restated 14 August 2020
- **Fee Control:** Schedule 4 of the Halcyon Services Agreement requires Halcyon to independently verify every management fee before payment; variance >$5K or >1% must be escalated.

**Fee Structure per LPA Section 8.1:**
- **During Investment Period:** 2.00% annual rate × Fee-Paying Commitments (quarterly in advance)
- **After Investment Period:** 1.50% annual rate × Invested Capital (attributable to Fee-Paying Partners, quarterly in advance)
- **Investment Period:** 14 August 2020 to 14 August 2025 (extendable one year by Advisory Committee consent)

**Actual Investment Period:** Extended to 14 August 2026 per Advisory Committee resolution, 12 June 2025 (LPAC Records).

---

## CRITICAL ERRORS IN THE INVOICE

### Error 1: Missing Wexford Marine Services Write-Off

**Transaction:** Investment written off as worthless 31 December 2025 following Chapter 7 liquidation order (20 November 2025).

**Acquisition Cost:** $16,000,000 (acquired 3 October 2022)

**LPA Requirement:** Section 8.1(b) and the definition of "Invested Capital" require reduction by "the acquisition cost of each Portfolio Investment... that has been... written off as worthless following the bankruptcy, liquidation or dissolution of the Portfolio Company."

**Invoice Treatment:** The invoice lists only Brindle Veterinary ($30M) and Tessaract Logistics ($60M) as "fully realized." Wexford is not deducted.

**Impact:** Invested Capital should be reduced by $16,000,000. **This is an error.**

---

### Error 2: Missing Orla Specialty Foods Partial Realization

**Transaction:** 40% stake sold 20 June 2023 to co-investor consortium for $30,000,000 in proceeds. Cost relief not yet posted in the investment cost ledger (per cost ledger notation IC-008).

**Acquisition Cost of Disposed Portion:** 40% × $36,000,000 = $14,400,000

**LPA Requirement:** "When only a portion [of a Portfolio Investment] is disposed of, the acquisition cost Realized is the cost attributable to that portion" (LPA definition of "Realized").

**Invoice Treatment:** The invoice does not deduct the Orla partial sale.

**Impact:** Invested Capital should be reduced by $14,400,000. **This is an error.**

---

### Error 3: Missing Pellucid Diagnostics Permanent Write-Down

**Transaction:** General Partner designated Permanent Write-Down of $16,000,000 effective 30 June 2026, following failure of the lead assay to obtain regulatory clearance. Approved by Advisory Committee per formal notice dated 22 July 2026.

**LPA Requirement:** The definition of "Invested Capital" specifies reduction by "the amount of each Permanent Write-Down" (LPA Section 8.1 and Article 1 definitions). "Permanent Write-Down" means "a write-down of the carrying value of a Portfolio Investment below its acquisition cost that the General Partner has designated as permanent by written notice to the Advisory Committee."

**Invoice Treatment:** The invoice does not deduct the Pellucid PWD.

**Impact:** Invested Capital should be reduced by $16,000,000. **This is an error.**

---

## CORRECT INVESTED CAPITAL CALCULATION

| Line Item | Amount |
|-----------|--------|
| Aggregate acquisition cost (through 30 Sep 2026, incl. follow-ons) | $308,000,000 |
| Less: Brindle Veterinary (full sale, 18 Mar 2025) | ($30,000,000) |
| Less: Tessaract Logistics (full sale, 15 Sep 2026) | ($60,000,000) |
| Less: Wexford Marine Services (write-off, 31 Dec 2025) | ($16,000,000) |
| Less: Orla Specialty Foods (40% sale, 20 Jun 2023) | ($14,400,000) |
| Less: Pellucid Diagnostics (PWD eff. 30 Jun 2026) | ($16,000,000) |
| **Total Invested Capital as of 1 October 2026** | **$171,600,000** |

**Invoice's Calculation:** $308M - $30M - $60M = $218M (missing $46.4M in deductions)

---

## ERROR 4: Q3 2026 STEP-DOWN ADJUSTMENT

**Critical Date:** Investment Period ended 14 August 2026, which falls within Q3 (1 July – 30 September 2026).

**LPA Requirement (Section 8.1(d)):** When the Investment Period ends on a day other than the last day of a calendar quarter, the Management Fee for that quarter must be recalculated as:
- **(i)** Installment under paragraph (a) [2.00% × Fee-Paying Commitments], multiplied by the number of days up to and including the last day of the Investment Period, divided by total days in quarter; **PLUS**
- **(ii)** Installment under paragraph (b) [1.50% × Invested Capital], using IC as of the first day of the quarter, multiplied by the remaining days, divided by total days in quarter.

**Q3 Day Count:**
- Days through 14 August 2026: **45 days** (July 1-31 + Aug 1-14)
- Days after 14 August 2026: **47 days** (Aug 15-31 + Sep 1-30)
- Total Q3 days: **92 days**

**Fee-Paying Commitments:** $394,000,000 (Total Commitments $400M less GP exempt $6M)

**Invested Capital as of 1 July 2026:**
- Aggregate cost (Q2 end): $304,000,000
- Less: Orla (40% realized): ($14,400,000)
- Less: Brindle (realized): ($30,000,000)
- Less: Wexford (written off): ($16,000,000)
- Less: Pellucid (PWD eff. 30 Jun): ($16,000,000)
- **Total: $227,600,000**

**Fee Attribution (FP Share):** $227,600,000 × (394M / 400M) = **$224,186,000**

**Q3 Recomputed Fee:**
- Part 1 (45 days at 2.00%): (45/92) × (1/4) × 2.00% × $394,000,000 = **$963,587**
- Part 2 (47 days at 1.50%): (47/92) × (1/4) × 1.50% × $224,186,000 = **$429,487**
- **Total Q3 correct fee: $1,393,074**

**Q3 as Paid:** $1,970,000 (calculated as flat quarter on Commitments, without step-down adjustment)

**Q3 Overpayment (Credit): $1,970,000 - $1,393,074 = $576,926**

**LPA Treatment (Section 8.1(d)):** "Any amount paid for that quarter in excess of the recomputed fee is credited against the next installment(s)..."

**Invoice Treatment:** The invoice does not acknowledge or apply this Q3 credit.

**Impact:** The $576,926 credit must reduce Q4 payment. **This is an error.**

---

## CORRECT Q4 2026 CALCULATION

**Invested Capital as of 1 October 2026:** $171,600,000 (per corrected calculation above)

**Fee-Paying Attribution (FP Share):** $171,600,000 × (394M / 400M) = **$169,026,000**

**Annual Management Fee (1.50%):** $169,026,000 × 0.015 = **$2,535,390**

**Q4 Quarterly Installment (1/4):** $2,535,390 / 4 = **$633,848**

**Less: Q3 Credit (to be applied per LPA 8.1(d)):** ($576,926)

**Q4 Net Amount Due:** $633,848 - $576,926 = **$56,921**

**Invoice Claims:** $817,500

**Overbilling:** $817,500 - $56,921 = **$760,579**

---

## ATTRIBUTION METHODOLOGY

The LPA Section 8.1(b) specifies that the post-period fee is "1.50% of the Invested Capital attributable to the Fee-Paying Partners." This language, combined with the attribution rule ("Invested Capital is attributed to Partners in proportion to their participation in each Portfolio Investment, which for the Partnership is pro rata to Commitments"), indicates that the fee base should reflect only the Fee-Paying Partners' share of IC, not 100% of partnership IC.

During the Investment Period, the fee is explicitly 2.00% × **Fee-Paying** Commitments (not total commitments). By analogy, after the Investment Period, the fee should apply only to the FP share of IC.

Calculation: 1.50% × (Total IC × FP Commitments / Total Commitments) = 1.50% × IC × 0.985

**This attribution is incorporated in the above figures.**

---

## IMMEDIATE ACTIONS REQUIRED

Per Schedule 4 (Payment of Management Fees) of the Halcyon Services Agreement:

1. **Hold the Payment** (Schedule 4.2): Do not release the $817,500 from partnership accounts pending correction.

2. **Notify the Manager** (Schedule 4.2 / 4.3): Send written notice to Manager CFO (Marcus Feld) detailing:
   - The three missing Invested Capital deductions (Wexford, Orla, Pellucid) and their LPA bases
   - The requirement to recompute Q3 per Section 8.1(d) and to credit the excess against Q4
   - The request for a revised invoice signed by Manager CFO per Schedule 4.4/4.5

3. **Escalate per Schedule 4.3** (if not resolved within 10 Business Days):
   - **LPAC Chair:** Notify of variance exceeding the 1% / $5K threshold
   - **Fund Auditor:** Notify of the payment hold and escalation

4. **Communicate with Sam:** Advise that the Q4 invoice cannot be approved for Monday payment and outline the corrections needed.

---

## SUPPORTING DOCUMENTS

All calculations are based on the following source documents within this work file:

- **LPA Excerpt:** `inputs/lpa/GACP_III_LPA_excerpt_management_fee.md` (Sections 8.1 and definition of Investment Period, Invested Capital, Realized, Permanent Write-Down)
- **Invoice:** `inputs/manager/GAM_invoice_GAM-III-2026-04.txt` (dated 1 October 2026)
- **Investment Cost Ledger:** `inputs/portfolio/investment_cost_ledger_GACP_III_20260930.csv` (transactions IC-001 through IC-015)
- **LPAC Records:** `inputs/governance/LPAC_records_GACP_III.txt` (Investment Period extension, Pellucid PWD notice)
- **Partner Register:** `inputs/investor_records/partner_register_GACP_III.csv` (commitments and fee-paying status)
- **Management Fee Installments:** `inputs/manager/management_fee_installments_GACP_III_2026.csv` (Q3 payment history)
- **Services Agreement:** `inputs/admin/halcyon_services_agreement_schedule4_fee_payments.md` (verification requirements and escalation procedures)

---

## CONCLUSION

**The Q4 2026 management fee invoice cannot be paid as presented.** It contains material calculation errors totaling $760,579 in overbilling, arising from three missed deductions from Invested Capital ($46.4M) and failure to apply the required Q3 step-down adjustment ($576,926 credit).

The correct amount due from the partnership to the Manager for Q4 is **$56,921** (after the Q3 credit), not $817,500.

The Manager must be asked to provide a corrected invoice, and if the corrections are not made within 10 business days, the matter must be escalated to the LPAC Chair and Fund Auditor per the Halcyon Services Agreement.

Recommend placing this item on the agenda for the next LPAC meeting, as the discrepancy is material and suggests either a significant error in the Manager's fee calculation system or a misunderstanding of the LPA fee provisions.

---

**Prepared by:** Fund Administration Review  
**Date:** 2 October 2026  
**Status:** REQUIRES MANAGEMENT RESPONSE BEFORE PAYMENT CAN BE RELEASED
