# Checker Review: Tollbridge Aggregates Rights Batch (CA-26-0915-TOLL)

**Prepared for:** Priya Castellanos, Asset Servicing Team Lead, Meridale Trust & Custody  
**Date:** 28-Sep-2026  
**Event:** Tollbridge Aggregates PLC EXRI (Rights Issue)  
**Batch ID:** B-TOLL-01  
**Status:** CORRECTIONS REQUIRED — 3 accounts with wrong elections; 1 account held pending escalation

---

## Summary of Corrections

The engine's draft batch contains significant errors in SI application and election determination. Three accounts have been assigned incorrect standing instructions, and one account (Lumenfield) has additional issues requiring management escalation.

| Account | Client | Draft SI | Draft Election | Corrected SI | Corrected Election | Issue |
|---------|--------|----------|---|----------|-----|--------|
| 4410-2201 | ASH | SI-0951 | LAPS | **SI-0412** | **EXER_PARTIAL_SLLE_BALANCE** | SI-0951 not valid until 15-Oct |
| 4410-2202 | ASH | SI-0951 | LAPS | **SI-0877** | **EXER_FULL_PLUS_OVER** | SI-0951 not valid; account-level SI overlooked |
| 4410-3107 | FEN | SI-0520 | SLLE | **SI-0931** | **EXER_PARTIAL_LAPS_BALANCE** | SI-0520 v2 expired 14-Sep; SI-0931 effective 15-Sep |
| 4410-5020 | LUM | SI-0944 | EXER | **SI-0605** | **LAPS_ALL** | SI-0944 PENDING_CALLBACK (unverified); late client instruction cannot be actioned |

---

## Detailed Analysis

### Key Dates & Deadlines

- **Event Reference:** CA-26-0915-TOLL (issued 15-Sep-2026 09:30 ET)
- **Client Response Deadline:** 28-Sep-2026 12:00 ET (per Meridale notice CA-26-0915-TOLL)
- **Sub-custodian (Carrow) Deadline:** 29-Sep-2026 12:00 London
- **Market Deadline:** 01-Oct-2026 11:00 London
- **Payment Due:** 01-Oct-2026
- **New Shares Admission:** 02-Oct-2026

### Subscription Terms

- **Entitlement:** 2 new shares for every 7 existing shares held at record date (11-Sep-2026)
- **Price:** GBP 1.85 per new share
- **Options:** 
  - 001 EXER: Take up (exercise)
  - 002 OVER: Excess application (only if all rights exercised)
  - 003 SLLE: Sell nil paid rights
  - 004 LAPS: Lapse (default, no MT565)

### Source Documents Reviewed

1. **Positions:** `inputs/positions/custody_positions_TOLL_20260928.csv`
   - ISIN GB005LKK3S13 (Tollbridge nil paid rights)
   - 4410-2201: 357,142 rights
   - 4410-2202: 139,000 rights
   - 4410-3107: 258,096 rights
   - 4410-5020: 114,285 rights
   - **Total:** 868,523 nil paid rights

2. **Standing Instructions:** `inputs/client_instructions/standing_instruction_register_extract_20260928.csv`
   - Bitemporal register per section 4 of Meridale Corporate Actions Service Terms
   - Governing SI = current row whose validity period contains the Client Response Deadline

3. **Cash Availability:** `inputs/cash/cash_availability_GBP_20260928_1200ET.csv`
   - Snapshot at 12:00 ET (Client Response Deadline)
   - Per section 5.1: available cash = cleared balance LESS reserved for pending outflows (with contractual value date ≤ market payment date)
   - Projected inflows (FX purchases, pending sales) do NOT count unless cleared by deadline

4. **Service Terms:** `inputs/policies/meridale_corporate_actions_service_terms_extract.md`
   - Section 4: Standing instruction governance
   - Section 5: Subscription event rules (available cash, partial funding, excess applications)
   - Section 7: Deadline rules and late instruction handling

5. **Client Notices:**
   - `inputs/notices/meridale_client_notice_CA-26-0915-TOLL.txt` — Meridale client notice with deadline and funding terms
   - `inputs/notices/MT564_CARWGB2L_TOLL_EXRI_20260915.txt` — Sub-custodian (Carrow) notice with option deadlines

6. **Client Instructions:**
   - `inputs/client_instructions/email_ashgrove_20260928_0852.txt` — Marcus Leland, 08:52 ET
   - `inputs/client_instructions/email_lumenfield_20260928.txt` — Harriet Voss, 17:05 ET (after deadline)

---

## Account-by-Account Analysis

### 4410-2201 (Ashgrove Pension Trust — Global Equity)

**Governing SI Determination:**
- **Available SI entries at deadline (28-Sep 12:00 ET):**
  - SI-0412: TAKE_UP_FULL (client-level, valid_from 01-Jan-2024, valid_to 31-Dec-9999, recorded_to 31-Dec-9999) ✓ VALID
  - SI-0951: LAPSE (client-level, valid_from 15-Oct-2026, valid_to 31-Dec-9999, recorded from 10-Sep) ✗ NOT YET VALID
  
- **Governing SI:** SI-0412 (TAKE_UP_FULL, balance_if_unfunded=SELL_NIL_PAID)
- **Draft Incorrectly Applied:** SI-0951 (effective date in future)

**Cash Analysis:**
- Cleared balance: GBP 612,400.00
- Pending outflows by market payment date (01-Oct): None
- Pending inflows: FX ticket AGP-FX-0928-01, GBP 60,000 (UNCONFIRMED, value 30-Sep)
- **Available cash (per section 5.1):** GBP 612,400.00 (FX not counted as unconfirmed and post-deadline)

**Election Calculation:**
- Rights held: 357,142
- Cash for full take-up: 357,142 × GBP 1.85 = GBP 660,712.70
- Cash available: GBP 612,400.00
- **Shortfall:** GBP 48,312.70

Per section 5.3, take up the largest whole number of shares affordable, apply balance_if_unfunded:
- Maximum shares: floor(612,400.00 / 1.85) = 331,027 shares
- Subscription cash: 331,027 × 1.85 = GBP 612,399.95
- Remaining rights: 357,142 - 331,027 = 26,115 rights
- Balance treatment per SI-0412: SELL_NIL_PAID → **SLLE 26,115 rights**

**Election:** EXER_PARTIAL_SLLE_BALANCE

**Note on FX:** Marcus Leland's email (08:52 ET) states "we've put an FX through this morning to buy GBP 60,000…value Wednesday 30th." The cash snapshot shows this as UNCONFIRMED with value date 30-Sep, which is after the deadline. Per section 5.1, projected inflows are not counted unless cleared by the deadline. If the FX has since been confirmed/cleared into the account, available cash would be GBP 672,400, enabling full take-up with 0 shares to sell. Current submission conservatively assumes it remains projected/unconfirmed.

---

### 4410-2202 (Ashgrove Pension Trust — UK Value)

**Governing SI Determination:**
- **Available SI entries at deadline:**
  - SI-0412: TAKE_UP_FULL (client-level, valid_from 01-Jan-2024) ✓ VALID
  - SI-0877: TAKE_UP_FULL, 25% excess cap (account-level 4410-2202, valid_from 01-Sep-2026) ✓ VALID
  - SI-0951: LAPSE (valid_from 15-Oct-2026) ✗ NOT YET VALID

- **Governing SI:** SI-0877 (account-level takes precedence over client-level per section 4.3(b) vs 4.3(c))
- **Draft Incorrectly Applied:** SI-0951

**Cash Analysis:**
- Cleared balance: GBP 300,000.00
- Pending outflows by 01-Oct: None
- Pending inflows: GBP 40,112.35 (equity sale settlement 29-Sep)
- **Available cash:** GBP 300,000.00 (settlement is after deadline)

**Election Calculation:**
- Rights held: 139,000
- Cash for full take-up: 139,000 × GBP 1.85 = GBP 257,150.00
- Cash available: GBP 300,000.00 ✓ **Full take-up covered**
- Remaining cash after take-up: 300,000.00 - 257,150.00 = GBP 42,850.00

Excess application per SI-0877:
- Maximum excess allowed: 25% × 139,000 = 34,750 shares
- Maximum excess affordable: floor(42,850.00 / 1.85) = 23,162 shares
- **Excess to apply:** 23,162 shares (limited by affordability, not the 25% cap)
- Excess cash: 23,162 × 1.85 = GBP 42,849.70
- **Total subscription cash:** 257,150.00 + 42,849.70 = GBP 299,999.70

**Election:** EXER_FULL_PLUS_OVER

---

### 4410-3107 (Fenwick County Retirement System — International Equity)

**Governing SI Determination:**

The SI register for Fenwick shows evolution of instructions:

| SI ID | Version | Election | Valid From | Valid To | Recorded From | Recorded To | Status |
|-------|---------|----------|-----------|----------|---|---|---|
| SI-0520 | 1 | SELL_NIL_PAID | 01-Mar-2025 | 31-Dec-9999 | 20-Feb-2025 | 16-Sep-2026 | VERIFIED |
| SI-0520 | 2 | SELL_NIL_PAID | 01-Mar-2025 | 14-Sep-2026 | 16-Sep-2026 | 31-Dec-9999 | VERIFIED |
| SI-0931 | 1 | TAKE_UP_FULL | 15-Sep-2026 | 31-Dec-9999 | 16-Sep-2026 | 31-Dec-9999 | VERIFIED |

Per section 4.1: "A row whose `recorded_to` is earlier has been replaced by a later version and must not be used."

At Client Response Deadline (28-Sep):
- SI-0520 v1: recorded_to 16-Sep (replaced) ✗ CANNOT USE
- SI-0520 v2: valid_to 14-Sep (expired as of deadline) ✗ CANNOT USE
- SI-0931: valid_from 15-Sep, valid_to 31-Dec-9999 ✓ VALID

**Governing SI:** SI-0931 (TAKE_UP_FULL, balance_if_unfunded=LAPSE)
**Draft Incorrectly Applied:** SI-0520 v2 (expired, replaced)

**Cash Analysis:**
- Cleared balance: GBP 520,000.00
- Pending outflows by market payment date (01-Oct):
  - EQ-B-260925-2207: GBP 58,214.40 (purchase settling 29-Sep) — on or before 01-Oct ✓ RESERVE
  - EQ-B-260928-2291: GBP 30,006.00 (purchase settling 05-Oct) — after 01-Oct ✗ DON'T RESERVE
- **Available cash:** 520,000.00 - 58,214.40 = GBP 461,785.60

**Election Calculation:**
- Rights held: 258,096
- Cash for full take-up: 258,096 × GBP 1.85 = GBP 477,477.60
- Cash available: GBP 461,785.60
- **Shortfall:** GBP 15,692.00

Per section 5.3, take up affordable shares, balance lapses:
- Maximum shares: floor(461,785.60 / 1.85) = 249,613 shares
- Subscription cash: 249,613 × 1.85 = GBP 461,784.05
- Remaining rights: 258,096 - 249,613 = 8,483 rights
- Balance treatment per SI-0931: LAPSE → **LAPSE 8,483 rights**

**Election:** EXER_PARTIAL_LAPS_BALANCE

---

### 4410-5020 (Lumenfield Endowment — Global Equity)

**Issue 1: SI Verification Status**

Standing instructions on file:
- SI-0605: LAPSE (recorded 24-Jun-2025, callback_status=VERIFIED, valid_from 01-Jul-2025)
- SI-0944: TAKE_UP_FULL (recorded 24-Sep-2026, callback_status=PENDING_CALLBACK, valid_from 24-Sep-2026)

Per section 4.4: "New or amended SIs, and event-specific instructions received by email, take effect only after a call-back to a registered contact number has been completed (`callback_status` = VERIFIED)."

SI-0944 register note: "Email from lumenfield-invest.org 2026-09-24, Callback attempts 09-25 and 09-28 unanswered on registered number; not effective until verified"

At the Client Response Deadline (28-Sep 12:00 ET):
- SI-0944 is still PENDING_CALLBACK → **cannot be used as governing SI**

**Governing SI:** SI-0605 (LAPSE, VERIFIED)
**Draft Incorrectly Applied:** SI-0944 (unverified)

**Issue 2: Late Instruction from Client**

Email from Harriet Voss (Lumenfield CIO), received 17:05 ET on 28-Sep:
> "Further to my email last Thursday updating our standing instruction, please take up our full Tollbridge entitlement in account 4410-5020… Cash will be in the account."

**Analysis:**
- Email time: 17:05 ET on 28-Sep (5:05 PM ET)
- Client Response Deadline: 12:00 ET on 28-Sep (12:00 PM ET)
- **This email arrives 5 hours 5 minutes AFTER the deadline**

Per section 7.2 — "Late instructions":
> "An instruction received after the Client Response Deadline does not bind Meridale. Asset Servicing may transmit it on a best-efforts basis only if all of the following are met: (i) the Head of Asset Servicing approves it in writing; (ii) the sub-custodian confirms in writing that it can still accept it; (iii) the account holds cleared cash in the event currency that covers the late election in full. If any condition is not met, the account is processed under 4.3(b) to (d) as if the late instruction had not been received."

**Condition Check:**
- (i) Head of Asset Servicing approval: NOT PROVIDED
- (ii) Carrow written confirmation: NOT PROVIDED
- (iii) Cleared cash covering full election: GBP 150,000 available vs GBP 211,427.25 required (114,285 rights × 1.85)
  - **SHORTFALL: GBP 61,427.25**

**All three conditions are NOT met** → late instruction cannot be actioned.

Per section 7.2: process as if instruction not received, i.e., apply standing instruction.

**Election (Per SI-0605):** LAPS_ALL (114,285 rights lapse)

**Per section 7.3:** Client must be notified in writing on the same day when a late instruction will not be actioned and why.

---

## Summary of Elections & Cash Debits

| Account | Client | Rights Held | Election | Exercise | Excess | Sell | Lapse | Subscription Cash (GBP) |
|---------|--------|-------------|---------|----------|--------|------|-------|-------------------------|
| 4410-2201 | ASH | 357,142 | EXER_PARTIAL_SLLE | 331,027 | — | 26,115 | — | 612,399.95 |
| 4410-2202 | ASH | 139,000 | EXER_FULL_PLUS_OVER | 139,000 | 23,162 | — | — | 299,999.70 |
| 4410-3107 | FEN | 258,096 | EXER_PARTIAL_LAPS | 249,613 | — | — | 8,483 | 461,784.05 |
| 4410-5020 | LUM | 114,285 | LAPS_ALL (held) | — | — | — | 114,285 | 0.00 (held) |
| **TOTAL** | | **868,523** | | **719,640** | **23,162** | **26,115** | **122,768** | **1,374,183.70** |

---

## Actions Required

### Immediate (by checker sign-off):

1. **Submit MT565 elections to Carrow for three accounts:**
   - 4410-2201: EXER_PARTIAL_SLLE_BALANCE (331,027 exercise + 26,115 sell)
   - 4410-2202: EXER_FULL_PLUS_OVER (139,000 exercise + 23,162 excess)
   - 4410-3107: EXER_PARTIAL_LAPS_BALANCE (249,613 exercise + 8,483 lapse)

2. **HOLD account 4410-5020** pending escalation and client contact

### Prior to Submission to Carrow (by 29-Sep 12:00 London):

3. **Escalate to Head of Asset Servicing:**
   - Lumenfield's late instruction (received after deadline)
   - Request decision: approve late take-up (with Carrow confirmation and emergency GBP 61,427.25 funding request), or deny and process as LAPS

### Client Communications Required (same day per section 7.3):

4. **Ashgrove (4410-2201):**
   - Confirm FX status: is AGP-FX-0928-01 now cleared into the account?
   - Advise: if FX cleared, election may be revised to full take-up

5. **Lumenfield (4410-5020):**
   - Notify: late instruction received after deadline cannot be actioned without approval from Head of Asset Servicing and Carrow confirmation
   - Advise: default treatment is LAPSE per SI-0605; if client wishes to pursue, must obtain Meridale approval and provide emergency funding of GBP 61,427.25

---

## Key Assumptions

1. **Available Cash Definition (section 5.1):**
   - Cleared GBP balance at Client Response Deadline
   - MINUS: cash reserved for pending outflows with contractual value date ≤ market payment date (01-Oct)
   - Projected inflows (FX, pending sales) NOT counted unless cleared by deadline

2. **SI Governance (section 4.2):**
   - Governing SI = current row whose validity period contains the Client Response Deadline (28-Sep)
   - Register rows: ignore if `recorded_to` is in the past (replaced by later version)

3. **Excess Application (section 5.4):**
   - Only if all rights are exercised AND instruction allows excess AND cash is available
   - Quantity = minimum of (excess % limit, affordable quantity)

4. **Late Instructions (section 7.2):**
   - Received after Client Response Deadline
   - Can only be actioned if ALL three conditions met: HoAS approval, sub-custodian confirmation, full funding

5. **Unverified SI (section 4.4):**
   - SI with callback_status ≠ VERIFIED cannot be used as governing SI
   - Applies to both newly recorded SIs and amended SIs

---

## References to Input Files

| Document | Use Case | Cited Evidence |
|----------|----------|---|
| `inputs/positions/custody_positions_TOLL_20260928.csv` | Rights held by account | 357,142 / 139,000 / 258,096 / 114,285 rights |
| `inputs/client_instructions/standing_instruction_register_extract_20260928.csv` | Determine governing SI at deadline | SI-0412, SI-0877, SI-0931, SI-0605 validity and callback status |
| `inputs/cash/cash_availability_GBP_20260928_1200ET.csv` | Calculate available cash | Cleared balances, pending outflows (4410-3107 purchase 58,214.40), projected inflows (4410-2201 FX 60,000 unconfirmed) |
| `inputs/policies/meridale_corporate_actions_service_terms_extract.md` | Service rules and precedence | Sections 4 (SI), 5 (subscription), 7 (deadlines) |
| `inputs/notices/meridale_client_notice_CA-26-0915-TOLL.txt` | Subscription terms and deadline | Price GBP 1.85, Client Response Deadline 28-Sep 12:00 ET, funding requirement |
| `inputs/notices/MT564_CARWGB2L_TOLL_EXRI_20260915.txt` | Options and sub-custodian terms | Sub-custodian deadline 29-Sep 12:00 London, option definitions |
| `inputs/client_instructions/email_ashgrove_20260928_0852.txt` | Ashgrove context | Marcus Leland confirms take-up per SI, mentions GBP funding issue, FX ticket AGP-FX-0928-01 |
| `inputs/client_instructions/email_lumenfield_20260928.txt` | Lumenfield context | Harriet Voss requests take-up in full at 17:05 ET (after deadline) |

---

## Sign-Off

This review corrects three accounts with incorrect SI application in the engine's draft, and escalates one account with unverified SI and late client instruction. The corrected batch is ready for submission to Carrow pending resolution of the Lumenfield account (4410-5020) by Head of Asset Servicing.

**Checker:** Claude Haiku 4.5  
**Session:** https://claude.ai/code/session_01EP7z5rzpGAM8dGG51aAur8
