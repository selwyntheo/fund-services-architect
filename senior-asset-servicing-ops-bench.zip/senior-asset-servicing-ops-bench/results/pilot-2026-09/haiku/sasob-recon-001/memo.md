# TGEI USD Cash Reconciliation Memorandum
**Date:** 2026-09-15  
**Fund:** Tidewell Global Equity Income Fund  
**Custodian Account:** Northgate 7730-104  
**Reconciler:** Automated Analysis

---

## Executive Summary

The TGEI USD custody account at Northgate (7730-104) shows a difference of **$1,280,183.04** as of 2026-09-15, with accounting closing at $9,790,604.12 versus custodian closing at $8,510,421.08. **All differences have been identified and explained.** The discrepancies stem from five distinct issues: (1) FX rate entry error in accounting, (2) dividend withholding tax and fee treatment, (3) bond purchase not recorded, (4) custody fee payment not recorded, and (5) a misdirected subscription wire for another fund.

After corrections to accounting, the fund's cash position reconciles exactly to custodian (accounting for the misdirected wire in the custodian statement). **No unexplained residual remains. No plugs are needed.**

---

## Detailed Findings

### 1. FX Rate Error – $900.00 (Accounting Side)

**Reference:** FX-260915-0117  
**Description:** The FX trade (EUR 2,000,000 buy / USD sell) was entered in accounting at the wrong exchange rate.

**Specifics:**
- Executed rate per counterparty confirmation: **1.174200** USD/EUR
- Rate recorded in accounting: **1.17465** USD/EUR
- Correct USD sale: EUR 2,000,000 × 1.174200 = **USD 2,348,400.00**
- Amount recorded: **USD 2,349,300.00**
- Error: **Overstated USD sale by $900.00**

**Sources:**
- FX confirmation (Bramwell Bank), Trade 260915-0117
- Accounting ledger entry, reference FX-260915-0117

**Treatment:** Correct the accounting entry from -2,349,300.00 to -2,348,400.00. Per fund policy 4.1, FX trades must be booked at the executed rate per counterparty confirmation, not at estimated rates.

**Action:** `post_entry` to accounting_system to reverse the 900.00 USD error.

---

### 2A. Dividend Withholding Tax – Excess of 10% – $11,544.00 (Custodian/Tax Documentation Side)

**Reference:** DV-VALC-0915 (Valcourt Energie SA ADS dividend)

**Facts:**
- Dividend record date: 2026-09-03
- Fund's French tax documentation (Form 5000 + Form 6166): Expired 2026-06-30
- Gross dividend per ADS: USD 0.6240 × 185,000 ADS = **USD 115,440.00**
- Treaty withholding rate (US residents): **15%**
- Statutory withholding rate (no relief): **25%**

**Withholding Analysis:**
- Withholding applied by Kestrel Depositary: 25% = **USD 28,860.00**
- Withholding at treaty rate: 15% = **USD 17,316.00**
- Excess (to reclaim): 10% = **USD 11,544.00**

**Sources:**
- Depositary Notice (Kestrel), Valcourt Energie SA dividend
- Tax documentation file (7730-104): France entry shows status EXPIRED for relief-at-source documentation
- Custodian statement (MT940), line for DV-VALC-0915: "GROSS USD 115,440.00 LESS FR TAX 25.00PCT USD 28,860.00"

**Why 25% Applied:** The relief-at-source documentation (Form 6166) expired on 2026-06-30, before the 2026-09-03 dividend record date. Kestrel correctly withheld at the statutory rate. The Fund is eligible to file for refund of the excess 10% under the French reclaim procedure (Form 5001).

**Treatment:** Record the excess withholding as a **Tax Reclaim Receivable** per fund policy 5.2. France reclaims are considered collectible. The dividend income should be recorded at the treaty withholding rate (15%), with the excess (11,544) set up as a GL 1450 receivable.

**Action:** `post_entry` to accounting_system to record dividend income at treaty rate and establish tax reclaim receivable. Coordinate with Tax Services (custodian) to file Form 5001 reclaim.

**Open Question:** What is the status of the Form 6166 renewal? Per the tax documentation file, it was requested from the IRS on 2026-05-20 but not yet received as of the data cutoff. If renewal is not completed, statutory 25% withholding will continue on future French dividends. This should be accelerated.

---

### 2B. Dividend – Depositary ADS Fee – $3,700.00 (Counterparty Side)

**Reference:** DV-VALC-0915 (same transaction)

**Facts:**
- ADS holder fee per Deposit Agreement: **USD 0.02 per ADS**
- Fund holding: **185,000 ADS**
- Fee deducted: 185,000 × 0.02 = **USD 3,700.00**

**Sources:**
- Depositary Notice: "In accordance with the Deposit Agreement, ADS holders will be charged a cash distribution fee of US$0.02 per ADS, deducted from the distribution."
- Custodian statement: "LESS DR FEE USD 3,700.00"
- Accounting ledger: Does not reflect the depositary fee deduction

**Treatment:** Per fund policy 5.3, "Depositary (ADR/ADS) fees deducted from distributions are recorded as a reduction of dividend income." The dividend income should be recorded net of the fee.

**Combined Dividend Correct Entry:**
- Gross dividend: USD 115,440
- Less 15% treaty withholding: (17,316)
- Less depositary fee: (3,700)
- **Net dividend income (GL 4100): USD 94,424**
- Tax reclaim receivable (GL 1450): USD 11,544
- Cash received: USD 82,880

---

### 3. Bond Purchase Not Recorded – $1,497,196.67 (Accounting Side)

**Reference:** BND-260914-0033 (Crestline Utilities 4.85% Senior Notes due 2033)

**Trade Details:**
- Trade date: 2026-09-14 (Monday)
- Settlement: Regular way (T+1 per policy 6.1) = 2026-09-15
- Par: USD 1,500,000
- Price: 98.412%
- Principal: USD 1,476,180.00

**Accrued Interest:**
- Last coupon date: 2026-06-01
- Settlement date: 2026-09-15
- Day count: 30/360 (US standard), 104 days
- Coupon rate: 4.85% (semi-annual = 2.425%)
- Semi-annual coupon: USD 1,500,000 × 2.425% = USD 36,375
- Accrued interest: USD 36,375 × (104 days / 180 days) = **USD 21,016.67**

**Settlement:**
- Total DVP settlement: 1,476,180.00 + 21,016.67 = **USD 1,497,196.67**

**Sources:**
- Trade ticket BND-260914-0033
- Custodian statement (MT940), line for BND-260914-0033: "DVP PURCH 1,500,000 CRESTLINE UTILITIES 4.85 12/01/33 USQJUPI78013 PRIN 1,476,180.00 INT 21,016.67"
- Accounting ledger: **Does not include this transaction**
- Pending settlements file: Shows transaction as pending for 2026-09-16 (T+2), but it actually settled on 2026-09-15

**Treatment:** Record the bond purchase as a settlement transaction on 2026-09-15. The accrued interest (21,016.67) should be recorded as an asset (accrued interest receivable) and will reverse into coupon income on the next coupon date (2026-12-01).

**Secondary Issue – Settlement Date Discrepancy:** The trade ticket correctly shows T+1 settlement (2026-09-15) per standard and policy 6.1. However, the pending settlements file shows T+2 (2026-09-16). The security master may have a default setting that conflicts with the trade ticket. Recommend confirming with Reference Data that BND-260914-0033 is set to T+1 in the security master; if defaulted to T+2, request correction per policy 6.1.

**Secondary Issue – Accrued Interest Variance:** The pending settlements file shows accrued interest of 21,218.75 (approximately 1 day more than custodian's 21,016.67). This is consistent with T+2 calculation versus T+1. The custodian's figure (21,016.67 for T+1 settlement on 2026-09-15) is correct.

**Action:** `post_entry` to accounting_system to record the bond settlement.

---

### 4. Custody Fee – Payment Not Recorded Against Accrual – $18,642.37 (Custodian Side)

**Reference:** INV-NTC-2608-7730 (Northgate custody invoice for August 2026)

**Facts:**
- Service period: August 1 – August 31, 2026
- Invoice total: **USD 18,642.37**
  - Safekeeping – US equities/bonds: USD 11,204.66
  - Safekeeping – non-US markets: USD 4,918.21
  - Transaction charges (212 txns): USD 1,896.00
  - FX settlement charges: USD 240.00
  - Income collection/tax: USD 383.50
- Accrual in accounting (August, estimate): USD 18,650.00
- Over-accrual: 18,650.00 - 18,642.37 = **USD 7.63**

**Payment:**
- Custodian auto-debit on 2026-09-15 per Section 7.2 of the Custody Fee Agreement
- Amount debited: USD 18,642.37
- Accounting treatment: Only the estimate accrual is reflected; the payment is not shown as a deduction against the accrual

**Sources:**
- Custody invoice NTC-2608-7730
- Custodian statement (MT940), line for INV-NTC-2608-7730: "CUSTODY AND SAFEKEEPING FEES AUGUST 2026 INVOICE NTC-2608-7730 AUTO DEBIT"
- Accounting accrued expenses file: Entry for "ACCRUED CUSTODY FEES 2026-08" with balance 18,650.00

**Treatment:** Per fund policy 3.5, "Accrued expenses paid by custodian auto-debit are recorded as a payment against the accrual. Any difference between the invoice and the accrual is trued up through the expense line."

**Accounting Entry Required:**
- Debit Accrued Custody Fees: 18,650.00
- Credit Cash: 18,642.37
- Credit Custody Expense (reversal of over-accrual): 7.63

This nets to zero for cash correction purposes (we're paying the actual invoice amount, not adjusting it), but the accrual variance of 7.63 will be recorded through expense as required by policy.

**Action:** `post_entry` to accounting_system to apply the payment against the accrual and true up the variance.

---

### 5. Misdirected Incoming Wire – $250,000.00 (Custodian Routing Error)

**Reference:** TSDF-SUB-0915-0042

**Description:** A subscription wire for the Tidewell Short Duration Fund (TSDF) was incorrectly credited to the TGEI custody account.

**Facts:**
- Activity: TSDF subscription, USD 250,000.00
- Intended destination: TSDF account 7730-118 (per wire ordering reference: "FFC TIDEWELL SHORT DURATION FUND ACCT 7730-118")
- Actual destination: **TGEI account 7730-104** (per custodian statement)
- Accounting treatment: **Not recorded** (correctly, per policy 3.4)
- Custodian treatment: **Incorrectly credited** to TGEI

**Sources:**
- Transfer agent daily activity file (TSDF record): Subscription 250,000.00
- Custodian statement (MT940), line for TSDF-SUB-0915-0042: "INCOMING WIRE ORDERING SANDRIDGE FUND SERVICES AS TA REF TSDF-SUB-0915-0042 FFC TIDEWELL SHORT DURATION FUND ACCT 7730-118 SUBSCRIPTION"

**Fund Policy Compliance:** Per policy 3.4, "Cash received that does not belong to the Fund (misdirected wires, other-fund activity) must not be recorded as Fund income or capital share activity. Notify the custodian and the relevant transfer agent/fund accounting team the same day and track as a custodian-side reconciling item until reversed."

Accounting correctly did not record this wire. The fund's books are correct.

**Treatment:** 
1. **Custodian Action:** Request Northgate to immediately transfer USD 250,000 from account 7730-104 (TGEI) to account 7730-118 (TSDF) with wire confirmation.
2. **Fund Accounting Action:** Treat as a reconciling item (custodian-side only) until Northgate confirms the transfer.
3. **Counterparty Notification:** Notify the Tidewell Short Duration Fund accounting team that their subscription wire was misdirected and request confirmation once transferred to the correct account.

**Reconciliation Impact:** This wire appears in the custodian closing balance (8,510,421.08) but should not be there. It must be removed (transferred to 7730-118) for the custodian balance to equal accounting (corrected).

**Action:** `request_info` to custodian to confirm transfer. `notify` to the other fund's accounting team.

---

## Reconciliation Summary

| Description | Amount |
|---|---|
| **Accounting Closing Balance** | $9,790,604.12 |
| **Custodian Closing Balance** | $8,510,421.08 |
| **Initial Difference** | $1,280,183.04 |
| | |
| **Corrections to Accounting:** | |
| FX rate error | +$900.00 |
| Dividend withholding & fee | -$15,244.00 |
| Bond purchase not recorded | -$1,497,196.67 |
| Custody fee not recorded | -$18,642.37 |
| **Total Correction** | -$1,530,183.04 |
| **Accounting after corrections** | $8,260,421.08 |
| | |
| **Custodian Corrected** | |
| Remove misdirected wire | -$250,000.00 |
| **Custodian corrected balance** | $8,260,421.08 |
| | |
| **Reconciliation** | ✓ MATCHES |
| **Unexplained Residual** | $0.00 |

---

## Key Figures for NAV Release

| Item | Amount |
|---|---|
| **Corrected Accounting Cash Balance** | $8,260,421.08 |
| **Tax Reclaim Receivable (GL 1450)** | $11,544.00 |
| **Bond Accrued Interest** | $21,016.67 |
| **Custody Fee Over-Accrual Reversal** | $7.63 |

**Note on Tax Reclaim:** The $11,544.00 tax reclaim receivable should be set up in GL 1450 and referred to Tax Services (custodian) for Form 5001 reclaim filing. This is considered a collectible receivable per fund policy.

---

## Actions Required Before NAV Release

1. **Post the FX correction** (900.00 reversal)
2. **Post the dividend correction** (82,880 received, establish 11,544 tax reclaim, reduce income for 3,700 fee)
3. **Record the bond settlement** (1,497,196.67 for principal and accrued interest)
4. **Post the custody fee payment** (apply against accrual, true-up variance)
5. **No plug required** – All differences explained with documented support

**Custodian Follow-Up (tomorrow):**
- Confirm transfer of 250,000.00 wire from 7730-104 to 7730-118
- Confirm status of France Form 6166 renewal for relief-at-source relief
- Initiate Form 5001 reclaim filing for the 11,544.00 excess French withholding

**Internal Follow-Up (tomorrow):**
- Notify TSDF accounting of misdirected wire and Northgate transfer-in-progress
- Request Reference Data to verify that BND-260914-0033 settlement cycle is set to T+1 (not T+2 default)
- Escalate Form 6166 renewal to Tax Department if not resolved with custodian

---

## Audit Trail

All amounts traced to:
- Cash ledger entries with transaction references and amounts
- Custodian MT940 statement with matching line-by-line entries
- Counterparty confirmations (FX, dividend notice, trade tickets)
- Internal policies and documentation (policy 3.1–6.1, tax documentation file)
- Invoice support (custody invoice, accrual worksheets)

**Reconciler's Conclusion:** The $1.28 million difference is fully explained. No unexplained residual. The fund is in compliance with policy 3.2 (all differences identified to root cause and corrected on the right side) and policy 3.3 (no plugs above USD 1,000).

