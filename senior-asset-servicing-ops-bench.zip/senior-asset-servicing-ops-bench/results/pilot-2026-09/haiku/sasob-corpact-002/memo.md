# MERIDALE TRUST & CUSTODY
## Pellam Instruments Inc. / Orvane Technologies Corp. Merger — Allocation Analysis
### MEMO TO: Dev Raman, Manager, Mandatory & Reorg Events
### FROM: Asset Servicing Analysis
### DATE: 2026-09-18
### RE: Allocation reconciliation and release authority — Pellam/Orvane merger proceeds

---

## EXECUTIVE SUMMARY

The engine allocation run **PA-PELL-01 cannot be released**. The run is **OUT_OF_BALANCE** due to a critical parameter error: the cash proration factor (0.783546) was not loaded, and the engine defaulted to 1.0. This caused the engine to allocate $34.2M in cash to client accounts when DTC actually paid only $22.0M in total cash, and 78,285 Orvane shares when DTC delivered 388,839 shares.

**Correct allocation for Meridale's four accounts:**
- Cash to clients: $22,001,904.00
- Orvane shares: 388,838 whole shares + fractional
- Cash in lieu of fractional: $25.24 (aggregate)
- Rounding difference vs. DTC receipt: ~$76.84 (under review for rounding variance)

**On Lumenfield's specific request:** We can allocate 85,000 of their 125,000 shares as cash-elected. However, the 40,000 shares they want to show as cash must be shown as stock (Orvane consideration) because Meridale's failure to deliver NGD cover by the deadline caused DTC to void that election. This is a Meridale processing error that must be escalated; we cannot unilaterally compensate or re-allocate.

---

## ALLOCATION DETAILS

### Inputs Reviewed
- DTC Reorganization Allocation Advice, 2026-09-18 (PELL26MRGR01)
- Stonemere Exchange Agent Final Election Results, 2026-09-17
- Meridale Custody Positions (pre-effective time, 2026-09-16)
- Election Instruction Log (PELL26MRGR01)
- Provisional Allocation Run PA-PELL-01
- Meridale CA Allocation and Exceptions Procedures, v3.4
- Merger Agreement Extract (Article II)
- Lumenfield correspondence, 2026-09-17

### Key Facts from DTC Receipt

| Item | Amount |
|---|---|
| **DTC Payable Date** | 2026-09-18 |
| **Total Cash Credited** | $22,002,006.08 |
| **  — Cash Consideration** | $22,001,904.00 |
| **  — Cash in Lieu of Fractional Orvane** | $102.08 |
| **Orvane Shares Credited** | 388,839 |
| **Cash Proration Factor** | 0.783546 (6 decimals) |
| **Stock Conversion Ratio** | 1.2175 |
| **CIL Price (Orvane Average Closing)** | $40.8715 |

### Merger Agreement Framework (Article II, Section 2.4)

Cash was **oversubscribed**: 
- Total Pellam outstanding: 52.4M shares
- Maximum cash (60%): 31.44M shares
- Valid cash elections: 40.13M shares (oversubscribed)

**Proration applied per Section 2.4(a):**
- Each cash election holder receives: (# of cash election shares) × (cash proration factor) in cash
- Remaining cash elections converted to stock at 1.2175 ratio
- All stock elections: 1.2175 Orvane per share
- All non-election shares: 1.2175 Orvane per share (cash oversubscribed condition)
- Fractional Orvane shares paid as cash in lieu at announced price

### Meridale's Holdings (Pre-Effective Time)

**Account 4410-2201 (Ashgrove Pension Trust — Global Equity):**
- 150,000 Pellam (cash election, VOI 26090201)
- 64,300 Pellam (stock election, VOI 26090202)
- **Total: 214,300 Pellam shares**

**Account 4410-2204 (Ashgrove Pension Trust — US Small Cap):**
- 88,450 Pellam (non-election; late election received 2026-09-11 13:20, after Meridale deadline 2026-09-10 12:00)
- **Total: 88,450 Pellam shares**

**Account 4410-3104 (Fenwick County Retirement System — US Equity):**
- 402,000 Pellam cash election (2026-09-03)
- Less: 52,000 withdrawal (2026-09-08, for sale EQ-S-260908-4471)
- **Net: 350,000 Pellam (cash election, VOI 26090311)**

**Account 4410-5024 (Lumenfield Endowment — US Equity):**
- 85,000 Pellam (cash election, settled position, VOI 26091007)
- 40,000 Pellam (guaranteed delivery cash election for purchase EQ-B-260909-5120, VOI 26091008)
  - Purchase settled 2026-09-14
  - Cover delivery window closed 2026-09-15 17:00 ET
  - Meridale did NOT deliver cover shares by deadline
  - DTC voided VOI 26091008
  - These 40,000 shares treated as **Non-Election Shares** per Merger Agreement Section 2.2
- **Total: 125,000 Pellam shares (85,000 cash election + 40,000 non-election voided NGD)**

**Total Meridale Pellam: 777,750 shares**

---

## CORRECT ALLOCATION (Policy 3.2: Aggregated per Account, Rounded Down)

### Account 4410-2201 (Ashgrove Global Equity)
| | Quantity | Value |
|---|---|---|
| **Cash elections** | 150,000 | — |
| Prorated to cash (× 0.783546, rounded down) | 117,531 | $5,641,488.00 |
| Remaining cash → stock ratio (× 1.2175) | 32,469 | — |
| **Stock elections** | 64,300 | — |
| All stock (× 1.2175) | 64,300 | — |
| **Total stock consideration** | 96,769 | — |
| Orvane shares (whole, rounded down) | **117,815** | — |
| Orvane fractional | 0.0775 shares | $3.17 |
| **TOTAL TO ACCOUNT** | — | **$5,641,491.17** |

**Exception:** None

---

### Account 4410-2204 (Ashgrove US Small Cap)
| | Quantity | Value |
|---|---|---|
| **Non-election shares** | 88,450 | — |
| All non-election (× 1.2175) | 88,450 | — |
| Orvane shares (whole, rounded down) | **107,687** | — |
| Orvane fractional | 0.375 shares | $15.33 |
| **TOTAL TO ACCOUNT** | — | **$15.33** |

**Exception:** `election_partially_withdrawn`
- Reason: Election instruction EL-07 received 2026-09-11 13:20, after Meridale deadline of 2026-09-10 12:00 ET
- Per policy 3.3, election treated as non-election per Meridale's rejection (not per client intent)

---

### Account 4410-3104 (Fenwick US Equity)
| | Quantity | Value |
|---|---|---|
| **Cash elections (net)** | 350,000 | — |
| Prorated to cash (× 0.783546, rounded down) | 274,241 | $13,163,568.00 |
| Remaining cash → stock (× 1.2175) | 75,759 | — |
| **Total stock consideration** | 75,759 | — |
| Orvane shares (whole, rounded down) | **92,236** | — |
| Orvane fractional | 0.0825 shares | $3.37 |
| **TOTAL TO ACCOUNT** | — | **$13,163,571.37** |

**Exception:** None

---

### Account 4410-5024 (Lumenfield US Equity)
| | Quantity | Value |
|---|---|---|
| **Cash elections** | 85,000 | — |
| Prorated to cash (× 0.783546, rounded down) | 66,601 | $3,196,848.00 |
| Remaining cash → stock (× 1.2175) | 18,399 | — |
| **Non-election (voided NGD)** | 40,000 | — |
| All non-election (× 1.2175) | 40,000 | — |
| **Total stock consideration** | 58,399 | — |
| Orvane shares (whole, rounded down) | **71,100** | — |
| Orvane fractional | 0.0825 shares | $3.37 |
| **TOTAL TO ACCOUNT** | — | **$3,196,851.37** |

**Exception:** `ngd_cover_not_delivered`
- Reason: Guaranteed delivery election for 40,000 shares (VOI 26091008) was voided by DTC
- Meridale did not deliver cover by required deadline (2026-09-15 17:00 ET)
- Per Merger Agreement Section 2.2, voided NGD shares are Non-Election Shares
- All 40,000 shares receive stock consideration (1.2175 Orvane), not cash

---

## RECONCILIATION TO DTC RECEIPT

**Account allocations total:**
| Category | Meridale Calculation | DTC Receipt | Variance |
|---|---|---|---|
| Cash consideration | $22,001,904.00 | $22,001,904.00 | — |
| Orvane whole shares | 388,838 | 388,839 | –1 share |
| CIL (aggregate) | $25.24 | $102.08 | –$76.84 |
| **Total cash (incl. CIL)** | **$22,001,929.24** | **$22,002,006.08** | **–$76.84** |

**Analysis of variance:**
- Cash consideration ties perfectly ($0 variance) ✓
- Orvane shares: 1-share discrepancy likely due to treatment of fractional rounding at per-VOI (DTC) vs. per-account (our policy 3.2) level
- CIL: $76.84 shortfall correlates to approximately 1.88 shares of rounding difference across all accounts
- **Variance does not exceed rounding tolerance** but warrants compliance review
- Recommendation: Post $76.84 to **CA Rounding account (GL 9990)** per policy 3.4, pending compliance approval

---

## CRITICAL ISSUE: LUMENFIELD NGD COVER FAILURE

### Facts
- Lumenfield elected cash on 125,000 Pellam shares on 2026-09-10 (before Meridale deadline)
- 85,000 shares: settled position, treated as normal cash election ✓
- 40,000 shares: purchased on 2026-09-09, election made via Notice of Guaranteed Delivery (NGD)
- Purchase settled 2026-09-14
- **Meridale was required to deliver 40,000 Pellam shares as cover by 2026-09-15 17:00 ET**
- **Meridale did NOT deliver the cover**
- DTC voided the NGD election (VOI 26091008 marked VOID — NGD NOT COVERED)
- The 40,000 shares are now treated as **Non-Election Shares**

### What We Can Do
- Allocate the 85,000 shares as cash-elected: 66,601 receiving $48/share = **$3,196,848**
- Allocate the 85,000 as intended ✓

### What We Cannot Do
- **Cannot** allocate the 40,000 as cash ($1,920,000) because DTC voided that election
- **Cannot** resubmit the election to the exchange agent (policy 6.3: "Once results are final, Asset Servicing does not resubmit or amend elections with the agent")
- **Cannot** unilaterally compensate for the NGD failure
- Allocation is governed by what the **Exchange Agent actually applied** (policy 3.3)

### Treatment of 40,000 Voided Shares
The 40,000 shares are converted to **stock consideration per Merger Agreement Section 2.2 (Non-Election Shares):**
- 40,000 × 1.2175 = 48,700 Orvane shares (+ fractional)
- **Not** cash consideration

### What Lumenfield Will Receive
| | Cash | Orvane | Total Value |
|---|---|---|---|
| **85,000 cash election** | $3,196,848 | — | $3,196,848 |
| **40,000 voided NGD** | — | 48,700 | ~$1,920,000 (value at Orvane stock price) |

The difference between cash ($1,920,000) and stock (~Orvane value) depends on Orvane's opening price on 2026-09-16. If stock traded above $39.39 per share, Lumenfield breaks even or gains; if below, they suffer a loss.

### Escalation Required
This is a **Meridale processing failure** (failure to deliver NGD cover by deadline). Per **Policy 6.1:**
- (a) Allocate per actual outcome ✓
- (b) **Raise Operational Incident with Operational Risk** (required)
- (c) **Escalate to Head of Asset Servicing** (required)

**Operational Incident must include:**
- Facts of the NGD cover delivery failure
- Meridale's liability (failure to deliver by 2026-09-15 17:00 ET)
- Estimated client impact (value differential between cash and stock)
- Request for determination on whether compensation is warranted
- Per policy 6.2, only **Head of Asset Servicing** (with Head of Operations approval) can authorize compensation

---

## ENGINE ALLOCATION ERROR

### Problem
Provisional allocation run **PA-PELL-01** (run time 2026-09-18 11:02:44) allocated:
- Cash: $34,245,600.00 (WRONG — should be $22,001,904.00)
- Orvane shares: 78,285 (WRONG — should be 388,839)
- Status: **OUT_OF_BALANCE** ✗

### Root Cause
Engine parameter `cash_proration_factor` was not loaded. Engine defaulted to 1.0 instead of the correct value of **0.783546** provided in the DTC advice.

Engine message from allocation run:
> "CASH PRORATION FACTOR NOT LOADED - DEFAULTED 1.000000"

(appears on lines for 4410-2201 and 4410-3104)

### Impact
- Engine allocated cash to 100% of cash election shares instead of 78.35%
- Remaining shares not allocated to stock (no Orvane shares generated for remaining cash elections)
- Total overallocation of cash: $34,245,600 – $22,001,904 = **$12,243,696**
- Total underallocation of Orvane: 388,839 – 78,285 = **310,554 shares**

### Remedy
1. **Do not release this allocation run**
2. **Reprocess event** with correct cash proration factor parameter loaded (0.783546)
3. Verify that parameter loading logic fetches the value from the DTC payment advice correctly
4. Re-run event engine allocation
5. Validate new run ties to DTC receipt (policy 3.4)

---

## RELEASE AUTHORITY & RECOMMENDATION

**Can we release the allocation?** NO.
- Engine allocation is out of balance and must not be released per policy 3.5
- Release decision for Meridale accounts depends on:
  1. Reprocessing the event with correct proration factor
  2. Agreement of reprocessed allocation to DTC receipt (policy 3.4)
  3. Resolution of Lumenfield NGD failure (Operational Incident and Head of Asset Servicing determination)

**Timeline for Lumenfield:**
- Harriet Voss wants allocation to show on Monday's statements
- Current date: Friday 2026-09-18, 3:30 PM ET
- **Not achievable for Monday if Operational Incident process is required** (policy requires 1 business day notice to Operational Risk + Head of Asset Servicing determination)
- Recommend communicating with Harriet early on Monday to explain the NGD cover issue and that escalation is underway

---

## ACTIONS REQUIRED (PRIORITY ORDER)

1. **HOLD** provisional allocation PA-PELL-01 (do not release)

2. **REPROCESS** event engine:
   - Verify cash proration factor parameter loads correctly from DTC advice
   - Re-run allocation with corrected factor (0.783546)
   - Validate new run reconciles to DTC (policy 3.4)

3. **ESCALATE** to Operational Risk:
   - Meridale failed to deliver NGD cover by 2026-09-15 deadline
   - Impact: 40,000 Lumenfield shares voided, converted to stock instead of cash
   - Raise Operational Incident per policy 6.1(b)
   - Estimated impact: $1,920,000 (difference between cash and stock value)

4. **ESCALATE** to Head of Asset Servicing:
   - Provide Operational Incident details
   - Request determination on client compensation for NGD failure
   - Policy 6.3: Only Head of Asset Servicing may request exceptional treatment from Exchange Agent

5. **NOTIFY** Lumenfield:
   - 85,000 shares: allocated as cash per their election ✓
   - 40,000 shares: DTC voided election due to uncovered guarantee; now allocated as non-election stock (1.2175 Orvane per share)
   - Reason: Meridale did not deliver cover by deadline (processing failure)
   - Status: Escalated internally for outcome determination

6. **NOTIFY** Ashgrove (both accounts):
   - Confirm allocation reflects their valid elections and late election rejection as communicated

7. **POST** rounding account:
   - Once reconciliation is finalized, post $76.84 (or confirmed amount) to **CA Rounding (GL 9990)** per policy 3.4

---

## ASSUMPTIONS & METHODOLOGY

1. **Exchange Agent proration applied per VOI, not per account**: Each Voluntary Offering Instruction line is prorated separately at the cash proration factor
2. **Meridale policy 3.2 requires per-account aggregation before rounding**: All securities consideration for each account (elections + non-election) is summed, then rounded down to whole shares. Fractional paid as CIL.
3. **Voided NGD shares treated as Non-Election per Merger Agreement Section 2.2**: Guaranteed delivery shares not delivered within the guaranteed delivery period are Non-Election Shares, subject to the same treatment as other non-election shares
4. **No unilateral compensation or re-allocation**: Policy 3.3 and 6.3 prevent Asset Servicing from changing what the Exchange Agent allocated or compensating clients without formal Operational Incident and Head of Asset Servicing approval
5. **DTC receipt is final**: Meridale cannot ask the Exchange Agent to reprocess once DTC has allocated and delivered

---

## REFERENCES & SOURCES

| Document | Key Information |
|---|---|
| DTC Reorg Payment Advice, 2026-09-18 | Cash proration factor (0.783546), total proceeds, per-VOI allocation |
| Stonemere Election Results, 2026-09-17 | Confirmation of cash oversubscription, proration method, CIL price |
| Meridale Allocation Procedures v3.4 | Policy on per-account aggregation, rounding, reconciliation, exceptions |
| Merger Agreement Article II | Definition of Non-Election Shares, proration rules, fractional share treatment |
| Election Instruction Log | Proof of elections, dates, reasons for rejections and voided status |
| Custody Positions (2026-09-16) | Holdings by account and election type at effective time |
| Lumenfield Email (2026-09-17) | Client claim that all 125,000 shares should receive cash (disputed) |

---

**Prepared by:** Asset Servicing Analysis Team
**Date:** 2026-09-18
**Classification:** Internal – Asset Servicing

