# BEIO September 2026 Section 19(a) Notice — Analysis and Findings

**Prepared for:** Nadia Okonkwo, Treasurer, Brightwater Equity Income Opportunities Fund  
**Prepared by:** Oakhurst Fund Administration  
**Date:** 2026-09-24  
**Subject:** Verification of sources for September 2026 Section 19(a) notice

---

## Executive Summary

The draft notice prepared by Kieran Doyle contains material errors in the attribution of distribution sources. The managed distribution plan procedures (Section 4.4) require that realized capital losses offset available gains from the other category. The draft does not apply this loss netting rule, resulting in:

- September current distribution overstated as 51% NII, 22% STCG, 27% ROC when it should be **100% ROC**
- FYTD cumulative overstated STCG by $0.1809/share (from $0.5104 to $0.3295)
- FYTD cumulative understated ROC by $0.1586/share (from $0.0992 to $0.2578)

Additionally, Talia Ruiz's request to align the notice with the tax team's zero-ROC estimate cannot be accommodated. Procedure 4.1 explicitly prohibits using tax-basis estimates for Section 19(a) purposes; sources must be determined from book accounting records.

---

## Data Sources and Calculation Method

### Input Files Used

1. **BEIO_book_income_and_realized_gains_FY2026.csv** — Monthly accounting data (net investment income, realized gains/losses by category)
2. **BEIO_nii_accrual_forecast_20260924_20260930.csv** — NII forecast for Sept 24-30 ($265,910)
3. **BEIO_capital_accounts_20251031_and_20260923.csv** — Shares outstanding (18,420,000) and undistributed NII at FY start ($412,540)
4. **BEIO_distribution_history_FY2026.csv** — Monthly distributions through September ($0.1150/share in September)
5. **BEIO_managed_distribution_plan_19a_procedures.md** — Section 4.4 (loss netting rule), Section 4.5 (ordering), Section 4.6 (cumulative attribution)
6. **BEIO_19a_notice_2026-08_AS_SENT.txt** — August notice for comparison (cumulative baseline)
7. **BEIO_tax_character_estimate_FY2026_20260915.csv** — Tax estimate (for reference; not used per Procedure 4.1)

### Calculation Procedure

Following Section 4.6 of the procedures:

#### Step 1: Calculate Available Sources Through September 30

**Net Investment Income Available:**
- Undistributed NII at FY start (Nov 1, 2025): $412,540
- FY2026 NII through August: $10,625,010 (sum of monthly NII, Nov 2025–Aug 2026)
- September NII actual (9/1–9/23): $812,640
- September NII forecast (9/24–9/30): $265,910
- **Total NII Available:** $412,540 + $10,625,010 + $812,640 + $265,910 = **$12,116,100**

**Realized Short-term Capital Gains Available (before loss offset):**
- FY2026 STCG through August: $8,932,730 (sum of monthly STCG, Nov 2025–Aug 2026)
- September STCG actual (9/1–9/23): $468,220
- (No forecast for realized gains per Procedure 4.3)
- **Total STCG before offset:** $8,932,730 + $468,220 = **$9,400,950**

**Realized Long-term Capital Losses Available:**
- FY2026 LTCG through August: −$3,033,920 (sum of monthly LTCG)
- September LTCG actual (9/1–9/23): −$298,430
- (No forecast)
- **Total LTCG:** −$3,033,920 − $298,430 = **−$3,332,350** (net loss)

#### Step 2: Apply Loss Netting Per Procedure 4.4

Procedure 4.4 states:
> "If either the short-term or the long-term fiscal-year-to-date amount is a net loss, that loss reduces the other category's available amount (not below zero), and the loss category is shown as zero."

Since LTCG is a net loss (−$3,332,350):
- **STCG Available (after loss offset):** max(0, $9,400,950 + (−$3,332,350)) = **$6,068,600**
- **LTCG Available:** $0 (shown as zero)

#### Step 3: Allocate Cumulative Distributions Through September

Per Procedure 4.5, distributions are allocated in order: NII → STCG → LTCG → ROC

Total FYTD distributions (11 months):
- Nov 2025–Feb 2026: 4 × $0.1100 = $0.44/share
- Mar 2026–Sep 2026: 7 × $0.1150 = $0.805/share  
- **Total:** $1.2450/share = 18,420,000 × $1.2450 = **$22,932,900**

Allocation in order:
1. NII: min($12,116,100, $22,932,900) = **$12,116,100**
2. Remaining: $22,932,900 − $12,116,100 = $10,816,800
3. STCG: min($6,068,600, $10,816,800) = **$6,068,600**
4. Remaining: $10,816,800 − $6,068,600 = $4,748,200
5. LTCG: min($0, $4,748,200) = **$0**
6. ROC (balancing): **$4,748,200**

#### Step 4: Convert to Per-Share Amounts and Percentages

**FYTD Cumulative (November 2025 – September 2026):**

| Source | Amount | Per Share | % of Total |
|--------|--------|-----------|-----------|
| NII | $12,116,100 | $0.6578 | 52.8% |
| STCG | $6,068,600 | $0.3295 | 26.5% |
| LTCG | $0 | $0.0000 | 0.0% |
| ROC | $4,748,200 | $0.2578 | 20.7% |
| **Total** | **$22,932,900** | **$1.2450** | **100.0%** |

#### Step 5: Calculate Current (September) Distribution

Subtract previous cumulative (through August) from current cumulative (through September):

**August Cumulative (with loss netting, 10 distributions = $20,814,600):**
- NII: min($12,116,100, $20,814,600) = $12,116,100
- Remaining: $8,698,500
- STCG: min($6,068,600, $8,698,500) = $6,068,600
- Remaining: $2,629,900
- LTCG: $0
- ROC: $2,629,900

Per share: NII $0.6578, STCG $0.3295, ROC $0.1427

**September Current (difference):**

| Source | Cumulative Through Sept | Cumulative Through Aug | Current Month |
|--------|--------|--------|--------|
| NII | $0.6578 | $0.6578 | **$0.0000** |
| STCG | $0.3295 | $0.3295 | **$0.0000** |
| LTCG | $0.0000 | $0.0000 | **$0.0000** |
| ROC | $0.2578 | $0.1427 | **$0.1150** |

**September percentages:** 100.0% ROC

---

## Comparison with Draft Notice

### Draft Figures (Incorrect — Loss Netting Not Applied)

The draft shows:
- **September current:** NII $0.0586 (51.0%), STCG $0.0254 (22.1%), ROC $0.0310 (27.0%)
- **FYTD cumulative:** NII $0.6354 (51.0%), STCG $0.5104 (41.0%), ROC $0.0992 (8.0%)

The draft's preparer notes state: "LT is a net loss for the year so shown as zero." This shows recognition that LTCG is a loss, but the loss is not netted against STCG as required by Procedure 4.4. Instead, the draft allocates distributions to STCG without the loss offset.

### Corrected Figures

- **September current:** NII $0.0000 (0.0%), STCG $0.0000 (0.0%), ROC $0.1150 (100.0%)
- **FYTD cumulative:** NII $0.6578 (52.8%), STCG $0.3295 (26.5%), ROC $0.2578 (20.7%)

### Impact of the Error

| Item | Draft | Corrected | Difference |
|------|-------|-----------|-----------|
| Sept NII/share | $0.0586 | $0.0000 | −$0.0586 |
| Sept STCG/share | $0.0254 | $0.0000 | −$0.0254 |
| Sept ROC/share | $0.0310 | $0.1150 | +$0.0840 |
| FYTD NII/share | $0.6354 | $0.6578 | +$0.0224 |
| FYTD STCG/share | $0.5104 | $0.3295 | −$0.1809 |
| FYTD ROC/share | $0.0992 | $0.2578 | +$0.1586 |

The cumulative STCG/ROC error is material at the $0.1809 level, well above the $0.01 "significant change" threshold in Procedure 5.1.

---

## Question: Can We Align with Tax Team's Estimate?

Talia Ruiz asked whether we can align the 19(a) notice with the tax team's estimate, which shows:
- Ordinary income (NII + STCG): $0.9412/share
- Long-term capital gains: $0.3038/share  
- Return of capital: $0.0000/share

**Answer: No, we cannot and should not.**

**Reason 1 — Procedural Prohibition:**  
Procedure 4.1 explicitly states:
> "Sources are determined, or reasonably estimated, from the Fund's accounting records (US GAAP book basis)…Tax-basis character estimates prepared for Form 1099-DIV are **not** used for Section 19(a) purposes."

The tax team's estimate is prepared for Form 1099-DIV federal income tax reporting. By definition, it cannot be used for the Section 19(a) notice. They use different bases (tax vs. book) and different treatment of deferred losses, straddle deferrals, wash-sale adjustments, and REIT/MLP recharacterizations.

**Reason 2 — Even with Book Basis, ROC Is Significant:**  
Even when using the correct book-basis accounting with proper loss netting (as required), the ROC comes to 20.7% of distributions, not zero. The difference stems from:
1. Book/tax differences in loss recognition and timing
2. The specific net loss position in LTCG this year

The two estimates will naturally diverge; this is expected and compliant.

---

## Performance and Disclosure Metrics (Verified)

The following metrics in the draft are **correct**:

- **Annualized distribution rate (9.15% of NAV at 8/31/2026):** ✓ Correct  
  Calculation: ($0.1150 × 12) / $15.4180 = 8.95% (rounded)

- **Cumulative fiscal YTD distribution rate (8.08% of NAV at 8/31/2026):** ✓ Correct  
  Calculation: $1.2450 / $15.4180 = 8.08%

- **5-year average annual total return (7.84%):** ✓ From performance summary file

- **Cumulative total return fiscal YTD (9.12%):** ✓ From performance summary file

- **Section 19(a) notice required?:** ✓ Yes  
  Distribution is not entirely from NII, so notice is required per Procedure 2.1.

- **Deficit statement required?:** ✓ No  
  Fund has positive accumulated gains and unrealized appreciation per capital accounts; no deficit exists.

---

## Escalation Issues

The corrected figures reveal two systemic issues requiring escalation:

### Issue 1: Apparent Non-Compliance in August Notice

The August notice (approved and sent on 2026-08-25) shows STCG at $0.4849 cumulative, but loss-netted calculation produces $0.3202. This suggests Procedure 4.4 was not applied in August either.

**Required action:** Escalate to Treasurer and CCO for clarification of whether this was intentional, an oversight, or a misinterpretation of the procedures.

### Issue 2: Marketing Pressure vs. Compliance

Talia Ruiz has requested alignment with the tax team's zero-ROC estimate to manage investor communications ("optics"). While understandable from a marketing perspective, compliance with Procedure 4.1 is non-negotiable. The 19(a) notice must use book basis; the tax estimate is off-limits.

**Required action:** Escalate to Treasurer to explain the procedural constraint to marketing.

---

## Assumptions and Caveats

1. **Shares outstanding:** Assumed constant at 18,420,000 throughout FY2026 per capital accounts (no issues or repurchases).

2. **NII forecast:** Relied on 2026-09-24 forecast of $265,910 for Sept 24–30. Actual will be determined when close-of-month books are finalized; the notice is based on "reasonably estimated" amounts per Procedure 4.1.

3. **Realized gains:** Per Procedure 4.3, realized gains are not forecast; only actual through 9/23 (daily NAV date) are used.

4. **Loss netting application:** Interpreted Procedure 4.4 strictly as written—LTCG losses offset STCG available amount. If this procedure has been modified or reinterpreted since adoption, written guidance should be obtained.

5. **Tax estimate comparison:** Included for context only; not used in any calculation per Procedure 4.1.

---

## Recommendations

1. **Do not release the draft notice in its current form.** Material revisions required.

2. **Implement loss netting per Procedure 4.4** in both the September notice and (if necessary) corrected communication regarding August.

3. **Escalate to CCO** for compliance review of August notice and review of whether procedures have been systematically misapplied.

4. **Request clarification from Treasurer** on whether Procedure 4.4 interpretation has changed, with written confirmation of correct future application.

5. **Explain to Talia Ruiz** that Section 19(a) basis and tax reporting basis must differ; tax basis results (Form 1099-DIV) will be separate from book basis notice.

6. **Include statement in notice** (required by Procedure 5.1) noting that "previously reported estimates have changed" due to refinement of realized loss information.

---

## Workpaper Support

Detailed Excel-style calculations available upon request, including:
- Monthly accounting data rollup and verification
- Loss netting computation
- Allocation table (NII → STCG → LTCG → ROC in order)
- Per-share and percentage conversion
- Comparison of draft vs. corrected figures

