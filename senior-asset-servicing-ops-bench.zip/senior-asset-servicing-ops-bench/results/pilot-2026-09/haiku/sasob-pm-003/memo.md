# GAOF II Second Closing - Equalization Numbers Memo

**To:** Priya Sethi, Head of Investor Services — Halcyon Private Fund Services  
**From:** Analysis Team  
**Date:** 17 September 2026  
**Subject:** GAOF II Second Closing (30 Sep 2026) — Equalization Calculations and Compliance Notes

---

## Executive Summary

Equalization calculations for the GAOF II second closing on 30 September 2026 are complete, working from the Fund II LPA rather than replicating Fund I's approach. The closing will admit **LP-0206 (Tamsin Bay, USD 50mm)** and **LP-0207 (Ostrander County, USD 35mm)**. LP-0208 (Sable Point, USD 40mm) is deferred to 15 December 2026.

**Key divergence from GP's Fund I approach:** The GAOF II LPA limits the Additional Amount to 8% interest on equalization contributions only, and specifies it must be distributed to existing partners (not treated as fund income). The GP's Fund I method charged interest on all capital contributions including management fees, and ran the interest through the fund waterfall as other income.

**Compliance flag:** LP-0206's side letter requests a waiver of the Additional Amount, but the GP declined without seeking LPAC consent as required by LPA Section 3.4(g).

---

## Closing Population

### Admitted at Second Closing (30 Sep 2026)

- **LP-0206** (Tamsin Bay Insurance Company): USD 50,000,000 commitment  
  Status: READY. Subscription docs complete, KYC cleared 2026-09-04, side letter executed 2026-09-11, wire instructions verified by call-back 2026-09-14.

- **LP-0207** (Ostrander County Firefighters' Retirement Fund): USD 35,000,000 commitment  
  Status: READY. Subscription docs complete, KYC cleared 2026-09-09, board approval minute received.

### Deferred to Third Closing (15 Dec 2026)

- **LP-0208** (Sable Point Private Markets Access Fund): USD 40,000,000 commitment  
  Status: DEFERRED per email from Owen Blackwood, 2026-09-16. IC approval slipped; UBO certification outstanding. Side letter status: DRAFT (not executed). AML/KYC status: OPEN. Do not include in 30 Sep closing.

---

## Capital Base for Equalization

### Non-Fee Capital Contributions Before Closing

Calculated from capital_activity_GAOF_II_20260917.csv, excluding all Management Fee entries:

| Call | Description | Date Noticed | Amount |
|------|---|---|---|
| 1 | Organizational/initial partnership expenses | 2 Feb 2026 | USD 1,020,000.00 |
| 2 | Investment (Project Wren) + partnership expenses | 18 Mar 2026 | USD 30,855,000.00 |
| 3 | Investment (Project Tern) + partnership expenses | 16 Jun 2026 | USD 20,527,500.00 |
| **Total** | | | **USD 52,402,500.00** |

### Existing Partners at Second Closing

- GP-0200: USD 5,000,000
- LP-0201: USD 75,000,000
- LP-0202: USD 60,000,000
- LP-0203: USD 50,000,000
- LP-0204: USD 40,000,000
- LP-0205: USD 25,000,000
- **Subtotal:** USD 255,000,000

### Post-Closing Totals

- **Incoming LPs:** USD 85,000,000 (LP-0206 + LP-0207)
- **Total Commitments After Closing:** USD 340,000,000
- **Funded Percentage:** 15.4125% (USD 52.4mm / USD 340mm)

---

## Equalization Calculations

All calculations follow **LPA Section 3.4 — Subsequent Closings**, working from the executed agreement, not Fund I precedent.

### LP-0206 (Tamsin Bay Insurance Company, USD 50mm)

**Commitment Percentage After Closing:** 50,000,000 / 340,000,000 = 14.7059%

#### Equalization Contribution
Per LPA Section 3.4(a): Commitment % × Aggregate prior non-fee Capital Contributions
- **14.7059% × USD 52,402,500 = USD 7,706,250.00**
- Reduces unfunded commitment

#### Management Fee Catch-Up
Per LPA Section 3.4(c): Fee-Paying Partners pay the Management Fee they would have paid from Initial Closing Date through end of quarter of Subsequent Closing.
- **Rate:** 1.75% per annum (reduced from standard 2% per side letter SL-OF2-004)
- **Period:** 2 Feb 2026 to 30 Sep 2026 = 241 calendar days (Q1: 58 days, Q2: 91 days, Q3: 92 days)
- **Fee:** 1.75% × USD 50,000,000 × (241/365) = **USD 577,739.73**
- Paid to Manager
- Reduces unfunded commitment

#### Additional Amount (8% Interest)
Per LPA Section 3.4(d): 8% per annum simple interest on the portion of each prior Capital Contribution attributable to this LP, calculated from the due date of that contribution to closing date (actual days / 365).

Due dates (10 business days from notice per LPA Section 3.3):
- Call 1 (noticed 2 Feb): due ~17 Feb 2026
- Call 2 (noticed 18 Mar): due ~1 Apr 2026
- Call 3 (noticed 16 Jun): due ~1 Jul 2026

| Call | LP-0206's Share | Due Date | Days to Closing | Interest Calculation | Amount |
|------|---|---|---|---|---|
| 1 | 14.7059% × USD 1,020,000 = USD 150,000 | 17 Feb | 225 | 8% × 150,000 × (225/365) | USD 7,397.26 |
| 2 | 14.7059% × USD 30,855,000 = USD 4,535,000 | 1 Apr | 182 | 8% × 4,535,000 × (182/365) | USD 181,002.74 |
| 3 | 14.7059% × USD 20,527,500 = USD 3,020,000 | 1 Jul | 91 | 8% × 3,020,000 × (91/365) | USD 60,209.59 |
| **Total Additional Amount** | | | | | **USD 248,609.59** |

**Important note:** The interest is calculated on the equalization contribution portion only. LPA Section 3.4(d) limits the interest base to the Capital Contribution amount (not management fees). This differs from GP's Fund I approach, which charged interest on all contributions including management fees.

#### LP-0206 Total Wire Amount (30 Sep 2026)
- Equalization contribution: USD 7,706,250.00
- Management fee: USD 577,739.73
- Additional amount: USD 248,609.59
- **Total: USD 8,532,599.32**

Unfunded commitment after closing: USD 50,000,000 - USD 7,706,250.00 = **USD 42,293,750.00**

---

### LP-0207 (Ostrander County Firefighters' Retirement Fund, USD 35mm)

**Commitment Percentage After Closing:** 35,000,000 / 340,000,000 = 10.2941%

#### Equalization Contribution
Per LPA Section 3.4(a):
- **10.2941% × USD 52,402,500 = USD 5,394,375.00**
- Reduces unfunded commitment

#### Management Fee Catch-Up
Per LPA Section 3.4(c): Standard 2.00% annual rate (no side letter adjustment)
- **Fee:** 2.00% × USD 35,000,000 × (241/365) = **USD 462,191.78**
- Paid to Manager
- Reduces unfunded commitment

#### Additional Amount (8% Interest)

| Call | LP-0207's Share | Due Date | Days to Closing | Interest Calculation | Amount |
|------|---|---|---|---|---|
| 1 | 10.2941% × USD 1,020,000 = USD 105,000 | 17 Feb | 225 | 8% × 105,000 × (225/365) | USD 5,178.08 |
| 2 | 10.2941% × USD 30,855,000 = USD 3,175,000 | 1 Apr | 182 | 8% × 3,175,000 × (182/365) | USD 126,701.92 |
| 3 | 10.2941% × USD 20,527,500 = USD 2,115,000 | 1 Jul | 91 | 8% × 2,115,000 × (91/365) | USD 42,146.71 |
| **Total Additional Amount** | | | | | **USD 174,026.71** |

#### LP-0207 Total Wire Amount (30 Sep 2026)
- Equalization contribution: USD 5,394,375.00
- Management fee: USD 462,191.78
- Additional amount: USD 174,026.71
- **Total: USD 6,030,593.49**

Unfunded commitment after closing: USD 35,000,000 - USD 5,394,375.00 = **USD 29,605,625.00**

---

## Distributions to Existing Partners

Per LPA Section 3.4(b), equalization contributions are distributed to Existing Partners pro rata to their commitments. Per LPA Section 3.4(e), additional amounts are also distributed to Existing Partners pro rata to commitments. Management fees are paid to the Manager.

### Aggregates
- **Total Equalization Contributions (incoming LPs):** USD 13,100,625.00
- **Total Management Fees (paid to Manager):** USD 1,039,931.51
- **Total Additional Amounts:** USD 422,636.30

### Distribution Percentages (by Existing Partner Commitment)
- GP-0200: 5,000,000 / 255,000,000 = 1.9608%
- LP-0201: 75,000,000 / 255,000,000 = 29.4118%
- LP-0202: 60,000,000 / 255,000,000 = 23.5294%
- LP-0203: 50,000,000 / 255,000,000 = 19.6078%
- LP-0204: 40,000,000 / 255,000,000 = 15.6863%
- LP-0205: 25,000,000 / 255,000,000 = 9.8039%

### Existing Partner Receipts

| Partner | Equalization Received | Additional Received | Manager Fee (GP only) | Total Received | Unfunded After |
|---------|---|---|---|---|---|
| **GP-0200** | USD 256,875.00 | USD 8,286.99 | USD 1,039,931.51 | **USD 1,305,093.50** | USD 5,000,000.00 |
| **LP-0201** | USD 3,853,125.00 | USD 124,304.79 | — | **USD 3,977,429.79** | USD 75,000,000.00 |
| **LP-0202** | USD 3,082,500.00 | USD 99,443.84 | — | **USD 3,181,943.84** | USD 60,000,000.00 |
| **LP-0203** | USD 2,568,750.00 | USD 82,869.86 | — | **USD 2,651,619.86** | USD 50,000,000.00 |
| **LP-0204** | USD 2,055,000.00 | USD 66,295.89 | — | **USD 2,121,295.89** | USD 40,000,000.00 |
| **LP-0205** | USD 1,284,375.00 | USD 41,434.93 | — | **USD 1,325,809.93** | USD 25,000,000.00 |
| **Totals** | **USD 13,100,625.00** | **USD 422,636.30** | **USD 1,039,931.51** | **USD 14,563,192.81** | — |

**Important:** Equalization distributions are treated as returns of Capital Contributions per LPA Section 3.4(b) and are added back to unfunded commitments (so unfunded commitment percentages remain unchanged for existing partners). Additional amounts are not treated as fund income per LPA Section 3.4(e); they are distributed to partners pro rata.

---

## Post-Closing Commitment Percentages

Calculated as each Partner's commitment / total commitments (USD 340mm):

| Partner | Commitment | Percentage |
|---------|---|---|
| GP-0200 | USD 5,000,000 | 1.4706% |
| LP-0201 | USD 75,000,000 | 22.0588% |
| LP-0202 | USD 60,000,000 | 17.6471% |
| LP-0203 | USD 50,000,000 | 14.7059% |
| LP-0204 | USD 40,000,000 | 11.7647% |
| LP-0205 | USD 25,000,000 | 7.3529% |
| LP-0206 | USD 50,000,000 | 14.7059% |
| LP-0207 | USD 35,000,000 | 10.2941% |
| **Total** | **USD 340,000,000** | **100.0000%** |

---

## Divergences from GP's Fund I Approach

1. **Interest on Management Fees:** Fund I charged 8% interest on all capital contributions including management fees, calculated as fund income running through the waterfall. **GAOF II LPA Section 3.4(d) limits the Additional Amount to interest on equalization contributions only** (the capital contribution portion, excluding management fees).

2. **Treatment as Fund Income:** Fund I treated interest as other income. **GAOF II LPA Section 3.4(e) specifies the Additional Amount is NOT income of the Partnership and is NOT taken into account in determining distributions under Article 9**; it must be distributed to existing partners pro rata to commitments.

3. **Interest Rate Calculation:** Both funds use 8% simple interest, but the base differs (see point 1 above).

### Impact on Incoming LPs
The GAOF II methodology results in **lower** additional amounts for incoming LPs, compared to Fund I's approach:
- LP-0206: USD 248,609.59 (vs. approximately USD 350,000+ under Fund I methodology if interest included management fees)
- LP-0207: USD 174,026.71 (vs. approximately USD 245,000+ under Fund I methodology)

---

## Compliance Issues

### LP-0206 — Additional Amount Waiver Without LPAC Consent

**Finding:** Side letter SL-OF2-004 Section 2.2 states: *"None. Tamsin Bay requested a waiver of the Additional Amount; GP declined (LPAC consent not sought)."*

**LPA Requirement:** LPA Section 3.4(g) states: *"The General Partner may reduce or waive the Additional Amount for any Subsequent Partner only with the consent of the Advisory Committee."*

**Issue:** The GP declined the waiver without seeking LPAC consent. Under the LPA, any waiver requires LPAC approval.

**Treatment:** We are charging the full Additional Amount (USD 248,609.59) to LP-0206. **Recommend escalation to LPAC to determine whether:**
1. LPAC ratification of the GP's decision to decline the waiver is required, or
2. The LPAC should be asked to reconsider the waiver request with full information.

---

## Open Questions / Information Needed

1. **Confirm Capital Call Due Dates:** Our calculations assume 10 business days after notice per LPA Section 3.3. Confirm actual due dates for calls 1, 2, and 3. If they differ from our assumptions (17 Feb, 1 Apr, 1 Jul), we must recalculate the Additional Amount (interest accrual depends on the number of days from due date).

2. **LPAC Approval Requirement:** Clarify whether LPAC approval must be obtained for the GP's decision to decline LP-0206's waiver request before closing. LPA Section 3.4(g) requires LPAC consent for any waiver.

3. **Accounting Treatment of Additional Amount:** Confirm with fund accounting team that Additional Amount receipts are NOT booked as fund income/other income, but are distributed to partners' capital accounts. Per LPA Section 3.4(e), these are not income of the Partnership and do not run through the waterfall.

4. **Q4 Management Fee Timing:** Email 2026-09-16 from Owen Blackwood states the Q4 management fee call goes out separately on 1 October and is not part of the closing. Confirm this is the intended treatment.

---

## Key Figures for Funds Flow Memo and Closing Notices

### What Each Incoming LP Wires on 30 Sep 2026

**LP-0206 (Tamsin Bay Insurance Company):**
- Equalization contribution: USD 7,706,250.00
- Management fee catch-up: USD 577,739.73
- Additional amount: USD 248,609.59
- **Total wire: USD 8,532,599.32**

**LP-0207 (Ostrander County Firefighters' Retirement Fund):**
- Equalization contribution: USD 5,394,375.00
- Management fee catch-up: USD 462,191.78
- Additional amount: USD 174,026.71
- **Total wire: USD 6,030,593.49**

### What Each Existing Partner Receives on 30 Sep 2026

**GP-0200 (Granite Arch Opportunities GP II, LLC):**
- Equalization distribution: USD 256,875.00
- Additional amount distribution: USD 8,286.99
- Manager fee (from incoming LPs' catch-up): USD 1,039,931.51
- **Total received: USD 1,305,093.50**

**LP-0201 (Commonwealth of Aldermoor SERS):**
- Equalization distribution: USD 3,853,125.00
- Additional amount distribution: USD 124,304.79
- **Total received: USD 3,977,429.79**

**LP-0202 (Brightwater Teachers' Pension):**
- Equalization distribution: USD 3,082,500.00
- Additional amount distribution: USD 99,443.84
- **Total received: USD 3,181,943.84**

**LP-0203 (Meridian Crossing Fund of Funds III):**
- Equalization distribution: USD 2,568,750.00
- Additional amount distribution: USD 82,869.86
- **Total received: USD 2,651,619.86**

**LP-0204 (Trustees of Northfield University Endowment):**
- Equalization distribution: USD 2,055,000.00
- Additional amount distribution: USD 66,295.89
- **Total received: USD 2,121,295.89**

**LP-0205 (Harrowgate Holdings LLC):**
- Equalization distribution: USD 1,284,375.00
- Additional amount distribution: USD 41,434.93
- **Total received: USD 1,325,809.93**

---

## Post-Closing Fund Status

| Metric | Value |
|--------|-------|
| Total Commitments | USD 340,000,000 |
| Total Non-Fee Capital Contributions | USD 52,402,500 |
| Funded Percentage | 15.4125% |
| Number of Partners | 8 (GP-0200 + 7 LPs) |
| GP Commitment % | 1.4706% |
| Largest LP Commitment % | 22.0588% (LP-0201) |

---

## Sources and Assumptions

### Input Files Used
1. `partner_register_GAOF_II_20260917.csv` — Partner commitments and status
2. `capital_activity_GAOF_II_20260917.csv` — Capital contributions by call
3. `GAOF_II_LPA_excerpt_closings_fees.md` — LPA Sections 3.3, 3.4, 8.1
4. `side_letter_terms_summary_GAOF_II.csv` — Management fee rates and Additional Amount waiver
5. `second_closing_checklist_20260917.csv` — Status of each incoming LP
6. `2026-09-17_brandt_equalization_first_cut.txt` — GP's Fund I methodology for reference
7. `2026-09-16_blackwood_second_close_update.txt` — Confirmation that LP-0208 is deferred

### Assumptions
1. **Capital Call Due Dates:** Assumed 10 business days from notice per LPA Section 3.3. Call 1 (noticed 2 Feb) due ~17 Feb; Call 2 (noticed 18 Mar) due ~1 Apr; Call 3 (noticed 16 Jun) due ~1 Jul. **Confirm with GP.**
2. **Management Fee Period:** Calculated from Initial Closing Date (2 Feb 2026) through end of Q3 (30 Sep 2026) = 241 calendar days.
3. **LP-0208 Exclusion:** Excluded from second closing per Owen Blackwood email 2026-09-16. Equalization numbers calculated for LP-0206 and LP-0207 only.
4. **Interest Calculation:** Simple interest, actual days elapsed / 365, rounded to nearest cent per LPA Section 3.4(f).
5. **Rounding:** All figures rounded to nearest cent. Any residual from rounding is allocated to GP per LPA Section 3.4(f).

---

## Next Steps

1. **Confirm capital call due dates** with GP before finalizing closing numbers (impacts Additional Amount calculation).
2. **Escalate LP-0206 Additional Amount waiver issue** to LPAC for approval/ratification per LPA Section 3.4(g).
3. **Verify wire instructions** to incoming LPs and distribute finalized equalization breakdowns.
4. **Post accounting entries** for equalization distributions and additional amount distributions to capital accounts.
5. **Notify Manager** of management fee catch-up amounts due from incoming LPs on closing date.
6. **Update partner register** to reflect post-closing commitment percentages and funded status.

---

**Prepared by:** Analysis Team  
**Date:** 17 September 2026
