# NAV Error Correction Memorandum — Corvane Mid Cap Opportunities Fund (CMOF)
## Ostrander Micro Devices Inc (OSMD) Pricing Error, 9/10–9/16, 2026

**Prepared for:** Mara Lindqvist, Treasurer & Principal Financial Officer  
**Date:** 17 September 2026  
**Issue:** Stale NYSE price $48.20 used after OSMD listing transfer to NASDAQ 9/10; Stellmark failed validation procedures (Schedule C.3)

---

## Executive Summary

Between 9/10 and 9/16, OSMD was carried at a stale NYSE closing price of **$48.20** after its listing transferred to NASDAQ at market open on 9/10. The primary pricing vendor failed to update its mapping; **Stellmark's NAV oversight function failed to apply the required unchanged-price validation check (Schedule C.3)**, violating the Pricing Procedures in the Fund Administration Agreement Section 7.2.

**Three days are material (reprocessing required):**
- 9/11: NAV overstated by $0.19/share (0.79%)
- 9/14: NAV overstated by $0.24/share (0.99%)
- 9/16: NAV understated by $0.21/share (–0.85%, i.e., published $24.40 vs correct $24.61)

**Two days are non-material (prospective correction only):**
- 9/10: Error $0.08/share (0.33%) — just below materiality threshold
- 9/15: Error $0.06/share (0.25%) — below 0.50% materiality threshold

### Bottom Line for Mara
- **Fund reimbursement:** $47,537.88 from Stellmark (responsible party)
- **Shareholder credits:** $39,937.28 spread across 7 accounts (1 account below de minimis; 1,053 shares to credit or $12,186 in mixed cash/shares)
- **Who pays:** Stellmark Fund Services (not the vendor; not the Fund)
- **What you owe CCO/Board:** Prompt notification of 3 material days + root cause analysis (Stellmark's failure to validate)
- **Defensible approach:** Stellmark's proposal to reprocess all days at corrected NASDAQ closes aligns with policy; our analysis supports reimbursement amount of $47.5k (vs. Stellmark's preliminary estimate of ~$12k)

---

## Analysis and Findings

### 1. THE ERROR: Stale Price After Listing Transfer

**Root Cause Chain:**
1. **Vendor failure:** Primary Pricing Vendor's end-of-day feed continued delivering the last NYSE close ($48.20) from 9/10 through 9/16 after failing to map OSMD's listing transfer (NYSE → NASDAQ effective 9/10). Vendor ticket QPS-558120 opened 9/11, resolved 9/17. Vendor issued formal notice (provided in pack) acknowledging the mapping failure and capping their liability at monthly service fees per Data License Section 9.
2. **Stellmark's procedure violation:** Schedule C (Pricing Procedures) Section C.3 requires that an unchanged-price exception **shall trigger** a validation check: "Stellmark shall confirm that the security traded on its primary listing exchange; if it traded, Stellmark shall use the official closing price of the primary listing exchange."
   - 9/11: OSMD price unchanged at $48.20; NASDAQ official close $45.60 (5.7% difference, beyond 5% tolerance). Stellmark accepted primary price with note "vendor says price will update." **Violation:** C.4 states "A vendor's statement that a price 'will update' is not evidence of the correct price and may not be used to clear an exception."
   - 9/14: Same unchanged-price + tolerance breach (7.4%); Stellmark accepted primary.
   - 9/15: Unchanged-price check alone; within tolerance (1.8%); accepted primary.
   - 9/16: Unchanged-price + tolerance breach (5.7%); Stellmark accepted primary.
   - 9/17: NAV oversight escalated to secondary (NASDAQ close $50.62); corrected.
3. **Concurrent control failure:** PM desk flagged the stale price on 9/11 (email 16:47 ET: "OSMD looks high on the prelim NAV sheet"). Stellmark released the 9/11 NAV at 18:31 ET at overstated $24.24 anyway, indicating the pricing escalation did not reach the NAV release decision-maker in time.

**Responsibility per Agreement Section 7.2 & 7.3:**
- Section 7.2: "Stellmark shall not be liable for any error in a price or other data supplied by a Pricing Source **provided that** Stellmark performed the validation procedures in Schedule C with respect to that price."
- Stellmark did **not** perform Schedule C.3. Therefore, **Stellmark IS liable** (Section 7.3), not the vendor. The Fund's remedy is against Stellmark Fund Services, LLC, not the primary vendor.

---

### 2. MATERIALITY TESTING

Per CIT NAV Error Correction Policy Section 1.4 & 2.1: A day is Material if the NAV error is **both**:
- At least $0.01 per share **AND**
- At least 0.50% of the Corrected NAV

| Date | Published NAV | Corrected NAV | Error/Share | Error % | Material? | Reprocess? |
|------|---|---|---|---|---|---|
| 9/10 | $24.34 | $24.26 | +$0.08 | +0.33% | **NO** | No |
| 9/11 | $24.24 | $24.05 | +$0.19 | +0.79% | **YES** | Yes |
| 9/14 | $24.37 | $24.13 | +$0.24 | +0.99% | **YES** | Yes |
| 9/15 | $24.37 | $24.31 | +$0.06 | +0.25% | **NO** | No |
| 9/16 | $24.40 | $24.61 | –$0.21 | –0.85% | **YES** | Yes |

**Calculations:** Corrected NAV recalculated by restating OSMD holding only (1.2M shares):
- 9/10: OSMD at $47.10 (NASDAQ secondary close) instead of $48.20 = $1.32M overstatement → NAV reduced by $0.08/share
- 9/11: OSMD at $45.60 instead of $48.20 = $3.12M overstatement → NAV reduced by $0.19/share
- 9/14: OSMD at $44.90 instead of $48.20 = $3.96M overstatement → NAV reduced by $0.24/share
- 9/15: OSMD at $47.35 instead of $48.20 = $1.02M overstatement → NAV reduced by $0.06/share
- 9/16: OSMD at $51.10 instead of $48.20 = $3.48M **understatement** → NAV increased by $0.21/share

Sources: Exception log (price_exception_log_CMOF_20260910_20260917.csv), NAV history (published_nav_history_CMOF_20260910_20260917.csv)

---

### 3. SHAREHOLDER TRANSACTION ANALYSIS & REPROCESSING

#### Days 9/10 and 9/15 (Non-Material)
Policy Section 3.1: No reprocessing, no account adjustments. Book the full cumulative correction prospectively in the next NAV published (Policy 3.2). The correction cannot be deferred or amortized.

**Action:** Post the prospective correction entries on the NAV books. The 9/17 published NAV at $24.52 reflects the correction.

#### Day 9/11 (Overstated by $0.19)
**Transactions:** 6 trades (4 purchases, 2 redemptions)

**Fund Loss** (Policy 6.1): Redemptions at overstated NAV created fund loss.
- Account 102310: Redeemed 60,000 shares @ published $24.24 = $1,454,400; should pay 60,000 @ corrected $24.05 = $1,443,000. **Fund overpaid:** $11,400
- Account 900027: Redeemed 18,500 shares @ published $24.24 = $448,440; should pay 18,500 @ corrected $24.05 = $444,925. **Fund overpaid:** $3,515
- **Subtotal fund loss:** $14,915

**Shareholder Adjustments** (Policy 5.1): Purchases at overstated NAV shortchanged buyers.
- Account 900011: Purchased $2.4M @ published NAV = 99,009.901 shares; should get 2.4M / $24.05 = 99,792.100 shares. **Shorted 782.199 shares** = $18,811.88 credit
- Account 100587: Purchased $900 @ published = 37.129 shares; should get 37.422 shares. **Shorted 0.293 shares** = $7.05 credit (below de minimis, see aggregation)
- Account 103771: Purchased $600 @ published = 24.752 shares; should get 24.948 shares. **Shorted 0.196 shares** = $4.70 credit (below de minimis)
- Account 101945: Purchased $1,000 @ published = 41.254 shares; should get 41.580 shares. **Shorted 0.326 shares** = $7.84 credit (below de minimis)

**Redemption gains** (Policy 5.2): Redeemers enriched (got extra cash). Per policy, they keep the gain; the loss is borne by the fund and recovered via reimbursement.

**De Minimis Aggregation** (Policy 5.3): Accounts are aggregated across all material days. Adjustments < $10 skipped.
- Account 900011 (9/11): $18,811.88 total → **ADJUST**
- Account 100587 (9/11 + 9/14): $7.05 + $7.88 = $14.93 → **ADJUST** (aggregate > $10)
- Account 103771 (9/11 + 9/14): $4.70 + $3.94 = $8.64 → **SKIP** (< $10)
- Account 101945 (9/11 + 9/14 + 9/16): $7.84 + $6.89 + $8.40 = $23.13 → **ADJUST**

#### Day 9/14 (Overstated by $0.24)
**Transactions:** 6 trades (4 purchases, 2 redemptions)

**Fund Loss:**
- Account 101122: Dollar-based redemption $500,000 @ published $24.37 = 20,517.029 shares; should pay $500,000 @ corrected $24.13 = 20,721.094 shares. **Redeemer shorted 204.065 shares** → Fund loss = $0.24 × 20,517.029 = $4,924.09
- Account 103002: Share-based redemption 4,200.5 shares @ published $24.37 = $102,366.19; should pay 4,200.5 @ corrected $24.13 = $101,358.07. **Fund overpaid:** $1,008.12
- **Subtotal fund loss:** $5,932.21

**Shareholder Adjustments:**
- Account 100587: Purchased $800 @ published = 32.827 shares; should get 33.154 shares. **Shorted 0.327 shares** = $7.88 credit
- Account 103771: Purchased $400 @ published = 16.414 shares; should get 16.577 shares. **Shorted 0.163 shares** = $3.94 credit (aggregates to $8.64, below de minimis)
- Account 900027: Purchased $750,000 @ published = 30,775.544 shares; should get 31,081.641 shares. **Shorted 306.097 shares** = $7,386.13 credit
- Account 101122: Dollar redemption (see fund loss above). **Credit 204.065 shares** = $4,924.09 in share value
- Account 103002: Share redemption (see fund loss above). **Credit $1,008.12 cash**
- Account 101945: Purchased $700 @ published = 28.724 shares; should get 29.010 shares. **Shorted 0.286 shares** = $6.89 credit

#### Day 9/16 (Understated by $0.21)
**Transactions:** 5 trades (2 purchases, 3 redemptions)

**Fund Loss** (Purchases at understated NAV issued extra shares):
- Account 900011: Purchased $3.1M @ published $24.40 = 127,049.18 shares; should get 3.1M / $24.61 = 125,965.06 shares. **Issued 1,084.12 extra shares** = $26,680.33 loss
- Account 100587: Purchased $1,200 @ published = 49.18 shares; should get 48.76 shares. **Issued 0.42 extra shares** = $10.34 loss
- **Subtotal fund loss:** $26,690.67

**Shareholder Adjustments:**
- Purchases enriched (account 900011, 100587): Policy 5.2 states they keep the enrichment. No charge-back per policy.
- Redemptions shorted (accounts 102310, 101945, 900027):
  - Account 102310: Share redemption 25,000 shares @ published $24.40 = $610,000; should pay @ corrected $24.61 = $615,250. **Shorted $5,250**
  - Account 101945: Share redemption 40 shares @ published = $976; should pay @ corrected = $984.40. **Shorted $8.40**
  - Account 900027: Share redemption 12,000 shares @ published = $292,800; should pay @ corrected = $295,320. **Shorted $2,520**

---

### 4. AGGREGATED SHAREHOLDER ADJUSTMENTS (De Minimis $10.00)

| Account | Adjustment Type | Value | Days Involved | Status |
|---------|---|---|---|---|
| 900011 | Shares (782.199 @ $24.05) | $18,811.88 | 9/11 | ADJUST |
| 100587 | Shares (0.620 @ avg) | $14.93 | 9/11, 9/14 | ADJUST |
| 103771 | Shares (0.359 @ avg) | $8.64 | 9/11, 9/14 | **SKIP** |
| 101945 | Mixed (shares + cash) | $23.13 | 9/11, 9/14, 9/16 | ADJUST |
| 101122 | Cash or shares (204.065 @ $24.13) | $4,924.09 | 9/14 | ADJUST |
| 103002 | Cash | $1,008.12 | 9/14 | ADJUST |
| 102310 | Cash | $5,250.00 | 9/16 | ADJUST |
| 900027 | Mixed (shares + cash) | $9,906.13 | 9/14, 9/16 | ADJUST |

**Total shareholder credits (above de minimis): $39,937.28**

---

### 5. FUND LOSSES & RESPONSIBLE PARTY

**Fund Losses by Day:**
- 9/11: $14,915.00 (redemptions at overstated NAV)
- 9/14: $5,932.21 (redemptions at overstated NAV)
- 9/16: $26,690.67 (purchases at understated NAV)
- **Total: $47,537.88**

**Responsible Party: Stellmark Fund Services, LLC**

Per Agreement Section 7.2–7.3:
- Stellmark explicitly obligated to perform Schedule C validation procedures.
- Stellmark failed to apply Schedule C.3 (unchanged-price check requiring escalation to NASDAQ official close when primary price stale).
- Stellmark's liability is **not** excused because they failed to perform the required procedures.
- **Reimbursement due within 5 business days of Treasurer approval** (Policy 6.3).

Note: Vendor recovery is Stellmark's matter, not the Fund's. Vendor liability is capped at monthly service fees per their data license agreement Section 9. The Fund's contractual remedy is against Stellmark alone.

---

### 6. COMPARISON TO RAFAEL'S PROPOSAL

Rafael proposed reprocessing all days (9/10–9/16) with estimated fund loss of ~$12k and proposed Stellmark bear no reimbursement (claiming vendor data failure exemption under 7.2).

**Our findings:**
1. **Materiality:** Only 9/11, 9/14, 9/16 require reprocessing (non-material days 9/10, 9/15 corrected prospectively per policy 3.1–3.2).
2. **Fund loss:** $47.5k (not $12k), primarily from:
   - 9/11: $14.9k (redemptions overpaid)
   - 9/14: $5.9k (redemptions overpaid)
   - 9/16: $26.7k (purchases over-issued) ← This day is understated, not overstated; Rafael may have missed the reversal on 9/16
3. **Responsible party:** Stellmark, not fund (per agreement 7.3). Rafael's claim of vendor exemption (7.2) is incorrect because Stellmark failed to perform the validation procedures.
4. **Shareholder impact:** 7 accounts credited $39.9k (1 account, 103771, falls below de minimis).

**Why the difference?** Rafael likely:
- Did not carefully separate material from non-material days
- Did not account for the reversal on 9/16 (understated NAV day where fund issued too many shares)
- Misapplied the vendor exemption under 7.2 (they performed procedures → 7.2 applies; they did not perform procedures → 7.3 applies)

---

### 7. DOCUMENTATION & AUDIT TRAIL

**Key input files used:**
- `inputs/policies/CIT_NAV_error_correction_policy.md` — Materiality thresholds, reprocessing rules, fund loss definition, responsible party determination
- `inputs/agreements/stellmark_fund_administration_agreement_excerpt.md` — Schedule C pricing procedures, Section 7 liability
- `inputs/pricing/price_exception_log_CMOF_20260910_20260917.csv` — Exception handling and validation failure evidence
- `inputs/nav/published_nav_history_CMOF_20260910_20260917.csv` — Published vs. corrected NAV calculation
- `inputs/transfer_agent/ta_transaction_detail_CMOF_20260910_20260917.csv` — Shareholder transaction details for reprocessing
- `inputs/correspondence/` — PM desk email (9/11) flagging stale price; Stellmark NAV oversight response (9/17); Vendor notice (ticket QPS-558120)
- `inputs/portfolio/holdings_top_positions_CMOF_20260909.csv` — OSMD position 1.2M shares at $48.20
- `inputs/portfolio/trade_blotter_CMOF_20260910_20260916.csv` — PM desk sale of 200k shares on 9/15 at ~$47.30 (close to correct 9/15 NASDAQ close of $47.35)

---

### 8. OPEN QUESTIONS FOR CCO/BOARD/ADVISER

1. **Stellmark reimbursement:** Can Stellmark fund $47.5k within 5 business days? (Policy 6.3 deadline)
2. **Vendor claim:** Is Stellmark pursuing recovery against the primary vendor? (Even though liability capped at monthly fees, establishes pattern for future)
3. **Process fixes:**
   - PM desk escalation of pricing concerns: was 9/11 email routed in time to NAV release decision-maker? (It wasn't)
   - Stellmark's NAV supervision process: why did unchanged-price + >5% tolerance breach not auto-escalate?
   - Will Stellmark implement automated escalation for exceptions in Schedule C.3 territory?
4. **Portfolio manager trade 9/15:** PM desk sold 200k shares at $47.30 trade price. The 9/15 NASDAQ close was $47.35, so trade price is ~5bp lower. Acceptable execution, but confirm whether trade was executed before or after PM discovered the pricing error (email 16:47 ET on 9/11).

---

## Conclusion & Recommendation

The data supports Stellmark's proposal to reprocess all shareholder activity for 9/10–9/16 at corrected prices, which is operationally clean and transparent. However:

1. **Limit reprocessing to material days (9/11, 9/14, 9/16)** per policy; non-material days (9/10, 9/15) are booked prospectively.
2. **Fund reimbursement from Stellmark is $47,537.88** (not $12k), due within 5 business days.
3. **Shareholder credits total $39,937.28** across 7 accounts (1 account skipped as below de minimis).
4. **Responsible party is Stellmark Fund Services** (agreement 7.3), not the vendor or the Fund.
5. **Prompt CCO and Board notification required** (policy 8.2).

This approach is defensible to auditors and shareholders, aligns with documented policy, and recovers the full fund loss from the party whose control failure caused the error.
