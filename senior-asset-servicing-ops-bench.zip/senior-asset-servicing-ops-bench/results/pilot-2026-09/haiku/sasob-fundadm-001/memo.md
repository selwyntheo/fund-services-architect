# BFVF RIC Diversification Test Review — 8/31/2026
## Internal Memo: Fund Tax Review

**From:** Oakhurst Fund Administration, Fund Tax  
**To:** Elaine Marsh, Treasurer, Brightwater Series Trust  
**Date:** September 18, 2026  
**Re:** BFVF August 31, 2026 Quarter-End Diversification Test — Critical Finding

---

## EXECUTIVE SUMMARY

After independent review of Stella Albright's first-cut RIC diversification test, I must report that **BFVF fails both required tests** at August 31, 2026. Stella's calculation, which showed PASS, contains material errors in methodology and security classification.

**Key Findings:**
- **50% test:** Fund holds only 49.58% qualifying assets (requirement: ≥50%)
- **25% test:** Stonefield + Harrowgate controlled group at 26.49% (limit: 25%)
- **Failure Type:** Acquisition-related (Harrowgate purchases in July)
- **Cure Required:** Yes, by September 30, 2026
- **Minimum Cure:** Dispose $9,435,417 of Stonefield/Harrowgate securities
- **Board Certificate:** Cannot state compliance; must be held pending cure and re-test

---

## ERRORS IN STELLA'S FIRST-CUT

### Error 1: Wrong Denominator
Stella used **Net Assets** ($581,160,485) instead of the policy-required **Total Assets** ($634,087,614).

**Policy Reference:** Policy Section 3.1 explicitly states: "Total Assets — the Fund's gross total assets as shown on the statement of assets and liabilities at the testing date, **before deduction of any liabilities** (including borrowings)."

**Impact:** Using Net Assets artificially reduces the percentages, making non-qualifying assets appear smaller. This is why Stella's analysis showed Kinsale at 5.33% (failing the 5% limit under correct analysis) and calculated 68.66% qualifying when the correct figure is 49.58%.

### Error 2: Misclassified Pemberton Securities Repo
Stella classified the Pemberton repo (P005, $22,000,000) as a government security.

**Policy Reference:** Policy Section 3.4: "A repurchase agreement that is 'collateralized fully' by cash and/or Government securities...is treated as an investment in Government securities. **Any other repurchase agreement is treated as a security of the repo counterparty.**"

**Evidence:** Repo Confirmation RP-PEM-260831-07 (dated 8/31/26) states:
- Seller: Pemberton Securities LLC
- Collateral: Corporate debt securities (BBB-/Baa3 or better; includes high-yield)
- This is **NOT government collateral**

**Result:** P005 should be treated as a security of Pemberton Securities, not as a government security. Aggregated with P006 (Pemberton CP), Pemberton holdings total $34,030,425 = 5.37% of Total Assets, exceeding the 5% limit. Therefore, **neither P005 nor P006 qualifies** for the 50% test.

### Error 3: Misclassified Non-U.S. Sovereign
Stella listed Republic of Castellan sovereign bonds (P007, $38,501,600) as government securities.

**Policy Reference:** Policy Section 3.3: "Obligations of non-U.S. governments...are **not** Government securities; each such obligor is a separate issuer."

**Result:** Castellan bonds count as a "other security" subject to the 5% and 10% voting limits. At 6.07% of Total Assets, Castellan **fails the 5% limit** and does not qualify.

### Error 4: Incomplete Voting Analysis
Stella did not properly check voting percentages for all issuers. This led to missing:
- Harrowgate Materials voting at 24.80% (exceeds 10% limit; also controlled at 20%+)
- Tallis Midstream voting at 11.20% (exceeds 10% voting limit)
- Ormsby Logistics (bonds) voting at 22.47% (controlled)

---

## CORRECTED TEST RESULTS

### 50% Test Calculation (Using Total Assets = $634,087,614)

| Component | Value | Qualifies? |
|-----------|-------|-----------|
| Cash & Receivables | $11,483,826 | YES |
| Government Securities | $78,035,663 | YES |
| RIC Securities (P008, P009) | $43,900,000 | YES |
| Other Qualifying: |  |  |
| — Corbeck Pipeline (P016) | $11,199,760 | YES (1.77%, voting 1.10%) |
| — Norbeck Chemical (P017) | $6,001,800 | YES (0.95%, non-voting pfd) |
| — Pellham Instruments (P018) | $9,801,792 | YES (1.55%, voting 9.60%) |
| — Kinsale Robotics (P019) | $30,985,800 | YES (4.89%, voting 0.53%) |
| — Aldermoor Software (P020) | $24,500,000 | YES (3.86%, voting 0.24%) |
| — Brixton Health (P021) | $22,800,000 | YES (3.60%, voting 0.23%) |
| — Cadell Foods (P022) | $19,600,000 | YES (3.09%, voting 0.63%) |
| — Dunmore Insurance (P023) | $17,300,000 | YES (2.73%, voting 0.54%) |
| — Everly Consumer (P024) | $15,900,000 | YES (2.51%, voting 0.26%) |
| — Fenwick Semiconductor (P025) | $14,200,000 | YES (2.24%, voting 0.18%) |
| — Galloway Water (P026) | $8,700,000 | YES (1.37%, voting 0.63%) |
| | | |
| **Total Qualifying** | **$314,408,641** | |
| **Total Assets** | **$634,087,614** | |
| **Percentage** | **49.58%** | **FAIL** |
| **Requirement** | **≥50%** | |

**Failed to Qualify (Exceeds Limits):**
- Pemberton Securities: $34,030,425 (5.37% > 5% limit)
- Castellan Sovereign: $38,501,600 (6.07% > 5% limit)
- Stonefield Aggregates: $87,976,080 (13.87% of assets; 23.60% voting)
- Harrowgate Materials: $79,981,240 (12.61% of assets; 24.80% voting)
- Quillon Systems: $35,997,840 (5.68% > 5% limit)
- Ormsby Logistics (combined): $34,479,300 (5.44% > 5%; voting 24.18% on bond position)
- Tallis Midstream: $8,599,584 (1.36% OK, but voting 11.20% > 10% limit)

---

### 25% Test — Controlled Groups

The Fund controls two issuers (≥20% voting) in the same sub-industry:

**Construction Materials - Aggregates:**
- Stonefield Aggregates (ISS-0410): 23.60% voting | $87,976,080
- Harrowgate Materials (ISS-0411): 24.80% voting | $79,981,240
- **Group Total: $167,957,320 = 26.49% of Total Assets**

**Result: FAIL** (exceeds 25% limit by $9,435,417)

**QPTP Aggregate:** Tallis + Corbeck = $19,799,344 = 3.12% (PASS, under 25% limit)

---

## ACQUISITION-RELATED FAILURE ANALYSIS

Per Policy Section 6.2, if the Fund acquired securities of an issuer that contributes to a discrepancy, the failure is "acquisition-related" and a cure is required.

**Harrowgate Purchases During Q3:**

| Trade Date | Side | Quantity | Cost | Running Total |
|------------|------|----------|------|---|
| 7/14/26 | BUY | 640,000 | $7,052,800 | 640k |
| 7/15/26 | BUY | 610,000 | $6,819,800 | 1,250k |
| 7/16/26 | BUY | 578,500 | $6,508,125 | 1,828.5k |

**Fund Voting at Test Date:** 1,828.5k new shares + prior holdings = 6,572,000 total shares / 26.5M outstanding = 24.80% voting

**Effect:** Moved Harrowgate from non-controlled (<20% voting at 5/31) to controlled (24.80%) status, creating a new controlled group with Stonefield in the same sub-industry.

**Conclusion:** The 25% test failure is **wholly attributable to acquisition.** Per Policy 6.2, acquisition-related failures require cure.

---

## CURE REQUIREMENT & TIMELINE

**Deadline:** 30 calendar days after quarter-end = **September 30, 2026**

**Calculation:** To bring Stonefield + Harrowgate to exactly 25% of Total Assets:
- Current group value: $167,957,320 (26.49%)
- Target (25%): $158,521,903
- **Minimum disposal: $9,435,417**

**Effect of Cure:** Disposing $9.44M of non-qualifying assets (Stonefield/Harrowgate) and replacing with cash (which qualifies):
- New qualifying assets: $314,408,641 + $9,435,417 = $323,844,058
- New percentage: 51.07%
- **This also fixes the 50% test**

**Recommendations:**
1. Portfolio manager to select specific securities to dispose (choice between Stonefield, Harrowgate, or both)
2. Dispose by trade date of 9/30/26 (settlement can be later)
3. Hold proceeds in cash; do not reinvest
4. Consider disposal buffer above minimum to provide cushion
5. Re-test both diversification tests after cure is complete

---

## ACTIONS REQUIRED

### Immediate (Today/Tomorrow)
1. **Call with PM Kapoor:** Inform of test failures; request confirmation that portfolio manager will execute required disposals and commitment to trade by 9/30/26
2. **Notify Elaine Marsh:** Board certificate cannot state compliance; must be held pending cure and re-test
3. **File note in workpaper:** Document errors in Stella's first-cut and correction; retain as evidence of proper review

### By September 30
1. **Monitor cure trades:** Ensure $9.44M+ disposals are executed by deadline
2. **Schedule re-test:** Obtain final 8/31 valuations after cure settlement; re-run diversification tests
3. **Obtain evidence:** Trade confirmations, broker statements, cash deposit evidence

### After Cure (By October 10)
1. **Complete re-test:** Confirm both tests pass post-cure
2. **Update board certificate:** Release for signature once cure is confirmed
3. **Finalize workpaper:** Document cure activity, re-test results, and Board notification
4. **Close audit file:** Notify independent auditor of final results

---

## WHO TO CONTACT & WHAT TO SAY

### Elaine Marsh (Treasurer)
*"Stella's first-cut analysis showed PASS, but our independent review found BFVF fails both RIC tests at 8/31. The errors were: (1) using Net Assets instead of Total Assets denominator; (2) misclassifying corporate-backed repo and non-U.S. sovereign as government securities. Our corrected analysis shows 49.58% qualifying (need 50%) and 26.49% in Stonefield+Harrowgate controlled group (limit 25%). The failure is acquisition-related, so cure is mandatory by 9/30. We need Dev Kapoor to dispose minimum $9.44M of Stonefield/Harrowgate by trade date 9/30 to fix both tests. The Board certificate cannot state compliance until cure is complete and re-tested. I'm calling Dev this afternoon."*

### Dev Kapoor (PM)
*"Our fund tax review found that BFVF's diversification test failed on the Stonefield/Harrowgate controlled group, which hit 26.49% of assets at 8/31—over the 25% limit. Your July purchases of Harrowgate moved the fund to 24.80% voting, making it a controlled issuer in the same sub-industry as Stonefield. Per Fund policy, we need to cure by 9/30/26. Please dispose of minimum $9.44M (at 8/31 values) of either Stonefield, Harrowgate, or both, with proceeds held in cash. This brings the group to exactly 25% and also fixes a secondary 50% test issue. Can you confirm you're comfortable executing this and have a disposal plan?"*

### Independent Auditor
*"During our Q3 review, we identified that BFVF's August 31 RIC diversification test failed both the 50% and 25% tests. The failure was acquisition-related (Harrowgate purchases in July created a controlled group exceeding limits). Cure is required by 9/30/26, consisting of minimum $9.44M disposals. We are monitoring the cure and will re-test afterward. Full documentation will be in the audit file."*

---

## OPEN ITEMS

1. **Tallis Midstream Prior-Quarter Voting:** Confirm whether Tallis voting was already >10% at 5/31 or changed this quarter (no trades in blotter, so likely pre-existing)
2. **Pemberton Repo Collateral:** Verify from Pemberton/custodian that P005 collateral remains corporate bonds and has not changed
3. **Adviser Cure Intent:** Confirm whether adviser plans cash proceeds or reinvestment (must be cash or govt securities, not reinvestment, per policy)
4. **Harrowgate 13D:** Review July 2026 13D filing and confirm no special considerations affect voting calculation

---

## SUPPORTING DOCUMENTATION

- **Inputs Used:** BFVF_portfolio_valuation_20260831.csv, BFVF_statement_of_assets_and_liabilities_20260831.csv, issuer_master_extract_20260831.csv, BFVF_trade_blotter_20260601_20260831.csv, repo_confirmations_20260831.txt, BFVF_diversification_test_20260531_final.csv, BST_RIC_qualification_compliance_policy.md
- **Policy References:** Policy Sections 3.1, 3.3, 3.4, 4.1–4.3, 5.1–5.3, 6.1–6.5, 7.1–7.3
- **Methodology:** IRC §851(b)(3) with Policy 6.2 acquisition rule applied; conservative attribution standard
- **Data Verification:** Total Assets per Statement = $634,087,614 ✓; Security sum to portfolio total ✓; Voting calculations cross-checked

---

**Recommendation:** Do not release the Board compliance certificate pending completion of cure and re-test. Escalate findings to Board Audit Committee if Q3 compliance certificate was already issued to Board; such certificate would need to be corrected.

