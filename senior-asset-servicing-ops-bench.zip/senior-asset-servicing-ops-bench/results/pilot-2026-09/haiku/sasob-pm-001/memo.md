# MEMO: GACP IV Call #2 (Lanternfly) — Allocation Analysis and Notice Readiness

**TO:** Nadia Kowalczyk, Client Service Director, Halcyon Private Fund Services
**FROM:** Fund Operations Analysis
**DATE:** 5 October 2026
**RE:** Granite Arch Capital Partners IV, L.P. — Call #2 Notice Readiness Assessment

---

## EXECUTIVE SUMMARY

**Call #2 is substantially ready for portal delivery on Monday 5 October 2026 and contains no technical barriers to proceeding.** The per-partner allocation is complete and compliant with the LPA and confirmed side letters. However, **one material decision is pending: whether to excuse Kestrel Ridge College from the Lanternfly investment.**

### Total Call Amount: USD 45,766,400

| Component | Amount (USD) | Notes |
|-----------|------|-------|
| Portfolio Investment (Lanternfly) | 44,000,000 | Pro rata to non-excused commitments |
| Partnership Expenses (Q3 admin, audit, counsel) | 180,000 | Pro rata to all partner commitments |
| Management Fee (gross, 73 days Oct 20–Dec 31) | 1,983,000 | Based on commitment × rate × (73/365) |
| Management Fee Offset (Osprey break-up fee) | (396,600) | 80% of USD 495,750 received Aug 14 |
| **Management Fee (net)** | **1,586,400** | |
| **TOTAL CALL** | **45,766,400** | Due by Friday 16 October 2026 |

**Excused from Lanternfly investment:** Ostrander County Firefighters' Retirement Fund (LP-0106) only  
**Pending excuse determination:** Kestrel Ridge College (LP-0107)

---

## ALLOCATION DETAIL

### By Partner

| Partner ID | Investment | Expenses | MGT Fee (Gross) | MGT Fee (Offset) | MGT Fee (Net) | **TOTAL CALL** |
|-----------|------|-------|--------|--------|--------|--------|
| **GP-0100** | 960,000 | 3,600 | — | — | — | **963,600** |
| **LP-0101** | 8,000,000 | 30,000 | 350,000 | (70,000) | 280,000 | **8,310,000** |
| **LP-0102** | 7,200,000 | 27,000 | 315,000 | (63,000) | 252,000 | **7,479,000** |
| **LP-0103** | 12,000,000 | 45,000 | 450,000 | (90,000) | 360,000 | **12,405,000** |
| **LP-0104** | 6,000,000 | 22,500 | 262,500 | (52,500) | 210,000 | **6,232,500** |
| **LP-0105** | 4,800,000 | 18,000 | 210,000 | (42,000) | 168,000 | **4,986,000** |
| **LP-0106** | — | 15,000 | 175,000 | (35,000) | 140,000 | **155,000** |
| **LP-0107** | 2,000,000 | 7,500 | 87,500 | (17,500) | 70,000 | **2,077,500** |
| **LP-0108** | 3,040,000 | 11,400 | 133,000 | (26,600) | 106,400 | **3,157,800** |
| | | | | | |
| **TOTALS** | **44,000,000** | **180,000** | **1,983,000** | **(396,600)** | **1,586,400** | **45,766,400** |

---

## KEY FINDINGS

### 1. LANTERNFLY INVESTMENT ALLOCATION (USD 44,000,000)

**Status: COMPLIANT**

Per LPA Section 3.7(c), the investment amount is allocated pro rata to non-excused partners based on their commitments.

- **Ostrander (LP-0106)** is excused from this investment (excusal amount: USD 3,666,667)
- **Non-excused total commitment:** USD 550,000,000 (all partners except Ostrander)
- **Allocation method:** USD 44,000,000 ÷ USD 550,000,000 × each partner's commitment
- **115% cap check:** No partner pays more than 115% of their pro rata share (all range from 102.5% to 109%)

**Reference:** 
- Inputs: partner_register_GACP_IV_20260930.csv
- LPA Article 3.7(a)–(c)

---

### 2. PARTNERSHIP EXPENSES (USD 180,000)

**Status: COMPLIANT**

Partnership expenses (Q3 administration, audit accrual, fund counsel) are allocated pro rata to **all partners**, including Ostrander (LP-0106), per LPA Section 3.7(d):

> "An Excused Partner is excused only from the Capital Contribution for the Excused Investment itself. It remains obligated for its share of Management Fees and of Partnership Expenses, other than Partnership Expenses that are specifically attributable to the Excused Investment, which are borne by the non-excused Partners."

No expenses are identified as specifically attributable to Lanternfly in the GP CFO's submission, so Ostrander pays its full pro rata share (USD 15,000).

**Reference:**
- GP CFO email 2026-10-02: "Partnership Expenses (Q3 admin fee, audit accrual, fund counsel; invoices on the shared drive, none of it deal-related)"
- LPA Section 3.7(d), 8.4

---

### 3. MANAGEMENT FEE CALCULATION

**Status: COMPLIANT**

#### Fee Rates

Per LPA Section 8.1(a) and confirmed side letters:

- **GP-0100:** Fee-exempt (0%)
- **LP-0103 (Meridian Crossing):** 1.50% per annum per SL-IV-001 (size-based rate, excluded from MFN)
- **All other fee-paying partners:** 1.75% per annum per LPA default

**Reference:** side_letter_terms_summary_GACP_IV.csv (SL-IV-001 for LP-0103)

#### Fee Period & Proration

- **Fee Commencement Date:** 2026-10-20 (Lanternfly acquisition/closing date)
- **Period covered:** 2026-10-20 through 2026-12-31 (73 days, counting first and last day)
- **Pro-ration formula:** Annual fee × (73 ÷ 365) per LPA 8.1(c)
- **Gross MGT fee:** USD 1,983,000

**Reference:** LPA Section 8.1(b)–(c)

---

### 4. MANAGEMENT FEE OFFSET (USD 396,600)

**Status: COMPLIANT (with forward-looking question)**

Per LPA Section 8.2(a):

> "Each installment of the Management Fee is reduced by 80% of all Fee Income received by the Manager, the General Partner or their Affiliates on or before the date of the Drawdown Notice that calls that installment, to the extent not applied to reduce an earlier installment."

**Fee Income Applied:**
- Osprey break-up fee (FI-IV-0001): USD 495,750 (received 2026-08-14)
  - 80% of this = USD 396,600 ✓
  - Osprey expense reimbursement (FI-IV-0002): USD 118,400 — NOT counted as "Fee Income" because it is explicitly excluded per LPA definition as "reimbursement of out-of-pocket expenses"

**Fee Income NOT Yet Applied:**
- Lanternfly transaction fee (FI-IV-0003): USD 1,100,000
  - Status: EXPECTED (payable at closing 2026-10-20)
  - As of Drawdown Notice preparation date (2026-10-05), this fee has NOT been received
  - Call #2 due date is 2026-10-16, which is before Lanternfly closing (2026-10-20)
  - Per LPA 8.2(a), only fees "received by the date of the Drawdown Notice" count toward offset
  - **Action:** Confirm whether GP intends to estimate/apply the Lanternfly fee or defer it to a later installment

**Offset Allocation:**
USD 396,600 is allocated pro rata among fee-paying partners based on each partner's MGT fee for this installment, per LPA 8.2(b).

**Reference:**
- fee_income_register_GAM_FundIV_2026.csv
- LPA Section 8.2(a)–(b)
- LPA Article 1 definition of "Fee Income"

---

### 5. NOTICE PERIOD COMPLIANCE (DELIVERY 5 OCTOBER / DUE 16 OCTOBER)

**Status: COMPLIANT**

Per LPA Section 3.3(a):

> "The Due Date shall be no earlier than the tenth (10th) Business Day following the date on which the Drawdown Notice is delivered."

**Calculation:**
- **Notice delivery date (planned):** Monday 5 October 2026
- **10th Business Day after notice:** Friday 16 October 2026
  - (Counting only weekdays; Columbus Day on Monday 12 October is not a Federal Reserve Bank business day per holiday calendar)
- **Requested due date:** Friday 16 October 2026 ✓ **COMPLIANT**
- **Earliest compliant due date:** Friday 16 October 2026 (coincides with requested date)

Per LPA Section 11.2, a notice delivered via portal before 5:00 p.m. NY time on a Business Day is treated as delivered on that day. Confirm portal delivery time on 5 October to lock in this calculation.

**Reference:**
- LPA Section 3.3(a)
- holiday_calendar_2026H2.csv
- LPA Section 11.2
- GP CFO request: notice on portal Monday 5 October, money in by Friday 16 October

---

### 6. EXCUSAL DETERMINATIONS

#### OSTRANDER COUNTY FIREFIGHTERS' RETIREMENT FUND (LP-0106)

**Determination: EXCUSED — VALID**

- **Request date:** 24 September 2026
- **Basis:** Section 7-114(c) of the Ostrander County Retirement Code prohibits the Fund from holding >10% equity in firearms manufacturers
- **Supporting documentation:** Opinion of counsel (Pruett & Laine LLP, dated 23 September 2026)
- **GP acceptance:** Received and accepted by Rachel Oyelaran, General Counsel, 28 September 2026
- **Timeline:** Request submitted within the 10-business-day deadline (Investment Notice date 15 September; 10th business day is 29 September)
- **LPA compliance:** Meets all requirements of LPA Section 3.7(a)
- **Effect:** Excused from capital contribution to Lanternfly investment only; remains liable for pro rata MGT fees and partnership expenses per LPA 3.7(d)

**Reference:**
- correspondence/2026-09-24_ostrander_excuse_request.txt
- LPA Section 3.7(a)–(d)

#### KESTREL RIDGE COLLEGE (LP-0107)

**Determination: INFORMATION REQUIRED — NO VALID EXCUSE YET**

- **Request date:** 2 October 2026 (AFTER the 10-business-day deadline of 29 September)
- **Stated basis:** Halberd's 28% firearms revenue conflicts with College's Responsible Investment Policy
- **Supporting documentation:** KRC_Responsible_Investment_Policy_2025.pdf (College investment policy document)
- **LPA requirement:** LPA Section 3.7(a) requires "an opinion of counsel reasonably satisfactory to the General Partner that its participation would violate a law or regulation applicable to that Limited Partner"
- **Issue:** Policy document is not a legal opinion; does not satisfy "opinion of counsel" requirement
- **Timeline issue:** Request is 3 calendar days after the 10-business-day deadline
- **Available pathway:** LPA Section 3.7(b) grants GP discretionary authority to excuse any LP in writing, regardless of deadline or counsel opinion

**What is needed:**
1. **Either:** Obtain from Kestrel a legal opinion confirming that participation in Lanternfly would violate a law or regulation binding on the College (not merely the College's internal investment policy), AND request GP to accept this opinion under LPA 3.7(a)
2. **Or:** Request GP to exercise discretionary excusal authority under LPA 3.7(b) in writing

**Effect if excused:**
- Excused from capital contribution to Lanternfly investment only
- Remains liable for pro rata MGT fees (USD 87,500) and partnership expenses (USD 7,500)
- Lanternfly amount redistributed pro rata to non-excused partners per LPA 3.7(c)

**Effect if NOT excused:**
- Called for full pro rata Lanternfly investment (USD 2,000,000)
- Called for pro rata MGT fees and expenses as calculated above
- Total call to Kestrel: USD 2,077,500

**Reference:**
- correspondence/2026-10-02_kestrel_ridge_email.txt
- LPA Section 3.7(a)–(c)
- side_letter_terms_summary_GACP_IV.csv (no side letter exception for Kestrel)

---

## OPEN QUESTIONS FOR GP / RACHEL OYELARAN (GENERAL COUNSEL)

1. **Kestrel Ridge excuse decision (CRITICAL — blocks notice finalization):**
   - Does the GP consent to excuse Kestrel Ridge under LPA 3.7(b), or does the GP require a legal opinion satisfying LPA 3.7(a)?
   - If GP denies excuse, confirm that Kestrel is called for USD 2,000,000 investment + expenses + fees.
   - If GP grants excuse, confirm in writing for inclusion in final notice package.

2. **Kestrel deadline interpretation (secondary question):**
   - Kestrel's 2 October request is 3 calendar days after the 29 September 10-business-day deadline in LPA 3.7(a). 
   - Does GP intend to treat this as a valid late request (exercising discretion under 3.7(b))? Or is the LPA 3.7(a) deadline firm, rendering the excuse request void regardless of merit?

3. **Lanternfly transaction fee timing (affects Call #2 offset):**
   - The Lanternfly transaction fee (USD 1,100,000) is expected at closing on 20 October 2026.
   - Call #2 due date is 16 October 2026.
   - LPA 8.2(a) applies offset only for fees "received by the date of the Drawdown Notice."
   - Does GP wish to (a) proceed with USD 396,600 offset from Osprey only, (b) estimate/accrue the Lanternfly fee and update the offset, or (c) defer the Lanternfly fee to a later installment?

4. **Partnership Expenses attribution (affects allocation):**
   - Confirm that NONE of the USD 180,000 Partnership Expenses are specifically attributable to Lanternfly (diligence, legal, advisory costs, etc.).
   - If any amount is Lanternfly-specific, those costs should be split only among non-excused partners per LPA 3.7(d).
   - As drafted, all USD 180K is split pro rata to all partners (including Ostrander).

5. **Portal delivery confirmation:**
   - Confirm that the Investment Notice will be delivered via investor portal on 5 October 2026 before 5:00 p.m. ET to lock in the 10-business-day calculation and the 16 October due date.

---

## SUBSCRIPTION FACILITY

**Status: NOT USED FOR LANTERNFLY**

Per GP CFO Marcus Feld: "We are not using the subscription line for Lanternfly. The Q4 draw on it is earmarked for Project Kite."

All capital for Call #2 will be drawn from committed capital. No subscription facility borrower notification required for Lanternfly.

**Reference:** 
- correspondence/2026-10-02_GP_CFO_call_request_call2.txt

---

## SUMMARY TABLE: WHAT MUST HAPPEN TODAY TO PROCEED

| Item | Status | Owner | By When |
|------|--------|-------|---------|
| **Kestrel Ridge excuse decision** | PENDING | GP / Rachel Oyelaran (GC) | TODAY (5 Oct) |
| All other allocations | COMPLETE | — | READY |
| Notice period compliance | COMPLETE | — | READY |
| Ostrander excusal documentation | RECEIVED | — | READY |
| Investment Notice text | DRAFT | GP Deal Team | TODAY (5 Oct) |
| Portal delivery | PLANNED | Nadia / Ops | 5 Oct 5pm ET |

---

## RECOMMENDATION

**Proceed with portal delivery on 5 October 2026.** All technical calculations are sound and compliant. The only blocker is the Kestrel decision, which can be resolved in writing today and amended into the notice or handled via contemporaneous side communication to Kestrel.

If Kestrel excuse is granted → use allocation with USD 2,077,500 call to Kestrel (investment + fees + expenses only, no Lanternfly investment)

If Kestrel excuse is denied → use allocation with USD 2,077,500 call to Kestrel (all components as shown in detail table)

Either way, the notice and allocation are ready to deliver.

---

## SOURCE DOCUMENTS & CITATIONS

**Governing Documents:**
- `inputs/lpa/GACP_IV_LPA_excerpt_capital_calls_fees.md` (LPA Articles 1, 3, 8, 11)

**Investor Records:**
- `inputs/investor_records/partner_register_GACP_IV_20260930.csv` (partner IDs, commitments, side letters)
- `inputs/investor_records/side_letter_terms_summary_GACP_IV.csv` (SL-IV-001 fee rate for LP-0103)

**Manager Records:**
- `inputs/manager/fee_income_register_GAM_FundIV_2026.csv` (Fee Income log)

**Correspondence:**
- `inputs/correspondence/2026-10-02_GP_CFO_call_request_call2.txt` (call request from Marcus Feld)
- `inputs/correspondence/2026-09-24_ostrander_excuse_request.txt` (Ostrander excusal request and GC acceptance stamp)
- `inputs/correspondence/2026-10-02_kestrel_ridge_email.txt` (Kestrel excusal request)
- `inputs/correspondence/2026-09-15_investment_notice_project_lanternfly.txt` (Investment Notice for Lanternfly)

**Operations:**
- `inputs/operations/holiday_calendar_2026H2.csv` (business day calendar)
- `inputs/operations/call_history_GACP_IV.csv` (prior Call #1 and Call #1-EQ)

---

**Prepared by:** Fund Operations Analysis, Halcyon Private Fund Services  
**Date:** 5 October 2026

