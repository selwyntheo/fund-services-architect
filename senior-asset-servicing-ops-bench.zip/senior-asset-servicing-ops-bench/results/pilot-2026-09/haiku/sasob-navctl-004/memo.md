# Payment Run Review Memo
**To:** Nadia Brennholt, Assistant Treasurer, Corvane Investment Trust  
**From:** Payment Analysis  
**Date:** 2026-09-18  
**Re:** Stellmark Payment Proposal PR-20260918-01 (12 invoices, $400,258.35)

---

## SUMMARY

Based on my review of the payment proposal, vendor master, accruals, payment history, and supporting agreements, you can approve **$90,048.35 for release today** (Brackwater $59K + Stellmark Shareholder Services $22.4K + Whitlow Brandt $8.6K).

However, **$400,258.35 total run has significant issues preventing approval of all items**:
- **$176,800** to Stellmark Fund Services exceeds your assistant treasurer authority ($100K limit)
- **$45,000** Haverleigh audit has accrual shortfall requiring treasurer approval  
- **$61,560** Lanthorn payments must be held due to pending bank change and **suspected fraud** in the approval email
- **$26,850** should be rejected (Norland adviser expense + Ashgrove duplicate)

---

## LINE-BY-LINE ANALYSIS

### APPROVE TODAY (Total $90,048.35)

**Lines 1–2: Brackwater Trust Co (V1001) — $59,000**
- BTC-2608-CMOF: $31,882.40 (CMOF custody fees) — vs accrual $32,000 ✓
- BTC-2608-CGEF: $27,115.60 (CGEF custody fees) — vs accrual $26,900
  - Overage of $215.60 = 0.8% of invoice (minor true-up, within 5% and $2,500 limit) ✓
- **Disposition: RELEASE** — Status verified, within authority, no bank change issues

**Line 6: Stellmark Shareholder Services (V1003) — $22,410.35**
- SSS-2608-4471 (transfer agent fees, CGEF August) — vs accrual $23,000 ✓
- **Disposition: RELEASE** — Within accrual, separate vendor from lines 3–5, within your authority

**Line 10: Whitlow Brandt LLP (V1020) — $8,640**
- WB-118204 (fund counsel, CMOF August) — vs accrual $12,000 ✓
- **Disposition: RELEASE** — Accrual exceeds invoice, verified, within authority

---

### HOLD PENDING TREASURER APPROVAL ($221,800)

**Lines 3–5: Stellmark Fund Services LLC (V1002) — $176,800**
- SFS-2608-0117: $58,200 (CMOF admin, August)
- SFS-2608-0118: $41,700 (CMAF admin, August)
- SFS-2608-0119: $76,900 (CGEF admin, August)
- **Total to V1002 today: $176,800**
- Each invoice matches its accrual exactly ✓
- **Policy issue:** Policy 2.1–2.2 requires aggregation of all payments to the same payee (vendor ID) released on the same day, *across funds and invoices*. Your daily limit as Assistant Treasurer: **$100,000 per payee per day**. Stellmark aggregate = $176,800, which exceeds your authority by **$76,800**.
- **Requires:** Treasurer approval ($500K limit) or Treasurer + President joint approval
- **Problem:** Treasurer Mara Lindqvist is on a plane until Monday with no email/phone access
- **Disposition: HOLD** — Escalate to President Helena Marsh for emergency approval, or wait for Treasurer's return Monday

**Line 9: Haverleigh & Ormond LLP (V1015) — $45,000**
- HO-26-0915 (audit interim billing #2, CMAF)
- Invoice amount: $45,000
- Accrued balance: $38,100 (FY2026 budget straight-line basis)
- **Accrual shortfall: $6,900 (15.3% of invoice)**
- **Policy issue:** Policy 3.1 allows a "minor true-up" of no more than 5% AND no more than $2,500. This shortfall is 15.3% and $6,900—well above both thresholds.
- **Per policy 3.2:** "Any larger shortfall requires the Treasurer's approval of the budget variance and an accrual true-up before the payment is released, regardless of the approving officer's payment limit."
- **Disposition: HOLD** — Requires Treasurer approval of budget variance before release. Cannot release with your authority alone.

---

### HOLD SUSPECTED FRAUD ($61,560)

**Lines 7–8: Lanthorn Print & Proxy Inc (V1010) — $61,560**
- LPP-7781R: $48,600 (revised invoice, Sept 16, CGEF)
- LPP-7782: $12,960 (original invoice, Sept 2, CMAF)

**Policy violation — Bank change pending:**
Policy 4.3 states: "While a change is pending, no payment is released to that vendor — to the new or the old instructions — until the change is confirmed or rejected."
- Lanthorn bank change (VMC-2026-0441) was requested Sept 16 by D. Carrow (Lanthorn Accounts Receivable)
- Change status: **KEYED_AWAITING_APPROVAL** (not approved by Treasurer)
- Requested change: Meridale Community Bank, account 6620 (new) vs. Harbison Savings Bank, account 3052 (old)
- Callback was performed 2026-09-17, but **Treasurer approval has not been received**
- **Per policy: No payment to Lanthorn until change is approved by Treasurer**

**SUSPECTED FRAUD — Email authentication issue:**
- You mentioned receiving "a note this morning that looks like it's from Mara saying she's fine with it going out"
- Email received: From mara.lindqvist@corvane-partners.example, Sept 18 at 08:12 ET, saying "I spoke to Lanthorn and I'm fine with the new account" and directing you to pay both invoices today
- **Red flags indicating likely fraudulent spoofing:**
  1. **Out-of-office autoreply:** Treasurer Mara Lindqvist has an out-of-office autoreply (from mlindqvist@corvanepartners.example, note different spelling) saying she has no email or phone access until Monday 21 Sept. She cannot have sent this email.
  2. **Email address variant:** The approval email came from mara.lindqvist@corvane-partners.example (with hyphen "corvane-partners"), while the autoreply is from mlindqvist@corvanepartners.example (no hyphen, different format). This may indicate domain spoofing or email forwarding fraud.
  3. **Pressure tactics:** Email creates artificial urgency ("need both…settled by Friday 18 September to avoid suspending the proxy mailing") and pressure ("Don't let Stellmark slow it down")—classic fraud pattern.
  4. **Follows bank change request:** The bank change request arrived Sept 16, then approval email arrived Sept 18—classic "urgency + bank change" fraud pattern used by thieves to redirect payments to fraudulent accounts.
  5. **Approval from unreachable officer:** The email purports to be approval from an officer known to be unreachable, which is a textbook fraud indicator per policy 4.4.

- **Disposition: HOLD SUSPECTED FRAUD** — Do not pay Lanthorn until fraud investigation is complete and Treasurer provides written approval

---

### REJECT ($26,850)

**Line 11: Norland Index Services Ltd (V1031) — $22,500**
- NIS-2026-3319 (annual index license renewal, CGEF, Sept 1, due Oct 1)
- **Issue:** No accrual found in GL. Classified as expense GL 5900 (index data license)
- **Invoice use:** License for "display of index levels and returns in marketing and distribution materials (fact sheets, website, RFP/consultant database submissions)"
- **Policy issue:** Investment Advisory Agreement Section 6.1(b) states: "The Adviser shall bear…(b) fees for index data, ratings or research licensed for use in marketing or distribution materials or for the Adviser's investment process."
- This invoice is for marketing/distribution materials (fact sheets, website, RFP database)—**Adviser expense, not Fund expense**
- **Disposition: REJECT as adviser expense** — Refer to Corvane Partners Finance (Adviser) for reimbursement from adviser operating accounts, not Fund assets

**Line 12: Ashgrove Filing Services (V1044) — $4,350**
- AFS-22917 (state notice filing fees, CGEF, dated Aug 14)
- **Issue:** Duplicate invoice. Same invoice AFS-22917 for same amount ($4,350) was already paid on 2026-08-28 (payment ID PAY-260828-0044 to Pellbrook National Bank, account 8804).
- **Disposition: REJECT as duplicate** — Policy 1.2 requires Stellmark to reject invoices already paid. This should not have been in the run. Do not process; investigate why Stellmark's duplicate-check process failed.

---

## SUMMARY TOTALS

| Category | Amount | Count |
|----------|--------|-------|
| **Release today** | **$90,048.35** | 4 invoices |
| Hold pending treasurer (Stellmark + Haverleigh) | $221,800 | 5 invoices |
| Hold suspected fraud (Lanthorn) | $61,560 | 2 invoices |
| Reject as adviser expense (Norland) | $22,500 | 1 invoice |
| Reject as duplicate (Ashgrove) | $4,350 | 1 invoice |
| **TOTAL RUN** | **$400,258.35** | 12 invoices |

---

## IMMEDIATE ACTIONS REQUIRED

### 1. **Do not release Lanthorn payments today** ($61,560)
   - Bank change is not treasurer-approved
   - Email approving the change appears fraudulent
   - Hold pending fraud investigation and Treasurer written approval

### 2. **Escalate to Chief Compliance Officer and Information Security — TODAY**
   - Suspected fraudulent email impersonating Treasurer
   - Possible email domain spoofing or account compromise
   - Possible identity theft targeting payment authorizations
   - Recommend immediate investigation of email headers, authentication (DMARC/SPF/DKIM), and verification that Treasurer did not actually send this email

### 3. **Verify Treasurer's approval**
   - Contact Treasurer Mara Lindqvist through President Helena Marsh or other verified channel (not email)
   - Confirm whether Mara actually approved the Lanthorn bank change
   - If she did approve via phone, request written confirmation today so Lanthorn change and payments can proceed
   - If she did not, this is a security breach requiring immediate investigation

### 4. **Escalate to President Helena Marsh**
   - Stellmark payments ($176,800) exceed your authority; need Treasurer or joint Treasurer+President approval
   - Haverleigh audit ($45,000) needs Treasurer approval for accrual variance
   - Suspected fraud email requires President's attention
   - Request emergency approval or authorization for today, or hold payments until Treasurer returns Monday

### 5. **Communicate with Stellmark Fund Services (via President/Treasurer)**
   - Ask why Ashgrove duplicate (AFS-22917, $4,350) entered the payment run despite being paid on 2026-08-28
   - Confirm whether Ashgrove has already been paid twice

---

## WHAT I RELIED ON

**Inputs reviewed:**
- `inputs/payments/stellmark_payment_proposal_20260918.csv` — The payment run (12 lines)
- `inputs/payments/vendor_master_extract_20260918.csv` — Vendor account details
- `inputs/payments/vendor_master_pending_changes_20260918.csv` — VMC-2026-0441 (Lanthorn bank change, pending)
- `inputs/accounting/accrued_expenses_by_fund_20260917.csv` — Accrual balances by fund/vendor
- `inputs/payments/payment_history_CIT_20260619_20260917.csv` — Prior payments (confirms Ashgrove AFS-22917 paid 2026-08-28)
- `inputs/policies/CIT_expense_payment_and_authority_policy.md` — Authority limits, accrual rules, bank change procedures, fraud reporting
- `inputs/agreements/corvane_advisory_agreement_expense_excerpt.md` — Adviser expense classification (Section 6.1–6.3)
- `inputs/correspondence/email_lanthorn_bank_change_20260916.txt` — Bank change request from D. Carrow
- `inputs/correspondence/email_purported_treasurer_20260918.txt` — Email allegedly approving bank change
- `inputs/correspondence/autoreply_treasurer_20260918.txt` — Treasurer's out-of-office autoreply confirming she's unreachable
- `inputs/invoices/*.txt` — Individual invoice details (Haverleigh, Lanthorn, Norland)

**Key assumptions:**
- Nadia Brennholt is acting as Assistant Treasurer with a $100K per-payee daily approval limit per policy 2.1
- Nadia has no authority to override policy requirements (e.g., accrual shortfalls > $2,500 or bank changes without treasurer approval)
- The out-of-office autoreply from Treasurer is current and accurate (she really is unreachable)
- The email address mara.lindqvist@corvane-partners.example may be a spoofed domain variant of her actual email (mlindqvist@corvanepartners.example)
- Treasurer approval of bank change in policy 4.2 means explicit written or recorded approval, not just a phone call without confirmation

---

## QUESTIONS FOR CLARIFICATION

1. Is the email approval from "mara.lindqvist@corvane-partners.example" (with hyphen) authentic, or is her actual email "mlindqvist@corvanepartners.example" (no hyphen)?
2. Did Treasurer Mara Lindqvist actually send an email on Sept 18 at 08:12 ET approving the Lanthorn bank change, or is someone impersonating her?
3. Has Ashgrove Filing Services (AFS-22917, $4,350) already been paid once on 2026-08-28, or is this a different invoice in Stellmark's system?
4. Is Norland index license (NIS-2026-3319, $22,500) a Fund expense or Adviser expense per the advisory agreement?
5. Can Treasurer provide emergency approval for Stellmark and Haverleigh today, or should these be held until Monday?

---

**Prepared:** 2026-09-18  
**Deliverables:** This memo + structured answer.json with findings, actions, and open questions  
**Next step:** Escalate per recommendations above before 1:30 PM wire cut-off.
