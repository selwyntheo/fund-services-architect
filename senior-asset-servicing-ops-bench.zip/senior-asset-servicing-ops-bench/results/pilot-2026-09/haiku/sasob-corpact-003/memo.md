# MERIDALE TRUST & CUSTODY
## MEMORANDUM: Fenwick Claims Analysis
**From:** Income & Claims (Analysis)  
**To:** Keisha Osei, Income & Claims Supervisor  
**Date:** 18 September 2026  
**Re:** Tomas Albright (Fenwick) trade claims list — Bracken Foods & Van Oosterlo  
**Classification:** Internal Working Paper

---

## EXECUTIVE SUMMARY

I have reviewed all 13 trades flagged by Fenwick as potentially giving rise to dividend claims. The policy permits claims only where entitlement and record-date holding diverge in specific ways. **Only 6 trades actually generate claims; 7 do not.** The total exposure is:

| | Receivable | Payable |
|---|---|---|
| **USD** | $19,980 | $4,320 |
| **EUR** | EUR 18,700 (net) | EUR 11,220 (net) |

I recommend booking all amounts today for the month-end pack. Three EUR claims (totaling EUR 18,700) have already been detected by the CSD or require manual submission to Vandermeer; the Bracken claims require raising with counterparty brokers. **Fenwick's request to accelerate Bracken payment is not feasible.** We cannot advance claims before receiving proceeds from the brokers; anticipated receipt is by the dividend payment date (25-Sep).

One old Van Oosterlo trade from May (EUR 7,905 net, time-barred) requires Fenwick's written instruction if they wish to pursue direct counterparty recovery.

---

## DETAILED ANALYSIS

### BRACKEN FOODS INC COM (ISIN US360MLX2669)

**Dividend:** USD 0.54 per share, record date 10-Sep 2026 (ex-date = record date for US T+1 settlement)  
**Settlement:** Regular-way T+1 (DTC)  
**Policy:** Claims are raised against counterparty brokers for full dividend amount; no tax withholding (client is tax-exempt W-9). Meridale does not pre-fund or advance claims.

| Trade Ref | Side | Qty | Settle Date | Entitlement | Holder of Record | Claim? | Route |
|---|---|---|---|---|---|---|---|
| EQ-S-260908-5490 | SELL | 5,000 | 09-Sep | Buyer | Seller (us) | **NO** | Settled before RD |
| EQ-B-260909-5501 | BUY | 12,000 | 10-Sep | Buyer (us) | Buyer (us) | **NO** | Settled on RD; entitled & holder agree |
| EQ-B-260909-5502 | BUY | 30,000 | 14-Sep | Buyer (us) | Seller | **YES** | Market claim, receivable $16,200 |
| EQ-S-260909-5503 | SELL | 8,000 | 11-Sep | Buyer | Seller (us) | **YES** | Market claim, payable $4,320 |
| EQ-B-260909-5504 | BUY | 25,000 | 10-Sep (18k) + 15-Sep (7k) | Buyer (us) | Seller | **YES (7k only)** | Market claim on 7,000 shares, receivable $3,780 |
| EQ-B-260910-5511 | BUY | 20,000 | 11-Sep | Seller | Seller | **NO** | Trade date on ex-date; seller entitled & holder; no mismatch |

**USD Claims to Book:**
- **Receivable:** $16,200 (5502) + $3,780 (5504 partial) = **$19,980**
- **Payable:** $4,320 (5503)

**Actions Required:**
1. Post receivable and payable entries to income ledger account 4410-3104
2. Submit market claims to:
   - **Aldwych Securities Inc** (5502, 5504): $19,980
   - **Tamsin & Co LLC** (5503 payable): $4,320

---

### VAN OOSTERLO HOLDING NV (ISIN NL0013582448)

**Dividend:** EUR 0.88 per share (interim, record date 09-Sep 2026), ex-date 08-Sep  
**Settlement:** T+2 (Euroclear Nederland / EUROCLEAR BANK via T2S or ICSD link)  
**Tax:** 15% Dutch dividend withholding standard rate; all claim compensation is net of this rate  
**Policy:** CSD auto-detects claims for T2S-settled trades; manual claims on ICSD link / FOP trades must be submitted through Vandermeer subcustodian within 20 T2S business days of record date

**Detected by CSD (T2S):**
- MC-2609-118834: EQ-B-260907-7101, market claim receivable EUR 11,220 (detected 11-Sep, settled 16-Sep)
- MC-2609-118902: EQ-S-260904-7088, market claim payable EUR 6,732 (detected 10-Sep, settled 16-Sep)
- RC-2609-020417: EQ-B-260908-7110, reverse claim payable EUR 4,488 (detected 10-Sep, pending settle 21-Sep)

**Manual Review Required:**

| Trade Ref | Side | Qty | Settle Date | Settle Location | Entitlement | Holder of Record | Claim? | Route |
|---|---|---|---|---|---|---|---|
| EQ-S-260904-7088 | SELL | 9,000 | 10-Sep | T2S | Buyer | Seller (us) | **YES** | CSD-detected payable EUR 6,732 |
| EQ-B-260907-7101 | BUY | 15,000 | 11-Sep | T2S | Buyer (us) | Seller | **YES** | CSD-detected receivable EUR 11,220 |
| EQ-B-260907-7102 | BUY | 10,000 | 14-Sep | ICSD LINK | Buyer (us) | Seller | **YES** | Manual claim receivable EUR 7,480 (not T2S) |
| EQ-B-260907-7103 | BUY | 4,000 | 10-Sep | T2S | Buyer (us) | Seller | **NO** | Opt-out marked; no market claim |
| EQ-B-260908-7110 | BUY | 6,000 | 09-Sep | T2S | Seller | Buyer (us) | **YES** | CSD-detected reverse claim payable EUR 4,488 |
| EQ-S-260908-7111 | SELL | 3,000 | 10-Sep | T2S | Seller (us) | Buyer | **NO** | Trade date on ex-date; trade settled after RD but seller entitled & not holder; no claim per policy 2.5 |
| EQ-B-260511-6620 | BUY | 7,500 | 20-May | ICSD LINK | Buyer (us) | Seller | **YES** | **TIME-BARRED:** May dividend detection ended ~27 June; beyond 20 BD window |

**EUR Claims to Book:**
- **Receivable:** EUR 11,220 (CSD 7101) + EUR 7,480 (manual 7102) = **EUR 18,700**
- **Payable:** EUR 6,732 (CSD 7088) + EUR 4,488 (CSD 7110) = **EUR 11,220**
- **Manual to raise:** EUR 7,480 (7102, requires Vandermeer submission)
- **Time-barred:** EUR 7,905 (6620, requires client direction)

**Actions Required:**
1. Post receivable and payable entries to income ledger account 4410-3107
2. Monitor CSD settlement:
   - MC-2609-118834 (7101): Confirm receipt EUR 11,220 (settled 16-Sep) ✓
   - MC-2609-118902 (7088): Confirm payment EUR 6,732 (settled 16-Sep) ✓
   - RC-2609-020417 (7110): Confirm payment EUR 4,488 (pending 21-Sep)
3. Submit manual claim to Vandermeer Bank (VANDNL2A):
   - Trade: EQ-B-260907-7102 (BUY 10,000 @ EUR 36.52, settled 14-Sep via ICSD link)
   - Amount: EUR 7,480 net (EUR 8,800 gross, less 15% tax)
   - Counterparty: Harlow Global Markets Ltd
   - Deadline: 07-Oct 2026 (20th T2S business day after 09-Sep record date)

---

## FENWICK PAYMENT REQUEST

**Q: Can we pay the Bracken claims to Fenwick now rather than wait until 25-Sep?**

**A: No. Our policy is clear and non-negotiable:**

1. **Meridale's policy** (section 3.4): "Claim proceeds are credited to the client when Meridale receives them, and not before the payable date. Meridale does not advance claims."

2. **Timing:** We must raise the USD $19,980 receivable with Aldwych Securities and Tamsin & Co. Depending on the counterparty agreement and claim settlement procedures:
   - Aldwych typically settles claims by the dividend pay date (25-Sep) or shortly after
   - Tamsin & Co will present the USD $4,320 payable when they demand it (likely by or shortly after 25-Sep)

3. **Credit to Fenwick:** Once Meridale receives the proceeds from the brokers (expected ~25-Sep), we will credit Fenwick's account immediately. We will not hold the funds pending the nominal Bracken payment date.

4. **Our messaging to Fenwick:** "We will raise all claims with the counterparty brokers and credit you when we receive the proceeds. We anticipate receipt by the dividend payment date of 25 September. We cannot advance or pre-fund claims before receiving them from the brokers."

---

## OLD VAN OOSTERLO TRADE (TIME-BARRED)

**Trade:** EQ-B-260511-6620 (BUY 7,500 @ EUR 38.90 on 11-May for May dividend)  
**Dividend:** VOH26DVCA01 (Final dividend EUR 1.24, record date 13-May 2026, paid 20-May)  
**Settlement:** 20-May (outside T+2 window, counterparty fail)  
**Claim Amount:** EUR 7,500 × 1.24 × 0.85 = **EUR 7,905 net**

Fenwick's note: "The June Van Oosterlo buy that settled late. It looks like we never got that dividend either."

**Issue:** The CSD detection period for the May dividend record date (13-May) ended ~27-June (20 T2S business days). We are now in mid-September, well outside the window. The claim can no longer be raised through the CSD or our subcustodian.

**Policy (section 5.1):** Time-barred claims cannot be raised through the CSD or subcustodian. Asset Servicing must notify the client and relationship manager in writing. We may pursue the counterparty directly only on the client's written instruction, and no receivable is booked until the counterparty has agreed.

**Recommendation:** Escalate to Fenwick via relationship manager with the following options:
- **(A)** Pursue direct recovery against Harlow Global Markets Ltd (counterparty) if Fenwick provides written authority
- **(B)** Write off the claim and treat it as a sunk loss
- **(C)** Request legal review if a contractual claim sits outside the standard detection window

**Amount at risk:** EUR 7,905 (not booked until resolved)

---

## SUMMARY OF ENTRIES TO BOOK TODAY

**Account 4410-3104 (USD):**
- Dr. Claims Receivable $19,980 | Cr. Counterparty Broker / Dividend Income
- Dr. Counterparty Broker / Dividend Expense | Cr. Claims Payable $4,320

**Account 4410-3107 (EUR):**
- Dr. Claims Receivable EUR 18,700 | Cr. CSD / Vandermeer (pending manual raise) / Dividend Income
- Dr. CSD (7088, 7110) | Cr. Claims Payable EUR 11,220

**Accounts affected:**
- 4410-3104 (Fenwick USD): +$19,980 receivable, –$4,320 payable, net +$15,660
- 4410-3107 (Fenwick EUR): +EUR 18,700 receivable, –EUR 11,220 payable, net +EUR 7,480

---

## OPEN ITEMS REQUIRING FOLLOW-UP

1. **USD payable acknowledgment:** Confirm Tamsin & Co has not already submitted a claim for trade 5503 ($4,320) and will accept our submission.
2. **CSD claim settlement:** Confirm that MC-2609-118834 (7101, EUR 11,220) has settled and been received; RC-2609-020417 (7110, EUR 4,488) will settle as scheduled on 21-Sep.
3. **Manual Van Oosterlo claim deadline:** Confirm Vandermeer subcustodian ready to submit EQ-B-260907-7102 (EUR 7,480) within the 20 BD window (deadline 07-Oct).
4. **Time-barred claim instruction:** Request Fenwick's written direction on whether to pursue EUR 7,905 recovery against Harlow Global Markets Ltd for the May trade, or write off.

---

## SOURCES & ASSUMPTIONS

**Input files reviewed:**
- `inputs/correspondence/email_fenwick_20260917.txt` — Tomas Albright's request
- `inputs/trades/fenwick_trade_settlement_status_20260918.csv` — Settlement status extract
- `inputs/notices/MT564_MRDL_BRACKEN_DVCA_20260821.txt` — Bracken dividend notice (USD 0.54, RD 10-Sep)
- `inputs/notices/MT564_MRDL_VANOOSTERLO_DVCA_20260826.txt` — Van Oosterlo interim dividend notice (EUR 0.88, RD 09-Sep)
- `inputs/csd/t2s_market_claims_report_VANDNL2A_20260918.csv` — CSD detected claims (3 items)
- `inputs/income/fenwick_income_ledger_VOH_BRKN.csv` — Record date positions and dividend rates
- `inputs/policies/meridale_market_claims_procedures.md` — Claims policy v5.0

**Policy applied:** Meridale Trust & Custody Income: Market Claims Procedures v5.0 (effective 2026-02-01)
- Entitlement principle (section 2.1): Buyer if trade date before ex-date; seller if on/after
- Claim types: Market claim (trade before ex-date, settled after RD); reverse claim (trade on/after ex-date, settled on/before RD)
- US procedure: Raise with counterparty brokers, no withholding for W-9 exempt clients
- NL procedure: CSD auto-detects T2S; manual submission for ICSD/FOP within 20 BD; net of 15% standard withholding
- Time-barred: Cannot raise after detection period; requires client written instruction for direct pursuit

**Assumptions:**
1. All trades with no settlement date remain failing and generate no claims
2. Trade 5504 partial settlement: 18,000 settled by record date (09-10), 7,000 settled 15-Sep (per notes); only 7,000 shares claimed
3. Trade 6620 is for the May (VOH26DVCA01) dividend; detected as time-barred based on record date of 13-May and claim detection deadline ~27-June
4. Fenwick's exempt pension status gives zero withholding on Bracken claims and 15% standard rate (no relief at source) on Van Oosterlo claims
5. CSD reports are accurate and settlement schedules will be met as stated

---

**Prepared by:** Income & Claims Analysis  
**Date:** 18 September 2026
