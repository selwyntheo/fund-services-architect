# Fund Tax Memorandum — BMAI December Distribution Estimate

**To:** Owen Latimer, Assistant Treasurer, Brightwater Series Trust  
**From:** Oakhurst Fund Administration, Fund Tax  
**Date:** November 13, 2026  
**Fund:** Brightwater Multi-Asset Income Series (BMAI)  
**Subject:** December 2026 Distribution Estimate — §4982 Excise Tax Compliance

## Executive Summary

The minimum December 2026 distribution to avoid 4% excise tax under IRC §4982(b) is **$7,591,319.78 total, or $0.0623 per share**. This reflects:

- Required distribution of $45,742,482 (inclusive of a prior-year 2025 carry-forward shortfall)
- Distributions through November of $38,151,163
- Projected record-date shares of 121,972,650

If December distributions are limited to the regular $0.0280 rate, the fund will face an excise tax liability of approximately **$167,043**.

## Calculation Methodology

### 1. Ordinary Income (Calendar Year 2026)

| Component | Amount | Notes |
|-----------|--------|-------|
| Deferred post-Oct 2025 §988 loss | ($184,300) | From 2025 excise workpaper; per IRC §4982(e)(5) |
| NII Jan–Oct 2026 (actual) | $33,974,695 | Sum of monthly tax-basis results |
| §988 FX gains Jan–Oct 2026 (actual) | $58,980 | Included in ordinary income through Oct 31 |
| NII Nov–Dec 2026 (forecast) | $7,143,050 | PM desk forecast dated Nov 10; §988 gains deferred to 2027 |
| **Ordinary Income** | **$40,992,425** | Excludes post-October 2026 §988 gains per policy |

**Source:** Tax basis monthly results (BMAI_monthly_tax_basis_income_and_gains_202507_202610.csv), income forecast (BMAI_income_forecast_20261101_20261231.csv), and policy section 2.2–2.3.

### 2. Capital Gain Net Income (Nov 1, 2025 – Oct 31, 2026)

| Component | Amount | Notes |
|-----------|--------|-------|
| Short-term realized gains/losses | $896,860 | Sum of realized ST gains and losses in the period |
| Long-term realized gains/losses | $4,105,030 | Sum of realized LT gains and losses in the period |
| Excise-basis loss carryover (prior year) | $0.00 | None available at Oct 31, 2025 |
| **Capital Gain Net Income** | **$5,001,890** | Positive net, so no current carryover |

**Source:** Monthly tax-basis data for Nov 2025–Oct 2026; 2025 excise workpaper confirms no prior loss carryover.

**Note:** The annual report shows capital loss carryforwards of ~$2.9 million reported under IRC §1212 for income-tax purposes. Per policy section 2.4, these cannot be used for §4982 excise calculations because "the losses behind them are already reflected in the realized results of the excise periods in which they arose." Excise basis uses only realized gains/losses and excise-basis carryovers, not tax carryforwards.

### 3. Prior-Year Carry-Forward (2025)

| Component | Amount | Notes |
|-----------|--------|-------|
| 2025 Ordinary Income (100%) | $39,872,174 | From final 2025 excise workpaper |
| 2025 Capital Gains (100%) | $6,905,400 | From final 2025 excise workpaper |
| 2025 Grossed-up Required Dist. | $46,777,574 | Sum of 100% of both components |
| 2025 Actual Distributed Amount | $46,119,524 | From final 2025 excise workpaper |
| **2025 Shortfall (added to 2026)** | **$658,050** | Carry-forward per policy section 2.1(c) |

The 2025 fund distributed $263,691 *more* than the minimum required under the 98%/98.2% test (resulting in zero excise tax for 2025), but $658,050 *less* than 100% of earnings. This underdistribution at the grossed-up level must be added to the 2026 required distribution per IRC §4982(b)(2).

**Source:** BMAI_2025_excise_workpaper_FINAL.csv.

### 4. 2026 Required Distribution

| Component | Amount | Calculation |
|-----------|--------|-------------|
| 98% of ordinary income | $40,172,577 | $40,992,425 × 0.98 |
| 98.2% of capital gains | $4,911,856 | $5,001,890 × 0.982 |
| 2025 carry-forward shortfall | $658,050 | From section 3 above |
| **Required Distribution** | **$45,742,482** | Total |

**Source:** Policy section 2.1; statutory calculation per IRC §4982(b).

### 5. Distributions Paid or Declared Through November 2026

| Month | Reference | Type | Amount |
|-------|-----------|------|--------|
| Jan | BMAI-D-2026-01 | INCOME | $3,316,830 |
| Feb | BMAI-D-2026-02 | INCOME | $3,319,204 |
| Mar | BMAI-D-2026-03 | INCOME | $3,322,141 |
| Apr | BMAI-D-2026-04 | INCOME | $3,385,532 |
| May | BMAI-D-2026-05 | INCOME | $3,388,205 |
| Jun | BMAI-D-2026-06 | INCOME | $3,391,878 |
| Jul | BMAI-D-2026-07 | INCOME | $3,394,742 |
| Aug | BMAI-D-2026-08 | INCOME | $3,396,826 |
| Aug | BMAI-D-2026-08S | ORDINARY INCOME (IRC §855) | $1,031,179 |
| Sep | BMAI-D-2026-09 | INCOME | $3,399,281 |
| Oct | BMAI-D-2026-10 | INCOME | $3,401,664 |
| Nov | BMAI-D-2026-11 | INCOME (declared) | $3,403,680 |
| | | **Total** | **$38,151,163** |

**Note on August distribution:** The BMAI-D-2026-08S ($1,031,179) represents undistributed ordinary income of fiscal year 2026 (year ended June 30, 2026), distributed under IRC §855 election on August 28, 2026. Although it is FY2026 earnings, policy section 3.2 specifies that "Dividends paid after the close of a taxable year under an IRC §855 election count for excise purposes in the calendar year in which they are **paid**." The August 28 payment therefore counts in 2026 calendar year for excise purposes.

**Note on December 2025 distribution:** BMAI-D-2025-12 was declared December 15, 2025, recorded December 29, 2025, and paid January 5, 2026. Under IRC §852(b)(7) exception in policy section 3.1, it is treated as paid December 31, 2025, and therefore counts toward 2025 excise requirements only, not 2026. It is excluded from the above total.

**Source:** Distribution register (BMAI_distribution_register_202507_202611.csv) and policy section 3.1–3.2.

### 6. Minimum December Distribution

| Item | Amount |
|------|--------|
| Required Distribution | $45,742,482 |
| Less: Paid through November | ($38,151,163) |
| **Minimum December Distribution** | **$7,591,320** |

Rounded to nearest cent: **$7,591,319.78**

Per policy section 4.2, this is the minimum floor. The fund may distribute more but must distribute at least this amount to avoid excise tax.

### 7. December Per-Share Rate

**Projected record-date shares:** 121,972,650.225  
(Shares outstanding as of Nov 12: 121,560,000 + projected activity through record date: +412,650)

**Per-share calculation:**  
$7,591,319.78 ÷ 121,972,650.225 = $0.062258...

**Rounded up to $0.0001 (per policy §4.3):** **$0.0623 per share**

## Adviser Views and Rationale

Marcus Whitcombe (Brightwater Advisors CFO) requested that December distribution be "kept as lean as possible" and made three points:

### 1. "No excise tax from 2025"
**Assessment: Correct.** The 2025 excise workpaper shows zero excise tax for 2025 (no underdistribution under the 98%/98.2% test). However, this does not eliminate the 2025 carry-forward shortfall of $658,050, which represents earnings not distributed at 100%. This carry-forward is a statutory requirement under IRC §4982(b)(2).

### 2. "Capital loss carryforwards should shelter most of this year's gains"
**Assessment: Incorrect.** The annual report shows $2.88 million of capital loss carryforwards (reported under IRC §1212 for income-tax purposes). The adviser appears to expect these to reduce the 2026 capital gain net income from $5.0 million to a much lower figure.

However, policy section 2.4 explicitly excludes income-tax carryforwards: "Capital loss carryforwards reported for the Fund's taxable (fiscal) year under §1212 are **not** used in the excise computation: the losses behind them are already reflected in the realized results of the excise periods in which they arose."

The excise calculation uses *realized* gains and losses in the measurement period (Nov 2025–Oct 2026). The $2.88 million carryforward represents losses *from prior periods*, which have already been deducted from realized results when they occurred. Using them again in 2026 would result in double-counting.

The $5.0 million capital gain net income is therefore correct.

### 3. "August special belongs to last year's numbers"
**Assessment: Partially valid concern, but policy is clear.** The August special ($1,031,179) is payment of FY2026 (year-ended June 30) earnings. Under IRC §855, for income-tax purposes, the recipient shareholders treat it as received in FY2026 (the earning year). This is economically tied to FY2026 operations.

However, for *excise tax* purposes, policy section 3.2 and the IRC are explicit: such distributions count in the calendar year *paid*, regardless of the fiscal year to which they relate. Excise tax is assessed on a calendar-year basis, not a fiscal-year basis. The fund had no ability to defer the August payment to December without losing the §855 election benefit.

**Conclusion:** The August special must count in 2026 for excise purposes.

## Scenario Analysis: December at Regular $0.0280 Rate

If the Board decides to keep the December distribution at the regular $0.0280 per share (as Marcus suggested):

| Metric | Value |
|--------|-------|
| December payout at $0.0280/share | $3,415,234 |
| Total 2026 distributions (incl. Dec) | $41,566,397 |
| Required distribution | $45,742,482 |
| **Underdistribution / Shortfall** | **$4,176,085** |
| **4% Excise Tax** | **$167,043** |

This excise tax would be owed to the IRS and, per policy, is the fund's responsibility (not passed to shareholders).

## Summary of Judgments

1. **Prior-year carry-forward of $658,050** — Statutory requirement; no discretion.
2. **August special counts in 2026** — Policy and IRC §855 are clear on timing of distributions; the August 28 payment counts in 2026 calendar year regardless of the fiscal year the earnings relate to.
3. **Capital loss carryforwards excluded** — Policy section 2.4 is explicit; excise basis does not allow tax-basis carryforwards, only realized gains/losses and excise-basis loss carryovers.
4. **Deferred post-October 2025 §988 loss** — Statutory deferral under IRC §4982(e)(5) reduces 2026 ordinary income by $184,300.

## Required Actions

1. **Notification:** Advise Owen Latimer and the Board that the minimum safe December distribution is $7,591,320 total ($0.0623 per share).
2. **Governance:** If the Board wishes to declare only $0.0280 per share, it must be aware of the $167,043 excise tax consequence.
3. **Reporting:** This calculation will be incorporated into the final 2026 excise workpaper to be filed with Oakhurst's records and made available to the independent auditor.

## Supporting Documentation

- BMAI_monthly_tax_basis_income_and_gains_202507_202610.csv — Monthly NII and realized gains
- BMAI_income_forecast_20261101_20261231.csv — November and December projections
- BMAI_distribution_register_202507_202611.csv — Distribution history
- BMAI_2025_excise_workpaper_FINAL.csv — Prior-year calculation and carry-forward basis
- BST_distribution_and_excise_policy.md — Policy governing the calculation
- BMAI_annual_report_FY2026_tax_note_extract.md — FY2026 earnings and carryforwards
- BMAI_shares_outstanding_and_projection_20261112.csv — Share count for per-share rate

---

**Prepared by:** [Oakhurst Fund Tax]  
**Reviewed by:** [Fund Tax Director]  
**Date prepared:** November 13, 2026
