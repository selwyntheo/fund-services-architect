# Position Reconciliation Memo — Tidewell Multi-Asset Income Fund
## Account 7730-131 as of 2026-09-17

**From:** Reconciliation Analysis  
**Date:** 2026-09-17  
**Re:** Four securities with differences between TMAI accounting (trade-date basis) and Northgate MT535 (settled holdings basis)

---

## Executive Summary

Pellmore identified four securities with non-zero differences between the fund's accounting position and the Northgate custodian statement. Analysis shows:

- **Brindlewood (170k difference)**: Explained entirely by 150k securities on loan (expected) + 20k unsettled purchase (expected). **No break; no adjustment required.**
- **Alder Semiconductor (64k difference)**: Stock split (2-for-1) payable 2026-09-17, ex-date 2026-09-18. Accounting correctly shows pre-split quantity; custodian already adjusted. **No break; timing difference per policy.**
- **Marlowe Water Technologies (46.25k missing)**: Spinoff should have been booked by 2026-09-15 (day before ex-date 2026-09-16). **Accounting error.** Must book using Form 8937 allocations. **Not material for NAV restatement but must correct in next NAV.**
- **Pinecrest (90k missing)**: Merger settled 2026-09-15, shares delisted 2026-09-15, cash received 2026-09-16. **Custodian error.** Northgate still shows shares on 2026-09-17 statement.

**Key finding**: Recommend against Pellmore's proposed force true-up of positions to Northgate's figures. The fund's accounting records are correct on a trade-date basis and appropriately reflect unsettled trades and securities on loan.

---

## Detailed Analysis

### 1. Brindlewood Industrial Corp (USLPV8NW1399)

| | Quantity |
|---|---|
| Accounting position (trade-date) | 420,000 |
| Northgate MT535 (settled holdings) | 250,000 |
| **Difference** | **170,000** |

**Explanation:**
- **150,000 shares on loan**: Loan HSF-L-2608-11932 with Borrower 0417, status OPEN as of 2026-09-17. Per custodian agreement (section 4.2) and Fund policy (section 2.3(b)), securities on loan do not appear in the MT535 settled holdings statement. Accounting correctly includes them.
- **20,000 unsettled purchase**: Trade EQ-260917-0412 (buy 20,000 @ $52.04) executed 2026-09-17, settling T+1 on 2026-09-18. PM email dated 2026-09-17 16:52 confirms this addition for voting material position in upcoming Brindlewood/Castellan special meeting (record date 2026-09-24, meeting 2026-10-22).

**Verification**: 250,000 (custodian) + 150,000 (on loan) + 20,000 (unsettled) = 420,000 (accounting) ✓

**Root cause**: Reconciling items (expected under policy 2.3).

**Responsible side**: Lending agent (loan) and timing (unsettled trade).

**Treatment**: Carry as reconciling item with expected clear date 2026-09-18 (for the trade).

**Adjustment required**: None. The accounting position is correct.

**Urgent action required**: **Yes.** 150,000 loaned shares must be recalled to settle by record date 2026-09-24. PM has designated the vote as material (proxy voting committee minutes 2026-08-27, item 4). Fund intends to vote AGAINST the all-stock Castellan deal. Per Securities Lending Authorization Agreement section 7.1-7.2, recall must be submitted at least 3 business days before record date. With record date at 2026-09-24, recall instruction must be sent by 2026-09-22 (allowing T+1 settlement on 2026-09-23, with one-day buffer). This should be actioned **today** (2026-09-17).

---

### 2. Alder Semiconductor Inc (US0C86UQ8545)

| | Quantity |
|---|---|
| Accounting position (trade-date) | 64,000 |
| Northgate MT535 (settled holdings) | 128,000 |
| **Difference** | **-64,000** |

**Explanation:**

Alder announced a 2-for-1 forward stock split effected as a stock dividend.
- **Record date**: 2026-09-10
- **Payable (distribution) date**: 2026-09-17
- **Ex-date**: 2026-09-18
- **Split-adjusted trading begins**: 2026-09-18

Per Fund policy (section 3.1), corporate actions are recorded on the ex-date. As of close of business 2026-09-17:
- **Accounting**: Correctly shows 64,000 pre-split shares (CA status SCHEDULED; will process on ex-date 2026-09-18).
- **Custodian**: Shows 128,000 post-split shares (their standard practice is to reflect splits when paid).

Both are correct for their respective bases.

**Root cause**: Corporate action timing (expected under policy 2.3(c)).

**Responsible side**: Timing only.

**Treatment**: No adjustment required as of 2026-09-17.

**Adjustment required**: None. The 64k pre-split quantity is correct through end of 2026-09-17; will adjust to 128k on 2026-09-18 when CA is booked.

**Verification**: On 2026-09-18, after the split is booked, accounting will show 128,000 shares and the reconciliation will clear.

---

### 3. Marlowe Diversified Holdings Inc / Marlowe Water Technologies Inc
**MDH ISIN**: USEY5J8C8865  
**MWT ISIN**: US3EP60F8227

| | MDH | MWT |
|---|---|---|
| Accounting | 185,002 shares | 0 shares |
| Custodian | 185,002 shares | 46,250 shares |
| **Difference** | 0 | **-46,250** |

**Explanation:**

Marlowe Diversified Holdings distributed Marlowe Water Technologies (spinoff):
- **Distribution ratio**: 1 MWT per 4 MDH
- **Record date**: 2026-09-04
- **Distribution date**: 2026-09-15
- **Ex-date**: 2026-09-16
- **Fractional settlement**: 0.5 fractional shares aggregated; cash in lieu at $24.3176/share

The fund held 185,002 MDH shares. Entitlement: 185,002 ÷ 4 = 46,250.5 shares.
- Whole shares received: 46,250
- Fractional entitlement: 0.5 (worth ~$12.16)

**Status**: CA-26-04655 is in PENDING_TERMS status, awaiting cost allocation from vendor. However, this deadline has passed. Per Fund policy (section 3.2):

> "Pending terms: an event may be held in PENDING_TERMS status for **no longer than the day before its ex-date**. If cost-allocation data is not available from the vendor feed by then, Fund Accounting books the event **using the issuer's published information**."

The ex-date was 2026-09-16, so the deadline was close of business 2026-09-15. IRS Form 8937 was published and filed on 2026-09-14 and posted to MDH investor relations website. The form includes (Part II, Line 15) the final cost allocation percentages:
- **Marlowe Diversified Holdings (remaining): 86.40%**
- **Marlowe Water Technologies (distributed): 13.60%**

These are not preliminary percentages; they are the final allocations per the Form 8937 published before the ex-date.

**Root cause**: Accounting has not booked the spinoff despite the Form 8937 being available.

**Responsible side**: Accounting.

**Treatment**: Book the corporate action using Form 8937 allocations.

**Adjustment required**: Yes. Create the following entry:

**Cost Allocation** (per Form 8937, line 15):
- Total MDH cost before distribution: $7,215,078.00
- MDH allocation: 86.40% × $7,215,078.00 = **$6,233,827.39**
- MWT allocation: 13.60% × $7,215,078.00 = **$981,250.61**

**MWT Position**:
- Whole shares: 46,250
- Cost per share (whole position): $981,250.61 ÷ 46,250 = **$21.19**
- Market value (2026-09-17): 46,250 × $24.91 = **$1,152,087.50**
- Unrealized gain: $1,152,087.50 − $981,250.61 = $170,836.89

**Fractional Shares**:
- Entitlement: 0.5 MWT shares
- Cost basis (pro rata): $981,250.61 × (0.5 ÷ 46,250.5) = **$10.61**
- Cash in lieu (receivable): **$12.16**
- Realized gain/loss: $12.16 − $10.61 = **$1.55 gain**

**Accounting Entry**:
```
Dr. MWT Security (46,250 sh @ $21.19 cost)      981,250.61
Dr. Cash in Lieu Receivable                         12.16
Dr. Realized Gain (fractional sale)                  1.55
    Cr. MDH cost basis adjustment                          981,250.61
    Cr. Cash received (pending 2026-09-22)                 12.16
    (net cost reduction from $7,215,078.00 to $6,233,827.39)
```

**NAV Impact** (for NAV dates 2026-09-16 and 2026-09-17):
- Missing market value of MWT on 2026-09-16: 46,250 × $24.55 = **$1,135,437.50**
- Missing market value of MWT on 2026-09-17: 46,250 × $24.91 = **$1,152,087.50**
- Error per share 2026-09-16: $1,135,437.50 ÷ 41,380,112.405 shares = **$0.0274**
- Error per share 2026-09-17: $1,152,087.50 ÷ 41,362,540.118 shares = **$0.0279**

**Materiality Assessment** (per Trust NAV Error Correction Policy, section 5.2):
An error is material only if both conditions met:
1. USD 0.01 per share or more
2. 0.50% of reported NAV per share or more

| Date | Error/Share | Material (≥$0.01)? | % of NAV | Material (≥0.50%)? | Overall Material? |
|---|---|---|---|---|---|
| 2026-09-16 | $0.0274 | ✓ Yes | 0.23% | ✗ No | **No** |
| 2026-09-17 | $0.0279 | ✓ Yes | 0.24% | ✗ No | **No** |

**Policy guidance** (section 5.4): "Errors that are not material: corrected in the next NAV struck; prior NAVs are not restated and shareholder transactions are not reprocessed."

Therefore: Prior NAVs (2026-09-16, 2026-09-17) are not restated. The correction is made in the next NAV. No shareholder reprocessing required.

**Adjustment for 2026-09-17 position record**: Yes. Record 46,250 MWT shares at cost $981,250.61.

---

### 4. Pinecrest Health Systems Inc (USE3E5QV1890)

| | Quantity |
|---|---|
| Accounting position | 0 |
| Northgate MT535 | 90,000 |
| **Difference** | **-90,000** |

**Explanation:**

Pinecrest Health Systems was acquired in a mandatory cash merger (acquirer: Halloran Care Partners LP).
- **Merger terms**: USD 41.25 per share (cash)
- **Effective date**: 2026-09-15
- **Shares delisted**: 2026-09-15
- **Cash settlement**: 90,000 × $41.25 = $3,712,500 received by fund on 2026-09-16

**Accounting** correctly processed the merger on 2026-09-15, removing 90,000 shares and recording the cash proceeds received on 2026-09-16. This is recorded in CA events (CA-26-04418, PROCESSED by CA_AUTO on 2026-09-15).

**Custodian statement** (MT535 as of 2026-09-17) still shows 90,000 Pinecrest shares held. This is inconsistent with the reported effective date (2026-09-15) and should not occur if settlement has completed.

**Root cause**: Custodian error or settlement failure.

**Responsible side**: Custodian.

**Treatment**: Raise exception with Northgate.

**Adjustment required**: None to the fund's accounting. However, we must get clarification from Northgate on why the shares still appear on their 2026-09-17 statement:
1. Has the merger actually settled?
2. Is there a settlement failure? (Unlikely given we received the cash.)
3. Has Northgate not yet processed the merger settlement on their end?

**Urgent follow-up**: Request immediate corrected statement from Northgate. The 90,000 shares should be removed and replaced with a cash entry if they haven't already been.

---

## Summary Table

| Security | Issue | Root Cause | Responsible | Treatment | Action Required |
|---|---|---|---|---|---|
| **Brindlewood** | 170k difference | On loan (150k) + unsettled (20k) | Lending + timing | Carry as reconciling item | **Yes - recall shares for vote** |
| **Alder** | 64k difference | Stock split timing (2:1) | Timing | No adjustment (processes 2026-09-18) | No |
| **Marlowe** | 46.25k MWT missing | CA not booked (deadline passed) | Accounting | Book using Form 8937 allocations | **Yes - post entry today** |
| **Pinecrest** | 90k still on custodian | Custodian didn't process merger | Custodian | Raise with Northgate | **Yes - request clarification** |

---

## Recommendations

### Do Not Accept Pellmore's Proposed True-Up

Pellmore's suggestion to "true our positions up to Northgate's figures today" should be rejected. The fund's accounting records are correct on a trade-date basis per FASB and SEFMA standards. The four differences are:
1. **Brindlewood**: Expected reconciling items (loan + unsettled trade).
2. **Alder**: Expected reconciling item (CA timing).
3. **Marlowe**: Accounting error that should be corrected using policy-compliant procedures, not a custodian true-up.
4. **Pinecrest**: Custodian error to be raised with Northgate.

**None of these warrant a force true-up.**

### Immediate Actions (Today, 2026-09-17)

1. **Brindlewood recall**: Direct Operations to submit recall instruction to Harrowgate for 150,000 shares (loan HSF-L-2608-11932) with settlement target of 2026-09-23 (to settle by record date 2026-09-24).

2. **Marlowe CA booking**: Approve and post the corporate action entry for MWT using Form 8937 allocations (86.40% MDH, 13.60% MWT). Create MWT security record and position: 46,250 shares at cost $981,250.61.

3. **Pinecrest inquiry**: Submit exception ticket to Northgate Client Service re: 90,000 Pinecrest shares still appearing on MT535 after 2026-09-15 settlement. Request immediate clarification and corrected statement.

### NAV Disclosure

- **Marlowe spinoff impact on 2026-09-16 NAV**: Understate by $0.0274/share (0.23% of reported NAV). Non-material; no restatement required per policy.
- **Marlowe spinoff impact on 2026-09-17 NAV**: Understate by $0.0279/share (0.24% of reported NAV). Non-material; no restatement required per policy.
- **Correction**: Include full MWT position in next NAV struck (2026-09-18 or later).

---

## Open Questions for Follow-Up

1. **Brindlewood voting**: Has the Proxy Voting Committee confirmed that the total position (420,000 including the unsettled 20,000-share addition) is adequate for the material vote on the Castellan deal?

2. **Marlowe cost allocation**: Will Pellmore's vendor deliver the final cost allocation by end of day 2026-09-17 to support the 2026-09-17 NAV, or will we finalize the adjustment using the Form 8937 allocations?

3. **Pinecrest settlement**: Can Northgate confirm whether Pinecrest merger has actually settled, and if so, why the shares still appear on their 2026-09-17 statement?

4. **Brindlewood dividend**: Are there any pending distributions on Brindlewood or loaned shares that would affect the vote count or require substitute payments?

---

## Files Referenced

- `inputs/accounting/positions_TMAI_7730-131_20260917.csv` — fund's trade-date position record
- `inputs/custodian/MT535_NTCUS33_7730-131_20260917.txt` — Northgate settled holdings statement
- `inputs/accounting/corporate_action_events_TMAI.csv` — CA status and processing log
- `inputs/lending/harrowgate_onloan_report_TMAI_20260917.csv` — on-loan securities report
- `inputs/accounting/unsettled_trades_TMAI_20260917.csv` — unsettled trade log
- `inputs/notices/alder_stock_split_notice.txt` — Alder split announcement
- `inputs/notices/marlowe_spinoff_notice_and_form8937_extract.txt` — Marlowe CA documentation and Form 8937
- `inputs/notices/brindlewood_special_meeting_notice.txt` — Brindlewood merger notice
- `inputs/correspondence/email_pm_brindlewood_vote.txt` — PM instruction re: Brindlewood voting
- `inputs/lending/securities_lending_authorization_agreement_extract.txt` — lending agreement recall terms
- `inputs/policies/TFT_position_reconciliation_and_corporate_actions_procedures.md` — Fund accounting policy
- `inputs/pricing/closing_prices_20260915_17.csv` — pricing data

---

**Prepared by:** Reconciliation Analysis  
**Date:** 2026-09-17  
**Status:** Ready for Operations Oversight review
