# MEMO RE: CMAF Fee Waiver Error — Correction Analysis and Recommendation

**TO:** Priya Ramaswamy, Director, Fund Administration Oversight — Corvane Partners LLC  
**FROM:** Fund Administration  
**DATE:** September 18, 2026  
**SUBJECT:** Management fee waiver applied after expiry — correction decision for 9/18 NAV

---

## EXECUTIVE SUMMARY

Stellmark's failure to update fee module rule WVR-CMAF-01 resulted in a 0.10% management fee waiver being applied through September 17, 2026, despite expiring on February 28, 2026 per Helena Marsh's letter of January 20, 2026. This underbilled the Fund $175,497 in management fees.

**Key finding:** This is **not a NAV error requiring shareholder reprocessing.** The cumulative error reaches $0.0142 per share (1.42 cents) but represents only 0.056% of NAV—below the Fund's 0.50% materiality threshold. Per the NAV error correction policy, the full correction must be booked in tomorrow's NAV (2026-09-18) without reprocessing, reducing net assets by a net $133,864 ($0.0109 per share), and requires Treasurer approval.

---

## FINDINGS

### 1. The Waiver Expiry and Stellmark's Implementation Failure

**Source:** Adviser letter dated January 20, 2026 (filed: `inputs/correspondence/adviser_letter_fee_waiver_20260120.txt`)

Helena Marsh, President of Corvane Partners LLC, explicitly stated:
> "Our contractual agreement to waive 0.10% of the management fee payable by Corvane Multi-Asset Fund runs through February 28, 2026 (letter of 25 February 2025). We will not renew it. From March 1, 2026 the Fund will accrue the full contractual management fee of 0.60%."

The letter instructed Stellmark to "update the fee and expense limitation set-up accordingly and confirm."

**Implementation failure:** Stellmark's fee module rule WVR-CMAF-01 (filed: `inputs/accounting/fee_module_setup_CMAF.csv`) shows:
```
rule_id: WVR-CMAF-01
effective_from: 2024-03-01
effective_to: 2026-12-31  ← Should be 2026-02-28
source_document: Adviser waiver letter 2025-02-25
last_modified_ts: 2025-03-03 16:40
```

**Error period:** The 10 bp waiver continued to be applied for all accrual dates from March 1 through September 17, 2026 (139 NAV dates), as shown in `inputs/accounting/mgmt_fee_daily_accrual_CMAF_FY2026_20260917.csv`.

**Quantified impact:** Waiver amounts improperly applied from 2026-03-01 through 2026-09-17: **$175,497** (matches Priyanka's rough estimate).

---

### 2. Is This a "NAV Error" Requiring Shareholder Reprocessing?

**Policy reference:** Corvane Investment Trust Policy on the Correction of NAV Errors, Section 1.4 (v3.1, adopted 2024-03-12; amended 2025-12-09).

A Material Day (triggering shareholder reprocessing) requires **both** of the following:
- **(a) $0.01 per share or more** difference between published and corrected NAV; **AND**
- **(b) 0.50% or more** of the corrected NAV per share

**Penny prong:** ✅ Met  
- Peak cumulative error: **$0.0142 per share** (September 17, 2026)
- 55 NAV dates met the $0.01+ threshold
- Published NAV per share (2026-09-17): $26.04
- Corrected NAV (adding back waiver): $26.054
- Difference rounded to penny: $0.01 ✓

**Percentage prong:** ❌ NOT met  
- Error as % of corrected NAV: **0.056%**
- Threshold: 0.50%
- Error is **less than 1/9th of the materiality threshold**

**Conclusion:** Zero Material Days exist. The error must be corrected per policy, but **without shareholder reprocessing**.

---

### 3. Correction Treatment (Policy Section 3 — Non-Material Days)

Per the policy:
- ✅ Full cumulative correction must be recorded in the next NAV to be calculated
- ✅ No deferral, amortization, or spreading over future NAVs
- ✅ No shareholder account adjustments
- ✅ No reprocessing of shareholder transactions

**Treasurer approval requirement (Section 3.3):**  
The correcting entry's NAV per share impact is $0.01 or more (rounded), so Treasurer approval must be obtained **before releasing the NAV**.

---

## THE CORRECTING ENTRY

### Primary Correction: Missing Management Fee

The 0.60% management fee should have been charged from March 1, 2026 onward; instead, only 0.50% was charged due to the continued waiver. The difference (10 bp) over 140 business days = **$175,497**.

**Accounting entry (to be booked 2026-09-18 NAV):**
```
Dr. GL 5100 (Management Fee)              $175,497
    Cr. GL 1390 (Management Fee Payable)              $175,497
```

This reduces net assets by $175,497 (increases expense accrual).

### Consequential Adjustment: Expense Limitation Reimbursement

**Source data** (`inputs/accounting/expense_summary_CMAF_FYTD_20260917.csv`):
- FYTD covered expenses (through 9/17): $2,201,519.44
- Expense limitation cap (0.85% of FYTD ADNA): $2,335,383.76
- Current Adviser reimbursement accrual: $0.00 (below cap)

**After correction:**
- New FYTD covered expenses: $2,201,519.44 + $175,497 = **$2,377,016.44**
- Cap: $2,335,383.76
- **Excess = $41,632.68** ← Adviser now owes this to the Fund

**Consequential entry (per procedure E3.1, `inputs/policies/stellmark_fee_and_expense_procedures_excerpt.md`):**
```
Dr. GL 1380 (Expense Limit Reimbursement Receivable)  $41,633
    Cr. GL 5900 (Expense Limit Reimbursement Income)              $41,633
```

### NET IMPACT ON NET ASSETS

| Item | Amount |
|------|--------|
| Management fee correction (increased expense) | –$175,497 |
| Adviser expense limit reimbursement (increased receivable) | +$41,633 |
| **Net reduction in net assets** | **–$133,864** |

**Per share impact:**
- Shares outstanding (2026-09-17 NAV): 12,332,341 shares
- Net reduction ÷ shares = $133,864 ÷ 12,332,341 = **$0.0109 per share**
- Rounded to nearest $0.01: **–$0.01 per share**

**NAV per share effect:**
- Current NAV (2026-09-17): $26.04
- After correction: $26.04 – $0.0109 = $26.0291
- Rounded to published NAV: $26.03 (reduction of $0.01 when both are rounded)

---

## BOARD DISCLOSURE FOR Q3

Since no Material Days exist, per Policy Section 8.3, this error is logged in the NAV error log and reported to the Board quarterly (not as an urgent Material Day report). However, given the magnitude and nature, include in the Q3 quarterly NAV error report:

**Proposed disclosure language:**
> "Non-Material Day fee accrual error (Error Period: March 1 – September 17, 2026). Stellmark Fund Services failed to update fee module rule WVR-CMAF-01's effective end date when the Adviser's 10 bp management fee waiver expired February 28, 2026. The waiver continued to be applied through September 17, 2026, resulting in underbilled management fees of $175,497. Peak cumulative error: $0.0142 per share (0.056% of NAV), meeting the $0.01 penny prong but not the 0.50% materiality threshold. No shareholder reprocessing required per Fund policy. Net NAV adjustment in 2026-09-18 NAV: –$0.0109 per share, inclusive of $41,633 in Adviser expense limitation reimbursement. Responsible party: Stellmark Fund Services; reimbursement to Fund due: $133,864."

---

## RESPONSIBLE PARTY AND REIMBURSEMENT

**Responsible party:** Stellmark Fund Services LLC (implementation error: failure to update rule end date).

**Fund reimbursement due:** $133,864.32 (net reduction in fund net assets attributable to Stellmark's error).

Per Policy Section 7.1: "The Responsible Party is the service provider whose act or omission caused the error, determined under the relevant service agreement."  
Per Policy Section 7.2: "The Fund does not bear the cost of a NAV error."

**Reimbursement timeline (Section 6.3, adapted to non-Material Day context):** Within five Business Days of Treasurer approval.

---

## WHAT NEEDS TO HAPPEN BY 3 PM TODAY (9/18/26 9 AM)

1. **Treasurer decision:** Approve the 2026-09-18 NAV correction (–$133,864, –$0.0109/share, rounded –$0.01).
   - This is not a reprocessing decision (no Material Days).
   - Confirmation needed for Stellmark and fund accounting.

2. **Rule fix:** Stellmark confirms that rule WVR-CMAF-01 effective_to has been corrected to 2026-02-28.

3. **Entries staged:** Fund accounting stages the two entries above for posting to the 2026-09-18 NAV:
   - Dr. GL 5100 $175,497 / Cr. GL 1390
   - Dr. GL 1380 $41,633 / Cr. GL 5900

4. **NAV release:** Once Treasurer approval is obtained (via email, etc.), release the 2026-09-18 NAV with the corrections and error log notation.

5. **Stellmark reimbursement commitment:** Obtain from Stellmark written confirmation of the $133,864.32 reimbursement due within 5 Business Days of Treasurer approval, with expected payment date.

---

## ANALYSIS SUPPORTING DOCUMENTS

All figures and conclusions are supported by:

- **Policy framework:** `inputs/policies/CIT_NAV_error_correction_policy.md` (Sections 1.4, 3, 6, 7, 8)  
- **Procedures:** `inputs/policies/stellmark_fee_and_expense_procedures_excerpt.md` (Sections E1, E2, E3)  
- **Adviser letter:** `inputs/correspondence/adviser_letter_fee_waiver_20260120.txt` (January 20, 2026)  
- **Rule setup:** `inputs/accounting/fee_module_setup_CMAF.csv` (rule WVR-CMAF-01)  
- **Accrual detail:** `inputs/accounting/mgmt_fee_daily_accrual_CMAF_FY2026_20260917.csv` (waiver applied through 9/17)  
- **Expense summary:** `inputs/accounting/expense_summary_CMAF_FYTD_20260917.csv` (FYTD expenses vs. cap)  
- **NAV history:** `inputs/nav/nav_history_CMAF_20251030_20260917.csv` (NAV dates, shares, dollar values)  
- **Prospectus:** `inputs/fund_documents/CMAF_prospectus_fee_table_excerpt_20260227.md` (fee structure confirmation)  
- **Stellmark email:** `inputs/correspondence/email_stellmark_fund_accounting_20260918.txt` (error discovery)

---

## ANSWERS TO PRIYA'S QUESTIONS

**Q: "Is this a NAV error in the reprocess-the-shareholders sense?"**  
A: No. The error meets the penny prong ($0.01+/share) but not the percentage prong (0.056% << 0.50%), so no Material Days exist. Per policy, the correction is booked in the next NAV without shareholder reprocessing or account adjustments.

**Q: "What exactly do we book tonight, and what does it do to the NAV?"**  
A: Two entries totaling a net $133,864 reduction in net assets (or $0.0109 per share, rounding to $0.01): (1) missing management fee $175,497 as expense, and (2) increased Adviser expense limitation reimbursement $41,633 as income. NAV per share falls by $0.0109 (rounds to $0.01 published NAV).

**Q: "Does anyone owe the Fund money?"**  
A: Yes. Stellmark Fund Services, as the responsible party for the implementation error, owes the Fund $133,864.32 (due within 5 Business Days of your approval). The Adviser is also obligated to pay the Fund $41,633 in expense limitation reimbursement per the Adviser's existing agreement, but Stellmark's reimbursement covers the net Fund loss.

**Q: "What needs to go in Board materials for Q3?"**  
A: A brief item in the quarterly NAV error log report noting the non-Material Day fee accrual error, its magnitude, root cause, and that no shareholder impact occurred. See proposed disclosure language above.

**Q: "Give me numbers I can stand behind — Mara will check them."**  
A: See figures section of the formal answer file. All amounts reconcile to the provided accounting extracts and NAV history; policy treatment is explicit in Sections 3, 6, 7, 8 of the NAV Error Correction Policy.

---

## OPEN ITEMS REQUIRING FOLLOW-UP

1. **Adviser communication:** Has the Adviser been informed of the corrected fee arrangement and the increase in their expense limitation reimbursement obligation? (This is a consequence of the correction, not optional.)

2. **Stellmark service agreement review:** The NAV error policy Section 7.1 notes that if Stellmark's agreement excludes liability for this type of error, the Adviser would reimburse instead. Confirm whether Stellmark's service agreement holds them liable for rule implementation failures.

3. **Stellmark process review:** Consider a review of Stellmark's rule maintenance process to prevent similar lapses (e.g., checklist confirmation from the Adviser when a rule change is implemented).

---

**Recommendation: Proceed with the correction as outlined. Request Treasurer approval for 2026-09-18 NAV.**

