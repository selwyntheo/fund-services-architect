# Distribution 8 (Delphine) — Waterfall Calculation & Analysis
**Granite Arch Capital Partners II, L.P.**
**Distribution Date: 30 September 2026**
**Prepared for: Jonas Whitcombe, Director PE Fund Accounting**

---

## Executive Summary

Distribution 8 represents the first capital event on Fund II to generate carried interest. Total distributable proceeds of USD 112,000,000.00 have been apportioned and distributed per Article 9 of the LPA.

**Key Figures:**
- **GP Commitment return:** USD 2,240,000.00 (pro rata apportionment)
- **LP distributions:** USD 87,808,000.00
- **GP carried interest (to operating account):** USD 3,216,000.00
- **Carried interest to escrow:** USD 5,488,000.00
- **Total to GP operating account (30 Sep):** USD 18,704,000.00

GP's total carried interest is USD 21,952,000.00, of which 75% (USD 16,464,000.00) is wired on the distribution date and 25% (USD 5,488,000.00) is held in the carry escrow account per Section 9.6.

---

## Calculation Methodology

### 1. Apportionment (Section 9.1)

Distributable proceeds are apportioned pro rata by commitment:

| Partner | Commitment | % of Total | Apportionment |
|---------|-----------|-----------|-------------|
| GP-0020 | USD 6,000,000 | 2.00% | USD 2,240,000.00 |
| LP-0021 | USD 60,000,000 | 20.00% | USD 22,400,000.00 |
| LP-0022 | USD 50,000,000 | 16.67% | USD 18,666,666.67 |
| LP-0023 | USD 45,000,000 | 15.00% | USD 16,800,000.00 |
| LP-0024 | USD 35,000,000 | 11.67% | USD 13,066,666.67 |
| LP-0025 | USD 40,000,000 | 13.33% | USD 14,933,333.33 |
| LP-0026 | USD 24,000,000 | 8.00% | USD 8,960,000.00 |
| LP-0027 | USD 40,000,000 | 13.33% | USD 14,933,333.33 |
| **TOTAL** | **USD 300,000,000** | **100%** | **USD 112,000,000.00** |

**GP Commitment Return (Section 9.3):** USD 2,240,000.00 is distributed 100% to GP, not subject to Article 9.2 waterfall or escrow.

**LP Apportioned Amount:** USD 109,760,000.00

### 2. Preferred Return Calculation

Per Article 1 definitions, Preferred Return for each LP is the amount that, together with unreturned capital contributions, gives the LP an 8% annually compounded internal rate of return on its contributions.

**Calculation for each LP:**
- Compound all capital contributions to 30 Sep 2026 at 8% p.a.
- Compound all prior distributions (through Distribution 7) back to 30 Sep 2026 at 8% p.a.
- Subtract unreturned capital (max of 0, contributions − prior distributions)
- Remaining amount = Preferred Return needed

**Result:** All LPs have previously received cumulative distributions exceeding their contributions. Therefore, unreturned capital = USD 0 for all LPs.

| LP | Pref Return Needed |
|---|---|
| LP-0021 | USD 15,066,895.95 |
| LP-0022 | USD 12,555,746.63 |
| LP-0023 | USD 11,300,171.96 |
| LP-0024 | USD 8,789,022.64 |
| LP-0025 | USD 10,044,597.30 |
| LP-0026 | USD 6,026,758.38 |
| LP-0027 | USD 10,044,597.30 |
| **TOTAL** | **USD 73,827,790.17** |

### 3. Article 9.2 Waterfall

The waterfall is applied to each LP's apportioned share, with four tiers:

#### Tier A: Return of Capital (Section 9.2(a))
**Status: Already Satisfied**

100% to the LP until cumulative distributions equal capital contributions.

**Result:** All LPs have already recovered their contributions. Tier A = USD 0.

#### Tier B: Preferred Return (Section 9.2(b))
**Status: Satisfied**

100% to the LP until it has received its Preferred Return.

**Calculation:**
- Total Tier B needed: USD 73,827,790.17
- Available (after Tier A): USD 109,760,000.00
- Tier B allocated: USD 73,827,790.17 (fully satisfied)
- Distribution by LP: Pro rata by preferred return proportion

**Remaining for Tier C+D:** USD 35,932,209.83

#### Tier C: General Partner Catch-Up (Section 9.2(c))
**Status: Satisfied**

80% to GP and 20% to LP until GP has received an amount equal to 20% of the sum of:
- (x) all amounts distributed under Tier B to that LP
- (y) all amounts distributed under Tier C to both GP and LP

**Algebraic Solution:**
Let C = total Tier C distribution. Since we distribute at 80% GP / 20% LP:
- GP receives: 0.80 × C
- LP receives: 0.20 × C

The constraint is: GP_receive = 0.20 × (Tier_B + Tier_C)

Substituting: 0.80C = 0.20(B + C)
Solving: C = B / 3

**Calculation:**
- Total Tier B (all LPs): USD 73,827,790.17
- Tier C needed: USD 73,827,790.17 / 3 = USD 24,609,263.39
- GP allocation: 80% = USD 19,687,410.71
- LP allocation: 20% = USD 4,921,852.68

**Remaining for Tier D:** USD 11,322,946.44

#### Tier D: Carried Interest Split (Section 9.2(d))
**Status: First Distribution with Carry**

80% to LP, 20% to GP.

**Calculation:**
- Total remaining: USD 11,322,946.44
- LP allocation (80%): USD 9,058,357.15
- GP allocation (20%): USD 2,264,589.29

**Carried Interest Definition & Escrow (Section 9.6):**

Per the LPA, "Carried Interest" means amounts distributed to GP under Sections 9.2(c) and 9.2(d)(ii).

- GP Tier C (catch-up): USD 19,687,410.71
- GP Tier D (carry split): USD 2,264,589.29
- **Total Carried Interest: USD 21,952,000.00**

Section 9.6 requires 25% of each distribution of Carried Interest to be paid to the Carry Escrow Account:
- To Escrow (25%): USD 5,488,000.00
- To GP Operating (75%): USD 16,464,000.00

---

## Comparison to GP's Preliminary Calculation

Marcus Feld's preliminary estimate (based on Delphine deal alone) suggested approximately USD 16.4mm of total GP carry. 

**Our Calculation (Whole-of-Fund):** USD 21,952,000.00

**Explanation of Difference:**

1. **Scope:** The LPA requires a whole-of-fund waterfall application, not deal-by-deal. Distribution 8 includes proceeds from two sources:
   - Delphine Logistics sale (primary): USD 115,420,000.00
   - Varro Security Software escrow release: USD 3,300,000.00
   
2. **Catch-Up Calculation:** The catch-up in Article 9.2(c) is not calculated on a single deal basis but applies to the entire LP apportioned amount after Tier B. Since all LPs together required USD 73.83mm of Tier B, the catch-up pool is 1/3 of that (USD 24.61mm), not calculated by individual deal economics.

3. **GP vs. LP Incentive:** The whole-of-fund waterfall ensures LP downside protection (full pref return) and allows GP to participate in profits once the catch-up target is met. This differs from a deal-by-deal hurdle structure.

---

## Distribution Instructions & Settlement

### Wire Instructions (30 September 2026)

**1. GP Operating Account**
- **Recipient:** GP-0020 (Granite Arch GP II, LLC)
- **Amount:** USD 18,704,000.00
- **Components:**
  - Commitment return: USD 2,240,000.00
  - Carried interest (75%): USD 16,464,000.00
- **SSI on file:** Confirm with Marcus Feld

**2. Carry Escrow Account**
- **Recipient:** Halcyon Trust Services
- **Account:** 4471-2290
- **Amount:** USD 5,488,000.00 (25% of carried interest)

**3. Limited Partners** (see attached per-LP notice)
- **Total to LPs:** USD 87,808,000.00
- **Settlement:** ACH or wire per individual LP SSI

### Distribution Notices

Issue per Section 9.8, showing for each LP:
- Tier A distribution: USD 0.00
- Tier B (Preferred Return): [amount]
- Tier C (Catch-Up Share): [amount]
- Tier D (Carry Share): [amount]
- Carried Interest Note: "This distribution includes the first carried interest distribution on Fund II. Pursuant to the LPA Section 9.6, USD [amount] of carried interest attributable to your interest is paid to the LP at this time; 25% (USD [amount]) is held in escrow for release upon final liquidation or per Section 9.7."

---

## Assumptions & Caveats

1. **8% Preferred Return Compounding:** Calculated on actual day count using 365-day year, compounding annually from each contribution date.

2. **No Prior Catch-Up or Carry:** Confirmed via distributions history (all prior distributions through Dist 7 show LP_TIERS_1_2, indicating Tiers A and B only). This is the first Tier C and D distribution.

3. **Whole-of-Fund Waterfall:** Per Article 9.2 language ("The amount apportioned to each Limited Partner...is distributed between that Limited Partner and the General Partner as follows"), the waterfall applies to the LP's pro-rata share of proceeds, not to individual deals.

4. **Carried Interest Escrow Permanence:** USD 5,488,000.00 is held in escrow until final liquidation of the fund per Section 9.6. LP side shares of Tier D (carried interest) are not subject to escrow (only GP's CI is escrowed).

---

## Files & References Consulted

- **inputs/lpa/GACP_II_LPA_excerpt_distributions.md** — Articles 1, 9 (sections 9.1–9.8)
- **inputs/investor_records/partner_register_GACP_II.csv** — Commitments and carry status
- **inputs/capital_activity/contributions_GACP_II_inception_to_20260917.csv** — All capital calls by partner and date
- **inputs/capital_activity/distributions_GACP_II_inception_to_20260917.csv** — All prior distributions (Dist 1–7)
- **inputs/investor_records/portfolio_realizations_GACP_II.csv** — Investment costs and exit proceeds
- **inputs/correspondence/2026-09-16_GP_distribution_approval_Delphine.txt** — IC approval; USD 112mm distributable proceeds
- **inputs/correspondence/2026-09-17_feld_email_carry.txt** — CFO request; confirms USD 112mm and wiring to GP operating on same day

---

## Signed

**Halcyon Private Fund Services** — PE Fund Accounting  
**On behalf of:** Jonas Whitcombe, Director, PE Fund Accounting  
**Date:** 19 September 2026  
**Distribution Date:** 30 September 2026
