# MEMORANDUM

**TO:** Mara Lindqvist, Treasurer & PFO, Corvane Investment Trust

**FROM:** Fund Control Analyst

**RE:** CGEF / Tarrant Hollis Orders 9/17/2026 — Late Trading Analysis

**DATE:** 2026-09-18

---

## Executive Summary

Six of the twelve Tarrant Hollis orders for trade date 9/17 were received after market close (4:00 PM ET) or transmitted after the 9:00 AM transmission deadline. If left at the 9/17 NAV as Ken proposes, the Fund faces dilution of **$128,764** to be recovered from the Intermediary.

**My recommendation:** Do NOT accept Ken's proposal to leave everything at 9/17 price. Correct the late orders to the 9/18 NAV per the agreement and policy.

---

## Analysis

### Orders Received After Market Close (4:00 PM ET on 9/17)

Per the Intermediary Agreement Article 4.1-4.2:
- Orders received **before** 4:00 PM ET on a business day are priced at that day's NAV (provided transmitted by 9:00 AM ET next day)
- Orders received **at or after** 4:00 PM ET are treated as next-day orders and priced at the next NAV
- Order increases/modifications after close are new orders (Article 4.4)

Converting all order times to Eastern Time (accounting for branch time zones):

| Order ID | Branch | Entry Time (ET) | Status | Reason |
|----------|--------|-----------------|--------|--------|
| 5501 | NY | 10:14:22 | Timely | — |
| 5502 | NY | 13:47:05 | Timely | — |
| 5503 | Chicago | 15:32:10 | Timely | — |
| **5504** | Chicago | **16:18:44** | **LATE** | Received 18m 44s after close |
| **5505** | Chicago | **16:26:09** | **LATE** | Received 26m 9s after close |
| 5506 | NY | 15:59:58 | Timely | 1.42 seconds before close |
| **5507** | NY | **16:00:00** | **LATE** | At close (per Article 4.2: "at or after") |
| 5508 | NY | 15:52:31 (entry) | **SPLIT** | Entry timely; qty increase at 16:12:40 (after close) |
| **5509** | NY | 15:47:03 (entry) | **LATE** | Transmission delay (see below) |
| 5510 | NY | 11:05:40 | Timely | — |
| 5511 | SF | 15:40:00 | Timely | — |
| **5512** | SF | **16:05:30** | **LATE** | Received 5m 30s after close |

### Transmission Deadline Issue (5509)

Per Article 4.3: Orders must be transmitted so as to be **received by the Transfer Agent no later than 9:00 AM ET** on the next business day.

- Tarrant's File FS1: Created/received by TA at **06:52:14 ET** on 9/18 ✓ (timely)
- Tarrant's File FS2 (supplemental): Created/received by TA at **09:41:37 ET** on 9/18 ✗ (after 9:00 AM deadline)

Order 5509 appears only in FS2. Although the order was entered before market close (15:47:03 ET), it was transmitted after the 9:00 AM deadline. Per Article 4.3, this makes it a late order priced at the NAV "next computed after such receipt" — which is the 9/18 NAV.

### Financial Impact

**NAVs:**
- 9/17 NAV: $31.42 (published at 18:29 ET)
- 9/18 NAV: $32.19 (published at 18:41 ET)
- Difference: $0.77 per share

**Late Order Amounts:**
- Purchases: $5,050,000 (5504: $1.5M, 5505: $2.25M, 5508 increase: $1.0M, 5509: $300K)
- Redemptions: 6,500 shares (5507: 4,500, 5512: 2,000)

**Dilution Calculation** (using formula from NAV Error Correction Policy Section 4):

*Purchases (dollar orders):*
- Each $ purchased at 9/17 NAV issued too many shares
- Excess shares valued at 9/18 NAV = Fund Loss

| Order | Amount | Shares @ 9/17 | Shares @ 9/18 | Excess | Impact |
|-------|--------|------------------|-----------------|---------|----------|
| 5504 | $1,500,000 | 47,740.293 | 46,608.070 | 1,132.223 | $36,412 |
| 5505 | $2,250,000 | 71,610.439 | 69,912.105 | 1,698.334 | $54,618 |
| 5508 increase | $1,000,000 | 31,836.951 | 31,050.930 | 786.021 | $25,206 |
| 5509 | $300,000 | 9,548.059 | 9,313.243 | 234.816 | $7,544 |
| **Subtotal** | | | | **3,844.634** | **$123,779** |

*Redemptions (share orders):*
- Each share redeemed at 9/17 NAV paid too little cash
- Obligation to customer valued at 9/18 NAV = Fund Loss

| Order | Shares | Cash @ 9/17 | Cash @ 9/18 | Shortfall |
|-------|--------|-------------|------------|-----------|
| 5507 | 4,500 | $141,390 | $144,855 | $3,465 |
| 5512 | 2,000 | $62,840 | $64,380 | $1,540 |
| **Subtotal** | | | | **$5,005** |

**TOTAL FUND DILUTION: $128,764**

### NAV Restatement — Material Day Test

Per NAV Error Correction Policy Section 1.4, a Material Day requires **BOTH**:
- (a) Difference ≥ $0.01 per share, **AND**
- (b) Difference ≥ 0.50% of Corrected NAV

**Calculation:**

If we correct the 9/18 NAV by removing the $128,764 dilution:

- Published 9/18 Assets: $856,047,840.83
- Corrected 9/18 Assets: $856,047,840.83 − $128,764.41 = $855,919,076.42
- Published 9/18 Shares: 26,595,743.702 (no change per policy — only assets are adjusted)
- Corrected NAV: $855,919,076.42 / 26,595,743.702 = **$32.1826** → rounds to **$32.18**

- Difference: $32.19 − $32.18 = **$0.01** ✓ Meets first threshold
- Percentage: $0.01 / $32.18 = **0.031%** ✗ Fails second threshold (< 0.50%)

**Result: NOT a Material Day**

Per Policy Section 3 (non-Material Days):
- No shareholder transactions are reprocessed
- No shareholder accounts are adjusted
- The correcting entry is recorded prospectively in the next NAV
- The Fund bears the entire loss (subject to recovery from Responsible Party)

### Responsible Party

Per Policy Section 7.1, the Responsible Party is the service provider whose act or omission caused the error.

**Intermediary Agreement Article 9.2:** "Intermediary shall indemnify and hold harmless the Trust and each Fund for any loss, including any loss arising from the correction or reprocessing of transactions, resulting from Intermediary's failure to comply with Article 4."

Tarrant Hollis failed to comply with Article 4 by:
1. Accepting orders after market close (4.2 violation)
2. Increasing an order after market close (4.4 violation)
3. Transmitting an order after the 9:00 AM deadline (4.3 violation)

**Responsible Party: Intermediary (Tarrant Hollis Securities LLC)**

---

## Policy Assumptions

This analysis assumes:

1. **Time Zones:** Order times recorded in local branch time have been correctly converted to Eastern Time to compare against the 4:00 PM ET close
2. **Close Definition:** Market close = 4:00:00 PM ET (normal business day); the 4:00:00 PM ET entry for 5507 is treated as "at close" = late per Article 4.2 ("at or after the Close")
3. **Good Order:** All orders were in good form; no "not_in_good_order" issues
4. **Trade Date:** All orders show trade date 9/17 in TA transmission; no trade-date mismatch issues
5. **Surveillance Decision:** The four orders flagged by surveillance (5504, 5505, 5508, 5509) are indeed late trades requiring correction

---

## Required Actions

### Immediate (by EOD 9/19)
1. **Notify CCO** per Order Acceptance procedures Section 5 — late orders must be reported same day with order-entry evidence
2. **Hold the surveillance items** — do not close them pending this analysis
3. **Notify Ken** (TA Supervisor) — do NOT accept his proposal to leave trades as processed; correction is required

### By COB 9/20 (Monday 9 AM deadline per Mara's email)
1. **Request explanation from Tarrant Hollis** — why were orders accepted after close? Supporting documentation for order-entry timing
2. **Escalate to CCO for Rule 22c-2 review** — Harrowgate announcement at 4:09 PM ET; orders placed 9-26 minutes after announcement may indicate late-trading concerns
3. **Obtain Treasurer approval** for the correcting entry and any NAV amendment

### By Wednesday 9/22
1. **Reprocess late orders** at 9/18 NAV (recalculate shares, adjust omnibus account)
2. **Post correcting entry** for Fund Loss ($128,764) as receivable from Tarrant Hollis
3. **Issue demand letter** to Tarrant Hollis for reimbursement (due within 5 business days per Policy Section 6.3)

### Ongoing
1. **Report to Board** at next meeting (incident, root cause, remediation)
2. **Review intermediary compliance** — did their surveillance procedures catch this? Are they enforcing deadline compliance?

---

## Supporting Documents Reviewed

- Tarrant Hollis order-entry audit (CGEF, 9/17)
- FundServ transmission records (FS1, FS2)
- TA processing report (settlement details & exception flags)
- Published NAV file (9/15–9/18)
- Intermediary Agreement (Article 4 & 9)
- Order Acceptance procedures (Policy Section 4–5)
- NAV Error Correction policy (Section 1–7)
- Newswire (Harrowgate announcement timing)
- TA Supervisor's email (Ken's position)

---

## Recommendation

**Do not accept Ken's proposal.** The late orders must be corrected per the Fund's service agreements and compliance policies. While this is NOT a Material Day (so no shareholder reprocessing is required), the Fund's loss must be recovered from the Intermediary under the indemnification clause. Failure to do so would expose the Fund to potential SEC examination findings and breach the Treasurer's fiduciary duty to protect Fund assets.

The fact that the surveillance team flagged these trades and the timing relative to the Harrowgate announcement suggests possible late-trading concerns that should be elevated to the CCO for Rule 22c-2 review.

