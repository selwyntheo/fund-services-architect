# BGOF N-PORT VALIDATION MEMORANDUM
**Brightwater Global Opportunities Fund — August 31, 2026 Form N-PORT Part C**

**From:** Senior Compliance Validator  
**To:** Graham Sato, Manager, Regulatory Reporting — Oakhurst Fund Administration  
**Date:** September 19, 2026  
**Subject:** Critical findings — N-PORT cannot be submitted as drafted; immediate Board notification required

---

## EXECUTIVE SUMMARY

The August 2026 N-PORT draft for Brightwater Global Opportunities Fund **cannot be filed as submitted** to SEC EDGAR. Validation against fund accounting records, valuation designee determinations, and the Fund's adopted Liquidity Risk Management Program (Version 4.0, Board-approved 2025-03-12) has identified:

1. **Six required corrections** to the N-PORT (L03 value and percentage, plus liquidity reclassifications on L14, L16, L19, L22)
2. **Illiquid investments at 15.63% of net assets, exceeding the 15% regulatory limit** by $505,000
3. **Highly liquid investments at 23.34%, below the required 25% minimum (HLIM shortfall)**

**The fund is in violation of two material compliance thresholds.** The LRM Program requires:
- Board notification within one business day of identifying illiquid excess (by close of business September 20)
- Form N-RN (Part B) filing within one business day of the excess (by September 20)
- Form N-RN (Part D) filing if HLIM shortfall exceeds 7 consecutive calendar days

This memo documents the findings and the corrected fund-level metrics you need to report to the Board and the SEC.

---

## DETAILED FINDINGS

### 1. Line Item Errors (6 corrections required)

#### L03 — Vaudrey SA (non-U.S. equity)

| Field | Draft | Corrected | Source |
|-------|-------|-----------|--------|
| **value_usd** | $11,186,000 | $12,399,681 | BGOF_holdings_valuation_20260831.csv |
| **pct_net_assets** | 3.04% | 3.37% | Recalculated: $12.4M / $367.96M net assets |

**Issue:** The N-PORT draft value does not match the accounting records. The holdings valuation shows Vaudrey SA valued at $12,399,681 (140,000 EUR shares @ 79.90 local close, adjusted by systematic fair value factor applied on 2026-08-31 due to U.S. market movement threshold breach, converted at FX rate of 1.1085). The N-PORT draft shows only $11,186,000, a shortfall of $1,213,681.

**Rationale:** The fair value factor adjustment is documented in the valuation designee memo (Section 5) and the holdings valuation file (pricing_source = "EXCHANGE_CLOSE x FAIR VALUE FACTOR (systematic, 2026-08-31 trigger)"). This is the correct valuation as of month-end.

---

#### L14 — Tessaly Biosciences Inc. (private placement preferred)

| Field | Draft | Corrected | Rationale |
|-------|-------|-----------|-----------|
| **liquidity_classification** | Less Liquid | Illiquid | Private placement, no approved override |

**Issue:** Tessaly Series C Convertible Preferred is classified as "Less Liquid" in the draft, but the fund's LRM Program Rule 3.5 requires private placements (restricted securities that are not Rule 144A-eligible and have no secondary market) to be classified as **Illiquid** unless the LRM Committee has approved a different classification in writing.

**Evidence:**
- BGOF_vendor_liquidity_classification_20260831.csv: Vendor bucket is "Less Liquid" and notes "No market data; default bucket for unlisted preferred"
- BGOF_liquidity_override_log_2026.csv: No entry for L14; no override was requested or approved
- BGOF_liquidity_risk_management_program_extract.md, Rule 3.5: "Restricted securities that are not Rule 144A-eligible and have no secondary market (private placements, PIPE shares under lock-up, bilateral private loans) are classified Illiquid unless the LRM Committee has approved a different classification in writing."

**Implication:** The correction of this single line increases illiquid holdings by $21.8M and is a primary driver of the 15% limit violation (see Section 2 below).

---

#### L16 — Norcastle Mining Corp. (common stock)

| Field | Draft | Corrected | Rationale |
|-------|-------|-----------|-----------|
| **liquidity_classification** | Highly Liquid | Illiquid | Trading halt, no alternative venue |

**Issue:** Norcastle common is classified as "Highly Liquid" in the draft, but a T12 trading halt has been in effect on its primary market since August 27, 2026 (three weeks before month-end). The halt remains in effect as of September 17, 2026. No alternative trading venue is available.

**Evidence:**
- exchange_notice_Norcastle_trading_halt_20260827.txt: Halt effective prior to open on 2026-08-27, T12 code (additional information requested), no alternative venues
- Update dated 2026-09-17: Halt remains in effect; issuer not expected to file required information before October 15, 2026
- BGOF_valuation_designee_memo_20260831.txt, Section 1: "No trading venue available. Fair valued at USD 6.00 per share... position is not saleable while the halt continues"
- BGOF_liquidity_risk_management_program_extract.md, Rule 3.4: "An investment whose primary market has halted or suspended trading, with no alternative trading venue, is classified Illiquid from the first business day of the halt until trading resumes."

**Implication:** This reclassification increases illiquid holdings by $9.6M (from $0 to $9.6M). This is the second-largest driver of the 15% limit violation.

---

#### L19 — Dellbrook Foods Inc. (bank loan assignment)

| Field | Draft | Corrected | Rationale |
|-------|-------|-----------|-----------|
| **liquidity_classification** | Illiquid | Less Liquid | Rejected override; vendor bucket applies |

**Issue:** Dellbrook Foods Term Loan B is classified as "Illiquid" in the draft, but the LRM Committee rejected a Portfolio Manager override request on August 20, 2026. The rejection was based on dealer quotes and recent trade prints showing the loan can be sold within 7 calendar days (settlement >7 days). Under Rule 3.7, this makes it Less Liquid, not Illiquid.

**Evidence:**
- BGOF_liquidity_override_log_2026.csv, OVR-2026-019: Requested 2026-08-12 by Portfolio Manager (R. Castell), REJECTED 2026-08-20
- Committee rejection rationale: "Two-dealer quotes and 2026-08 trade prints support sale within 7 days; settlement >7 days -> Less Liquid per P3.7. Revert to vendor bucket."
- BGOF_vendor_liquidity_classification_20260831.csv: Vendor bucket = "Less Liquid"
- BGOF_liquidity_risk_management_program_extract.md, Rule 3.7: "Syndicated loans that can be sold within seven calendar days but settle in more than seven calendar days are Less Liquid, not Illiquid."

**Implication:** This reclassification **decreases** illiquid holdings by $10.5M (removes position from Illiquid category). This partially offsets the other corrections but does not eliminate the 15% limit violation.

---

#### L22 — Pembury Retail plc (non-U.S. equity)

| Field | Draft | Corrected | Rationale |
|-------|-------|-----------|-----------|
| **fair_value_level** | 1 | 2 | Systematic fair value factor applied |

**Issue:** Pembury Retail (GBP-denominated) is classified as Level 1 (unadjusted exchange close) in the draft, but accounting records show Level 2 (exchange close adjusted by systematic fair value factor).

**Evidence:**
- BGOF_holdings_valuation_20260831.csv, L22: fair_value_hierarchy_level = 2, pricing_source = "EXCHANGE_CLOSE x FAIR VALUE FACTOR (systematic, 2026-08-31 trigger)"
- BGOF_valuation_designee_memo_20260831.txt, Section 5: "The systematic fair value factor was triggered on 31 August 2026 (U.S. market move after European and Asian closes above threshold). All non-U.S. equities valued at local close times fair value factor — Level 2 for the month-end."

**Implication:** This is a fair value hierarchy classification correction with no impact on liquidity classification or the 15% limit.

---

### 2. Fund-Level Liquidity Compliance

#### Illiquid Investments — Regulatory Limit Exceeded

After correcting the line-item errors above, the fund's illiquid investments (those classified as "Illiquid" per the LRM Program) total:

| Position | Classification | Value (USD) |
|----------|---|---|
| L14 — Tessaly Biosciences (corrected) | Illiquid | $21,804,000 |
| L15 — Kilnworth Holdings (term loan) | Illiquid | $17,901,000 |
| L16 — Norcastle Mining (corrected) | Illiquid | $9,600,000 |
| L17 — Amberlane Therapeutics (PIPE) | Illiquid | $8,200,000 |
| **Total Illiquid** | | **$57,505,000** |

**Fund-Level Metrics:**
- **Net Assets:** $367,956,922
- **Illiquid Investments:** $57,505,000
- **Illiquid Percentage:** 15.63%
- **Regulatory Limit:** 15.00%
- **Excess Amount:** $505,000 (0.63 percentage points)
- **Status:** **LIMIT EXCEEDED**

**Program Requirements (Rule 22e-4(b)(1)(iv), implemented in BGOF LRM Program Section 4):**
- Section 4.2: "If more than 15% of net assets are illiquid investments that are assets, the Program Administrator must report the occurrence to the Board **within one business day**, with an explanation of the extent and causes and how the Fund plans to bring illiquid investments to or below 15% within a reasonable period, and the Fund must file **Form N-RN (Part B)** with the SEC within one business day."
- Section 4.3: "If an excess is identified after it occurred (for example, because a classification is corrected during Form N-PORT validation), the Program Administrator reports to the Board and causes Form N-RN to be filed no later than **one business day after identification**."

**Cause Analysis:**
The illiquid excess is driven by corrections to two positions:
1. **L14 (Tessaly): $21.8M reclassified to Illiquid** — Private placement with no approved override. The vendor model suggested "Less Liquid," but Program Rule 3.5 requires illiquid classification absent committee approval.
2. **L16 (Norcastle): $9.6M reclassified to Illiquid** — Trading halt (T12, ongoing since 2026-08-27) with no alternative venue. Program Rule 3.4 requires illiquid classification during halts.

The reclassification of L19 (Dellbrook, -$10.5M from illiquid) partially offsets these but does not resolve the excess.

---

#### Highly Liquid Investment Minimum (HLIM) — Shortfall Identified

The Fund's HLIM requirement (BGOF LRM Program Section 5) is **25% of net assets**. The compliance measure is "highly liquid investments (including cash) less the value of any highly liquid assets posted as margin or collateral in connection with derivatives."

**Highly Liquid Holdings (as of August 31):**

| Item | Classification | Value (USD) |
|------|---|---|
| DDA Cash (Fallowmere) | Highly Liquid | $16,900,000 |
| L01 — Ashgrove Systems | Highly Liquid | $12,099,920 |
| L02 — Brenmoor Pharmaceuticals | Highly Liquid | $10,400,000 |
| L03 — Vaudrey SA (corrected value) | Highly Liquid | $12,399,681 |
| L04 — Kiyomasa Precision | Highly Liquid | $6,200,146 |
| L09 — US Treasury Note | Highly Liquid | $14,499,852 |
| L11 — Brightwater Money Market Fund | Highly Liquid | $9,000,000 |
| L22 — Pembury Retail | Highly Liquid | $8,799,618 |
| L24 — FX Forward | Highly Liquid | $181,350 |
| **Subtotal** | | **$90,480,567** |
| Less: Futures margin (L23, FCM segregated) | *Deducted* | **(4,600,000)** |
| **HLIM Measure** | | **$85,880,567** |

**Fund-Level Metrics:**
- **Net Assets:** $367,956,922
- **Highly Liquid Assets (HLIM measure):** $85,880,567
- **HLIM Percentage:** 23.34%
- **HLIM Requirement:** 25.00%
- **Shortfall Amount:** $7,620,000 (1.66 percentage points)
- **Status:** **SHORTFALL**

**Program Requirements (Rule 22e-4(b)(3)(iii), implemented in BGOF LRM Program Section 5):**
- Section 5.3: "If the measure falls below the HLIM, the Program Administrator reports to the Board at its next regular meeting (next: 14 October 2026). If the shortfall lasts more than seven consecutive calendar days, the Program Administrator reports to the Board within one business day and the Fund files Form N-RN (Part D) within one business day."

**Current Status:** The shortfall as of August 31, 2026 is confirmed through this validation. The duration of the shortfall (whether it exceeds 7 consecutive calendar days) should be determined from daily liquidity monitoring data maintained by the LRM Program Administrator. If the shortfall is more than 7 days old at the time this N-PORT is filed, Form N-RN (Part D) must be filed concurrent with or before the N-PORT filing.

**Liquidity Note:** The pending Tessaly Series D subscription ($6M, scheduled September 25, 2026) will further increase illiquid holdings post-month-end, making remediation more urgent. Similarly, the pending Harwood Leisure add-on ($2.5M, settlement October 2) may also increase illiquids if classified as Less Liquid.

---

## CORRECTED N-PORT FILING INFORMATION

**Filing Deadline (Form N-PORT):** September 30, 2026 (30 days after month-end)  
**Form N-RN (Part B) — Illiquid Excess:** September 20, 2026 (one business day after identification)  
**Form N-RN (Part D) — HLIM Shortfall:** September 20, 2026 (if shortfall >7 consecutive days) or by Board meeting date  

**Corrected N-PORT totals (Part C, 25 holdings):**
- All corrections outlined in Section 1 must be applied
- Total investment value will increase by approximately $1.2M due to L03 correction
- Percentages of net assets will be recalculated for affected lines
- Liquidity classifications on L14, L16, L19 will be corrected
- Fair value level on L22 will be corrected to Level 2

---

## REQUIRED ACTIONS — IMMEDIATE (by September 20, 2026)

1. **Board Notification (LRM Committee + Full Board)**
   - Illiquid excess: 15.63% vs. 15% limit ($505K excess)
   - HLIM shortfall: 23.34% vs. 25% requirement ($7.6M shortfall)
   - Cause: Reclassification of L14 Tessaly (private placement, no override) and L16 Norcastle (trading halt)
   - Proposed remediation timeline and options

2. **SEC Filings (Form N-RN)**
   - File Part B (illiquid excess) within one business day
   - File Part D (HLIM shortfall) if >7 consecutive days, within one business day

3. **N-PORT Corrections**
   - Apply all six line-item corrections (L03 value/percentage, L14/L16/L19 liquidity, L22 fair value level)
   - Recalculate N-PORT totals
   - Hold corrected filing pending resolution of regulatory exceedances

4. **Valuation Designee Confirmation**
   - Confirm with Brightwater Advisors: Is L03 value $11.186M or $12.400M? Request written confirmation and reconciliation if discrepancy exists in their records.

5. **Portfolio Manager Notification**
   - Brief R. Castell on L14 (Tessaly) classification change and implications for Series D subscription
   - Confirm status of Norcastle (L16) halt and any remediation efforts
   - Discuss Harwood Leisure add-on (L20 additional $2.5M) and impact on illiquid holdings

---

## ASSUMPTIONS & METHODOLOGY

**Data Sources:**
- BGOF_NPORT_draft_2026-08_PartC_holdings.csv — draft N-PORT
- BGOF_holdings_valuation_20260831.csv — accounting records of market values and fair value levels
- BGOF_statement_of_net_assets_20260831.csv — net assets and total assets/liabilities
- BGOF_valuation_designee_memo_20260831.txt — valuation determinations and fair value adjustments
- BGOF_vendor_liquidity_classification_20260831.csv — third-party liquidity model output
- BGOF_liquidity_override_log_2026.csv — all requested and approved liquidity overrides
- BGOF_liquidity_risk_management_program_extract.md — Fund's adopted LRM Program (Version 4.0, Board-approved 2025-03-12)
- exchange_notice_Norcastle_trading_halt_20260827.txt — exchange notice of trading halt (T12)
- BGOF_security_master_extract.csv — reference for security identification

**Valuation approach:**
- Holdings valuation file treated as source of truth for market values (reconciles to BGOF_statement_of_net_assets_20260831.csv total assets)
- Percentages of net assets recalculated using net assets of $367,956,922.39

**Liquidity classification approach:**
- Vendor model output is default starting point
- Program rules (Section 3) applied in the following order:
  1. Rule 3.4 — Trading halts → Illiquid
  2. Rule 3.5 — Private placements without approved override → Illiquid
  3. Rule 3.6 — Rule 144A securities → Use vendor model
  4. Rule 3.7 — Bank loans sold <7 days, settle >7 days → Less Liquid
  5. Rule 3.8 — Derivatives → Use vendor model
- LRM Committee overrides applied only if APPROVED; REJECTED or PENDING overrides are ignored

**HLIM calculation:**
- Includes all cash ($16.9M DDA + $4.6M broker cash = $21.5M, but broker cash is margin and deducted)
- Includes all holdings classified as Highly Liquid in corrected N-PORT
- Deducts all cash posted as margin/collateral for derivatives (full $4.6M cash margin for L23 futures, classified Moderately Liquid)
- Expressed as percentage of net assets

**Illiquid calculation:**
- Includes all holdings classified as Illiquid in corrected N-PORT
- Expressed as percentage of net assets

---

## OPEN QUESTIONS FOR CLARIFICATION

1. **Vaudrey SA valuation discrepancy (L03):** The N-PORT draft shows $11.186M but accounting records show $12.400M (difference of $1.214M). Please confirm: Is this a data entry error in the draft, or do the valuation and accounting systems show different values for this position? Valuation designee memo indicates the systematic fair value factor should be applied, supporting the higher figure.

2. **Tessaly Series D timing and compliance:** The email from Brightwater Advisors (dated 2026-09-17) indicates the Series D subscription ($6M) was pre-trade cleared based on illiquids at 9.9%. However, corrected August month-end illiquids are 15.63%. Does the 9.9% figure include post-month-end adjustments or a different calculation methodology? Will the September pre-trade clearance be revisited in light of the corrected August baseline?

3. **Norcastle halt remediation:** Is the Fund considering any active steps to restore liquidity to the Norcastle position (e.g., engaging with the issuer to accelerate filing of required information, exploring off-exchange sales, or liquidating the position)? What is management's timeline for a decision?

4. **Harwood Leisure add-on:** The pending add-on ($2.5M, settlement 2026-10-02) is classified as Less Liquid in the current N-PORT. If the first add-on is settled before the N-PORT is filed, will this position be included in the month-end illiquid count? Current illiquids are already 15.63%; a Less Liquid position would not worsen the metric, but a reclassification to Illiquid would.

5. **HLIM shortfall duration:** Using daily liquidity monitoring data, determine whether the HLIM shortfall has lasted more than 7 consecutive calendar days as of the N-PORT filing date. This will determine whether Form N-RN (Part D) must be filed.

---

## CONCLUSION

The August 2026 N-PORT draft contains material errors that, when corrected, reveal that the Fund has exceeded its regulatory illiquid investment limit and fallen short of its HLIM requirement. Neither threshold violation can be ignored or remedied by re-dating the month-end. Both require immediate Board notification and SEC filing (Form N-RN Parts B and D).

**The N-PORT cannot be submitted to EDGAR in its current form.** Corrected line items must be applied, and the regulatory notifications must be filed concurrently with or before the corrected N-PORT filing (due September 30, 2026).

Please advise how you wish to proceed, and do not hesitate to ask for clarification on any of the findings above.

---

**Prepared by:** Senior Compliance Validator  
**Date:** September 19, 2026  
**Validated against:** Form N-PORT preparation procedures (BST_Form_NPORT_preparation_procedures.md) and BGOF Liquidity Risk Management Program Version 4.0
