# ALDERMOOR GLOBAL EQUITY FUND
## NAV Calculation & Hedge Monitoring — 18 September 2026
### From: Operations/Fund Accounting  
### To: Henrik Aalto, Fund Accounting Manager  
### Date: 18 September 2026

---

## Executive Summary

**AGEF 18 September 2026 NAV calculation is complete and ready for 11:30 publication.** All three class NAVs have been calculated with securities pricing and sub-fund P&L applied as reviewed. Independent hedge monitoring has been performed and identified one critical issue requiring immediate escalation.

**CRITICAL ACTION REQUIRED:**  
The I-EUR-H-Acc class hedge ratio has breached the 105% upper tolerance limit at **107.82%** following large net redemptions. This requires notification to Brackenridge Bank and escalation to ManCo Risk for determination of rebalancing action.

### Published Class NAVs (18 September 2026)
- **I-USD-Acc:** USD 149.86 per share
- **A-USD-Acc:** USD 145.26 per share  
- **I-EUR-H-Acc:** EUR 120.55 per share

---

## Calculation Basis & Methodology

### Starting Position (17 September 2026)
| Class | Shares in Issue | Net Assets USD | NAV/Share | WMR Rate |
|-------|-----------------|----------------|-----------|----------|
| I-USD-Acc | 1,412,337.55 | $212,688,904.12 | $150.59 | 1.17380 |
| A-USD-Acc | 811,204.99 | $118,420,556.40 | $145.98 | 1.17380 |
| I-EUR-H-Acc | 562,118.44 | $79,843,118.27 | €121.01 | 1.17380 |
| **Total** | | **$410,952,578.79** | | |

### 18 September P&L & Allocations

**Sub-Fund Level P&L:** –$2,104,922.06

This comprised:
- Dividend income: $184,220.40
- Foreign withholding tax: –$21,488.11
- Interest on cash: $3,318.62
- Realized securities gains: $1,240,118.55
- Unrealized securities change: –$3,912,440.18
- FX translation adjustment: $402,337.90
- Operating expenses (depositary, admin, audit, CSSF): –$989.24

**Allocation to Classes** (based on 17 Sep net asset ratios):
- I-USD-Acc: –$1,089,404.45 (51.76%)
- A-USD-Acc: –$606,556.70 (28.82%)
- I-EUR-H-Acc: –$408,960.91 (19.43%)

**Class-Specific Fees:**
- I-USD-Acc: –$4,428.59 (mgmt 0.75% + taxe 0.01%)
- A-USD-Acc: –$5,028.82 (mgmt 1.50% + taxe 0.05%)
- I-EUR-H-Acc: –$1,728.10 (mgmt 0.75% + taxe 0.01% + hedging fee 0.03%)

### Dealing Activity (18 September 2026)

| Class | Subscriptions | Redemptions | Net | Currency |
|-------|---------------|-------------|-----|----------|
| I-USD-Acc | $2,000,000.00 | $0 | **+$2,000,000.00** | USD |
| A-USD-Acc | $312,400.00 | $850,000.00 | **–$537,600.00** | USD |
| I-EUR-H-Acc | €250,000.00 | €4,500,000.00 | **–€4,250,000.00** | EUR |

**Note:** I-EUR-H-Acc dealing instructions were transmitted to Brackenridge Bank on 21 September (delayed due to RTA interface incident INC-7730) and not included in Brackenridge's 18 Sep 13:05 report.

### Currency Hedges — Class-Specific (I-EUR-H-Acc)

**Realized P&L:**
- **FWD-H-0817** (matured 18 Sep): Received EUR 34M @ 1.17840 WMR fix = $40,065,600; paid $39,820,800 @ 1.17120 contract rate → **Realized gain $244,800**

**Unrealized P&L Changes:**
- **FWD-H-0901** (open, matures 19 Oct): MTM change from –$41,400 (17 Sep) to +$124,200 (18 Sep) → **Unrealized gain $165,600**
- **FWD-H-0918** (new, rolled contract; matures 20 Oct): Buy EUR 34M @ 1.17985 → **Unrealized MTM $10,200**

**Total I-EUR-H-Acc Class Hedge P&L: $420,600**

### Portfolio-Level Hedges (Allocated to All Classes)

**FWD-P-0818** (JPY/USD forward, open):
- 17 Sep MTM: –$31,006.78
- 18 Sep MTM: $61,687.39
- **Total gain: $92,694.17**

Allocated by class net asset ratio:
- I-USD-Acc: $47,973.96 (51.76%)
- A-USD-Acc: $26,710.86 (28.82%)
- I-EUR-H-Acc: $18,009.36 (19.43%)

### Final Class NAVs (Post-Dealing, Pre-Publication)

| Class | Net Assets USD | Shares | NAV/Share USD | NAV/Share Published |
|-------|----------------|--------|---------------|-------------------|
| I-USD-Acc | $213,643,045.04 | 1,425,618.6464 | $149.8599 | **$149.86** |
| A-USD-Acc | $117,298,081.73 | 807,522.2950 | $145.2568 | **$145.26** |
| I-EUR-H-Acc | $74,862,838.62 | 526,997.3756 | €120.5494 | **€120.55** |

*I-EUR-H-Acc converted to EUR at WMR 18 Sep 1.17840*

---

## Independent Hedge Monitoring Check

### Hedge Ratio Analysis

**Brackenridge's Report (18 Sep 13:05 CEST):**
- Hedge basis NAV (17 Sep): EUR 68,021,058.33
- Open hedge notional: EUR 68,500,000 (34.5M + 34M)
- Reported ratio: 100.70% ✓ (within 95–105%)
- Note: Report run before dealing adjustments were received

**Our Independent Post-Dealing Calculation:**
- Post-dealing class NAV USD: $74,862,838.62
- Converted to EUR @ 1.17840: EUR 63,529,224.89
- Open hedge notional: EUR 68,500,000
- **Calculated hedge ratio: 107.82% ✗ BREACH**

### Breach Analysis

The large net redemption of EUR 4.25M reduced the I-EUR-H-Acc NAV by approximately EUR 4.25M / 1.17840 = USD 3.61M in dealing proceeds, plus the reduction effect of the actual EUR conversion. The hedge notional (EUR 68.5M) is now over-hedged relative to the reduced net assets.

**Required Notional Adjustment:** EUR –4,970,775.11 (reduction needed to return to 100% target)

### Hedge Attribution Verification ✓

**Class-Specific Contracts (I-EUR-H-Acc only):**
- FWD-H-0817: ✓ Tagged to I-EUR-H-Acc, matured & rolled 18 Sep
- FWD-H-0901: ✓ Tagged to I-EUR-H-Acc, open
- FWD-H-0918: ✓ Tagged to I-EUR-H-Acc, open (roll of FWD-H-0817)

**Portfolio-Level Contracts (allocated to all classes by net assets):**
- FWD-P-0818: ✓ Tagged PORTFOLIO, JPY/USD forward, correctly allocated per Prospectus 5.5

All attribution requirements met.

---

## Actions Required

### 1. **IMMEDIATE NOTIFICATION — Brackenridge Bank (Hedging Agent)**
Notify Brackenridge of:
- Post-dealing I-EUR-H-Acc net assets: EUR 63,529,224.89
- Hedge ratio breach: 107.82% (exceeds 105% tolerance)
- Recommended notional adjustment: Reduce hedge notional by EUR 4,970,775 to return to 100%
- Dealing instructions (EUR –4.25M net) were transmitted 21 Sep due to RTA interface incident; await confirmation of receipt/processing

### 2. **ESCALATION — ManCo Risk**
Escalate hedge ratio breach per AAM Hedging Procedure section 4:
- Notify of ratio outside tolerance
- Request policy determination on rebalancing (reduce to 100%, or monitor for discretionary action?)
- Decision required to either instruct Brackenridge to reduce notional, or determine acceptable tolerance for this valuation day

### 3. **NAV RELEASE FOR PUBLICATION**
- **Status:** Ready for 11:30 CET publication
- Class NAVs: I-USD-Acc $149.86, A-USD-Acc $145.26, I-EUR-H-Acc €120.55
- Hedge ratio breach does **not** suspend or delay publication (Procedure section 4)
- Publish with note that hedge rebalancing is under review

---

## Assumptions & Judgements

1. **Sub-Fund P&L Allocation:** Allocated using 17 September net asset ratios (51.76%, 28.82%, 19.43%) per Prospectus 8.2. This is the standard approach for non-class-specific items.

2. **Dealing Processing:** I-EUR-H-Acc dealing calculated from EUR amounts (subscriptions €250K, redemptions €4.5M) at 17 Sep NAV/share (€121.01/share). This is the normal treatment for currency-class subscriptions/redemptions.

3. **Hedge P&L Attribution:** Class hedge P&L (FWD-H contracts) attributed 100% to I-EUR-H-Acc. Portfolio hedge P&L (FWD-P) allocated to all classes by net asset proportion per Prospectus 5.5.

4. **Conversion to EUR:** I-EUR-H-Acc net assets converted at WMR 18 Sep 4pm London close (1.17840) per Prospectus 8.3.

5. **Hedge Notional:** Based on open contracts after the 18 Sep roll (FWD-H-0901 EUR 34.5M + FWD-H-0918 EUR 34M). Matured FWD-H-0817 excluded per Hedging Procedure section 2.

---

## Open Questions / Issues for Requester

1. **Brackenridge's Updated Report:** The 18 Sep hedging report (13:05) did not include post-dealing adjustments (not yet received at report time). Will Brackenridge issue an updated report with 21 Sep dealing instructions factored in, or shall we await tomorrow's report?

2. **Hedge Rebalancing Decision:** What is ManCo Risk's response to the 107.82% ratio? Should we instruct Brackenridge to reduce notional to 100% immediately, or will the position be monitored for rebalancing on the next business day?

3. **RTA Interface Incident:** Has INC-7730 been resolved? Any other impacts on settlement or collateral management identified?

4. **Redemption Timing:** The EUR 4.5M redemption (vs EUR 250K subscription) is unusual. Confirm this is a single large investor redemption and not a data error.

---

## Supporting Files & References

**Input files used:**
- `inputs/accounting/nav_final_AGEF_20260917.csv` — 17 Sep NAVs (starting position)
- `inputs/accounting/pnl_and_expenses_AGEF_20260918.csv` — Sub-fund P&L items
- `inputs/accounting/class_expense_accruals_AGEF_20260918.csv` — Class fees
- `inputs/registrar/dealing_summary_AGEF_DD20260918.csv` — Dealing activity
- `inputs/fx/fx_forwards_AGEF_20260917_20260918.csv` — Forward contracts & MTM
- `inputs/fx/fx_settlement_report_20260918.csv` — Realized P&L from matured contract
- `inputs/fx/wmr_rates_20260917_20260918.csv` — FX conversion rates
- `inputs/fx/hedging_agent_daily_report_20260918.txt` — Brackenridge's 13:05 report
- `inputs/governance/AAM_share_class_hedging_procedure_v2.md` — Hedge policy
- `inputs/prospectus/AGS_prospectus_extract_hedged_classes.md` — Allocation & hedging rules

**Calculation verified:** All amounts cross-checked for completeness and internal consistency.

---

**Ready for publication at 11:30 CET. Awaiting ManCo Risk determination on hedge rebalancing action.**
