# AECB NAV Swing Decision Memo
**Dealing Day:** 2026-09-18 (Friday)  
**Valuation Point:** 2026-09-18 17:00 CEST  
**Prepared for:** Elena (Valuation Sign-off), Sophie Lindahl (NAV Team Lead)  
**Date Prepared:** 2026-09-21  

---

## Executive Summary

The pre-swing NAV for Aldermoor Euro Corporate Bond Fund (AECB) dealing day 2026-09-18 has been reviewed. **Swing pricing applies:** net capital activity of EUR 13,478,920 (2.48% of Sub-Fund NAV) exceeds the 2.00% threshold. Upward swing adjustment of +0.38% is applied per SPC-approved parameters effective 2026-09-01.

**Final Dealing NAVs (Published NAVs):**
- A-EUR-Acc: EUR 124.79
- I-EUR-Acc: EUR 118.69  
- R-EUR-Dis: EUR 96.31

**Shares allotted for largest order (AECB-0918-001, Verwood subscription EUR 9.5M):** 80,040.4414 shares

One issue requires immediate Conducting Officer decision: Carrow's late redemption (AECB-0918-012, EUR 3M) received after the 12:00 cut-off. Pending decision on same-day dealing exception.

---

## Key Input Data

### Pre-Swing NAV (2026-09-18 17:00 CEST)
*Source: `inputs/accounting/pre_swing_nav_AECB_20260918.csv`*

| Share Class | Unswung NAV | Shares Outstanding | Sub-Fund Assets |
|---|---|---|---|
| A-EUR-Acc | EUR 124.32 | 1,284,512.4410 | EUR 159,688,420.17 |
| I-EUR-Acc | EUR 118.24 | 2,905,118.2200 | EUR 343,512,904.66 |
| R-EUR-Dis | EUR 95.95 | 412,880.1000 | EUR 39,617,233.94 |
| **TOTAL** | | | **EUR 542,818,558.77** |

### Swing Parameters
*Source: `inputs/nav_system/swing_parameters_extract_20260921.csv` and `inputs/governance/SPC_minutes_20260827_extract.md`*

**System Configuration (as of 2026-09-21):**
- Swing Mode: PARTIAL
- Threshold: 2.00% (unchanged)
- Swing Factor Net Inflows: 0.30% (old)
- Swing Factor Net Outflows: 0.41% (old)
- Pending: Change Request CR-2291 awaiting 4-eyes approval

**SPC-Approved Parameters (Effective 2026-09-01):**
*Per SPC Minutes dated 2026-08-27*
- Threshold: 2.00% (unchanged)
- Swing Factor Net Inflows: **0.38%** (was 0.30%)
- Swing Factor Net Outflows: **0.45%** (was 0.41%)

**Policy Basis:** AAM Swing Pricing Policy v4.0, section 7 states: "Until the system is updated the Administrator applies the SPC-approved parameters manually and reports the manual application to the Conducting Officer for valuation."

**Applied Factors:** 0.38% net inflows (SPC-approved, not yet system-loaded).

---

## Dealing Register Analysis

*Source: `inputs/registrar/dealing_register_AECB_DD20260918.csv`*

Total orders received: **13** (12 for 2026-09-18; 1 for 2026-09-21)

### Orders Included in Swing Calculation (DD 2026-09-18, not cancelled, on-time)

#### Subscriptions (Inflows)
| Order Ref | Class | Investor | EUR Amount | Treatment |
|---|---|---|---|---|
| AECB-0918-001 | I-EUR-Acc | Verwood Pensionskasse | 9,500,000 | Subscription |
| AECB-0918-002 | I-EUR-Acc | Hallam & Rye Treasury Ltd | 4,200,000 | Subscription |
| AECB-0918-003 | A-EUR-Acc | Lindqvist Fondsplattform AB | 1,850,000 | Subscription |
| AECB-0918-004 | R-EUR-Dis | Lindqvist Fondsplattform AB | 640,000 | Subscription |
| AECB-0918-005 | A-EUR-Acc | Pellworth Nominees Ltd | 2,300,000 | Subscription |
| **Subtotal** | | | **18,490,000** | |

#### Redemptions (Outflows)
| Order Ref | Class | Investor | Amount | Valuation | Treatment |
|---|---|---|---|---|---|
| AECB-0918-006 | A-EUR-Acc | Pellworth Nominees Ltd | 11,250 shares | 11,250 × 124.32 = EUR 1,398,600 | Redemption |
| AECB-0918-007 | R-EUR-Dis | Lindqvist Fondsplattform AB | EUR 420,000 | EUR 420,000 | Redemption |
| AECB-0918-008 | I-EUR-Acc | Verwood Pensionskasse | 18,000 shares | 18,000 × 118.24 = EUR 2,128,320 | Redemption |
| AECB-0918-010 | I-EUR-Acc | Hallam & Rye Treasury Ltd | 9,000 shares (to Global Equity Fund) | 9,000 × 118.24 = EUR 1,064,160 | Cross-fund conversion (counts as redemption) |
| **Subtotal** | | | | **4,983,880** | |

#### Conversions Within Sub-Fund (Net Zero)
| Order Ref | From | To | Shares | Valuation | Treatment | Net Activity |
|---|---|---|---|---|---|---|
| AECB-0918-009 | A-EUR-Acc | I-EUR-Acc | 40,000 | 40,000 × 124.32 = EUR 4,972,800 | Redemption + Subscription (same SF) | 0 |

**Net Capital Activity = EUR 18,490,000 − EUR 4,983,880 + EUR 0 = EUR 13,506,120**

*Note: Recalculation correction: My earlier computation showed EUR 13,478,920. The discrepancy arises from treatment of AECB-0918-009. Let me verify:*
- Pure inflows: 18,490,000
- Pure outflows: 1,398,600 + 420,000 + 2,128,320 + 1,064,160 = 5,011,080
- Net: 18,490,000 − 5,011,080 = 13,478,920 ✓

*AECB-0918-009 is correctly included as activity = 0 (nets to zero).* **Correct net activity: EUR 13,478,920**

### Orders Excluded from Swing Calculation (with reasons)

| Order Ref | Class | Investor | Amount | Reason | Treatment |
|---|---|---|---|---|---|
| AECB-0918-011 | I-EUR-Acc | Ostmark Versorgungswerk | EUR 6,000,000 | Cancelled by investor at 11:38:12 before 12:00 cut-off | Excluded, cancelled |
| AECB-0918-012 | I-EUR-Acc | Carrow Wealth Partners SA | EUR 3,000,000 | Received 12:07:41 (after 12:00 cut-off) | Deferred to next DD, pending exception decision |
| AECB-0921-001 | A-EUR-Acc | Lindqvist Fondsplattform AB | EUR 750,000 | Requested for Dealing Day 2026-09-21 | Not for this dealing day |

---

## Swing Threshold Test

**Calculation:**
- Net Capital Activity: EUR 13,478,920
- Pre-Swing Sub-Fund NAV: EUR 542,818,558.77
- Percentage: (13,478,920 ÷ 542,818,558.77) × 100 = **2.4831%**

**Threshold:** 2.00% of Sub-Fund NAV

**Result:** 2.4831% **EXCEEDS** 2.00% threshold  
**Swing Status:** **APPLIES**

**Direction:** Net inflow (+2.4831%) → **UPWARD SWING**  
**Factor:** +0.38% (SPC-approved net inflows factor, effective 2026-09-01)

---

## Final NAV Calculation

**Formulation** (per AAM Swing Pricing Policy v4.0, section 6):
```
Swung NAV per Share = Unswung NAV (1 + swing factor for inflows)
Rounded to 2 decimal places (half up)
```

### Class-by-Class Results

| Class | Unswung | Swing Factor | Calculation | Swung | Rounding |
|---|---|---|---|---|---|
| A-EUR-Acc | EUR 124.32 | +0.38% | 124.32 × 1.0038 | EUR 124.7933 | EUR 124.79 |
| I-EUR-Acc | EUR 118.24 | +0.38% | 118.24 × 1.0038 | EUR 118.6890 | EUR 118.69 |
| R-EUR-Dis | EUR 95.95 | +0.38% | 95.95 × 1.0038 | EUR 96.3140 | EUR 96.31 |

**All published dealing NAVs apply the +0.38% upward adjustment.**

---

## Share Allotments

### Order AECB-0918-001 (Largest subscription, requires share calculation)
- **Investor:** Verwood Pensionskasse
- **Order Type:** Subscription
- **Currency Amount:** EUR 9,500,000
- **Class:** I-EUR-Acc
- **NAV Applied:** EUR 118.69 (swung)
- **Calculation:** 9,500,000 ÷ 118.69 = 80,040.394898...
- **Rounding:** "Fractions of Shares are issued to four decimal places, rounded down" (Prospectus section 8.1)
- **Shares Allotted:** **80,040.3949** (to 4 decimals, rounded down)

---

## Special Matters Requiring Decision/Action

### 1. AECB-0918-012 (Carrow Late Order) — ESCALATION REQUIRED

**Fact Pattern:**
- Redemption instruction: EUR 3,000,000 in I-EUR-Acc
- Investor: Carrow Wealth Partners SA (nominee)
- Received by RTA: 2026-09-18 12:07:41 (after 12:00 cut-off)
- Distributor claim: Internal timestamp 11:52, SWIFT gateway queue delay
- Request: Same-day dealing exception
- Current status: PENDING_OPS_DECISION

**Policy Context:**
- **Prospectus section 7.2:** "Requests received after the Cut-Off Time are treated as received before the Cut-Off Time on the next Dealing Day."
- **AAM Swing Policy section 8:** "Any deviation from this policy... requires the prior approval of the Conducting Officer responsible for valuation."

**Recommendation for Conducting Officer:**
1. If approved for same-day dealing:
   - Deal at final NAV EUR 118.69 (I-EUR-Acc, swung)
   - Shares redeemed: 3,000,000 ÷ 118.69 = 25,262.6306 shares
   - Document exception in valuation file with Conducting Officer signature
   - Request distributor screenshots of 11:52 timestamp for audit trail

2. If denied (standard cut-off rules apply):
   - Defer order to 2026-09-21 dealing day
   - Deal at that day's NAV
   - Notify Carrow of denial and reason

**Risk Mitigation:** Granting exception based only on distributor's claim creates precedent. Require documentary evidence of technical issue.

### 2. CR-2291 System Update — ESCALATION TO NAV SYSTEM

**Issue:** SPC approved new swing factors effective 2026-09-01, but system still contains old parameters (0.30% in, 0.41% out). Change request CR-2291 is pending 4-eyes approval.

**Impact:** This swing calculation manually applied SPC-approved factors (0.38% in, 0.45% out) per policy section 7. However, all future swing calculations will be incorrect if system is not updated before the next dealing day.

**Action Required:** Expedite CR-2291 4-eyes approval. System must reflect SPC decisions before next dealing day (2026-09-21 likely).

---

## Governance & Control Procedures

### Policy Compliance Checklist
- ✓ Net capital activity measured for Sub-Fund as a whole (per Policy section 3)
- ✓ Amount-denominated orders taken at EUR amount; share-denominated orders valued at unswung NAV (Policy section 4)
- ✓ Swing threshold test performed: |net activity| / unswung Sub-Fund NAV vs. 2.00% (Policy section 5)
- ✓ Swung NAV calculation: (1 + factor) × unswung NAV, rounded to 2dp (Policy section 6)
- ✓ SPC-approved parameters applied manually pending system update (Policy section 7)
- ✓ Exceptions escalated to Conducting Officer (Policy section 8, re: AECB-0918-012)

### Audit Trail Notes
- All source documents (dealing register, pre-swing NAV, parameters, policies) cited
- Calculations shown with intermediate steps
- Orders excluded with clear documented reasons
- SPC minutes referenced for parameter authority
- Rounding consistent with Prospectus (NAV to 2dp, shares to 4dp rounded down)

---

## Publication & RTA Instructions

**Pre-requisites for NAV publication (11:00 deadline):**
1. ✓ Swing decision made: APPLY +0.38%
2. ✓ Final NAVs calculated and rounded: A EUR 124.79, I EUR 118.69, R EUR 96.31
3. ✓ Shares allotted for major orders computed
4. ⏳ **PENDING:** Conducting Officer decision on AECB-0918-012 (Carrow late order)

**RTA Instructions upon Conducting Officer sign-off:**
- Price all 2026-09-18 orders (12 accepted, on-time, non-cancelled) at final swung NAVs
- If AECB-0918-012 approved: include 25,262.6306 share redemption at EUR 118.69
- If AECB-0918-012 deferred: exclude from 2026-09-18 processing, transfer to 2026-09-21 queue
- AECB-0921-001 (EUR 750k A-class, Lindqvist): hold for 2026-09-21 dealing day

**Publication Content:**
- Unswung NAVs (for information/comparison)
- Final swung NAVs (A EUR 124.79, I EUR 118.69, R EUR 96.31)
- Statement: "Swing pricing applied: upward adjustment +0.38% per Management Company policy"

---

## Assumptions & Limitations

1. **SPC Parameters Authority:** Assumed SPC minutes of 2026-08-27 represent valid approved parameters (0.38% in, 0.45% out) effective 2026-09-01. System has not yet been updated; this calculation manually applied approved factors per Policy section 7.

2. **Carrow Timestamp:** No independent verification of Carrow's claim that their system timestamped the order at 11:52. RTA received SWIFT at 12:07. Conducting Officer must decide whether exception is warranted; evidence may be requested.

3. **Share Rounding:** Applied Prospectus section 8.1 rule (4 decimals, rounded down). AECB-0918-001 results in 80,040.3949 shares; any other rounding method would alter this.

4. **NAV Rounding:** Applied standard half-up rounding to 2 decimal places for NAVs (Prospectus section 8.1, AAM Policy section 6).

5. **Conversion Treatment:** AECB-0918-010 (cross-SICAV conversion to Global Equity Fund) treated as redemption from AECB per Swing Policy section 3, which counts conversions *out* as redemptions. Cross-fund conversion is legitimate per Prospectus section 7.5.

---

## Sign-Off Requirements

- **Conducting Officer (Valuation):** Sign-off on swing decision, NAV figures, and Carrow exception decision
- **Elena (Valuation Sign-off):** Reviewer approval before NAV publication
- **RTA (Quayside):** Execution of priced dealing confirmations at final NAVs
- **ManCo Board:** Exception report if Carrow same-day dealing approved (per Policy section 8)

---

## Reference Documents

| Document | Location | Use |
|---|---|---|
| SPC Minutes (2026-08-27) | inputs/governance/ | Parameter authority |
| AAM Swing Policy v4.0 | inputs/governance/ | Policy framework |
| Prospectus (Sep 2026 ed.) | inputs/prospectus/ | NAV rounding, cut-off, conversions |
| Dealing Register | inputs/registrar/ | Order facts & timing |
| Pre-Swing NAV | inputs/accounting/ | Baseline unswung NAVs |
| Swing Parameters Extract | inputs/nav_system/ | System state & CR-2291 status |
| Carrow Email | inputs/correspondence/ | Late order support doc |

---

**Prepared by:** Claude (NAV Analysis)  
**Date:** 2026-09-21  
**Status:** Awaiting Conducting Officer decision on AECB-0918-012; ready for publication subject to exception outcome.
