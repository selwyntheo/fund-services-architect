# TCBF NAV Reconciliation — 2026-09-17

## TO: Anneliese Kroft, NAV Oversight Manager  
## FROM: NAV Reconciliation Analysis  
## RE: Core Bond (TCBF) shadow break reconciliation  
## DATE: 2026-09-17

---

## Executive Summary

The 1.8-cent shadow break (adviser shadow 10.3558 vs. admin draft 10.3379) has been reconciled to four discrete issues affecting USD 719,893 of net assets (USD 745,618 after the required admin correction). One issue requires mandatory correction per fund policy; two require escalation to the VD; one requires notification to adviser.

**Recommendation: Correct Calloway Freight Lines per policy 4.2; hold NAV pending VD written approval of Harrow Point Energy repricing, or release with policy-compliant pricing if VD does not approve override.**

---

## Issues Identified

### 1. CALLOWAY FREIGHT LINES (USPH76AX8211) — MANDATORY CORRECTION
**Impact: USD -25,725 to investments**

**Issue:** Calloway is priced at prior-day carry-forward of 101.115, even though Vendor B evaluated bid is available at 100.380.

**Analysis:**
- Vendor A status: "NP - insufficient observable inputs" (no price today)
- Vendor B available: 100.380 (OK status)
- Admin pricing source: PRIOR_DAY_CARRY_FORWARD
- Policy 4.2: "If Vendor A does not provide a price (NP), use Vendor B evaluated bid"
- Policy 4.5: "Prior-day carry permitted only when no source 4.1–4.3 available"

**Ruling:** Admin has made a policy error. Vendor B is available and must be used per hierarchy. Prior-day carry is not permitted when a policy-prescribed source exists. This is an error under policy 6.3 and must be corrected before release.

**Correction:** Change Calloway investment value from 3,539,025 to 3,513,300. Journal entry: DR Investments 25,725 / CR Unrealized Gain/Loss 25,725.

**Corrected admin net assets:** 415,714,484.87  
**Corrected admin NAV per share (4dp):** 10.3350  
**Corrected admin NAV per share (2dp):** 10.34

---

### 2. HARROW POINT ENERGY (US4NCZQ04871) — ESCALATE FOR VD APPROVAL
**Impact: USD +84,480 to investments (if adviser pricing adopted)**

**Issue:** Adviser has adopted broker quote of 99.250 (Coverdale Securities mid); admin uses Vendor A evaluated bid of 97.842. PM challenged the Vendor A price citing refinancing news and street consensus of 98.75/99.75.

**Analysis:**
- Admin pricing source: VENDOR_A_EVAL_BID, price 97.842 (OK status)
- Adviser pricing source: BROKER_QUOTE_COVERDALE_MID, price 99.250
- PM challenge submitted at 15:10 ET to Vendor A with request to carry 99.25 in shadow
- Vendor A auto-response: Challenge received after 14:00 ET cutoff; will review next business day
- Policy 4.3: Broker quote requires "written VD approval of the single-source quote"
- Policy 4.6: "A challenge does not change the price until vendor issues revised price or VD approves override in writing"

**Ruling:** Policy-compliant, admin is correct on current facts. The broker quote is a valid potential source but requires written VD approval per section 4.3. The PM challenge/request to shadow team is not formal written VD approval. However, Tidewell (as VD) is asking admin to hold and reprice in their 17:58 ET email.

**Situation:** Tidewell requests admin hold and reprice to their marks. To proceed with repricing to broker quote, need documented written VD approval. If Tidewell as VD approves the override (in writing), admin may reprice. If not, admin releases with policy-compliant Vendor A price.

**Recommendation:** Escalate immediately to Tidewell VD (Hollis or designated approver) for written authorization of broker quote override. If approved, reprice. If not approved, proceed with Vendor A price 97.842 and notify.

---

### 3. KESTREL AUTO ABS (USTSSMTX1062) — ADVISER ERROR
**Impact: USD +500,823 to investments (adviser error)**

**Issue:** Adviser pool factor is 0.68240000; admin has 0.64118000. Difference results in adviser holding larger current face (8,188,800 vs. 7,694,160) and higher market value (8,291,160 vs. 7,790,337).

**Analysis:**
- Servicer report dated 2026-09-15 (Kestrel Monthly Report for distribution date 2026-09-15)
- Beginning balance for period: 249,076,000 with implied factor 0.68240000
- Ending balance (after distribution): 234,030,700 with factor 0.64118000
- Principal distribution: 15,045,300
- NAV date: 2026-09-17 (after distribution occurred)
- Policy 5.3: "Principal paydowns recorded on payment date using factor published by trustee/servicer"

**Ruling:** Admin is correct. The distribution occurred on 2026-09-15 (before NAV date of 2026-09-17). Admin correctly updated to post-distribution factor. Adviser is using pre-distribution factor and has not yet incorporated the servicer report or processed the distribution.

**No correction required to admin NAV.** Adviser should update shadow to post-distribution factor 0.64118000.

---

### 4. BRACKETT SPECIALTY RETAIL (USCOHZR54060) — ADVISER ERROR
**Impact: USD +160,125 to interest receivable (adviser error)**

**Composition:**
- Adviser accrued interest: 2,625
- Adviser past-due interest: 157,500
- Admin: 0 (correctly on non-accrual)

**Issue:** Adviser continues to show accrual status ACCRUING with both current accrued interest and past-due interest; admin correctly placed on non-accrual as of 2026-09-16.

**Timeline:**
- 2026-09-15 (17:30 ET): Trustee notice — interest payment due 2026-09-15 will not be made
- 2026-09-16 (07:05 ET): Company press release — filed voluntary Chapter 11; does not expect to make interest payment
- Admin positions dated 2026-09-17: Non-accrual status (eff 2026-09-16)
- Adviser positions dated 2026-09-17: Still accruing

**Analysis:**
- Policy 5.4: Non-accrual effective "on (a) issuer's filing for bankruptcy protection"
- Brackett filed Chapter 11 on 2026-09-16
- Policy 5.4: "On placement, all accrued interest and past-due interest are reversed"
- Admin has correctly reversed all interest to zero

**Ruling:** Admin treatment is correct per policy 5.4. Once bankruptcy is filed, accrual stops and interest claims become part of restructuring, not current receivables. Admin has correctly reversed interest; adviser has not.

**No correction required to admin NAV.** Adviser should update shadow to non-accrual status (eff 2026-09-16) with accrued and past-due interest removed.

---

### 5. Amortization Method — Policy Discrepancy (No NAV Impact)

All 14 positions show:
- Admin: EFFECTIVE_INTEREST (policy 5.2)
- Adviser: STRAIGHT_LINE (non-compliant)

Policy 5.2 specifies: "Premium amortized and discount accreted on the effective interest (constant yield) method, computed per coupon period and recognized daily on a straight-line basis within each period."

This affects amortized_cost and income statement presentation but does NOT affect NAV, which is based on market value. Admin is compliant with policy. Adviser's use of straight-line method should be corrected for procedural compliance and income statement accuracy, but does not require NAV change.

---

## Reconciliation of Differences

| Item | Admin | Adviser | Difference | Analysis |
|------|-------|---------|-----------|----------|
| Calloway price | 101.115 | 100.380 | -25,725 | **Admin error — must correct** |
| Harrow Point price | 97.842 | 99.250 | +84,480 | Admin compliant; adviser awaits VD approval |
| Kestrel pool factor | 0.64118 | 0.68240 | +500,823 | Admin correct (post-dist); adviser error |
| Kestrel accrued int | 2,962.25 | 3,152.69 | +190.44 | Inherent to pool factor difference |
| Brackett interest | 0 | 160,125 | +160,125 | Admin correct (non-accrual); adviser error |
| **Subtotal after Calloway correction** | | | +720,618 | Remaining break = adviser errors |

---

## Financial Impact

**Admin draft net assets:** USD 415,740,209.87  
**Calloway correction:** USD -25,725  
**Admin corrected net assets:** USD 415,714,484.87  
**NAV per share (4dp):** 10.3350  
**NAV per share (2dp, to release):** **10.34**

**Remaining shadow difference after admin correction:** USD 745,618  
(This is the adviser's net errors on Harrow Point, Kestrel, and Brackett positions — not requiring admin NAV change)

---

## Actions Required Before 19:00 ET Release

1. **Post entry for Calloway correction** (net investment value -25,725)
2. **Escalate Harrow Point to VD immediately** for written approval of broker quote repricing
   - If approved: Reprice to 99.250; release NAV 10.35 (2dp)
   - If not approved: Proceed with Vendor A 97.842; release NAV 10.34 (2dp)
3. **Notify Adviser Fund Oversight** of Kestrel pool factor and Brackett accrual issues

If VD approval of Harrow Point repricing cannot be obtained before 19:00, recommend **holding NAV release** pending either VD approval or Treasurer approval to release with policy-compliant Vendor A price (per policy 6.5).

---

## Supporting Documentation

- Admin positions: `inputs/administrator/draft_nav_positions_TCBF_20260917.csv`
- Adviser positions: `inputs/adviser/shadow_nav_positions_TCBF_20260917.csv`
- Vendor prices: `inputs/pricing/vendor_prices_TCBF_20260917.csv`
- Kestrel servicer report: `inputs/notices/kestrel_auto_2025-2_servicer_report_20260915.txt`
- Brackett notices: `inputs/notices/brackett_trustee_notice_and_press_release.txt`
- Policy: `inputs/policies/TFT_valuation_income_and_shadow_nav_procedures.md`
- PM price challenge: `inputs/correspondence/email_pm_harrowpoint_price_challenge.txt`
- VD request: `inputs/correspondence/email_tidewell_oversight_shadow_break.txt`

---

## Quenby Health Partners Amortized Cost Note

Adviser amortized cost: 4,307,349.21  
Admin amortized cost: 4,315,302.17  
Difference: USD -7,952.96  

This difference reflects the use of straight-line vs. effective interest amortization method, per the policy discrepancy noted above. It does not affect NAV or market value (4,248,560 for both).

