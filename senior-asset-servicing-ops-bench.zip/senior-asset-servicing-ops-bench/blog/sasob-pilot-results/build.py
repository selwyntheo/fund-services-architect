#!/usr/bin/env python3
"""Build the blog post from the committed pilot results (no hand-typed numbers in the charts)."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RUN = "pilot-2026-09"
summ = json.loads((ROOT / f"results/{RUN}/summary.json").read_text())
qa = json.loads((ROOT / f"leaderboard/results/_qa_{RUN}.json").read_text())
cheat = json.loads((ROOT / "leaderboard/results/_cheat_trials.json").read_text())
cal = json.loads((ROOT / "leaderboard/results/_calibration.json").read_text())
static = json.loads((ROOT / "leaderboard/results/_static_checks.json").read_text())

models = {k: {f: v[f] for f in ("basic_pass@1", "det_controlled_pass@1", "avg_steps", "avg_total_tokens",
                                 "avg_wall_clock_s")} for k, v in summ.items()}
tasks = []
for t in qa["tasks"]:
    row = {"id": t["task_id"], "domain": t["domain"]}
    for a, x in t["agents"].items():
        row[a] = {"b": x["basic"], "g2": x["g2"], "s": x["g1_score"], "fc": x["failed_critical"]}
    tasks.append(row)
lc = qa["lifecycle_counts"]
abl = [t["no_inputs_g1_score"] for t in qa["tasks"]]
n_err = sum(bool(v["errors"]) for v in static.values())
pipeline = [
    {"k": "1 · static checks", "t": "Structure & leak scan", "r": f"<strong>{n_err}</strong> errors · 6 enum-position biases fixed"},
    {"k": "2 · rubric review", "t": "Independent re-derivation", "r": "<strong>24/24</strong> re-solved · 16 tasks amended"},
    {"k": "3 · oracle / no-op", "t": "Calibration", "r": f"<strong>{sum(x['calibrated'] for x in cal['tasks'])}/{cal['n_tasks']}</strong> oracle ✓ no-op ✗"},
    {"k": "4 · live trials", "t": "4 models × 24 tasks", "r": f"<strong>{lc.get('saturated',0)}</strong> saturated · <strong>{lc.get('discriminating',0)}</strong> discriminating"},
    {"k": "4b · leakage ablation", "t": "Evidence folder emptied", "r": f"<strong>0/24</strong> solved · mean partial {sum(abl)/len(abl):.2f}"},
    {"k": "5 · cheat trials", "t": "Enum guessing & action spam", "r": f"<strong>{cheat['n_flagged']}/{cheat['n_tasks']}</strong> gameable"},
    {"k": "6 · human triage", "t": "5 frontier failures", "r": "2 capability · 2 contract · <strong>1 grader defect</strong> (fixed)"},
]
data = {"models": models, "tasks": tasks, "pipeline": pipeline}
html = (HERE / "template.html").read_text().replace("__DATA__", json.dumps(data)).replace("__DATE__", "21 September 2026")
(HERE / "index.html").write_text(html)
print("wrote", HERE / "index.html")
