# Adding the pilot-results post to scalefirst.org

Everything in `sasob-pilot-results/` is built from the committed results. `build.py` reads `results/pilot-2026-09/`
and `leaderboard/results/_*.json`, so none of the chart numbers are typed by hand. After a new run, re-run
`python blog/sasob-pilot-results/build.py` and re-export the figures.

| File | Use |
|---|---|
| `index.html` | Full interactive post (charts with hover and a table toggle, dark mode). Self-contained apart from Google Fonts |
| `post.mdx` | The same article as MDX, with frontmatter in the same fields your existing posts show (title, date, author, category, tags, reading time) |
| `fig-*.png` | 2× static exports of the three figures, used by `post.mdx` |
| `template.html`, `build.py` | Source and generator |

Your blog serves posts at `/blog/<slug>/` and appears to be MDX-based. Pick one of the three options below.

## Option A: MDX post (simplest, fits your existing pipeline)
1. Copy `post.mdx` into your posts folder (commonly `content/blog/` or `src/content/blog/`) as
   `frontier-models-passed-our-fund-ops-benchmark.mdx`.
2. Copy the three `fig-*.png` files to `public/blog/frontier-models-passed-our-fund-ops-benchmark/`. The image
   paths in the MDX already point there.
3. If your frontmatter keys differ (for example `pubDate` instead of `date`, or `categories` as an array), rename
   them to match an existing post.
4. Run the dev server, check `/blog/frontier-models-passed-our-fund-ops-benchmark/`, then commit and deploy.

## Option B: MDX post with the interactive charts
Do Option A, then put `index.html` at `public/embeds/sasob-pilot/index.html` and swap any figure image in the MDX
for an embed:
```mdx
<iframe src="/embeds/sasob-pilot/index.html#fig3" title="SASOB per-task results"
        style={{width: "100%", height: "760px", border: 0}} loading="lazy" />
```
(For an iframe, you may want a stripped `index.html` that holds only the figures. Remove the prose in
`template.html` and re-run `build.py`.)

## Option C: standalone page
Deploy `index.html` as-is at `public/blog/frontier-models-passed-our-fund-ops-benchmark/index.html`. It's a
complete page with its own typography (Fraunces, Public Sans, IBM Plex Mono), light and dark themes, and a mobile
layout. It won't pick up your site header and footer.

## Before publishing
- Push the repo first. The post links to `github.com/scalefirstai/senior-asset-servicing-ops-bench`, and the claims
  reference `results/pilot-2026-09/` and `docs/qa/pilot-2026-09.md`.
- Model IDs in the post are self-reported by each agent. Keep the caveat paragraph.
- Add the post to your RSS feed and OG image as you do for other posts. `fig-pass-rates.png` works as a social card.
