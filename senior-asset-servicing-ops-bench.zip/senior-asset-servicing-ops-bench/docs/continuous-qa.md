# Continuous QA

SASOB treats a benchmark as a product that ships releases, not a dataset that gets published once. The QA pipeline
is adapted from Snorkel's [Terminal-Bench 4 continuous QA framework](https://snorkel.ai/blog/terminal-bench-4-continuous-qa/),
which runs every task through six stages: static checks, an implementation rubric, oracle/no-op validation, live
agent trials, adversarial cheat trials, and human review. The table below shows how each stage works in SASOB and
what it produced on the v0.1 public split.

| # | Terminal-Bench 4 stage | SASOB implementation | Runs | v0.1 result |
|---|---|---|---|---|
| 1 | **Static checks** (format, paths, canary, no test fetching) | `scripts/validate_tasks.py` enforces the structure and identifiers. `scripts/static_checks.py` looks for leaks: absolute paths, critical expected values appearing in the prompt, hints or schema, input file names in the prompt, grader artefacts in inputs, and enum position bias | CI, every commit | 0 errors. 6 enum-position-bias warnings, fixed. 14 W1 warnings (expected value also printed in an input) reviewed as legitimate |
| 2 | **Implementation rubric** (does the instruction reveal the test? is difficulty real or tedium?) | The authoring spec (`docs/task-spec.md` §2) plus Layer 2 adversarial re-derivation: a second solver works the task from the prompt and inputs alone | per task, before merge | 24/24 re-derived. 16 tasks amended (ambiguity pinned in policy docs, over-strict checks loosened) |
| 3 | **Oracle and no-op validation** | `validate_tasks.py` and `scripts/calibrate.py` check that the oracle passes every check through the full grading pipeline and that `{}` and a schema skeleton both fail Gate 1 | CI | 24/24 calibrated |
| 4 | **Live agent trials** with trajectory review | `scripts/trials.py prepare/grade`. Frontier agents run in isolated sandboxes, every failure is triaged by hand (`results/<run>/triage.yaml`), and `scripts/qa_report.py` assigns each task a lifecycle state | per release | 4 models × 24 tasks. 23 saturated, 1 discriminating. 5 frontier failures triaged: 2 capability gaps, 2 contract ambiguities, 1 grader defect (fixed and re-graded) |
| 4b | **Leakage ablation** (SASOB addition) | Same agent, same prompt and schema, with an **empty `inputs/`**. Any Gate 1 pass means the answer leaks through the prompt or schema | per release | 0/24 pass Gate 1. Mean partial correctness 0.08 |
| 4c | **Sandbox-escape audit** (SASOB addition) | Answer keys are encrypted at rest during trials, and every tool call in every trajectory is scanned for access to solutions, verifiers, other trials or transcripts | per release | 0 accesses to answer material across 120 trajectories. Several agents wrote scratch files to `/tmp`; noted, benign |
| 5 | **Adversarial cheat trials** | `scripts/cheat_trials.py`: no-op, skeleton, first-enum, 400 seeded random fills, numbers copied from the prompt, and action spam against the control gate. It sees only what an agent sees | CI | 0/24 gameable. Best partial Gate 1 score by any strategy: 0.39 |
| 6 | **Human review and iteration** | Triage verdicts feed a versioned backlog (`docs/qa/hardening-backlog.md`). Any change to inputs or checks bumps the task `version`, and results are reported per benchmark version | per release | v0.2: contract clarified on negative and conditional actions, recon-002 → v2 |

## Task lifecycle

`task.yaml → qa.lifecycle` records where each task stands:

```
draft → static_ok → oracle_ok → trialed ─┬─ saturated       (every frontier agent solves it) → hardening round
                                         ├─ discriminating  (some do, some don't)            → keep
                                         ├─ unsolved        (none do)                        → solvability review
                                         └─ leaking         (solved with inputs removed)     → rewrite
          → hardened → expert_validated → released
```

A task can only be `released` after it is `discriminating` on the current frontier and has passed Layer 3 expert
review.

## Failure-triage verdicts

| verdict | meaning | action |
|---|---|---|
| `capability_gap` | the agent was wrong and the task was fair | none; counts against the agent |
| `grader_defect` | a correct answer was marked wrong | fix the check, bump the task version, re-grade all trials |
| `contract_ambiguity` | the answer contract allowed a reasonable reading that the check rejects | clarify the contract for future runs; the score stands |
| `task_defect` | inputs contradict each other, or the task is unsolvable or ambiguous | fix, bump the version, re-run |
