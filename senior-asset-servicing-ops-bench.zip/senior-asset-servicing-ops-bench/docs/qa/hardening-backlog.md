# Hardening backlog (v0.2 → v0.3)

The backlog is driven by the pilot-2026-09 trials: 23 of 24 tasks were saturated at the frontier on the
deterministic gates. Items are ordered by expected discriminative value.

## Benchmark-wide
1. **Discovery mode.** Ship a second schema per task that asks for the headline figures and actions but does **not**
   name the intermediate quantities (for example `tips_index_ratio`) or list root-cause enums. The agent has to
   discover what matters. Root causes are graded by the judge panel against the rubric, and the headline figures
   are graded deterministically. The pilot suggests the structured schema is the biggest source of scaffolding.
2. **Turn on the judge gates (G3, G4, G6)** with a cross-family panel, and report Controlled Solve. Calibrate
   against expert grading on 5 tasks first (Cohen's κ).
3. **Over-escalation controls.** For each task, add at least one `action_absent` check on a reflexive-caution move
   that would be wrong. Examples: holding a NAV that should be released, escalating a timing item, reprocessing
   below threshold. Target: a no-inputs agent passes G2 on at most 25% of tasks (currently 67%).
4. **Scale.** Replace hand-sized extracts with realistic volumes (5k–50k rows) where the trap is one row among
   thousands and has to be found by reconciliation, not by reading.
5. **Compounding traps.** Traps whose correct treatment depends on another trap. For example, a corrected price
   changes a materiality test, which in turn changes remediation.
6. **Missing-information tasks.** Tasks where the senior answer is to stop and ask. Grading covers the quality of
   `request_info` and the absence of fabricated figures.
7. **Author diversity.** Add practitioner-authored tasks and tasks drafted by non-Claude models so results are not
   biased towards the authoring model family.
8. **Reliability.** Three attempts per task and pass^3 as a headline companion metric.

## Task-specific
| Task | Item |
|---|---|
| sasob-pm-002 | Keep as is (discriminating). Add a variant with a GP clawback test |
| sasob-recon-001 | Remove `bond_purchase_accrued_interest` and `custody_fee_accrual_true_up` from the schema in discovery mode, and add 3 more netted MT940 lines |
| sasob-nav-003 | Add a second sub-fund with shared distributor flows and an in-kind subscription |
| sasob-navctl-001 | Add a second pricing error in the same period that offsets on one day |
| sasob-corpact-001 | Add an SI amendment received through a channel that needs call-back, at 11:58 ET |
| sasob-fundadm-004 | Scale the N-PORT extract to 1,200 holdings, with the errors spread across them |
| all | Review every `why:` so it states the principle and does not only restate the answer |
