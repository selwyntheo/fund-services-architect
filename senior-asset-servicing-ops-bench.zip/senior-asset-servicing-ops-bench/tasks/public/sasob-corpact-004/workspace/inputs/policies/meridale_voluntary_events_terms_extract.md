# Meridale Trust & Custody — Corporate Actions Service Terms (Schedule 4), extract: voluntary events
Version 6.1, effective 2026-01-01.

7.1 **Client Response Deadline.** For US tender and exchange offers, the Client Response Deadline for tenders,
amendments and withdrawals is 5:00 p.m. New York time (ET) on the business day before the offer's expiration date,
unless the notification states otherwise. All times are New York time.

7.2 **Late instructions**, including withdrawals, do not bind Meridale. Asset Servicing may transmit one on a
best-efforts basis only with the written approval of the Head of Asset Servicing. Meridale has no liability for a
late instruction that is not transmitted.

8.1 **Odd-lot certifications.** Meridale completes an odd-lot certification only if the beneficial owner's aggregate
holding, across all Meridale accounts and as confirmed by the client, is below the offer's odd-lot threshold on both
the date of tender and the expiration date. Separate accounts of the same beneficial owner are aggregated.

8.2 **Proration and allocation.** Tender results are allocated per tender instruction (VOI) using the depositary's
final proration factor and the offer's rounding rule. Preliminary factors in issuer press releases are used only for
indicative client communication. They are never used for booking or crediting.

8.3 **No contractual crediting of prorated offers.** Proceeds of a tender offer subject to proration are credited
when the depositary pays, not earlier. Any engine projection scheduled for automatic credit must be held and re-run
on final terms.

9.1 **Client complaints and compensation.** Where a client disputes an outcome, Asset Servicing establishes the
facts from the instruction log and time stamps. Compensation may be offered only through the Operational Incident
process, with Head of Operations approval. Relationship managers and Asset Servicing staff may not promise or credit
compensation. After expiration, Meridale does not ask a depositary to reverse or amend a tender.
