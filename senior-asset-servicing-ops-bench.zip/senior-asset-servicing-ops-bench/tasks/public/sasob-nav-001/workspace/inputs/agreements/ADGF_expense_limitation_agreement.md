# EXPENSE LIMITATION AGREEMENT (excerpt)
**Parties:** Aldermoor Funds Trust, on behalf of Aldermoor Dividend Growth Fund (the "Fund"), and Aldermoor Capital
Management LLC (the "Adviser"). Amended and restated effective 2025-03-01. Term: through 2027-02-28, renewable.

**1. Expense Limitation.** The Adviser agrees to waive its management fee and/or reimburse Operating Expenses of each
class of the Fund to the extent necessary so that the Operating Expenses of the class, expressed as an annual
percentage of the average daily net assets of the class, do not exceed the Operating Expense Limit for that class:

| Class | Operating Expense Limit (from 2025-03-01) | Operating Expense Limit (2023-03-01 to 2025-02-28) |
|---|---|---|
| A | 1.00% | 0.90% |
| C | 1.75% | 1.65% |
| I | 0.70% | 0.70% |

(The Class A and Class C limits were increased on 2025-03-01 when the Class A 12b-1 rate was raised from 0.15% to
0.25% with shareholder approval, and the Class C limit was aligned.)

**2. Operating Expenses.** "Operating Expenses" means all expenses borne by a class — its Class Expenses and its
allocated share of Fund expenses — **other than** Excluded Expenses. "Excluded Expenses" are: (i) interest and other
borrowing costs on amounts drawn under any credit facility (commitment fees on undrawn amounts are Operating
Expenses); (ii) taxes; (iii) brokerage commissions and other transaction costs; (iv) acquired fund fees and expenses;
(v) dividend and interest expense on securities sold short; and (vi) extraordinary expenses, including litigation
and indemnification expenses and expenses of any shareholder meeting not in the ordinary course.

**3. Class-by-class application.** The limit is applied separately to each class. A waiver or reimbursement
attributable to one class shall not be reduced by, or offset against, Operating Expenses of another class that are
below that class's limit.

**4. Daily application.** For each calendar day the Administrator shall compare each class's Operating Expenses
accrued for the day with that class's daily limit (Operating Expense Limit x beginning-of-day class net assets as
defined in the Multiple Class Plan / 365) and accrue the excess, rounded to the cent, as a waiver of the management
fee allocated to that class and, to the extent the excess exceeds that allocated fee, as a reimbursement.

**5. Recoupment.** The Adviser may recoup amounts waived or reimbursed for a class until the last day of the 36th
month following the month in which the waiver or reimbursement was accrued, **provided that** (a) the recoupment
does not cause the class's Operating Expenses to exceed the lesser of (x) the Operating Expense Limit in effect when
the amount was waived and (y) the Operating Expense Limit in effect at the time of recoupment, and (b) the recoupment
has been approved by the Board of Trustees. The Administrator shall not accrue any recoupment until it has received
written notice from the Fund Treasurer that Board approval has been obtained, specifying the class and maximum amount.

**6. Records.** The Administrator shall maintain a register of each class's waived and reimbursed amounts and their
recoupment expiry dates.
