# Aldermoor Funds Trust — Aldermoor Dividend Growth Fund (ADGF)
## Extract A: Multiple Class Plan pursuant to Rule 18f-3 (as amended and restated 2025-03-01)

**Section 2 — Class Expenses.** The following expenses are borne solely by the class to which they relate
("Class Expenses"): (a) fees under the Rule 12b-1 Distribution and Service Plan (Class A 0.25%; Class C 1.00% of
average daily net assets of the class; Class I none); (b) sub-transfer agency, recordkeeping and shareholder
servicing fees paid to financial intermediaries that are attributable to a class (currently Class I only);
(c) transfer agency per-account fees attributable to the shareholder accounts of a class.

**Section 3 — Allocation of income, gains and fund expenses.** Income, realized and unrealized capital gains and
losses, and expenses other than Class Expenses are allocated to each class on the basis of the **relative net
assets of each class at the beginning of the day**. For this purpose the net assets of a class at the beginning of
a day are the net assets of the class as finally determined at the close of the preceding business day, adjusted
for capital share transactions with a trade date on or before that preceding business day. Capital share
transactions with a trade date on the current day are priced at the current day's net asset value and do not
participate in the current day's income, gains, losses or expenses.

**Section 4 — Waivers and reimbursements.** Expense waivers or reimbursements under any expense limitation
agreement may be applied differently to each class where the agreement so provides, and are allocated to the class
to which they relate.

## Extract B: Quayside Fund Administration — Daily NAV Procedures for ADGF (v3.1, approved by the Fund Treasurer 2026-01-12)

B.1 Asset-based expenses (management, administration, custody, 12b-1, sub-TA) accrue daily at the annual rate on
    the relevant beginning-of-day net assets (Plan §3 definition) divided by 365.
B.2 Fund-level items are allocated line by line using the beginning-of-day allocation ratios (unrounded). Each
    allocated amount is rounded to the cent; any rounding residual on a line is assigned to the class with the
    largest allocation base so that class amounts sum to the fund total.
B.3 The expense limitation worksheet is prepared daily by the fund accountant and the resulting waiver /
    reimbursement is booked by manual entry (GL 5900 / 1390). The NAV system does not calculate it; draft
    NAVs from the system exclude it.
B.4 The allocation base used by the NAV system must be agreed each day to the prior day's final NAV report before
    the draft class NAVs are relied upon.
B.5 NAV per share = class net assets (before current-day capital share activity) / class shares outstanding
    (after capital share activity through the prior business day). It is calculated to four decimal places
    (round half up) for internal controls and is published rounded to the nearest cent (round half up, from the
    unrounded value).
B.6 No entry that affects the NAV may be booked on the instruction of the Adviser alone where the governing
    agreement requires Board or Fund Treasurer approval. Such requests are referred to the Fund Treasurer.
