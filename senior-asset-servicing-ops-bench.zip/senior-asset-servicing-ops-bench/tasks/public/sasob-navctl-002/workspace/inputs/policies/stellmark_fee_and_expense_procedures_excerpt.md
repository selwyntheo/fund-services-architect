# Stellmark Fund Services — Fund Accounting Procedures: Fees, Accruals and Expense Limitations (extract)
Corvane Investment Trust service schedule. Version 6.0, 2025-08-01.

## E1. Daily accrual conventions
E1.1 Asset-based fees (management, administration) accrue for each calendar day at the annual rate / 365 on the
     net assets of the NAV struck on the Business Day **preceding** the NAV in which the accrual is booked.
E1.2 A Business Day's NAV includes the accruals for every calendar day from that Business Day up to (but not
     including) the next Business Day. A Friday NAV therefore includes Saturday and Sunday accruals, and a
     calendar day that follows a waiver or fee change date is booked in whichever NAV covers that day.
E1.3 Contractual fee waivers are applied by the fee module for accrual days within the rule's effective dates.
     Rule dates are set up from the source document and reviewed by a second preparer.

## E2. Expense limitation (FYTD method)
E2.1 Each NAV date the fee module recomputes, on a fiscal-year-to-date basis through the latest accrual date:
     cap amount = limit (bps) × FYTD average daily net assets × FYTD calendar days / 365.
     Reimbursement receivable (GL 1380) = max(0, FYTD covered expenses − cap amount). The daily entry is the
     change in that receivable.
E2.2 Covered expenses exclude items the Expense Limitation Agreement excludes (interest, taxes, brokerage
     commissions, acquired fund fees and expenses, and expenses designated extraordinary by the Board).
E2.3 FYTD average daily net assets uses each calendar day's net assets (non-Business Days take the preceding
     NAV). Prior NAVs' net assets are not restated for corrections that do not produce a Material Day.

## E3. Corrections
E3.1 Correcting entries are measured as of the latest accrual date of the last NAV struck and are booked in the
     next NAV, together with the consequential expense-limitation true-up under E2.1.
E3.2 Corrections are subject to the Trust's Policy on the Correction of NAV Errors.
