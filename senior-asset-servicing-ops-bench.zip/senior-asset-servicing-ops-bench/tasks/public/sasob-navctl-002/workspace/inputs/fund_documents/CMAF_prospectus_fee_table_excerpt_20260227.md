# Corvane Multi-Asset Fund — Prospectus dated February 27, 2026 (extract)

## Fees and Expenses of the Fund — Institutional Shares
| Annual Fund Operating Expenses (as a % of the value of your investment) | |
|---|---|
| Management Fee | 0.60% |
| Other Expenses | 0.30% |
| Acquired Fund Fees and Expenses | 0.06% |
| Total Annual Fund Operating Expenses | 0.96% |
| Fee Waiver and/or Expense Reimbursement(1) | (0.05)% |
| Total Annual Fund Operating Expenses After Fee Waiver and/or Expense Reimbursement | 0.91% |

(1) Corvane Partners LLC (the "Adviser") has contractually agreed to waive fees and/or reimburse expenses so that
Total Annual Fund Operating Expenses (excluding interest, taxes, brokerage commissions, acquired fund fees and
expenses, and extraordinary expenses such as litigation) do not exceed 0.85% of the Fund's average daily net
assets through February 28, 2027. This agreement may be terminated only by the Board of Trustees. The Adviser's
separate contractual waiver of 0.10% of its management fee expired on February 28, 2026 and has not been renewed.

## Dividends and distributions
The Fund declares and pays dividends from net investment income and distributes net capital gains, if any,
annually, normally in December.
