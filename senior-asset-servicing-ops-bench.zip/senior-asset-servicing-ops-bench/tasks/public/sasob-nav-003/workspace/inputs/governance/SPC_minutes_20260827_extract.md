# Swing Pricing Committee — Minutes (extract) — 27 August 2026
Present: E. Marchetti (Chair, Conducting Officer — Valuation & Risk), T. Aubry (Risk), J. Kowal (Portfolio
Management, non-voting), Quayside Fund Administration (observer).

**Item 3 — Quarterly review of swing factors (Q3 2026).** Following the review of dealing costs (bid-ask spreads,
market impact, transaction taxes) for June–August 2026, the Committee APPROVED the following parameters for
Aldermoor Euro Corporate Bond Fund with effect from Dealing Day **1 September 2026**:

| Parameter | Previous (from 1 June 2026) | Approved (from 1 Sep 2026) |
|---|---|---|
| Swing threshold (% of Sub-Fund NAV) | 2.00% | 2.00% (unchanged) |
| Swing factor — net inflows | 0.30% | **0.38%** |
| Swing factor — net outflows | 0.41% | **0.45%** |

**Item 4 — Stressed-market factors.** Risk presented a draft proposal to raise the net-outflow factor to 0.55% in
stressed conditions. NOT APPROVED; to be revisited at the Q4 meeting with further liquidity analysis.

**Action:** Quayside to update the NAV system parameters for AECB effective DD 2026-09-01 (written notification sent
28 Aug 2026).
