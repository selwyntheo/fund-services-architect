# Brightwater Series Trust — RIC Qualification Compliance Policy (extract)

Owner: Treasurer of the Trust. Operated by Oakhurst Fund Administration (Fund Tax) under the Fund
Administration Agreement, Schedule D. Approved by the Board 2025-12-10. Version 3.1.

## 1. Scope
1.1 Applies to each series of the Trust that intends to qualify as a regulated investment company
    ("RIC") under Subchapter M of the Internal Revenue Code, including series that are
    "non-diversified" for purposes of the Investment Company Act of 1940.
1.2 This extract covers the asset diversification requirements of IRC §851(b)(3). Gross income
    (§851(b)(2)) and distribution requirements are covered in sections 7–9 (not reproduced).

## 2. Testing dates
2.1 Diversification is tested at the close of each quarter of the Fund's **taxable year**. Each series
    uses its fiscal year as its taxable year. Brightwater Focused Value Fund (BFVF): fiscal year ends
    30 November; quarter-ends are the last day of February, May, August and November.
2.2 Values are the values used to strike the Fund's NAV at the close of the testing date (market
    quotations where readily available, otherwise fair value as determined under the Fund's
    valuation procedures).

## 3. Definitions used by Fund Tax
3.1 **Total Assets** — the Fund's gross total assets as shown on the statement of assets and
    liabilities at the testing date, before deduction of any liabilities (including borrowings).
3.2 **Cash and cash items** — cash, and receivables (including dividends and interest receivable,
    receivables for investments sold and for Fund shares sold). Prepaid expenses and other
    non-security assets are included in Total Assets but are **not** qualifying assets.
3.3 **Government securities** — as defined in section 2(a)(16) of the 1940 Act: securities issued or
    guaranteed as to principal or interest by the United States, or by a person controlled or
    supervised by and acting as an instrumentality of the U.S. Government pursuant to authority
    granted by Congress. Fund Tax treats U.S. Treasury obligations and obligations of U.S. agencies
    and government-sponsored enterprises (e.g. GNMA, FHLB, FNMA, FHLMC, FFCB) as Government
    securities. Obligations of non-U.S. governments, their agencies and political subdivisions,
    supranational organisations and U.S. states and municipalities are **not** Government
    securities; each such obligor is a separate issuer.
3.4 **Repurchase agreements** — a repurchase agreement that is "collateralized fully" by cash and/or
    Government securities (as that term is used in 1940 Act Rule 5b-3) is treated as an investment
    in Government securities. Any other repurchase agreement is treated as a security of the
    repo counterparty and aggregated with all other securities of that counterparty.
3.5 **Securities of other RICs** — shares of an investment company for which a RIC election is on file
    in the issuer master (`ric_election_on_file = Y`). Other pooled vehicles are analysed by
    Fund Tax case by case.
3.6 **Issuer aggregation** — all securities of the same issuer (common and preferred stock, debt,
    commercial paper, repurchase agreements under 3.4 and any other instrument) are aggregated
    for every limit in this policy.

## 4. The 50% test (IRC §851(b)(3)(A))
4.1 At least 50% of Total Assets must be represented by: (i) cash and cash items, Government
    securities and securities of other RICs; and (ii) other securities, limited in respect of any
    one issuer to not more than 5% of Total Assets and not more than 10% of the outstanding voting
    securities of the issuer.
4.2 Fund Tax applies 4.1(ii) issuer by issuer on an all-or-nothing basis: if the aggregate value of an
    issuer's securities exceeds 5% of Total Assets, or the Fund holds more than 10% of the issuer's
    outstanding voting securities, **none** of that issuer's securities count as qualifying assets.
4.3 Voting securities: common stock and other securities entitled to vote for directors. Non-voting
    preferred stock and debt count toward the 5% limit but not the 10% voting limit. Under IRC
    §851(c)(5) the equity securities (units) of a qualified publicly traded partnership are treated
    as outstanding voting securities for this purpose.

## 5. The 25% test (IRC §851(b)(3)(B))
5.1 Not more than 25% of Total Assets may be invested in: (i) the securities (other than Government
    securities or securities of other RICs) of any one issuer; (ii) the securities (other than
    securities of other RICs) of two or more issuers which the Fund controls and which are engaged
    in the same or similar trades or businesses or related trades or businesses; or (iii) the
    securities of one or more qualified publicly traded partnerships (QPTPs).
5.2 "Controls" means ownership of 20% or more of the total combined voting power of all classes of
    stock entitled to vote (IRC §851(c)(2)).
5.3 Fund Tax treats controlled issuers that share the same `sub_industry` in the issuer master as
    engaged in the same or similar trades or businesses unless Tax Counsel concludes otherwise in
    writing before the testing date.

## 6. Failures and cure
6.1 **Acquisition rule (IRC §851(d)(1)).** A Fund that met the requirements at the close of the prior
    quarter does not lose RIC status for a discrepancy at the close of a later quarter unless the
    discrepancy exists immediately after the acquisition of any security or other property and is
    wholly or partly the result of that acquisition. Such a discrepancy is cured if it is eliminated
    within 30 days after the close of the quarter.
6.2 **Conservative attribution.** If the Fund acquired, during the quarter, any security of an issuer
    whose securities contribute to a discrepancy (or any non-qualifying asset, where the 50% test
    is failed), Fund Tax treats the discrepancy as attributable to acquisition and a cure is required.
6.3 **Cure deadline** — the 30th calendar day after the quarter-end (for 31 August: 30 September).
    Trades must have a trade date on or before the deadline.
6.4 **Cure sizing** — Fund Tax reports the minimum market value of securities to be disposed of, at
    quarter-end values, with disposal proceeds assumed held in cash or Government securities
    (Total Assets unchanged), such that **both** tests are met. A cure may not be achieved by
    increasing Total Assets through borrowing or capital share activity. The adviser selects the
    securities to be sold; Fund Tax reports the minimum and recommends a buffer.
6.5 **De minimis / reasonable cause relief (IRC §851(d)(2))** is a last resort, requires Tax Counsel and
    the Treasurer, and is not available as a planning alternative to a timely cure.

## 7. Escalation and certification
7.1 Any failed test, or any test result that differs from the preparer's first cut, is escalated the
    same day to the Director of Fund Tax (Oakhurst) and the Trust Treasurer.
7.2 Where a cure is required, the adviser's Chief Compliance Officer and the portfolio manager are
    notified in writing of the discrepancy, the minimum cure amount and the deadline. Oakhurst does
    not place or instruct trades.
7.3 The quarterly compliance certificate to the Board may not state that a Fund met the §851(b)(3)
    requirements for a quarter until any required cure has been completed and re-tested; the
    certificate for that Fund is held pending cure.
