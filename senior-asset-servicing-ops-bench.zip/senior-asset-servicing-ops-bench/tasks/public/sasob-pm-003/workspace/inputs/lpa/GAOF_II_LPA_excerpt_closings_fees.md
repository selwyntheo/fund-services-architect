# Granite Arch Opportunities Fund II, L.P.
## Agreement of Limited Partnership dated as of 2 February 2026 — EXCERPT (closings, drawdowns, fees)
Operational extract prepared by Halcyon Private Fund Services. The executed agreement governs.
Partnership LEI 549300ERVEJPNBRH4950.

---

### Article 1 — Definitions (extract)

**"Initial Closing Date"** means 2 February 2026.

**"Subsequent Closing"** means any closing after the Initial Closing Date at which Subsequent Partners are
admitted, or existing Partners increase their Commitments. The final Subsequent Closing shall occur no later than
the first anniversary of the Initial Closing Date.

**"Subsequent Partner"** means a Partner admitted, or a Partner increasing its Commitment, at a Subsequent Closing
(in respect of the new or increased Commitment only). **"Existing Partner"** means, for a Subsequent Closing,
each Partner admitted before that Subsequent Closing.

**"Commitment Percentage"** means, for any Partner, its Commitment divided by the aggregate Commitments of all
Partners (including the General Partner), as in effect from time to time.

**"Fee-Paying Partner"** means each Limited Partner other than the General Partner and its Affiliates.

### Section 3.4 — Subsequent Closings

(a) **Equalization Contribution.** Each Subsequent Partner shall contribute on the date of its Subsequent Closing
an amount equal to its Commitment Percentage (determined after giving effect to that Subsequent Closing) of the
aggregate Capital Contributions made by all Partners before that Subsequent Closing, other than Capital
Contributions in respect of Management Fees. The Equalization Contribution is a Capital Contribution by the
Subsequent Partner and reduces its Unfunded Commitment.

(b) **Distribution to Existing Partners.** Amounts contributed under paragraph (a) are distributed to the Existing
Partners (including the General Partner), pro rata to their Commitments, so that after the Subsequent Closing each
Partner's Capital Contributions (other than in respect of Management Fees) equal its Commitment Percentage of the
aggregate of such Capital Contributions. Amounts so distributed are treated as a return of Capital Contributions,
are added back to the recipient's Unfunded Commitment, and may be recalled.

(c) **Management Fee.** Each Subsequent Partner that is a Fee-Paying Partner shall pay the Management Fee it would
have paid had it been admitted on the Initial Closing Date, for the period from the Initial Closing Date through
the last day of the calendar quarter in which the Subsequent Closing occurs, at the rate applicable to it. This
amount is paid to the Manager. It is a Capital Contribution in respect of Management Fees and reduces the
Subsequent Partner's Unfunded Commitment.

(d) **Additional Amount.** Each Subsequent Partner shall also pay an additional amount (the "**Additional
Amount**") equal to simple interest at 8% per annum on the portion of each Capital Contribution included in the
amount described in paragraph (a) that is attributable to it, calculated from and including the due date of that
Capital Contribution to but excluding the date of the Subsequent Closing, on the basis of the actual number of
days elapsed and a year of 365 days. The portion attributable to a Subsequent Partner is its Commitment
Percentage (determined after giving effect to that Subsequent Closing) of that Capital Contribution by all
Partners.

(e) The Additional Amount is paid in addition to, and not as part of, the Subsequent Partner's Commitment. It is
not a Capital Contribution and does not reduce the Subsequent Partner's Unfunded Commitment. It is distributed to
the Existing Partners (including the General Partner) pro rata to their Commitments. It is not income of the
Partnership and is not taken into account in determining distributions under Article 9.

(f) Amounts under this Section are computed for each Partner and each Capital Contribution separately and
rounded to the nearest cent. Any residual arising from rounding in the allocation among Existing Partners is
allocated to the General Partner.

(g) The General Partner may reduce or waive the Additional Amount for any Subsequent Partner only with the consent
of the Advisory Committee.

### Section 3.3 — Drawdowns (extract)

Capital Contributions are due on the date specified in the Drawdown Notice (the "due date"), which shall be no
earlier than ten Business Days after the notice. A Partner that pays after the due date owes default interest
under Section 3.8. Section 3.8 obligations are separate from, and do not affect, amounts payable under Section 3.4.

### Section 8.1 — Management Fee (extract)

(a) Each Fee-Paying Partner pays the Manager an annual Management Fee of 2.00% of its Commitment during the
Investment Period, or such lower rate as is set out in a side letter with that Partner.

(b) The Management Fee is payable quarterly in advance on the first day of each calendar quarter. Each full-quarter
installment equals one quarter of the annual Management Fee. The installment for any period shorter than a
calendar quarter equals the annual Management Fee multiplied by the number of days in the period (counting the
first and last day) divided by 365.
