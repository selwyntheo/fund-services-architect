# Brightwater Equity Income Opportunities Fund — Managed Distribution Plan and Section 19(a) Notice Procedures

Owner: Treasurer of the Fund. Prepared by Oakhurst Fund Administration (CEF Administration) under the
Administration Agreement. Adopted by the Board 2024-03-06; last revised 2026-02-18 (rate change effective
March 2026 distribution). Version 1.6.

## 1. The Plan
1.1 The Fund pays a fixed monthly distribution under a managed distribution plan (the "Plan") in reliance on
    exemptive relief from Section 19(b) of the Investment Company Act of 1940 and Rule 19b-1. The Board sets
    the rate; FY2026 rate: $0.1100/share (November 2025 – February 2026), $0.1150/share from March 2026.
1.2 The Fund's fiscal year ends 31 October.

## 2. When a Section 19(a) notice is required
2.1 Section 19(a) and Rule 19a-1 require a separate written statement accompanying any distribution that is
    paid in whole or in part from a source other than net investment income. Under the Plan's exemptive
    conditions the Fund also issues the notice by press release and posts it on the Fund's website, and the
    notice must accompany the payment (mailed/transmitted to shareholders of record with the payment).
2.2 If the entire distribution (current) is estimated to be from net investment income, no Section 19(a)
    notice is required for that distribution, but Plan disclosures continue.

## 3. Content (Plan exemptive conditions)
3.1 For the current distribution and for the cumulative distributions paid in the current fiscal year to date
    (including the current distribution): the estimated amount per share, and the percentage of the
    distribution, from each of: (i) net investment income; (ii) net realized short-term capital gains;
    (iii) net realized long-term capital gains; (iv) return of capital (paid-in capital).
3.2 Performance information, each computed as of the last day of the month immediately preceding the
    payment date: the average annual total return in relation to NAV for the five-year period; the annualized
    current distribution rate (current distribution × 12 ÷ NAV); the cumulative total return in relation to NAV
    for the fiscal year to date; and the cumulative fiscal-year-to-date distribution rate (cumulative
    distributions per share for the fiscal year to date, including the current distribution ÷ NAV).
    Percentages to two decimals.
3.3 The standard legends ("You should not draw any conclusions…", estimates not for tax reporting, Form
    1099-DIV) and, where Rule 19a-1(b) applies, the statement of any deficit in accumulated realized
    gains/losses plus unrealized appreciation/depreciation after giving effect to the payment.

## 4. Determining sources — book basis
4.1 Sources are determined, or reasonably estimated, from the Fund's accounting records (US GAAP book basis)
    to the close of the period as of which the distribution is paid (Rule 19a-1(e)). For a monthly
    distribution, that period is the **calendar month in which the distribution is paid**. Tax-basis
    character estimates prepared for Form 1099-DIV are **not** used for Section 19(a) purposes.
4.2 **Net investment income available** = undistributed net investment income at the start of the fiscal
    year (book) + fiscal-year-to-date book NII. For the current month, NII is actual through the latest daily
    NAV plus the accrual forecast to month-end.
4.3 **Realized gains available**: fiscal-year-to-date net realized short-term and long-term gains/losses,
    actual through the latest daily NAV. Realized gains are not forecast.
4.4 **Net profits are measured in aggregate.** If either the short-term or the long-term fiscal-year-to-date
    amount is a net loss, that loss reduces the other category's available amount (not below zero), and the
    loss category is shown as zero.
4.5 **Ordering.** Distributions are attributed to available sources in this order: net investment income;
    net realized short-term gains; net realized long-term gains; return of capital.
4.6 **Cumulative and current amounts.**
    (a) Cumulative: attribute the fiscal-year-to-date distributions **including** the current distribution,
        in the 4.5 order, to sources available through the close of the current month.
    (b) Previous cumulative: attribute the fiscal-year-to-date distributions **through the previous
        distribution**, in the same order, to sources available through the close of the previous month
        (final books).
    (c) Current distribution = (a) − (b), source by source.
4.7 **Per share and rounding.** Dollar amounts ÷ shares outstanding on the record date, rounded to four
    decimals. Return of capital is the balancing figure so that the sources sum to the distribution rate
    (current) and to the cumulative distributions per share (cumulative). Percentages of the distribution to
    one decimal.

## 5. Changes to previously reported estimates
5.1 Each month, compare the previous cumulative attribution recomputed under 4.6(b) with the cumulative
    amounts stated in the last notice. If any source differs by more than **$0.0100 per share**, the prior
    estimate is treated as inaccurate in a significant amount (Rule 19a-1(e)): (i) notify the Chief
    Compliance Officer and the Treasurer before the current notice is released; (ii) include a statement in
    the current notice explaining that previously reported estimates have changed; and (iii) flag for the next
    report to shareholders.

## 6. Approval and release
6.1 Oakhurst prepares the notice and the supporting workpaper. The Treasurer approves. Nothing is released to
    the transfer agent, the printer, the newswire or the website until the Treasurer has approved the final
    figures.
6.2 Timetable for a month-end payment: final figures to the Treasurer by the business day before the
    transfer agent's insert deadline; TA insert file by 12:00 ET on the third business day before payment;
    press release no later than the second business day before payment.
