# Corvane Investment Trust — Policy on the Correction of NAV Errors (extract)

Adopted by the Board of Trustees 2024-03-12; amended 2025-12-09 (v3.1). Applies to every series of the Trust.
Owner: Treasurer and Principal Financial Officer. Administrator and transfer agent: Stellmark Fund Services /
Stellmark Shareholder Services.

## 1. Definitions
1.1 **NAV** — net asset value per share of a class, struck and published to the nearest $0.01.
1.2 **Corrected NAV** — the NAV per share recalculated for a Business Day after correcting the error(s). Unless
    the Treasurer directs otherwise, the Corrected NAV is recalculated by restating the affected asset or liability
    only, using the published shares outstanding for that day, and rounded to the nearest $0.01. Second-order
    effects of mispriced shareholder activity on later days' net assets are addressed through Sections 5 and 6,
    not by re-striking later NAVs.
1.3 **Error Period** — each consecutive Business Day on which a published NAV differed from the Corrected NAV
    as a result of the same error.
1.4 **Material Day** — a Business Day on which the difference between the published NAV and the Corrected NAV
    is **both** (a) $0.01 per share or more **and** (b) 0.50% or more of the Corrected NAV. These thresholds
    follow prevailing industry convention; they are not prescribed by statute or SEC rule.

## 2. Testing
2.1 Each Business Day in an Error Period is tested separately. An Error Period may contain Material Days and
    days that are not Material Days.
2.2 **Accrual errors.** Where an income or expense accrual was misstated, the error on a Business Day is the
    cumulative misstatement of the accrual included in that day's NAV. For testing, the misstatement is measured
    gross, before any consequential effect on an expense limitation or fee waiver arrangement.

## 3. Days that are not Material Days
3.1 No shareholder transactions are reprocessed, no shareholder account is adjusted and no reimbursement is
    sought for Fund gains or losses on a day that is not a Material Day. The books are corrected prospectively.
3.2 **Correcting entry.** Where an Error Period contains no Material Day, the full cumulative correction —
    including any consequential adjustment to expense limitation or fee waiver accruals — is recorded in the
    next NAV to be calculated. The correction may not be deferred, amortized or spread over future NAVs, and may
    not be recorded against capital or prior periods.
3.3 **NAV movement from a correcting entry.** If the correcting entry changes the NAV per share by $0.01 or more,
    the Administrator shall obtain the Treasurer's written approval before releasing that NAV, and the item is
    recorded in the NAV error log with an explanation of the day's NAV movement. The approval does not change the
    requirement in 3.2 to book the correction in full.

## 4. Material Days — reprocessing
4.1 All shareholder purchases and redemptions with a trade date on a Material Day are recalculated at the
    Corrected NAV. Share amounts are calculated to three decimal places (round half up); cash to the cent.
4.2 Dollar-amount orders are recalculated by holding the dollar amount constant and recalculating the shares;
    share-amount orders are recalculated by holding the shares constant and recalculating the dollars.

## 5. Shareholder accounts
5.1 A shareholder account that received **less value than it should have** is made whole:
    (a) purchases (and dollar-amount redemptions) — by crediting or reinstating shares, calculated per 4.1;
    (b) share-amount redemptions — by a cash payment of the shortfall.
    The value of a share adjustment is the number of shares multiplied by the Corrected NAV for that trade date.
5.2 A shareholder account that received **more value than it should have** is not charged, debited or asked to
    repay. The resulting loss to the Fund is a Fund Loss under Section 6.
5.3 **De minimis.** Amounts owed to an account under 5.1 are aggregated across all Material Days in the Error
    Period (shares at their respective Corrected NAVs plus cash). If the aggregate for the account is less than
    **$10.00**, no adjustment is made for that account. Amounts by which an account benefited (5.2) are not
    offset against amounts owed to it.
5.4 Omnibus accounts are treated as a single account at the Fund level; allocation to underlying beneficial
    owners is the intermediary's responsibility under its selling/servicing agreement.

## 6. The Fund
6.1 **Fund Loss** means, for each transaction on a Material Day, the value the Fund gave up relative to
    processing at the Corrected NAV (for example, redemption proceeds paid in excess of the corrected proceeds,
    or shares issued in excess of the corrected shares, valued at the Corrected NAV).
6.2 The Fund shall be reimbursed by the Responsible Party for the **sum of all Fund Losses on all Material Days**.
    Fund Losses are **not** reduced by gains the Fund made on other transactions or on other days; any such
    gains are passed to shareholders under 5.1 or, where 5.3 applies, retained by the Fund.
6.3 Reimbursement is due within five Business Days of the Treasurer's approval of the correction calculation.

## 7. Responsible Party
7.1 The Responsible Party is the service provider whose act or omission caused the error, determined under the
    relevant service agreement. Where an agreement excludes the provider's liability for the relevant cause,
    the Adviser shall reimburse the Fund, subject to Board review.
7.2 The Fund does not bear the cost of a NAV error. Any recovery from third parties (e.g. data vendors) is a
    matter between the Responsible Party and that third party and does not delay reimbursement to the Fund.

## 8. Approval and reporting
8.1 The Treasurer approves every correction calculation before shareholder activity is reprocessed.
8.2 Any Material Day must be reported promptly to the Chief Compliance Officer and to the Board at its next
    regular meeting, together with the root cause and remediation.
8.3 Errors that do not produce a Material Day are logged in the NAV error log and reported to the Board quarterly.
