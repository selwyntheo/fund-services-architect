# Fund Administration and Accounting Agreement — Corvane Investment Trust / Stellmark Fund Services, LLC
Dated 2023-07-01, as amended 2025-04-01. Extract provided by Corvane legal (sections 7 and Schedule C only).

## 7. Standard of care; liability
7.1 Stellmark shall perform its duties with the care, skill and diligence of a professional fund administrator
    and in accordance with the Fund's policies and procedures delivered to it, including the Pricing Procedures
    in Schedule C and the Trust's Policy on the Correction of NAV Errors.
7.2 Stellmark shall not be liable for any error in a price or other data supplied by a Pricing Source
    **provided that** Stellmark performed the validation procedures in Schedule C with respect to that price.
7.3 Where a NAV error results from Stellmark's negligence, bad faith, willful misconduct or failure to perform
    the procedures in Schedule C, Stellmark shall reimburse the Fund in accordance with the Trust's Policy on the
    Correction of NAV Errors, and shall bear its own costs of reprocessing.
7.4 Stellmark's liability under 7.3 is not reduced by any right it may have against a Pricing Source.

## Schedule C — Pricing Procedures (daily validation), extract
C.1 Primary source for exchange-listed equities: Primary Pricing Vendor end-of-day file. Secondary source:
    Secondary Pricing Vendor (official closing price of the primary listing exchange).
C.2 **Tolerance check.** Where the primary and secondary prices differ by more than 5.00%, Stellmark shall use
    the official closing price of the security's primary listing exchange, unless the Adviser's pricing
    committee directs otherwise in writing.
C.3 **Unchanged-price check.** An exchange-listed equity whose primary price is unchanged from the prior
    Business Day is an exception **regardless of the tolerance check**. Stellmark shall confirm that the security
    traded on its primary listing exchange; if it traded, Stellmark shall use the official closing price of the
    primary listing exchange. An unchanged-price exception may not be cleared on the basis that the primary and
    secondary prices are within tolerance.
C.4 A vendor's statement that a price "will update" is not evidence of the correct price and may not be used to
    clear an exception.
C.5 Exceptions are cleared by a Stellmark pricing analyst and reviewed by the Stellmark NAV supervisor before
    NAV release.
