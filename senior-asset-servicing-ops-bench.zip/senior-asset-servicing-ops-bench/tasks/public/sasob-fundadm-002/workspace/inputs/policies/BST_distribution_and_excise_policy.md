# Brightwater Series Trust — Distribution and Excise Tax Policy (extract)

Owner: Treasurer of the Trust. Calculations performed by Oakhurst Fund Administration (Fund Tax).
Approved by the Board 2025-12-10. Version 2.4.

## 1. Objective
1.1 Each series distributes enough in each calendar year to avoid the 4% excise tax under IRC §4982, and
    enough for each taxable year to avoid fund-level income tax under IRC §852. This extract covers §4982.

## 2. Required distribution (IRC §4982(b))
2.1 The required distribution for a calendar year is the sum of:
    (a) 98% of **ordinary income** for the calendar year (1 January – 31 December); and
    (b) 98.2% of **capital gain net income** for the one-year period ending **31 October** of the calendar
        year (no series of the Trust has made the §4982(e)(4) election to use its taxable year); plus
    (c) the excess, if any, of the **grossed-up required distribution** for the preceding calendar year
        (the required distribution computed at 100% rather than 98%/98.2%) over the distributed amount for
        the preceding calendar year (§4982(b)(2)).
2.2 **Ordinary income** is investment company taxable income computed without the dividends-paid deduction
    and without taking into account any gain or loss from the sale or exchange of a capital asset
    (§4982(e)(1)). Section 988 foreign currency gains and losses are ordinary income.
2.3 **Specified gains and losses after 31 October** (including §988 foreign currency gains and losses)
    arising in November and December are treated as arising on 1 January of the following calendar year
    (§4982(e)(5)). The Fund's §988 items for November–December are excluded from the current year's
    ordinary income and the prior year's November–December §988 items are included.
2.4 **Capital gain net income** is the excess of gains over losses from sales or exchanges of capital assets
    (short- and long-term combined) realized in the 1 November – 31 October period. The only loss carryover
    taken into account is the **excise-basis** capital loss carryover recorded in the prior year's excise
    workpaper (net capital loss of the prior 1 November – 31 October period). Capital loss carryforwards
    reported for the Fund's taxable (fiscal) year under §1212 are **not** used in the excise computation:
    the losses behind them are already reflected in the realized results of the excise period(s) in which
    they arose.

## 3. Distributed amount (IRC §4982(c))
3.1 Dividends are counted in the calendar year in which they are paid, except that a dividend declared in
    October, November or December, payable to shareholders of record on a date in that month, and actually
    paid in January of the following year is treated as paid on 31 December of the year declared
    (IRC §852(b)(7)).
3.2 Dividends paid after the close of a taxable year under an IRC §855 election count for excise purposes
    in the calendar year in which they are **paid**, regardless of the taxable year to which they relate.
3.3 A dividend declared but not yet paid is included at its estimated amount for planning purposes.
3.4 Any overdistribution for the preceding calendar year (distributed amount in excess of the grossed-up
    required distribution) increases the current year's distributed amount (§4982(c)(2)).

## 4. December planning distribution
4.1 By mid-November Fund Tax prepares the December distribution estimate using: actual tax-basis results
    through 31 October; the desk forecast of net investment income for November and December; the
    distribution register; and the transfer agent's projected record-date shares.
4.2 The **minimum December distribution** equals the required distribution less the distributed amount
    (including dividends declared for the year but not yet paid), floored at zero.
4.3 The per-share rate is the minimum December distribution divided by the projected record-date shares
    (total of all classes), **rounded up** to the next $0.0001.
4.4 Fund Tax may recommend an additional cushion, but must report the minimum separately.
4.5 Distributions are declared by the Board (or by the Treasurer under delegated authority within limits
    approved by the Board). The per-share rate is communicated to the transfer agent and pricing only after
    declaration. Fund Tax does not instruct the transfer agent.
