# Fund Services and Order Processing Agreement — Corvane Investment Trust and Tarrant Hollis Securities LLC
Dated 2022-10-03, as amended 2025-06-30. Extract (Article 4 and Article 9).

## Article 4 — Receipt, time-stamping and transmission of orders
4.1 **Agent for receipt.** The Trust appoints Intermediary as its agent solely for the limited purpose of receiving
    purchase and redemption orders for Shares from Customers. An order received by Intermediary in proper form
    **before** the close of regular trading on the New York Stock Exchange (normally 4:00:00 p.m. Eastern Time;
    earlier on days the NYSE closes early) (the "Close") on a Business Day shall be deemed received by the Trust on
    that Business Day and priced at that day's NAV, **provided** it is transmitted to the Transfer Agent in
    accordance with Section 4.3.
4.2 **Orders at or after the Close.** An order received by Intermediary at or after the Close shall be treated as
    received on the next Business Day and priced at the NAV next computed.
4.3 **Transmission deadline.** Orders deemed received on a Business Day must be transmitted through the NSCC
    Fund/SERV system (or other agreed means) so as to be received by the Transfer Agent no later than 9:00 a.m.
    Eastern Time on the next Business Day. An order received by the Transfer Agent after that time shall be treated
    as received by the Trust when received by the Transfer Agent and priced at the NAV next computed after such
    receipt, notwithstanding any earlier trade date shown on the transmission.
4.4 **Changes after the Close.** An order received before the Close may not be cancelled or modified after the
    Close, except that a Customer may reduce an order to correct a documented error. Any increase in the amount of an
    order made at or after the Close constitutes a new order for the amount of the increase, received at the time of
    the increase.
4.5 **Time-stamping.** Intermediary shall time-stamp each order upon receipt and maintain records sufficient to
    demonstrate the date and time of receipt. Where Intermediary's systems record local branch time, records shall
    identify the time zone. Intermediary shall produce its order-entry records for any order within one Business Day
    of the Trust's or Transfer Agent's request.
4.6 **Rule 22c-2.** Intermediary shall provide Customer identity and transaction information upon request, and shall
    execute instructions to restrict or prohibit further purchases by a Customer identified by the Trust, in
    accordance with the Shareholder Information Agreement dated 2022-10-03.

## Article 9 — Indemnification
9.2 Intermediary shall indemnify and hold harmless the Trust and each Fund for any loss, including any loss arising
    from the correction or reprocessing of transactions, resulting from Intermediary's failure to comply with
    Article 4.
