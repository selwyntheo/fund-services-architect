# Changelog

## 0.2.0 — 2026-09-21
Continuous QA, adapted from Terminal-Bench 4.
- Added `scripts/static_checks.py` (leak and hygiene checks), `scripts/cheat_trials.py` (adversarial fills),
  `scripts/trials.py` (prepare and grade live trials, including a no-inputs leakage ablation) and `scripts/qa_report.py`
  (difficulty calibration and task lifecycle). All of them run in CI.
- Removed first-position enum bias in 6 answer schemas.
- Answer contract: decisions *not* to act must use `no_action`; conditional steps go inside a `hold`.
- sasob-recon-002 → v2: the lending recall is accepted as `escalate` or `submit_instruction` (a grader defect found by
  trajectory triage).
- The report adds a deterministic-controlled metric (G1∧G2∧G5).
- First published results: `results/pilot-2026-09/` (Claude Haiku 4.5, Sonnet 5, Opus 5 and Fable 5.1, plus a
  no-inputs ablation). 23 of 24 tasks are marked `saturated` and go to a hardening round (`docs/qa/hardening-backlog.md`).

## 0.1.0 — 2026-09-18
- 24 public tasks across 6 domains, the six-gate grading design, the `sabench` harness and the static leaderboard.
